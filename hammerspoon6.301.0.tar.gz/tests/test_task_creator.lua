-- =====================================================================
-- test_task_creator.lua — the Asana Task Creator as a module. 6.98.0
-- =====================================================================
--     lua5.4 test_task_creator.lua [/path/to/hammerspoon]
--
-- The creator moved out of init.lua in 6.98.0. This suite boots the
-- REAL module with a Mac-in-tables and proves:
--
--   C1  the 30-day history loads, prunes, and saves on real disk
--   C2  the pipe parser still forgives quotes, ~, and leading junk
--   C3  assignee autocomplete works — and a missing asana_comments
--       roster costs autocomplete, never the picker
--   C4  the one shared submit path validates before it posts
--   C5  🔐 the attachment upload NEVER puts the token in curl's
--       argument list — it travels in a chmod-600 header file that is
--       deleted the moment curl answers, and success is judged by the
--       real HTTP status, not curl's exit code
--   C6  drafts survive, hotkeys land where they always did, and
--       warm() sweeps header files a killed Hammerspoon left behind
--
-- task_form.lua's side of the story is test_taskform.lua (it stubs
-- _G.asanaSubmitTask; here the real one answers).

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail, failures = 0, 0, {}
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else
        fail = fail + 1
        failures[#failures + 1] = label .. (extra and ("  [" .. tostring(extra) .. "]") or "")
        io.write("   ❌ " .. failures[#failures] .. "\n")
    end
end
local function out(s) io.write(s) end

-- ---- a Mac in tables --------------------------------------------------
local TMP = "/tmp/hs-test-task-creator-" .. tostring(os.time())
os.execute('rm -rf "' .. TMP .. '" && mkdir -p "' .. TMP .. '"')

local ALERTS, HTTP_POSTS, HTTP_GETS, TASKS, WARNS = {}, {}, {}, {}, {}
local TIMERS, DEGRADES = {}, {}
local BOUND, HYPER, SERVICE_CALLS = {}, {}, {}
local POPUPS, PASTE, PASTE_SET = 0, nil, nil
local NEXT_JSON = nil
local printed = {}
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    printed[#printed + 1] = table.concat(p, " ")
end
local function alerted(needle)
    for _, a in ipairs(ALERTS) do if a:find(needle, 1, true) then return true end end
end

-- hs.json stand-in: a Lua-literal round trip. Both halves are ours, so
-- what the module writes it can read back — which is all the real
-- hs.json guarantees the module relies on.
local function ser(v)
    local t = type(v)
    if t == "table" then
        local parts = {}
        if #v > 0 then
            for _, x in ipairs(v) do parts[#parts + 1] = ser(x) end
        else
            for k, x in pairs(v) do
                parts[#parts + 1] = "[" .. string.format("%q", tostring(k)) .. "]=" .. ser(x)
            end
        end
        return "{" .. table.concat(parts, ",") .. "}"
    elseif t == "string" then return string.format("%q", v)
    else return tostring(v) end
end

local function newChooserStub(fn)
    local c = { fn = fn, queries = {} }
    function c:placeholderText(p) self.placeholder = p; return self end
    function c:choices(list) self.rows = list; return self end
    function c:query(q)
        if q ~= nil then table.insert(self.queries, q); self.q = q; return self end
        return self.q
    end
    function c:queryChangedCallback(f) self.qcb = f; return self end
    function c:width(w) self.w = w; return self end
    function c:isVisible() return false end
    return c
end

hs = {
    json  = { encode = function(t) return ser(t) end,
              decode = function(s) local f = load("return " .. s); return f and f() end },
    alert = { show = function(msg) table.insert(ALERTS, tostring(msg)) end },
    chooser = { new = newChooserStub },
    hotkey = { bind = function(mods, key, fn)
        BOUND[table.concat(mods, "+") .. "|" .. tostring(key)] = fn; return {} end },
    http = {
        asyncPost = function(url, body, headers, cb)
            -- 6.299.0 — stamp the timers that already exist, so a check
            -- can assert the belt was armed BEFORE the request went
            -- out. A timer created afterwards is never stamped, which
            -- is what makes the ordering provable rather than assumed.
            for _, t in ipairs(TIMERS) do
                if t.armedBefore == nil then t.armedBefore = true end
            end
            table.insert(HTTP_POSTS, { url = url, body = body, headers = headers, cb = cb }) end,
        asyncGet = function(url, headers, cb)
            table.insert(HTTP_GETS, { url = url, headers = headers, cb = cb }) end,
    },
    task = { new = function(path, cb, args)
        local t = { path = path, cb = cb, args = args }
        function t:start() self.started = true; return true end
        table.insert(TASKS, t); return t end },
    pasteboard = { readString = function() return PASTE end,
                   setContents = function(s) PASTE_SET = s ; return true end },
    canvas = { windowLevels = { overlay = 1 }, new = function() return nil end },
    -- 🔬 6.299.0 — a real Mac HAS hs.timer.doAfter, and the submit's
    -- timeout belt is armed with it. A stub without it is a stub on
    -- which the belt can never exist, so every belt check would pass by
    -- never running (6.290.0). TIMERS holds them; a test fires one.
    timer  = { secondsSinceEpoch = function() return os.time() end,
               doAfter = function(secs, fn)
                   local t = { secs = secs, fn = fn, stopped = false }
                   t.stop = function(self) (self or t).stopped = true end
                   TIMERS[#TIMERS + 1] = t
                   return t
               end },
    fs = {
        attributes = function(p)
            if os.execute('test -e "' .. p .. '"') then return { mode = "file" } end
            return nil
        end,
        mkdir = function(p) return os.execute('mkdir -p "' .. p .. '"') end,
        dir = function(p)
            local h = io.popen('ls -1 "' .. p .. '" 2>/dev/null')
            local all = {}
            if h then for l in h:lines() do all[#all + 1] = l end; h:close() end
            local i = 0
            return function() i = i + 1; return all[i] end
        end,
    },
}

_G.choosers = {}
_G.asanaTaskHistory = {}
_G.asanaTeamMembers = {
    { name = "Sarah Chen",  gid = "123456789012345", email = "sc@example.edu" },
    { name = "Lee LeBlanc", gid = "222222222222222", email = "ll@example.edu" },
}

local ASANA_OK = true
local core = {
    logsDir = TMP, hostTag = "TestMac", configDir = TMP,
    homeDir = "/Users/lee",
    adoptLegacyFile = function() end,
    warnWriteFailed = function(what) table.insert(WARNS, what) end,
    showPopup = function() POPUPS = POPUPS + 1 end,
    resolveBaseScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1000, h = 800 } end } end,
    chooserTopLeft = function() return { x = 0, y = 100 } end,
    panelAlpha = 0.9,
    requireAsana = function()
        if ASANA_OK then return true end
        table.insert(ALERTS, "🔒 Asana is off on this Mac"); return false
    end,
    -- 🔔 6.301.0 — the real core HAS a degrade door (6.215.0), and a
    -- stub without one makes every module under test take its no-door
    -- fallback, so the door is never exercised. 6.278.0 paid for that
    -- once already; 6.290.0's rule is the same sentence about macOS.
    degrade = function(tool, why)
        DEGRADES[#DEGRADES + 1] = { tool = tostring(tool), why = tostring(why) }
        return false, why
    end,
    asanaToken = "SECRET-TOKEN-abc123",
    asanaProjectId = "PROJ1",
    safeJson = function() return NEXT_JSON end,
    call = function(name, ...) table.insert(SERVICE_CALLS, { name = name, ... }) end,
    hyperAddShortcut = function(mods, key, fn)
        HYPER[table.concat(mods or {}, "+") .. "|" .. tostring(key)] = fn end,
}

-- =====================================================================
out("\n=== C1. History: load → prune 30 days → save, on real disk ===\n")

local histFile = TMP .. "/asana_history-TestMac.json"
local fresh = { title = "keep me",  timestamp = os.time() - 1000 }
local stale = { title = "forget me", timestamp = os.time() - 40 * 86400 }
local f = assert(io.open(histFile, "w"))
f:write(ser({ stale, fresh })); f:close()

local chunk = assert(loadfile(HS .. "/modules/task_creator.lua"))
local M = chunk()
check("the module keeps the contract (table with setup)",
      type(M) == "table" and type(M.setup) == "function")
check("it ships a profile-overridable config with the auto-comment knob",
      type(M.config) == "table" and type(M.config.autoComment) == "string")
check("init.lua's BASE list loads it on every Mac", (function()
    local fh = io.open(HS .. "/init.lua", "r"); if not fh then return false end
    local src = fh:read("*a"); fh:close()
    local base = src:match("local BASE = {(.-)\n}") or ""
    return base:find('"task_creator"', 1, true) ~= nil
end)())

local okSetup, setupErr = pcall(M.setup, core)
check("setup() runs clean", okSetup, setupErr)
check("the 40-day-old entry was pruned, the fresh one kept",
      #_G.asanaTaskHistory == 1 and _G.asanaTaskHistory[1].title == "keep me",
      #_G.asanaTaskHistory)
check("...and the pruned version went straight back to disk", (function()
    local fh = io.open(histFile, "r"); if not fh then return false end
    local on = hs.json.decode(fh:read("*a")); fh:close()
    return #on == 1 and on[1].title == "keep me"
end)())

out("\n=== C2. The pipe parser forgives what pasting does to paths ===\n")

local chooser = _G.choosers.task
check("the pipe chooser exists and is armored",
      chooser ~= nil and type(chooser.qcb) == "function")

local function actionRow(query)
    chooser.qcb(query)
    for _, row in ipairs(chooser.rows or {}) do
        if row.isAction then return row end
    end
end

local row = actionRow("Fix the printer | It is angry | | '~/shot.png'")
check("quotes are stripped and ~ becomes the home folder",
      row and row.rawAttach == "/Users/lee/shot.png", row and row.rawAttach)
row = actionRow("time|||/path/file.png")
check("no-space pipes still land the path in field 4",
      row and row.rawAttach == "/path/file.png", row and row.rawAttach)
row = actionRow("title | | | r /Users/lee/a.png")
check("leading junk before the first / is dropped",
      row and row.rawAttach == "/Users/lee/a.png", row and row.rawAttach)

out("\n=== C3. Assignee autocomplete — and life without the roster ===\n")

chooser.qcb("Task | | sa")
local suggestion
for _, r in ipairs(chooser.rows) do
    if r.isAssigneeSuggestion then suggestion = r break end
end
check("two pipes + a partial name suggests from the roster",
      suggestion and suggestion.memberName == "Sarah Chen",
      suggestion and suggestion.memberName)

chooser.qcb("Task | | zz")
local noMatch
for _, r in ipairs(chooser.rows) do
    if (r.text or ""):find("No team member matches", 1, true) then noMatch = r end
end
check("zero matches says so on a safe no-op row",
      noMatch ~= nil and noMatch.isHistory == true)

_G.asanaTeamMembers = nil
printed = {}
chooser.qcb("Task | | sa")
check("no roster (asana_comments off) costs autocomplete, NOT the picker",
      (function()
          for _, l in ipairs(printed) do
              if l:find("render error", 1, true) then return false end
          end
          for _, r in ipairs(chooser.rows) do
              if r.isAction then return true end
          end
      end)())
_G.asanaTeamMembers = {
    { name = "Sarah Chen",  gid = "123456789012345", email = "sc@example.edu" },
    { name = "Lee LeBlanc", gid = "222222222222222", email = "ll@example.edu" },
}

out("\n=== C4. One submit path, validating before it posts ===\n")

ALERTS, HTTP_POSTS = {}, {}
check("an empty title is refused with an alert, nothing posted",
      _G.asanaSubmitTask("", "", "", "") == false
      and alerted("title cannot be empty") and #HTTP_POSTS == 0)

ALERTS, HTTP_POSTS = {}, {}
check("a short digit string is NOT trusted as a GID (6.16.14 rule)",
      _G.asanaSubmitTask("T", "", "1", "") == false
      and alerted("No team member matches") and #HTTP_POSTS == 0)

ALERTS, HTTP_POSTS = {}, {}
check("a typed name resolves to the roster GID before the API sees it",
      _G.asanaSubmitTask("Named", "", "sarah chen", "") == true
      and #HTTP_POSTS == 1
      and HTTP_POSTS[1].body:find("123456789012345", 1, true) ~= nil)

HTTP_POSTS = {}
_G.asanaSubmitTask("Do thing", "the details", "me", "")
local post = HTTP_POSTS[1]
check("the post goes to the tasks endpoint",
      post and post.url == "https://app.asana.com/api/1.0/tasks")
check("the token travels in a header, never the body",
      post and post.headers["Authorization"] == "Bearer SECRET-TOKEN-abc123"
      and post.body:find("SECRET%-TOKEN") == nil)
check("the task is filed into the configured project",
      post and post.body:find("PROJ1", 1, true) ~= nil)
local entry = _G.asanaTaskHistory[#_G.asanaTaskHistory]
check("the history row shows ⏳ while the answer is out",
      entry and entry.displaySub:find("⏳", 1, true) == 1, entry and entry.displaySub)

ALERTS, SERVICE_CALLS, NEXT_JSON = {}, {}, { data = { gid = "999" } }
post.cb(201, "{}")
check("a 201 alerts success and stamps the history row ✅",
      alerted("✅ Task Created") and entry.displaySub:find("✅", 1, true) == 1)
check("...and the auto-comment goes through the asana_comments service",
      SERVICE_CALLS[1] and SERVICE_CALLS[1].name == "asana.addComment"
      and SERVICE_CALLS[1][1] == "999"
      and SERVICE_CALLS[1][2] == M.config.autoComment)
check("...and the outcome is persisted to disk", (function()
    local fh = io.open(histFile, "r"); if not fh then return false end
    local on = hs.json.decode(fh:read("*a")); fh:close()
    return on[#on] and on[#on].title == "Do thing"
end)())

HTTP_POSTS, SERVICE_CALLS = {}, {}
M.config.autoComment = ""
_G.asanaSubmitTask("Quiet one", "", "", "")
NEXT_JSON = { data = { gid = "1000" } }
HTTP_POSTS[1].cb(201, "{}")
check("autoComment = \"\" disables the comment (a profile can set this)",
      #SERVICE_CALLS == 0)
M.config.autoComment = "Sent by Hammerspoon Task Creator \"⌃⌥⌘T\", file init.lua"

ALERTS, HTTP_POSTS = {}, {}
_G.asanaSubmitTask("Doomed", "", "", "")
HTTP_POSTS[1].cb(500, "boom")
local doomed = _G.asanaTaskHistory[#_G.asanaTaskHistory]
check("an HTTP failure alerts and the history row says ❌, kept not dropped",
      alerted("❌ Error: 500") and doomed.displaySub:find("❌", 1, true) == 1)

out("\n=== C4b. 6.152.0 — the schedule and the project's custom fields ===\n")
-- The cache as warm()'s fetch would fill it: LL's real fields, in shape.
_G.asanaCustomFields = {
    { gid = "F_PRIO", name = "Task Priority", subtype = "enum",
      options = { { gid = "OPT_HI", name = "High" },
                  { gid = "OPT_LO", name = "Low" } } },
    { gid = "F_VALS", name = "SAC Values", subtype = "multi_enum",
      options = { { gid = "V1", name = "Students First" },
                  { gid = "V2", name = "Respect" } } },
    { gid = "F_SUP",  name = "Supervisor", subtype = "people", options = {} },
    { gid = "F_NUM",  name = "Progress",   subtype = "number", options = {} },
}

ALERTS, HTTP_POSTS = {}, {}
check("a start date without an end date is refused BEFORE the request "
      .. "(Asana's rule, alerted instead of a Console 400)",
      _G.asanaSubmitTask("S", "", "", "", { startDate = "2026-09-08" }) == false
      and alerted("END date") and #HTTP_POSTS == 0)
ALERTS, HTTP_POSTS = {}, {}
check("a time without its date is refused too",
      _G.asanaSubmitTask("S", "", "", "", { dueTime = "14:00" }) == false
      and alerted("A time needs its date") and #HTTP_POSTS == 0)
ALERTS, HTTP_POSTS = {}, {}
check("both dates but only one time: refused — _at cannot mix with _on",
      _G.asanaSubmitTask("S", "", "", "", { startDate = "2026-09-08",
          dueDate = "2026-09-10", dueTime = "14:00" }) == false
      and alerted("BOTH times or neither"))

HTTP_POSTS = {}
_G.asanaSubmitTask("Dated", "", "", "", { dueDate = "2026-09-10" })
check("an end date alone goes out as due_on",
      HTTP_POSTS[1].body:find("due_on", 1, true) ~= nil
      and HTTP_POSTS[1].body:find("2026-09-10", 1, true) ~= nil)

HTTP_POSTS = {}
_G.asanaSubmitTask("Timed", "", "", "",
                   { dueDate = "2026-09-10", dueTime = "14:30" })
check("an end date + time goes out as due_at — ISO 8601 with the LOCAL "
      .. "offset spelled ±hh:mm",
      HTTP_POSTS[1].body:find("due_at", 1, true) ~= nil
      and HTTP_POSTS[1].body:match("2026%-09%-10T14:30:00[%+%-]%d%d:%d%d") ~= nil,
      HTTP_POSTS[1].body)

HTTP_POSTS = {}
_G.asanaSubmitTask("Span", "", "", "",
                   { startDate = "2026-09-08", dueDate = "2026-09-10" })
check("start + end without times: start_on + due_on",
      HTTP_POSTS[1].body:find("start_on", 1, true) ~= nil
      and HTTP_POSTS[1].body:find("due_on", 1, true) ~= nil)

HTTP_POSTS = {}
_G.asanaSubmitTask("Meta", "", "", "", { custom = {
    F_PRIO = "OPT_HI", F_VALS = { "V1", "V2" }, F_SUP = "sarah chen",
    F_NUM = "60", F_GONE = "" } })
local mb = HTTP_POSTS[1].body
check("custom_fields rides on the payload", mb:find("custom_fields", 1, true) ~= nil)
check("an enum pick travels as its option gid", mb:find("OPT_HI", 1, true) ~= nil)
check("a multi-select travels as an ARRAY of option gids",
      mb:find('{"V1","V2"}', 1, true) ~= nil or mb:find('{"V2","V1"}', 1, true) ~= nil, mb)
check("a people field resolves the typed NAME through the same roster as "
      .. "Assignee", mb:find("123456789012345", 1, true) ~= nil)
check("a number field goes out as a number, not a string",
      mb:find("]=60", 1, true) ~= nil, mb)
check("an empty value is DROPPED, never sent as an empty string",
      mb:find("F_GONE", 1, true) == nil)

ALERTS, HTTP_POSTS = {}, {}
check("an unresolvable people name is refused before posting",
      _G.asanaSubmitTask("M2", "", "", "",
          { custom = { F_SUP = "zorp" } }) == false
      and alerted("No team member matches") and #HTTP_POSTS == 0)

HTTP_POSTS = {}
_G.asanaSubmitTask("Legacy", "", "", "")
check("the four-string legacy call still posts, untouched — the pipe "
      .. "chooser knows nothing of `extra` and must not have to",
      #HTTP_POSTS == 1 and HTTP_POSTS[1].body:find("due_on", 1, true) == nil
      and HTTP_POSTS[1].body:find("custom_fields", 1, true) == nil)

out("\n=== C4c. the field cache is FETCHED from the project, never typed ===\n")
HTTP_GETS = {}
M.fetchCustomFields()
local cfGet = HTTP_GETS[#HTTP_GETS]
check("the fetch asks the project's custom_field_settings, options included",
      cfGet and cfGet.url:find("/projects/PROJ1/custom_field_settings", 1, true) ~= nil
      and cfGet.url:find("enum_options", 1, true) ~= nil, cfGet and cfGet.url)
check("...with the token in a header", cfGet
      and cfGet.headers["Authorization"] == "Bearer SECRET-TOKEN-abc123")
NEXT_JSON = { data = {
    { custom_field = { gid = "CF1", name = "Task Priority",
        resource_subtype = "enum",
        enum_options = { { gid = "O1", name = "High", enabled = true },
                         { gid = "O2", name = "Retired", enabled = false } } } },
    { custom_field = { gid = "CF2", name = "Supervisor",
        resource_subtype = "people" } },
} }
cfGet.cb(200, "{}")
check("the cache keeps each field's subtype and its ENABLED options only",
      _G.asanaCustomFields[1] and _G.asanaCustomFields[1].gid == "CF1"
      and #_G.asanaCustomFields[1].options == 1
      and _G.asanaCustomFields[1].options[1].gid == "O1"
      and _G.asanaCustomFields[2]
      and _G.asanaCustomFields[2].subtype == "people",
      _G.asanaCustomFields[1] and #_G.asanaCustomFields[1].options)
local cachedBefore = _G.asanaCustomFields
cfGet.cb(401, "denied")
check("a failed refetch keeps the cache it had and says so in the Console",
      _G.asanaCustomFields == cachedBefore)
_G.asanaCustomFields = {}

out("\n=== C5. 🔐 The attachment upload keeps the token out of argv ===\n")

local attFile = TMP .. "/receipt.png"
f = assert(io.open(attFile, "w")); f:write("png-bytes"); f:close()

ALERTS, HTTP_POSTS, TASKS = {}, {}, {}
_G.asanaSubmitTask("With file", "", "", attFile)
NEXT_JSON = { data = { gid = "777" } }
HTTP_POSTS[1].cb(201, "{}")
local curl = TASKS[#TASKS]
check("a 201 with an attachment starts curl", curl and curl.started == true)
check("🚨 NO curl argument contains the token", (function()
    if not curl then return false end
    for _, a in ipairs(curl.args) do
        if tostring(a):find("SECRET", 1, true) then return false, a end
    end
    return true
end)())
local hdrPath
for i, a in ipairs(curl and curl.args or {}) do
    if a == "-H" then hdrPath = tostring(curl.args[i + 1]):match("^@(.+)$") end
end
check("the header arrives as -H @file instead", hdrPath ~= nil)
check("...and that file carries exactly the auth header", (function()
    local fh = hdrPath and io.open(hdrPath, "r"); if not fh then return false end
    local c = fh:read("*a"); fh:close()
    return c == "Authorization: Bearer SECRET-TOKEN-abc123\n"
end)())
check("...under ~/.hammerspoon/.tmp — local disk, never a synced folder",
      hdrPath ~= nil and hdrPath:find(TMP .. "/.tmp/hdr-", 1, true) == 1, hdrPath)
check("the upload is bounded (--max-time travels with it)", (function()
    for _, a in ipairs(curl and curl.args or {}) do
        if a == "--max-time" then return true end
    end
end)())

ALERTS = {}
curl.cb(0, "201", "")
check("a real 201 reports 📎 uploaded and stamps the history row",
      alerted("📎 Attachment uploaded")
      and _G.asanaTaskHistory[#_G.asanaTaskHistory].displaySub:find("📎 attached", 1, true) ~= nil)
check("...and the header file is already gone",
      io.open(hdrPath, "r") == nil)

HTTP_POSTS, TASKS = {}, {}
_G.asanaSubmitTask("Refused file", "", "", attFile)
NEXT_JSON = { data = { gid = "778" } }
HTTP_POSTS[1].cb(201, "{}")
curl = TASKS[#TASKS]
local hdr2
for i, a in ipairs(curl.args) do
    if a == "-H" then hdr2 = tostring(curl.args[i + 1]):match("^@(.+)$") end
end
ALERTS = {}
curl.cb(0, "401", "")
check("curl exit 0 with HTTP 401 is a FAILURE now, not a success",
      alerted("❌ Attachment upload failed")
      and _G.asanaTaskHistory[#_G.asanaTaskHistory].displaySub:find("⚠️ attach failed", 1, true) ~= nil)
check("...and the header file is gone on failure too",
      io.open(hdr2, "r") == nil)

ALERTS, HTTP_POSTS, TASKS = {}, {}, {}
_G.asanaSubmitTask("Ghost file", "", "", TMP .. "/nope.png")
NEXT_JSON = { data = { gid = "779" } }
HTTP_POSTS[1].cb(201, "{}")
check("a vanished attachment is one clear alert, no curl",
      alerted("⚠️ Attachment not found") and #TASKS == 0)

out("\n=== C6. Drafts, hotkeys, and the warm() sweep ===\n")

chooser.qcb("half-typed idea | still thinking")
check("every keystroke lands in _G.taskDraft",
      _G.taskDraft == "half-typed idea | still thinking")
ALERTS, POPUPS = {}, 0
_G.asanaOpenTaskChooser()
check("reopening restores the draft and says so",
      POPUPS == 1 and alerted("Draft restored")
      and chooser.queries[#chooser.queries] == "half-typed idea | still thinking")

_G.taskDraft = "A | B | sa | "
chooser.fn({ isAssigneeSuggestion = true, memberName = "Sarah Chen" })
check("picking a suggestion splices the name — it never submits",
      _G.taskDraft == "A | B | Sarah Chen | ", _G.taskDraft)

HTTP_POSTS = {}
chooser.fn({ isAction = true, rawTitle = "", rawDesc = "", rawAssignee = "", rawAttach = "" })
check("Enter on Create with an empty title keeps the draft",
      _G.taskDraft == "A | B | Sarah Chen | " and #HTTP_POSTS == 0)
chooser.fn({ isAction = true, rawTitle = "Ship it", rawDesc = "", rawAssignee = "", rawAttach = "" })
check("a successful submit clears the draft",
      _G.taskDraft == "" and #HTTP_POSTS == 1)

check("⌃⌥⌘T and ⌃⌥⌘A are bound (the §0.4 map turns them into ⇪T · ⇪A)",
      BOUND["ctrl+alt+cmd|T"] ~= nil and BOUND["cmd+ctrl+alt|A"] ~= nil)
check("🚨 NO ⇪⇧S here since 6.161.0 — it is the snippets panel's, and a claim "
      .. "from this module (loaded later) would win and hide the snippets",
      HYPER["shift|s"] == nil and next(HYPER) == nil)
check("the pipe picker is still openable by name (⇪T's fallback, the Console)",
      type(_G.asanaOpenTaskChooser) == "function")

ASANA_OK = false
ALERTS, POPUPS = {}, 0
BOUND["ctrl+alt+cmd|T"]()
check("no secret.lua: ⌃⌥⌘T explains instead of opening anything",
      POPUPS == 0 and #ALERTS == 1)
ASANA_OK = true

local FORM_CALLS = 0
_G.taskFormShow = function() FORM_CALLS = FORM_CALLS + 1 end
POPUPS = 0
BOUND["ctrl+alt+cmd|T"]()
check("⌃⌥⌘T prefers the labeled form when task_form loaded",
      FORM_CALLS == 1 and POPUPS == 0)
_G.taskFormShow = nil
BOUND["ctrl+alt+cmd|T"]()
check("...and falls back to the pipe chooser when it did not",
      POPUPS == 1)

PASTE = "https://app.asana.com/0/1200/1201234567890123"
HTTP_GETS, ALERTS, PASTE_SET = {}, {}, nil
BOUND["cmd+ctrl+alt|A"]()
check("⌃⌥⌘A asks the API about the task in the clipboard, token in a header",
      HTTP_GETS[1]
      and HTTP_GETS[1].headers["Authorization"] == "Bearer SECRET-TOKEN-abc123")
NEXT_JSON = { data = { name = "My Task" } }
HTTP_GETS[1].cb(200, "{}")
check("...and writes back 'Name | url'",
      PASTE_SET == "My Task | " .. PASTE and alerted("✅ Formatted"))
PASTE = "not an asana link"
ALERTS = {}
BOUND["cmd+ctrl+alt|A"]()
check("a non-Asana clipboard is one clear alert",
      alerted("does not contain an Asana URL"))

os.execute('mkdir -p "' .. TMP .. '/.tmp"')
f = assert(io.open(TMP .. "/.tmp/hdr-1-0001.txt", "w"))
f:write("Authorization: Bearer LEFTOVER\n"); f:close()
printed = {}
M.warm(core)
check("warm() sweeps header files a killed Hammerspoon left behind",
      io.open(TMP .. "/.tmp/hdr-1-0001.txt", "r") == nil)
check("...and says how many it cleared",
      printed[1] and printed[1]:find("leftover auth%-header"))

out("\n=== C4d. 🔔 6.299.0 — Asana's own answer reaches the caller ===\n")
-- 🚨 WHAT THIS FUNCTION RETURNS HAS NEVER MEANT "IT WENT": `true` is
-- handed back the instant the POST is fired. Every caller read it as
-- "sent" — which is how Hamsidian came to print "✅ → Asana" over a
-- task Asana refused with a 400, defeating 6.278.0 entirely.
do
    local SEEN
    local function catcher() SEEN = {} ; return function(ok, why, gid)
        SEEN[#SEEN + 1] = { ok = ok, why = why, gid = gid } end end

    -- 1. a refusal BEFORE the request leaves
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    local cb = catcher()
    local r = _G.asanaSubmitTask("", "", "", "", { onDone = cb })
    check("a validation refusal answers onDone once, with the cause",
          r == false and #SEEN == 1 and SEEN[1].ok == false
          and tostring(SEEN[1].why):find("title", 1, true) ~= nil,
          #SEEN .. " / " .. tostring(SEEN[1] and SEEN[1].why))
    check("...and arms no belt, because there is nothing to wait for",
          #TIMERS == 0, #TIMERS)

    -- 2. 🚨 THE ONE THAT WAS INVISIBLE: accepted for posting, then
    --    REFUSED by Asana. The return says true and always did.
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    cb = catcher()
    local posted = _G.asanaSubmitTask("Refused one", "", "", "", { onDone = cb })
    check("🚨 the RETURN is true the moment the POST is fired — it has "
          .. "never meant Asana said yes", posted == true and #SEEN == 0)
    HTTP_POSTS[1].cb(400, '{"errors":[{"message":"bad"}]}')
    check("...and Asana's refusal reaches the caller, with its own words",
          #SEEN == 1 and SEEN[1].ok == false
          and tostring(SEEN[1].why):find("400", 1, true) ~= nil
          and tostring(SEEN[1].why):find("bad", 1, true) ~= nil,
          tostring(SEEN[1] and SEEN[1].why))

    -- 3. a success hands back the TASK GID — the half a subtask needs
    ALERTS, HTTP_POSTS, TIMERS, NEXT_JSON = {}, {}, {}, { data = { gid = "7777" } }
    cb = catcher()
    _G.asanaSubmitTask("Good one", "", "", "", { onDone = cb })
    HTTP_POSTS[1].cb(201, "{}")
    check("🪪 a success answers with Asana's task gid — a subtask needs "
          .. "its parent's, and it does not exist until the create returns",
          #SEEN == 1 and SEEN[1].ok == true and SEEN[1].gid == "7777",
          tostring(SEEN[1] and SEEN[1].gid))

    -- 4. EXACTLY ONCE, whatever arrives afterwards
    HTTP_POSTS[1].cb(500, "late")
    check("🔑 exactly once — a second callback for the same submit is "
          .. "ignored, or one send would be counted twice", #SEEN == 1, #SEEN)

    -- 5. the belt: armed BEFORE the post (6.246.0), stopped by the answer
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    cb = catcher()
    _G.asanaSubmitTask("Belted", "", "", "", { onDone = cb })
    check("🛟 a belt is armed for a caller that asked for the answer",
          #TIMERS == 1 and TIMERS[1].secs == M.config.answerSecs,
          #TIMERS .. " timer(s)")
    check("...and it was armed BEFORE the request went out, not after — "
          .. "the order is the guarantee, not that both happened "
          .. "(6.220.0)", TIMERS[1].armedBefore == true,
          "armedBefore=" .. tostring(TIMERS[1] and TIMERS[1].armedBefore))
    NEXT_JSON = { data = { gid = "8" } }
    HTTP_POSTS[1].cb(201, "{}")
    check("...and Asana answering STOPS it, so the timeout cannot fire "
          .. "over a task that already landed", TIMERS[1].stopped == true)
    TIMERS[1].fn()
    check("...and firing it anyway changes nothing — still exactly once",
          #SEEN == 1, #SEEN)

    -- 6. Asana never answers at all
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    cb = catcher()
    _G.asanaSubmitTask("Silent", "", "", "", { onDone = cb })
    TIMERS[1].fn()
    check("🛟 a silent Asana is REPORTED rather than left waiting for ever",
          #SEEN == 1 and SEEN[1].ok == false
          and tostring(SEEN[1].why):find("did not answer", 1, true) ~= nil,
          tostring(SEEN[1] and SEEN[1].why))
    HTTP_POSTS[1].cb(201, "{}")
    check("...and a late answer after the timeout does not answer twice",
          #SEEN == 1, #SEEN)

    -- 7. a caller whose callback THROWS must not take the submit down
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    local okThrow = pcall(_G.asanaSubmitTask, "Thrower", "", "", "",
                          { onDone = function() error("boom", 0) end })
    check("🔒 a caller's onDone that throws is caught — a raise inside an "
          .. "hs.http callback is a silence (6.235.0)", okThrow == true)
    local okThrow2 = pcall(function() HTTP_POSTS[1].cb(201, "{}") end)
    check("...on the answer path too", okThrow2 == true)

    -- 8. a caller that asks for nothing is completely unchanged
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    local plain = _G.asanaSubmitTask("Plain", "", "", "")
    check("a caller that passes no onDone arms no belt and still posts",
          plain == true and #HTTP_POSTS == 1 and #TIMERS == 0)

    -- 9. no hs.timer.doAfter: it POSTS anyway and SAYS it had no belt.
    --    Driving a path with the dependency MISSING is the check 6.265.0
    --    was lost for not having.
    ALERTS, HTTP_POSTS, TIMERS = {}, {}, {}
    local savedDo = hs.timer.doAfter
    hs.timer.doAfter = nil
    cb = catcher()
    local noBelt = _G.asanaSubmitTask("Beltless", "", "", "", { onDone = cb })
    hs.timer.doAfter = savedDo
    check("a Mac that cannot arm a timer still POSTS — no belt is worse "
          .. "than no send, but only just", noBelt == true and #HTTP_POSTS == 1)
    HTTP_POSTS[1].cb(201, "{}")
    check("...and the answer still reaches the caller", #SEEN == 1 and SEEN[1].ok)
    -- 🔎 AND IT IS COUNTED APART, because a submit with no belt is one
    -- whose silence is unrecoverable — that is a different Mac, not a
    -- different task, and the report must not hide it (6.196.1).
    do
        local pr, sv = {}, print
        print = function(x) pr[#pr + 1] = tostring(x) end
        _G.asanaSubmitReport()
        print = sv
        check("...and the report SAYS this Mac sent one with no belt",
              table.concat(pr, "\n"):find("NO timeout belt", 1, true) ~= nil,
              table.concat(pr, "\n"))
    end

    -- 10. the report tells the three outcomes apart (6.196.1)
    local printedR = {}
    local savedPrint = print
    print = function(x) printedR[#printedR + 1] = tostring(x) end
    _G.asanaSubmitReport()
    print = savedPrint
    local rep = table.concat(printedR, "\n")
    check("🔎 the report counts accepted, refused and never-answered apart",
          rep:find("accepted by Asana", 1, true) ~= nil
          and rep:find("refused or never sent", 1, true) ~= nil
          and rep:find("never answered", 1, true) ~= nil, rep)
    check("...and says plainly that the return has only ever meant "
          .. "\"accepted for posting\"",
          rep:find("accepted for posting", 1, true) ~= nil)
end

out("\n=== C4e. 🗂 6.301.0 — subtasks, through the parent's own gid ===\n")
-- An Asana subtask is an ordinary task carrying `parent = <gid>`, and
-- that gid does not exist until the parent's create has come back. LL
-- asked whether the id in his project URL was the parent id: it is not
-- — that is the PROJECT gid, which every task here already goes to.
do
    local SEEN
    local function catcher() SEEN = {} ; return function(ok, why, gid, info)
        SEEN[#SEEN + 1] = { ok = ok, why = why, gid = gid, info = info } end end

    ALERTS, HTTP_POSTS, TIMERS, DEGRADES = {}, {}, {}, {}
    NEXT_JSON = { data = { gid = "5150" } }
    local cb = catcher()
    _G.asanaSubmitTask("Parent one", "", "", "", {
        subtasks = { "first step", "second step", "   " }, onDone = cb })
    check("the parent goes out alone first — a subtask has no parent yet",
          #HTTP_POSTS == 1, #HTTP_POSTS)
    HTTP_POSTS[1].cb(201, "{}")
    check("🗂 ...and the subtasks follow once the gid comes back",
          #HTTP_POSTS == 3, #HTTP_POSTS .. " post(s)")
    check("...an empty S: line is not a subtask", #HTTP_POSTS == 3)
    -- (this suite's hs.json.encode is a stub that renders a Lua table,
    -- so the two tokens are asserted rather than the JSON spelling)
    local function carriesParent(b)
        return b:find("parent", 1, true) ~= nil and b:find("5150", 1, true) ~= nil
    end
    check("🪪 each carries the PARENT's gid",
          carriesParent(HTTP_POSTS[2].body)
          and carriesParent(HTTP_POSTS[3].body), HTTP_POSTS[2].body)
    check("🚨 ...and NOT the project — Asana files a subtask under its "
          .. "parent, and a project as well puts the same line twice on "
          .. "his board", HTTP_POSTS[2].body:find("PROJ1", 1, true) == nil,
          HTTP_POSTS[2].body)
    check("⏳ the caller has not been answered yet — the task is not done "
          .. "until its subtasks are", #SEEN == 0, #SEEN)
    check("🛟 ...and the belt was re-armed for the second leg, or a slow "
          .. "subtask would leave the caller waiting exactly as long as "
          .. "6.299.0's belt exists to prevent", #TIMERS == 2, #TIMERS)
    HTTP_POSTS[2].cb(201, "{}")
    check("...still nothing after only one of the two", #SEEN == 0)
    HTTP_POSTS[3].cb(201, "{}")
    check("🗂 the caller is answered when the LAST subtask lands, and told "
          .. "how many went", #SEEN == 1 and SEEN[1].ok == true
          and SEEN[1].gid == "5150" and SEEN[1].info.subs == 2
          and SEEN[1].info.subFail == 0,
          SEEN[1] and tostring(SEEN[1].info and SEEN[1].info.subs))

    -- 🚨 A REFUSED SUBTASK DOES NOT FAIL ITS PARENT. The parent EXISTS;
    -- a caller that marked this failed would retry and put a SECOND
    -- copy on his board. Duplicating it is worse than a missing line
    -- he is told about at the moment it goes missing.
    ALERTS, HTTP_POSTS, TIMERS, DEGRADES = {}, {}, {}, {}
    cb = catcher()
    _G.asanaSubmitTask("Parent two", "", "", "", {
        subtasks = { "will fail" }, onDone = cb })
    HTTP_POSTS[1].cb(201, "{}")
    HTTP_POSTS[2].cb(400, '{"errors":[{"message":"nope"}]}')
    check("🚨 a refused SUBTASK still answers ok — the parent is in Asana "
          .. "and a retry would duplicate it",
          #SEEN == 1 and SEEN[1].ok == true and SEEN[1].info.subFail == 1,
          SEEN[1] and tostring(SEEN[1].ok))
    check("🔔 ...and it takes the degrade door at the moment it happens, "
          .. "because nothing downstream will ever retry it",
          #DEGRADES == 1 and DEGRADES[1].tool:find("subtask", 1, true) ~= nil
          and DEGRADES[1].why:find("Parent two", 1, true) ~= nil,
          #DEGRADES .. " degrade(s)")

    -- no subtasks at all: unchanged, and no second belt
    ALERTS, HTTP_POSTS, TIMERS, DEGRADES = {}, {}, {}, {}
    cb = catcher()
    _G.asanaSubmitTask("Lonely", "", "", "", { onDone = cb })
    HTTP_POSTS[1].cb(201, "{}")
    check("a task with no subtasks answers at once and arms no second belt",
          #SEEN == 1 and SEEN[1].ok == true and SEEN[1].info == nil
          and #TIMERS == 1, #TIMERS)

    -- the report names them, and names the caveat
    do
        local pr, sv = {}, print
        print = function(x) pr[#pr + 1] = tostring(x) end
        _G.asanaSubmitReport()
        print = sv
        local rep = table.concat(pr, "\n")
        check("🔎 the report counts subtasks apart, and says why a refused "
              .. "one is not retried", rep:find("subtasks:", 1, true) ~= nil
              and rep:find("second copy", 1, true) ~= nil, rep)
    end
end

os.execute('rm -rf "' .. TMP .. '"')
out(("\n── test_task_creator: %d passed, %d failed\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
