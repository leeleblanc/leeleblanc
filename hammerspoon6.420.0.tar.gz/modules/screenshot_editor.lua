-- =====================================================================
-- MODULE: SCREENSHOT EDITOR — blur boxes, text boxes, arrows
-- =====================================================================
-- Opens a screenshot in a window with THREE TOOLS (buttons, or B/T/A):
--
--   ▦ BLUR   drag a rectangle — it is blurred in place, destructively,
--            for names/emails/tokens that must not travel.
--   🅣 TEXT   click, type, ⏎ — a label in white text with a white
--            outline box (6.88.0, LL's spec). Drag it to move it. To
--            EDIT the words: click it with the Text tool (6.207.0 —
--            a click, not a drag), double-click it with any tool, or
--            select it and press ⏎.
--   ➤ ARROW  drag one out. Drag either END to stretch AND rotate it —
--            the head follows the second endpoint; drag the shaft to
--            move the whole arrow.
--
-- Text and arrows stay LIVE OBJECTS until you save — movable, editable,
-- deletable (⌫ removes the selected one) — and only get painted into
-- the pixels at save time. ⌘Z undoes anything: blurs, adds, moves,
-- edits, deletes, newest first. ⌘⏎ (or the button) saves the result
-- AND puts it on the clipboard; ⌘⇧⏎ saves a SMALL JPEG instead (same
-- sips-style shrink the panel's ⌃⏎ does, done in-page); Esc throws the
-- edits away. The original file is never touched: the result is
-- written NEXT TO it as "… (edited).png" (or ".jpg").
--
-- No hotkey of its own. It is reached from the Screenshots module:
-- the ⇪⇧4 panel opens it after a menu capture, and ⌥⏎ on any history
-- row opens that screenshot for editing. (Service: screenshotEditor.open)
--
-- ---------------------------------------------------------------------
-- HOW THE BLUR ACTUALLY HAPPENS, because Hammerspoon cannot do it
-- ---------------------------------------------------------------------
-- hs.image has no filters — no blur, nothing. But a WKWebView has a
-- full <canvas>, and a canvas gives pixel arrays. So the image travels
-- INTO the page as a data: URI (a WKWebView loaded from an html string
-- has no file access — the Capture Pad learned that in 6.44.x), the
-- blur is a ~40-line box blur written right in the page (three passes
-- ≈ gaussian; ctx.filter would be the built-in way but Safari's canvas
-- support for it is too new to lean on), and the finished PNG travels
-- BACK as a data: URI through the message bridge. A Retina screenshot
-- makes both trips as a multi-megabyte string; that is the cost of the
-- only pixel pipeline available, and it is a beat, not a stall.
--
-- The blur core is a PURE function (boxBlurRGBA) on a flat RGBA array,
-- on purpose: tests/test_editor_js.js executes the real page script in
-- node and drives synthetic pixels through it — the same "run the JS,
-- don't grep it" rule the Capture Pad's suite enforces.
-- =====================================================================

local M = {
    name  = "Screenshot Editor",
    order = 23.5,
    family = "screen",
    cheatsheet = {
        title = "🖌 SCREENSHOT EDITOR (blur · text · arrows — ⇪⇧1)",
        entries = {
            { "open",  "⇪⇧1 opens the newest shot · ⇪⇧5 menu captures too · ⌥⏎ on a history row" },
            { "B T A", "tools: Blur box · Text box · Arrow (buttons too)" },
            { "L O H C", "6.212.0: Line · Oval · Highlighter (translucent yellow box) · Counter (①②③ — a numbered badge per click, ⌘Z takes the last back)" },
            { "S M",   "6.213.0: Spotlight (darkens everything but the box) · Magnifier (a 2× circle; drag its right-hand dot to size it)" },
            { "⌘V ⌘A", "6.213.0: paste the clipboard's IMAGE onto the shot · Add capture — drag an area of the screen and it lands on the shot (move the editor first if it is in the way)" },
            { "⌘D",    "6.342.0: Delayed AREA capture (macOS's ⇧⌘5 order) — this window gets out of the way, you DRAG the area you want, then five seconds to arrange the screen, then that rectangle lands on the shot" },
            { "⌘F",    "6.256.0: Full screen — the whole screen, right now, with this window out of the picture" },
            { "K",     "6.414.0: CROP — drag a rectangle and everything outside it dims, so you can see what would GO before anything happens; ⏎ crops to it, ⌫ removes the rectangle, ⌘Z puts the shot back. One rectangle at a time; a new drag replaces it, and the marks inside move with the crop" },
            { "⌘O",    "6.415.0: Load a PRIOR shot — the canvas grows so you can see both, and the shot lands as a MARK you can drag anywhere (even over the first). ⌘Z undoes the whole thing" },
            { "text",  "click, type, ⏎ — white text, white outline box · click an EXISTING box (Text tool) to edit its words, or ⏎ on a selected one" },
            { "move",  "drag text/arrows around · arrow ENDS stretch + rotate · a selected text box has a corner dot — drag it to make the text bigger or smaller (⌘Z undoes it)" },
            { "⌘-click", "6.221.0: hold ⌘ and click ANY mark to select it — a text box opens its words at once, whatever tool is armed; a ⌘-click that misses creates nothing" },
            { "⌫",     "delete the selected note · double-click text re-edits" },
            { "⌘Z",    "undo anything: blur, add, move, edit, delete" },
            { "⌘⏎",   "save “… (edited).png” + clipboard · ⌘⇧⏎ small JPEG" },
            { "text",  "T then click: type · ⏎ drops a line · ⇧⏎ done · drag the corner to RE-WRAP, ⇧drag to change the letter size (6.287.0)" },
            { "esc",   "close without saving — the original is never touched, and the blurs, text and arrows are kept: reopen the SAME shot and they are back" },
            { "",      "6.286.0: EVERY way out keeps them now — esc, Cancel, and ⇪⇧1 on another shot" },
        },
    },
}

function M.setup(core)
    local ed = {}

    -- ✏️ EDIT HERE ---------------------------------------------------------
    ed.enabled    = true
    -- 6.221.0 — how much of the window ⌘-drag may grab: the header, whose
    -- CSS is 54 pt tall. Everything below it belongs to the page, which
    -- reads ⌘ as "edit this mark".
    ed.dragStripH = 54
    -- 🖼 6.270.0 — THE TWO RAILS. LL, for the third time and the first
    -- time with the sizing spelled out: "the tools that run across the
    -- top of the editor and a column on the left-hand side and the right
    -- hand side so at a minimum, the canvas that the screenshot is placed
    -- on would be big enough to accommodate the tool buttons on each
    -- side." Every button lived in ONE wrapping strip across the top, and
    -- the window was sized as the image plus 28 points — twelve a side —
    -- so there was not only no rail, there was no ROOM for one.
    -- 🔑 THESE NUMBERS ARE READ IN TWO PLACES AND TYPED IN NONE: the
    -- page's CSS is written from them and `ed.windowSizeFor` reserves
    -- them, so a check moves the config and requires both to follow
    -- (6.239.0 — asserting a shipped default passes when the number is
    -- typed in twice).
    ed.railW      = 136    -- each rail, points. Both rails are the same
                           -- width: a canvas centred between two unequal
                           -- rails is off-centre in the window.
    ed.railMinH   = 382    -- what the TALLER rail (TEN tools, 6.414.0) needs
                           -- show every button without scrolling. The
                           -- window floor is this plus the header, which
                           -- is the vertical half of his "big enough".
    -- 📐 6.407.0 — THE CEILING, AND WHAT HAPPENS WHEN IT MEETS THE FLOOR.
    -- LL: "the editor window is growing too big … 80% of the largest
    -- screenshot size … but not shrink down so much that the tools are
    -- not usable." The FLOOR half was built in 6.270.0 and is the line
    -- above — said rather than rebuilt, because claiming to fix what
    -- already works is how a release spends itself (6.317.0).
    -- 🔑 WHAT WAS MISSING IS A CEILING THAT IS NOT ONLY A FRACTION. 0.85
    -- of a screen is a sensible number on a 1440-point laptop and an
    -- absurd one on his LG at full points, where it is a window over
    -- three thousand points wide — and 0.80 of that is still absurd, so
    -- moving the fraction alone would have been a cosmetic answer to a
    -- real complaint (6.355.0: a bound you typed is a bound that will be
    -- wrong, and the question is what the bound is a proxy FOR). It is a
    -- proxy for "big enough to work in, small enough to see at once", so
    -- there is an absolute cap beside the fraction and the SMALLER wins.
    -- 🚨 AND THE FLOOR AND THE CEILING CAN CONTRADICT EACH OTHER, which
    -- nothing decided before: on a small screen the tool rails need more
    -- height than 80% of the display has, and `math.max` let the floor
    -- win silently — a window taller than the screen, which cannot be
    -- reached. THE SCREEN WINS, because the rails SCROLL (6.270.0 built
    -- that) and a window you cannot reach does not. Said out loud in the
    -- report rather than left as a surprise.
    ed.maxFrac    = 0.80   -- his number: never more of the screen than this
    ed.maxW       = 1600   -- …and never wider than this, however big the display
    ed.maxH       = 1100   -- …nor taller
    ed.minW       = 720    -- the floor, named rather than a literal (6.248.0)
    ed.minH       = 320
    ed.blurRadius = 12     -- box-blur radius in image pixels (Retina = 2x)
    ed.blurPasses = 3      -- 3 box passes ≈ gaussian
    ed.maxUndo    = 20
    ed.jpegQuality = 0.7   -- ⌘⇧⏎ "small JPEG" quality, 0–1
    -- 6.188.0 — LL: the text boxes are hard to grab. A handle was sized in
    -- IMAGE pixels, and the canvas is displayed SCALED DOWN to fit the
    -- window — so on a 4K screenshot in a 1,000 pt window a 35 px handle
    -- was a 9 px target. This is the radius LL's mouse actually sees, in
    -- SCREEN points, and it is converted into image space at hit time.
    ed.handlePx   = 12
    -- 6.189.0 — LL: "I hit escape 2 times and all my screenshot work
    -- wasn't saved as I accidentally hit escape." On the way out the page
    -- hands its state back and it is held HERE, in memory, in ONE slot.
    -- `cv` carries the base image with the blurs BAKED IN and the text /
    -- arrows live on the OVERLAY canvas, so image + notes is the whole of
    -- the work and neither half is drawn twice on the way back in.
    -- ONE slot on purpose — LL: "If I do a second screenshot though, it
    -- will overwrite the prior image, and that's fine."
    ed.keepOnClose = true
    ed.keepMaxBytes = 40 * 1024 * 1024   -- a 4K PNG data URI, with room
    ed.keepMaxNoteBytes = 8 * 1024 * 1024   -- 6.213.0: a pasted image rides
                                            -- in the notes as a data URI
    -- 🔍 6.213.0 — the magnifier's zoom and the spotlight's veil
    ed.magZoom   = 2
    ed.veilAlpha = 0.55
    -- ⏲ 6.255.0 — the delayed capture (⌘D). LL asked for five seconds.
    ed.delaySecs      = 5     -- the countdown, in seconds
    ed.hideForDelay   = true  -- get this window out of the shot
    ed.delayGraceSecs = 3     -- the belt: how long past the countdown
                              -- before the window comes back regardless
    -- 📐 6.342.0 — ⌘D drags an area FIRST now, and nothing can say how
    -- long a hand will take over it. This is the LAST-RESORT leg: the
    -- longest the editor may sit hidden with a selector open before it
    -- comes back by itself (plus delayGraceSecs, as every belt here).
    -- It is deliberately generous — a belt that fires while he is still
    -- choosing a rectangle is worse than one he never sees.
    ed.regionGraceSecs = 90
    -- 🖥 6.256.0 — the full-screen grab (⌘F) has no countdown to hide
    -- behind, and :hide() is not instant: macOS takes the window off the
    -- screen on its own turn, so a screencapture asked for on the next
    -- line photographs a window that is still there. This is the beat it
    -- waits, and it is the ONLY thing standing between "full screen" and
    -- "a picture of the editor".
    ed.hideSettleSecs = 0.4
    -- 🖼 6.258.0 — loading a PRIOR shot onto this one
    ed.growGap    = 12          -- pixels of surround between the two shots
    ed.growFill   = "#202127"   -- what the new room is painted with
    ed.growRows   = 40          -- prior shots offered in the picker

    -- ✂️ 6.414.0 — CROP. D7's second half, and the only tool here that
    -- takes pixels AWAY. Drag a rectangle with it and everything outside
    -- is dimmed so what would GO is visible before anything happens; ⏎
    -- commits. ONE rectangle at a time on purpose: two crops is a rule
    -- he would have to remember, and the second one's meaning (of the
    -- first result, or of the original?) has no obvious answer.
    ed.cropMin    = 32          -- the floor on each side, image pixels
    ed.cropDim    = 0.72        -- how dark the part that would go is drawn
    ed.kept = nil    -- { path, img, notes } — never written to disk, never
                     -- survives a reload; this is a safety net, not a store
    -- ----------------------------------------------------------------------

    local function say(m)  if _G.diag then _G.diag.say("shotEditor", m)  end end
    local function warn(m) if _G.diag then _G.diag.warn("shotEditor", m) end end

    local function num(v, default)
        local n = tonumber(v)
        if n and n >= 0 then return n end
        return default
    end

    -- ⏲ 6.255.0 — the delayed capture's own state. Counted apart because
    -- "never asked" and "asked and failed" are different answers (6.196.1),
    -- and because a window that had to be brought back by the BELT is the
    -- one number that says this feature nearly cost him his work.
    -- 📐 6.342.0 — `cancelled` is its own count: a selector he pressed
    -- Esc on is not a capture that failed, and a report that summed them
    -- would make his own decision read as a fault (6.196.1).
    ed.delays    = { asked = 0, landed = 0, failed = 0, late = 0, cancelled = 0 }
    ed.regionRunning = false   -- is a ⌘D selector open right now
    ed.delayBusy = false
    ed.hidden    = false
    ed.delayTimer = nil       -- HELD, its own slot (6.196.1)
    ed.settleTimer = nil      -- HELD, ITS OWN slot: two timers, never one
    ed.lastDelayWhy = nil
    -- 🖼 6.258.0. canvasW/H is what the PAGE last said it is — never what
    -- Lua assumes (6.238.0: a page tells Lua when it exists and what it
    -- holds; Lua does not guess). `pageSized` is how the report tells
    -- "the page told me" from "I read it off the file at open", and those
    -- are different facts about the same number.
    ed.canvasW, ed.canvasH, ed.pageSized = nil, nil, false
    ed.grows = { asked = 0, landed = 0, failed = 0 }
    ed.lastGrowWhy, ed.lastGrow = nil, nil
    -- 🖼 6.415.0 — the "it is a mark, drag it" line is said ONCE a
    -- session: it answers a question he only has on his first load, and
    -- a message he reads every time is one he stops reading (6.269.0).
    ed.growSaid = false
    -- ✂️ 6.414.0 — counted APART from the grows: a crop refused for being
    -- too small and a crop that covers the whole shot are different facts
    -- and send a reader to different places (6.196.1).
    ed.crops = { asked = 0, landed = 0, refused = 0 }
    ed.lastCropWhy, ed.lastCrop = nil, nil

    -- ---- files -----------------------------------------------------------
    function ed.editedPathFor(path, ext)
        ext = ext or "png"
        local stem = path:gsub("%.%w+$", "")
        local candidate = stem .. " (edited)." .. ext
        local exists
        pcall(function() exists = hs.fs.attributes(candidate, "size") end)
        if not exists then return candidate end
        for n = 2, 99 do
            local p = stem .. (" (edited %d)."):format(n) .. ext
            local e
            pcall(function() e = hs.fs.attributes(p, "size") end)
            if not e then return p end
        end
        return candidate
    end

    local function readFileBase64(path)
        local f = io.open(path, "rb")
        if not f then return nil end
        local bytes = f:read("*a")
        f:close()
        if not bytes or #bytes == 0 then return nil end
        local b64
        pcall(function() b64 = hs.base64.encode(bytes) end)
        -- hs.base64.encode line-wraps its output; a data: URI must be one
        -- unbroken run or WKWebView drops the image without a word.
        if b64 then b64 = b64:gsub("%s+", "") end
        return b64
    end

    -- ---- the page --------------------------------------------------------
    -- Three tools now live here. The BLUR is destructive on the canvas
    -- pixels (undo snapshots them); TEXT and ARROWS are live objects on
    -- an OVERLAY canvas — movable and editable until save, when they are
    -- painted into the pixels once. One undo stack covers all of it.
    -- `keep` is ed.kept when it matches the image being opened, else nil.
    -- Both halves are made safe for injection here, NOT in the page: the
    -- image is refused unless it is a plain base64 PNG data URI (no
    -- quotes, no angle brackets can survive that test) and the notes ride
    -- as base64 so a note containing a quote or a </script> is inert.
    function ed.buildHtml(dataURI, keep)
        local keepImg, keepNotes = "", ""
        if type(keep) == "table" then
            local img = tostring(keep.img or "")
            if img:match("^data:image/png;base64,[A-Za-z0-9+/=]+$") then
                keepImg = img
            end
            local nb
            pcall(function() nb = hs.base64.encode(tostring(keep.notes or "")) end)
            keepNotes = (nb or ""):gsub("%s+", "")
        end
        -- 🎨 6.90.0 — shared card colors (ui_style.lua), cascade-last.
        local themeCss = (_G.uiStyle and _G.uiStyle.cssOverride
                          and _G.uiStyle.cssOverride()) or ""
        -- ⏲ 6.255.0 — the page is GIVEN the number, never told it twice:
        -- the BUTTON'S LABEL is written from the same `ed.delaySecs` the
        -- capture is asked for with, so a settings override moves both or
        -- neither. 6.239.0's rule — asserting the shipped default passes
        -- when the number is typed in two places.
        local delaySecs = math.floor(num(ed.delaySecs, 5))
        -- 🖼 6.270.0 — the page is GIVEN the rail numbers rather than
        -- carrying its own copies, so `ed.windowSizeFor` and this CSS can
        -- never disagree about how wide a rail is. A check moves the
        -- config and requires the drawing to follow (6.239.0).
        local railW   = math.floor(num(ed.railW, 136))
        local headerH = math.floor(num(ed.dragStripH, 54))
        return [[
<meta charset="utf-8">
<style>
  :root { color-scheme: dark; }
  body { margin:0; font-family:-apple-system,BlinkMacSystemFont,sans-serif;
         font-size:14px; background:#141418; color:#e8e8ec; overflow:hidden; }
  header { padding:8px 12px; display:flex; gap:8px; align-items:center;
           border-bottom:1px solid #2a2a32; user-select:none; -webkit-user-select:none;
           height:]] .. tostring(headerH) .. [[px; box-sizing:border-box; }
  h1 { font-size:15px; margin:0 4px 0 0; font-weight:600; }
  .hint { color:#8a8a96; font-size:12px; margin-left:auto; }
  button { background:#2a2a34; color:#e8e8ec; border:1px solid #3b3b47;
           border-radius:7px; padding:6px 12px; font-size:13px; cursor:pointer; }
  button.go { background:#3566cc; border-color:#4a7fe0; }
  button.tool.on { background:#3d3d52; border-color:#7aa0e8; }
  button:hover { filter:brightness(1.18); }
  /* 🖼 6.270.0 — header across the top, a rail down each side, the shot
     between them. The rails SCROLL rather than clip on a window too short
     to hold them: a button you cannot reach is the bug being fixed. */
  #body { display:flex; height:calc(100vh - ]] .. tostring(headerH) .. [[px);
          box-sizing:border-box; }
  .rail { width:]] .. tostring(railW) .. [[px; flex:0 0 ]] .. tostring(railW) .. [[px;
          box-sizing:border-box; padding:8px 8px 12px; display:flex;
          flex-direction:column; gap:6px; overflow-y:auto; background:#17171c; }
  .rail .lbl { color:#7c7c8a; font-size:11px; letter-spacing:.06em;
               text-transform:uppercase; margin:2px 0 2px 2px; }
  .rail button { width:100%; text-align:left; padding:6px 10px; }
  #railL { border-right:1px solid #2a2a32; }
  #railR { border-left:1px solid #2a2a32; }
  #stage { position:relative; flex:1 1 auto; display:flex; justify-content:center;
           align-items:flex-start; padding:12px;
           box-sizing:border-box; overflow:auto; }
  #wrap { position:relative; display:inline-block; }
  #cv { display:block; max-width:calc(100vw - ]] .. tostring(railW * 2 + 24) .. [[px);
        max-height:calc(100vh - ]] .. tostring(headerH + 24) .. [[px);
        box-shadow:0 4px 24px rgba(0,0,0,.5); }
  /* the overlay rides EXACTLY on the displayed canvas — annotations are
     drawn here so they stay movable until save */
  #ov { position:absolute; left:0; top:0; width:100%; height:100%;
        cursor:crosshair; }
  #tin { position:absolute; display:none; z-index:5; min-width:120px;
         background:rgba(20,20,26,.92); color:#fff; border:2px solid #fff;
         border-radius:4px; font-size:15px; padding:4px 8px; outline:none;
         resize:none; font-family:inherit; line-height:1.25; min-width:160px; }
  /* fixed, not absolute: the drag math works in viewport coordinates
     (getBoundingClientRect), and position:fixed is the box that lives
     in exactly that coordinate space */
  #band { position:fixed; border:2px dashed #4a7fe0;
          background:rgba(74,127,224,.15); pointer-events:none; display:none; }
  ]] .. themeCss .. [[
</style>
<header>
  <h1 id="grip" style="cursor:grab" title="drag to move">🖌 Edit</h1>
  <button class="go" onclick="saveIt('png')" title="⌘⏎">Save &amp; copy&nbsp;&nbsp;⌘⏎</button>
  <button onclick="saveIt('jpg')" title="⌘⇧⏎">Small JPEG</button>
  <button onclick="stashAndCancel()" title="esc">Cancel</button>
  <span class="hint">hold ⌘ and click a mark to edit it · ⌫ deletes a note · saved as “… (edited)” next to the original</span>
</header>
<div id="body">
  <nav id="railL" class="rail">
    <div class="lbl">Tools</div>
    <button id="tool-blur" class="tool on" onclick="setTool('blur')" title="B">▦ Blur</button>
    <button id="tool-text" class="tool" onclick="setTool('text')" title="T">🅣 Text</button>
    <button id="tool-arrow" class="tool" onclick="setTool('arrow')" title="A">➤ Arrow</button>
    <button id="tool-line" class="tool" onclick="setTool('line')" title="L">／ Line</button>
    <button id="tool-oval" class="tool" onclick="setTool('oval')" title="O">◯ Oval</button>
    <button id="tool-hl" class="tool" onclick="setTool('hl')" title="H">🖍 Highlight</button>
    <button id="tool-count" class="tool" onclick="setTool('count')" title="C">① Counter</button>
    <button id="tool-spot" class="tool" onclick="setTool('spot')" title="S">🔦 Spotlight</button>
    <button id="tool-mag" class="tool" onclick="setTool('mag')" title="M">🔍 Magnifier</button>
    <button id="tool-crop" class="tool" onclick="setTool('crop')" title="K — drag a rectangle, then ⏎">✂︎ Crop</button>
  </nav>
  <div id="stage">
    <div id="wrap">
      <canvas id="cv"></canvas>
      <canvas id="ov"></canvas>
      <textarea id="tin" rows="1" spellcheck="false" autocorrect="off"
                autocapitalize="off" placeholder="type · ⏎ new line · ⇧⏎ done"></textarea>
    </div>
    <div id="band"></div>
  </div>
  <nav id="railR" class="rail">
    <div class="lbl">Add</div>
    <button onclick="say({a:'paste'})" title="⌘V">📋 Paste image</button>
    <button onclick="say({a:'capture'})" title="⌘A">📸 Add capture</button>
    <button id="btn-delay" onclick="say({a:'delay'})" title="⌘D — drag an area, then ]] .. tostring(delaySecs) .. [[ seconds to set it up">⏲ Area +]] .. tostring(delaySecs) .. [[s</button>
    <button id="btn-full" onclick="say({a:'full'})" title="⌘F">🖥 Full screen</button>
    <button id="btn-load" onclick="say({a:'loadshot'})" title="⌘O — the canvas grows and the shot lands as a mark you can drag anywhere">🖼 Load shot</button>
    <div class="lbl">Edit</div>
    <button id="btn-crop" onclick="cropAsk()" title="⏎ — after dragging a rectangle with ✂︎ Crop (K)">✂︎ Crop to it</button>
    <button onclick="undoLast()" title="⌘Z">↩︎ Undo</button>
  </nav>
</div>
<script>
  var RADIUS = ]] .. tostring(math.floor(ed.blurRadius)) .. [[;
  var PASSES = ]] .. tostring(math.floor(ed.blurPasses)) .. [[;
  var MAXUNDO = ]] .. tostring(math.floor(ed.maxUndo)) .. [[;
  var HANDLEPX = ]] .. tostring(math.floor(tonumber(ed.handlePx) or 12)) .. [[;
  // 6.189.0 — the work carried back in from the last Esc on THIS image.
  // Empty on a first open, and a bad stash must restore nothing rather
  // than break the editor.
  var RESTOREIMG   = ']] .. keepImg .. [[';
  var RESTORENOTES = ']] .. keepNotes .. [[';
  var JPEGQ = ]] .. tostring(ed.jpegQuality) .. [[;
  var MAGZOOM = ]] .. tostring(tonumber(ed.magZoom) or 2) .. [[;
  var VEIL = ]] .. tostring(tonumber(ed.veilAlpha) or 0.55) .. [[;
  var CROPDIM = ]] .. tostring(tonumber(ed.cropDim) or 0.72) .. [[;
  var DELAYSECS = ]] .. tostring(delaySecs) .. [[;

  function say(m){ window.webkit.messageHandlers.shotEditor.postMessage(m || {}); }
  // Leaving is the only moment the work can be handed back, so an
  // in-progress text box is committed first and every read is guarded —
  // a failure here must still CLOSE the editor, just with nothing kept.
  function stashAndCancel(){
    var img = '', nj = '[]';
    try { commitText(); } catch (e) {}
    try { if (cv && cv.toDataURL) img = cv.toDataURL('image/png'); } catch (e) { img = ''; }
    try { nj = JSON.stringify(notes); } catch (e) { nj = '[]'; }
    say({ a: 'cancel', img: img, notes: nj });
  }

  // 6.89.0 — the title is the drag handle (same pattern as the Capture
  // Pad: JS only REPORTS the grab; Lua polls the real mouse, so the drag
  // survives the pointer outrunning the window). Guarded: the node
  // harness's stub DOM has no #grip.
  var grip = document.getElementById('grip');
  if (grip && grip.addEventListener){
    grip.addEventListener('mousedown', function(ev){
      if (ev && ev.preventDefault) ev.preventDefault();
      say({ a: 'dragStart' });
    });
  }

  // ---- THE BLUR CORE — pure, and tested by node against synthetic
  // pixels (tests/test_editor_js.js). px = flat RGBA Uint8ClampedArray.
  function blurLine(px, tmp, start, step, count, radius){
    var win = radius * 2 + 1, r = 0, g = 0, b = 0, a = 0, i, o, t;
    for (i = -radius; i <= radius; i++){
      o = (start + Math.min(count - 1, Math.max(0, i)) * step) * 4;
      r += px[o]; g += px[o+1]; b += px[o+2]; a += px[o+3];
    }
    for (i = 0; i < count; i++){
      t = i * 4;
      tmp[t] = r / win; tmp[t+1] = g / win; tmp[t+2] = b / win; tmp[t+3] = a / win;
      var ao = (start + Math.min(count - 1, i + radius + 1) * step) * 4;
      var so = (start + Math.max(0, i - radius) * step) * 4;
      r += px[ao] - px[so]; g += px[ao+1] - px[so+1];
      b += px[ao+2] - px[so+2]; a += px[ao+3] - px[so+3];
    }
    for (i = 0; i < count; i++){
      o = (start + i * step) * 4; t = i * 4;
      px[o] = tmp[t]; px[o+1] = tmp[t+1]; px[o+2] = tmp[t+2]; px[o+3] = tmp[t+3];
    }
  }
  function boxBlurRGBA(px, w, h, radius, passes){
    if (w < 1 || h < 1 || radius < 1) return;
    var tmp = new Float32Array(Math.max(w, h) * 4), p, x, y;
    for (p = 0; p < passes; p++){
      for (y = 0; y < h; y++) blurLine(px, tmp, y * w, 1, w, radius);
      for (x = 0; x < w; x++) blurLine(px, tmp, x, w, h, radius);
    }
  }

  // ---- wiring (guarded so the node harness can load this script with
  // only a stub DOM and drive the pure core directly) ----
  var cv = document.getElementById('cv');
  var ctx = cv && cv.getContext ? cv.getContext('2d') : null;
  var ov = document.getElementById('ov');
  var octx = ov && ov.getContext ? ov.getContext('2d') : null;
  var band = document.getElementById('band');
  var tin = document.getElementById('tin');

  var tool = 'blur';
  var notes = [];      // {kind:'text',x,y,text,size} | {kind:'arrow'|'line',x1,y1,x2,y2}
                       // | {kind:'oval'|'hl',x,y,w,h} | {kind:'count',x,y,n}   (6.212.0)
                       // | {kind:'spot',x,y,w,h} | {kind:'mag',x,y,r} | {kind:'img',x,y,w,h,src}   (6.213.0)
  if (RESTORENOTES) {
    try {
      var _b = atob(RESTORENOTES), _a = new Uint8Array(_b.length), _i;
      for (_i = 0; _i < _b.length; _i++) _a[_i] = _b.charCodeAt(_i);
      var _n = JSON.parse(new TextDecoder('utf-8').decode(_a));
      if (_n && _n.length) notes = _n;
      ensureImages();   // 6.213.0 — a kept image note needs its pixels again
    } catch (e) { }   // a stash it cannot read leaves notes empty
  }
  var sel = null;      // the selected note, if any
  var undoStack = [];  // {op:'blur'|'add'|'del'|'set', ...} — one stack for all

  // annotation sizes scale with the IMAGE, not the window — a Retina
  // screenshot gets text you can read once pasted at full size
  function tsize(){ return Math.max(16, Math.round(cv.width / 42)); }
  function lwidth(){ return Math.max(4, Math.round(cv.width / 260)); }
  // 6.188.0 — IMAGE pixels per SCREEN pixel. The canvas is displayed at
  // whatever width fits the window, so on a 4K shot this is around 4:
  // every hit target measured in image pixels is a QUARTER of that on
  // screen. Anything the mouse has to hit goes through here.
  function viewScale(){
    if (!cv || !cv.getBoundingClientRect) return 1;
    var r = cv.getBoundingClientRect();
    if (!r || !r.width) return 1;               // before layout, or hidden
    return cv.width / r.width;
  }
  // the grab radius: never smaller than HANDLEPX points of real screen,
  // and never smaller than the line it belongs to
  function handleR(){
    return Math.max(10, lwidth() * 2.5, HANDLEPX * viewScale());
  }
  // …and never BIGGER than the thing it belongs to. A radius that swallows
  // its own note is the opposite bug and just as real: a short arrow whose
  // two ends are one target, or a small label that can only ever be
  // resized because the corner handle covers the whole box.
  function handleRFor(n){
    var r = handleR();
    if (n.kind === 'arrow' || n.kind === 'line'){
      var len = distPt(n.x1, n.y1, n.x2, n.y2);
      return Math.max(4, Math.min(r, len * 0.35));
    }
    var b = noteBox(n);
    return Math.max(4, Math.min(r, Math.min(b.w, b.h) * 0.45));
  }

  function pushUndo(u){
    undoStack.push(u);
    if (undoStack.length > MAXUNDO) undoStack.shift();
  }

  function setTool(t){
    tool = t;
    var names = ['blur', 'text', 'arrow', 'line', 'oval', 'hl', 'count', 'spot', 'mag', 'crop'], i, b;
    for (i = 0; i < names.length; i++){
      b = document.getElementById('tool-' + names[i]);
      if (b) b.className = 'tool' + (names[i] === t ? ' on' : '');
    }
  }

  function applyBlur(rx, ry, rw, rh){
    rx = Math.max(0, Math.round(rx)); ry = Math.max(0, Math.round(ry));
    rw = Math.min(cv.width - rx, Math.round(rw));
    rh = Math.min(cv.height - ry, Math.round(rh));
    if (rw < 2 || rh < 2) return false;
    pushUndo({ op: 'blur', x: rx, y: ry, w: rw, h: rh,
               data: ctx.getImageData(rx, ry, rw, rh) });
    var patch = ctx.getImageData(rx, ry, rw, rh);
    boxBlurRGBA(patch.data, rw, rh, RADIUS, PASSES);
    ctx.putImageData(patch, rx, ry);
    return true;
  }

  function undoLast(){
    if (!ctx) return;
    commitText();
    var u = undoStack.pop();
    if (!u) return;
    if (u.op === 'blur') ctx.putImageData(u.data, u.x, u.y);
    else if (u.op === 'grow'){
      // 6.415.0 — the loaded shot rides on this row, so one ⌘Z takes the
      // room AND the picture; a row from before it carries no note.
      if (u.note){
        var gi = notes.indexOf(u.note);
        if (gi >= 0) notes.splice(gi, 1);
        if (sel === u.note) sel = null;
      }
      cv.width = u.w; cv.height = u.h;
      if (ov){ ov.width = u.w; ov.height = u.h; }
      ctx.putImageData(u.data, 0, 0);
      sayCanvas();
    }
    // ✂️ 6.414.0 — the whole old canvas AND the shift, because a crop
    // destroys the pixels outside it and moved every mark inside it
    else if (u.op === 'crop'){
      cv.width = u.w; cv.height = u.h;
      if (ov){ ov.width = u.w; ov.height = u.h; }
      ctx.putImageData(u.data, 0, 0);
      shiftNotes(u.dx, u.dy);
      sayCanvas(true);
    }
    else if (u.op === 'add'){
      var i = notes.indexOf(u.note);
      if (i >= 0) notes.splice(i, 1);
      if (sel === u.note) sel = null;
    }
    else if (u.op === 'del') notes.splice(Math.min(u.index, notes.length), 0, u.note);
    else if (u.op === 'set'){ for (var k in u.before) u.note[k] = u.before[k]; }
    redraw();
  }

  // ---- annotations: geometry, drawing, hit-testing ----
  function setFont(g, n){
    g.font = n.size + 'px -apple-system, BlinkMacSystemFont, sans-serif';
  }
  // 6.212.0 — the counter badge's radius scales with the image like the
  // text does, so a "①" pasted at full size is readable
  function countR(){ return Math.max(12, Math.round(tsize() * 0.9)); }
  function nextCount(){
    var m = 0;
    for (var i = 0; i < notes.length; i++)
      if (notes[i].kind === 'count' && notes[i].n > m) m = notes[i].n;
    return m + 1;   // one past the HIGHEST, so a deleted ② never comes back as a second ③
  }
  // ✏️ 6.287.0 — A TEXT NOTE IS A BOX, NOT A LINE. LL, four asks in one
  // breath: it must WRAP; the font size must change independently of the
  // box and the box independently of the font; RETURN must drop a line
  // instead of resizing; and dragging the box SMALLER must re-wrap the
  // text rather than grow it ("so I may need to hold shift down or some
  // other solution"). They are one defect seen from four sides — 6.188.0
  // built the corner handle as a glyph SCALE, so the only thing a text
  // note had was a font size.
  //
  // 🔑 THE NOTE GAINS ONE FIELD, `w`: the width it wraps at, in canvas
  // pixels. A note WITHOUT it (every note in an older kept session, and
  // every note in an older build's saved state) lays out exactly as
  // before — one line, its own measured width — so nothing that exists
  // changes shape. snapNote already carries every numeric field, so ⌘Z
  // undoes a re-wrap through the same generic 'set' op as a move.
  //
  // PURE given a measurer: hard \n breaks are ALWAYS honoured (his
  // Return), words wrap at the width, and a single word longer than the
  // width is broken by character rather than allowed to run out of the
  // box — a URL in a narrow box is the case that makes the difference
  // visible.
  function measureW(g, str, n){
    if (g && g.measureText){
      setFont(g, n);
      var m = g.measureText(str);
      if (m && typeof m.width === 'number') return m.width;
    }
    return (str || '').length * n.size * 0.6;   // no measurer: estimate
  }
  function wrapLines(g, n){
    var text = (n.text === null || n.text === undefined) ? '' : String(n.text);
    var hard = text.split('\n'), out = [], maxW = n.w;
    if (!(typeof maxW === 'number' && maxW > 0)){
      // No width stored: this is a pre-6.287.0 note. One line per hard
      // break, no wrapping — identical to what it drew before.
      for (var h = 0; h < hard.length; h++) out.push(hard[h]);
      return out;
    }
    for (var i = 0; i < hard.length; i++){
      var words = hard[i].split(' '), line = '';
      for (var j = 0; j < words.length; j++){
        var word = words[j];
        var tryLine = line === '' ? word : (line + ' ' + word);
        if (line !== '' && measureW(g, tryLine, n) > maxW){
          out.push(line); line = word;
        } else {
          line = tryLine;
        }
        // A single word wider than the box is broken by character; left
        // whole it would run past the box it is supposed to be inside.
        while (measureW(g, line, n) > maxW && line.length > 1){
          var cut = line.length - 1;
          while (cut > 1 && measureW(g, line.slice(0, cut), n) > maxW) cut--;
          out.push(line.slice(0, cut));
          line = line.slice(cut);
        }
      }
      out.push(line);
    }
    return out;
  }
  function lineH(n){ return Math.round(n.size * 1.25); }
  // The width a note is LAID OUT at: its own if it has one, else what its
  // longest line measures. One function, so the box, the draw and the
  // corner handle cannot disagree about where the right edge is.
  function textW(g, n){
    if (typeof n.w === 'number' && n.w > 0) return n.w;
    var lines = wrapLines(g, n), w = 0;
    for (var i = 0; i < lines.length; i++){
      var lw = measureW(g, lines[i] || ' ', n);
      if (lw > w) w = lw;
    }
    return Math.max(1, w);
  }
  function noteBox(n){
    if (n.kind === 'arrow' || n.kind === 'line'){
      return { x: Math.min(n.x1, n.x2), y: Math.min(n.y1, n.y2),
               w: Math.abs(n.x2 - n.x1), h: Math.abs(n.y2 - n.y1) };
    }
    if (n.kind === 'oval' || n.kind === 'hl' || n.kind === 'spot' || n.kind === 'img'
        || n.kind === 'crop')
      return { x: n.x, y: n.y, w: n.w, h: n.h };
    if (n.kind === 'mag') return { x: n.x - n.r, y: n.y - n.r, w: n.r * 2, h: n.r * 2 };
    if (n.kind === 'count'){
      var cr = countR();
      return { x: n.x - cr, y: n.y - cr, w: cr * 2, h: cr * 2 };
    }
    var g = octx || ctx;
    var w = textW(g, n);
    var rows = Math.max(1, wrapLines(g, n).length);
    var pad = Math.round(n.size * 0.5);
    var h = n.size + (rows - 1) * lineH(n);
    return { x: n.x - pad, y: n.y - n.size - pad, w: w + pad * 2, h: h + pad * 2 };
  }
  // LL's spec, verbatim: "white text and white outline". A soft dark
  // shadow under both keeps white readable on a white screenshot.
  // 6.213.0 — pasted / captured images, by data URI. Loaded once each;
  // a note whose image has not arrived yet draws nothing and no error.
  var imgCache = {};
  function loadImg(src){
    if (!src || imgCache[src]) return imgCache[src];
    var im = new Image(), rec = { im: im, ok: false };
    imgCache[src] = rec;
    im.onload = function(){ rec.ok = true; redraw(); };
    im.src = src;
    return rec;
  }
  function ensureImages(){
    for (var i = 0; i < notes.length; i++) if (notes[i].kind === 'img') loadImg(notes[i].src);
  }
  // Lua calls this (evaluateJavaScript) with the clipboard's image or a
  // fresh capture: sized to fit 40% of the shot's width, aspect kept,
  // centred, then an ordinary note — moved, resized, undone, saved.
  function addImage(src, w, h){
    if (!cv || !src) return false;
    w = Number(w) || 100; h = Number(h) || 100;
    var maxW = Math.max(16, Math.round(cv.width * 0.4));
    var sc = Math.min(1, maxW / w);
    var nw = Math.max(8, Math.round(w * sc)), nh = Math.max(8, Math.round(h * sc));
    var n = { kind: 'img', src: src, w: nw, h: nh,
              x: Math.round((cv.width - nw) / 2), y: Math.round((cv.height - nh) / 2) };
    loadImg(src);
    notes.push(n); sel = n;
    pushUndo({ op: 'add', note: n });
    redraw();
    return true;
  }
  // 🖼 6.258.0 — the canvas GROWS and a prior shot lands in the new room.
  // Lua worked the geometry out and handed the numbers in; this does them
  // and nothing else, so there is one copy of the rule, in Lua, where the
  // gate can drive it. The old pixels go back at 0,0 — never centred —
  // because every note is in canvas coordinates and would otherwise move.
  // `fit` is additive (6.299.0): the old callers pass nothing and Lua
  // only records, as it always has. A CROP — and the undo of one —
  // changes the shape of the picture, and a canvas scaled to fit an
  // unchanged window is drawn bigger and blurrier than it was, so those
  // two ask for the window as well.
  function sayCanvas(fit){
    if (cv) say({ a: 'size', w: cv.width, h: cv.height, fit: !!fit });
  }
  // 🖼 6.415.0 — AND THE LOADED SHOT IS A MARK, NOT PIXELS. It used to be
  // drawn straight into the canvas, so where it landed was where it
  // stayed for ever. It is an ordinary `img` note now, at its OWN size
  // (40% is ⌘V's rule, and the size is the difference between the two
  // doors) at the offset Lua planned — so the drag, the corner scale,
  // ⌫, the selection ring and the stash across a close all serve it
  // with no new code, and it can be put on top of the first shot.
  // 🔁 ONE ⌘Z TAKES BOTH BACK. The note rides on the grow's own undo row
  // rather than pushing a second one: 6.258.0 promised that ⌘Z undoes a
  // whole grow, and one action owing two presses is the kind of thing
  // nobody remembers at the moment they need it.
  function growTo(src, nw, nh, ax, ay, fill, aw, ah){
    if (!cv || !ctx || !src) return false;
    nw = Math.round(Number(nw) || 0); nh = Math.round(Number(nh) || 0);
    if (nw < cv.width || nh < cv.height) return false;   // a grow never shrinks
    var im = new Image();
    im.onload = function(){
      var old = ctx.getImageData(0, 0, cv.width, cv.height);
      // 📏 THE UNDO CARRIES THE OLD PIXELS, because shrinking a canvas
      // destroys them — the same shape as a blur's patch, one size up.
      // Lua measured the file and planned the room from those numbers, so
      // they are what the mark is drawn at; naturalWidth is the belt for
      // a Mac that could not measure it (additive — 6.299.0).
      var iw = Math.round(Number(aw) || im.naturalWidth || 0);
      var ih = Math.round(Number(ah) || im.naturalHeight || 0);
      if (iw <= 0 || ih <= 0) return;
      var n = { kind: 'img', src: src, w: iw, h: ih,
                x: Math.round(Number(ax) || 0), y: Math.round(Number(ay) || 0) };
      pushUndo({ op: 'grow', w: cv.width, h: cv.height, data: old, note: n });
      cv.width = nw; cv.height = nh;
      if (ov){ ov.width = nw; ov.height = nh; }
      ctx.fillStyle = fill || '#202127';
      ctx.fillRect(0, 0, nw, nh);
      ctx.putImageData(old, 0, 0);
      imgCache[src] = { im: im, ok: true };   // already loaded; never fetch it twice
      notes.push(n); sel = n;                 // selected, so it can be dragged at once
      redraw();
      sayCanvas();
    };
    im.src = src;
    return true;
  }

  // ✂️ 6.414.0 — CROP. The rectangle is an ordinary box note, so the hit
  // test, the move, the size handle, ⌘Z and the stash-across-a-close all
  // serve it with no new code — what is new is how it is DRAWN and what
  // committing it does.
  // 🔒 AND IT IS DRAWN FOR THE SCREEN AND NEVER FOR THE FILE. saveIt bakes
  // the marks in with `drawAll(ctx, false)`, so every call here is behind
  // `withSel`: a pending crop can never burn a dim overlay into a saved
  // shot, and drawNote draws nothing at all for the kind.
  function cropNote(){
    for (var i = notes.length - 1; i >= 0; i--)
      if (notes[i].kind === 'crop') return notes[i];
    return null;
  }
  function drawCropMask(g){
    var n = cropNote();
    if (!n || !(n.w > 0) || !(n.h > 0)) return;
    g.save();
    g.shadowBlur = 0;
    // the spotlight's veil INVERTED: there the box is the hole, here the
    // box is the only thing that stays. What would GO is what is dim, so
    // the question "what am I about to lose" is answered before ⏎.
    g.fillStyle = 'rgba(0,0,0,' + CROPDIM + ')';
    g.beginPath();
    g.rect(0, 0, cv.width, cv.height);
    g.rect(n.x, n.y, n.w, n.h);
    g.fill('evenodd');
    g.strokeStyle = '#ffffff';
    g.lineWidth = Math.max(1, Math.round(lwidth() * 0.6));
    if (g.setLineDash) g.setLineDash([Math.max(4, lwidth() * 2), Math.max(3, lwidth() * 1.5)]);
    g.strokeRect(n.x, n.y, n.w, n.h);
    if (g.setLineDash) g.setLineDash([]);
    // 6.203.0 — the size and the two keys are said WHERE HE IS LOOKING,
    // not in an alert under the window. Above the rectangle, or below it
    // when there is no room above, and never off the side of the shot.
    var fs = Math.max(13, Math.round(tsize() * 0.6));
    g.font = fs + 'px -apple-system, BlinkMacSystemFont, sans-serif';
    g.textBaseline = 'alphabetic';
    g.textAlign = 'left';
    var lbl = Math.round(n.w) + ' \u00d7 ' + Math.round(n.h) + '   \u23ce crops \u00b7 \u232b removes';
    var tw = (g.measureText ? g.measureText(lbl).width : lbl.length * fs * 0.55) + fs;
    var ty = (n.y > fs * 2.4) ? (n.y - fs * 0.7) : (n.y + n.h + fs * 1.5);
    var tx = Math.min(Math.max(0, n.x), Math.max(0, cv.width - tw));
    g.fillStyle = 'rgba(0,0,0,0.78)';
    g.fillRect(tx, ty - fs, tw, fs * 1.45);
    g.fillStyle = '#ffffff';
    g.fillText(lbl, tx + fs * 0.5, ty + fs * 0.2);
    g.restore();
  }
  // every mark is in canvas coordinates, so a crop moves all of them
  function shiftNotes(dx, dy){
    for (var i = 0; i < notes.length; i++){
      var n = notes[i];
      if (typeof n.x1 === 'number'){
        n.x1 += dx; n.x2 += dx; n.y1 += dy; n.y2 += dy;
      } else if (typeof n.x === 'number'){
        n.x += dx; n.y += dy;
      }
    }
  }
  // The page ASKS and Lua decides — one copy of the rule, in the place the
  // gate can drive it (6.258.0's shape). With no rectangle it still asks,
  // so the refusal is Lua's one sentence rather than a silent button.
  function cropAsk(){
    commitText();
    var n = cropNote();
    if (!n){ say({ a: 'crop' }); return false; }
    say({ a: 'crop', x: n.x, y: n.y, w: n.w, h: n.h });
    return true;
  }
  function cropTo(x, y, w, h){
    if (!cv || !ctx) return false;
    x = Math.round(Number(x) || 0); y = Math.round(Number(y) || 0);
    w = Math.round(Number(w) || 0); h = Math.round(Number(h) || 0);
    if (w < 1 || h < 1 || x < 0 || y < 0
        || x + w > cv.width || y + h > cv.height) return false;
    commitText();
    var keep = ctx.getImageData(x, y, w, h);
    // 📏 THE UNDO CARRIES THE WHOLE OLD CANVAS AND THE SHIFT: shrinking a
    // canvas destroys its pixels, and every mark moved with it.
    pushUndo({ op: 'crop', w: cv.width, h: cv.height, dx: x, dy: y,
               data: ctx.getImageData(0, 0, cv.width, cv.height) });
    cv.width = w; cv.height = h;
    if (ov){ ov.width = w; ov.height = h; }
    ctx.putImageData(keep, 0, 0);
    // the rectangle goes WITH the crop: it describes a shot that no longer
    // exists, and a crop of a crop is a rule nobody asked for
    var cn = cropNote(), ci = cn ? notes.indexOf(cn) : -1;
    if (ci >= 0){ if (sel === cn) sel = null; notes.splice(ci, 1); }
    shiftNotes(-x, -y);
    redraw();
    sayCanvas(true);
    return true;
  }

  // 6.213.0 — ONE veil for every spotlight: the whole canvas, with each
  // spot punched out (even-odd), so two spotlights are two holes and
  // never a double-dark. Drawn under the marks, over the magnifiers.
  function drawVeil(g){
    var any = false, i;
    for (i = 0; i < notes.length; i++) if (notes[i].kind === 'spot'){ any = true; break; }
    if (!any) return;
    g.save();
    g.shadowBlur = 0;
    g.fillStyle = 'rgba(0,0,0,' + VEIL + ')';
    g.beginPath();
    g.rect(0, 0, cv.width, cv.height);
    for (i = 0; i < notes.length; i++){
      var n = notes[i];
      if (n.kind === 'spot') g.rect(n.x, n.y, n.w, n.h);
    }
    g.fill('evenodd');
    g.restore();
  }
  // the order every surface draws in: magnifiers read the clean pixels
  // first, then the veil, then everything else on top
  function drawAll(g, withSel){
    var i;
    for (i = 0; i < notes.length; i++)
      if (notes[i].kind === 'mag') drawNote(g, notes[i], withSel && notes[i] === sel);
    drawVeil(g);
    for (i = 0; i < notes.length; i++)
      if (notes[i].kind !== 'mag') drawNote(g, notes[i], withSel && notes[i] === sel);
    // ✂️ last, over the marks, and ONLY for the screen — see drawCropMask
    if (withSel) drawCropMask(g);
  }
  function drawNote(g, n, isSel){
    g.save();
    g.shadowColor = 'rgba(0,0,0,0.55)';
    g.shadowBlur = Math.max(3, lwidth());
    g.strokeStyle = '#ffffff'; g.fillStyle = '#ffffff';
    if (n.kind === 'spot' || n.kind === 'crop'){
      // the veil (drawVeil) is the spotlight and drawCropMask is the crop;
      // here only their selection ring — and for the crop that matters
      // twice over, because drawNote is what saveIt BAKES (6.414.0)
    } else if (n.kind === 'mag'){
      // 6.213.0 — the pixels under the circle, MAGZOOM× bigger, clipped
      // to the circle, with a white ring. Source is the base canvas, so
      // blurs show magnified too and the veil never does.
      var z = MAGZOOM || 2, r = Math.max(4, n.r);
      g.save();
      g.shadowBlur = 0;
      g.beginPath(); g.arc(n.x, n.y, r, 0, 6.2832);
      if (g.clip) g.clip();
      if (g.drawImage) g.drawImage(cv, n.x - r / z, n.y - r / z, 2 * r / z, 2 * r / z,
                                   n.x - r, n.y - r, 2 * r, 2 * r);
      g.restore();
      g.lineWidth = lwidth();
      g.beginPath(); g.arc(n.x, n.y, r, 0, 6.2832); g.stroke();
    } else if (n.kind === 'img'){
      var rec = imgCache[n.src] || loadImg(n.src);
      if (rec && rec.ok && g.drawImage){ g.shadowBlur = 0; g.drawImage(rec.im, n.x, n.y, n.w, n.h); }
    } else if (n.kind === 'line'){
      // 6.212.0 — an arrow without its head
      g.lineWidth = lwidth(); g.lineCap = 'round';
      g.beginPath(); g.moveTo(n.x1, n.y1); g.lineTo(n.x2, n.y2); g.stroke();
    } else if (n.kind === 'oval'){
      // 6.212.0 — a white ring around the thing; ellipse where the
      // canvas has it, a circle of the longer side where it does not
      g.lineWidth = lwidth();
      g.beginPath();
      var cx = n.x + n.w / 2, cy = n.y + n.h / 2;
      if (g.ellipse) g.ellipse(cx, cy, Math.max(1, n.w / 2), Math.max(1, n.h / 2), 0, 0, 6.2832);
      else g.arc(cx, cy, Math.max(1, Math.max(n.w, n.h) / 2), 0, 6.2832);
      g.stroke();
    } else if (n.kind === 'hl'){
      // 6.212.0 — a translucent yellow box, NO shadow (a shadow under a
      // translucent fill reads as a smudge)
      g.shadowBlur = 0; g.shadowColor = 'rgba(0,0,0,0)';
      g.fillStyle = 'rgba(255,230,0,0.38)';
      g.fillRect(n.x, n.y, n.w, n.h);
    } else if (n.kind === 'count'){
      // 6.212.0 — a white disc with the number in dark ink
      var cr = countR();
      g.beginPath(); g.arc(n.x, n.y, cr, 0, 6.2832); g.fill();
      g.shadowBlur = 0;
      g.fillStyle = '#1b2a4a';
      g.font = Math.round(cr * 1.2) + 'px -apple-system, BlinkMacSystemFont, sans-serif';
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(String(n.n), n.x, n.y);
    } else if (n.kind === 'arrow'){
      var dx = n.x2 - n.x1, dy = n.y2 - n.y1;
      var len = Math.sqrt(dx * dx + dy * dy) || 1;
      var ux = dx / len, uy = dy / len;
      var hl = Math.max(10, lwidth() * 3);           // arrowhead length
      var bx = n.x2 - ux * hl, by = n.y2 - uy * hl;  // head base
      g.lineWidth = lwidth(); g.lineCap = 'round';
      g.beginPath(); g.moveTo(n.x1, n.y1); g.lineTo(bx, by); g.stroke();
      g.beginPath();
      g.moveTo(n.x2, n.y2);
      g.lineTo(bx - uy * hl * 0.5, by + ux * hl * 0.5);
      g.lineTo(bx + uy * hl * 0.5, by - ux * hl * 0.5);
      g.closePath(); g.fill();
    } else {
      setFont(g, n);
      g.textBaseline = 'alphabetic';
      g.textAlign = 'left';
      var b = noteBox(n);
      g.lineWidth = Math.max(2, Math.round(n.size / 8));
      g.strokeRect(b.x, b.y, b.w, b.h);
      // 6.287.0 — every line, at the note's own line height. n.x/n.y stay
      // the FIRST line's baseline, so a note that gains a second line
      // grows downward and never moves off the thing it points at.
      var tl = wrapLines(g, n);
      for (var li = 0; li < tl.length; li++)
        g.fillText(tl[li] || '', n.x, n.y + li * lineH(n));
    }
    if (isSel){
      var bb = noteBox(n);
      g.shadowBlur = 0;
      g.strokeStyle = 'rgba(116,168,255,0.95)'; g.lineWidth = 1;
      if (g.setLineDash) g.setLineDash([4, 3]);
      g.strokeRect(bb.x - 4, bb.y - 4, bb.w + 8, bb.h + 8);
      if (g.setLineDash) g.setLineDash([]);
      // 6.188.0 — DRAWN THE SIZE THEY ARE HIT. They used to be drawn at
      // 0.6× the grab radius, which teaches the eye to aim at a dot
      // smaller than the target and reads as "it did not take".
      if (g.arc){
        g.fillStyle = 'rgba(116,168,255,0.95)';
        g.strokeStyle = 'rgba(10,14,26,0.85)';
        g.lineWidth = Math.max(1, handleR() * 0.12);
        var hr = handleRFor(n);
        var dot = function(x, y){
          g.beginPath(); g.arc(x, y, hr, 0, 6.2832); g.fill(); g.stroke();
        };
        if (n.kind === 'arrow' || n.kind === 'line'){ dot(n.x1, n.y1); dot(n.x2, n.y2); }
        else if (n.kind === 'mag'){ dot(n.x + n.r, n.y); }               // the radius handle
        else if (n.kind !== 'count'){ dot(bb.x + bb.w, bb.y + bb.h); }   // the resize corner (text, oval, highlight, spotlight, image)
      }
    }
    g.restore();
  }
  function redraw(){
    if (!octx) return;
    octx.clearRect(0, 0, ov.width, ov.height);
    drawAll(octx, true);
  }

  function distPt(ax, ay, bx, by){
    var dx = ax - bx, dy = ay - by;
    return Math.sqrt(dx * dx + dy * dy);
  }
  function segDist(p, n){
    var dx = n.x2 - n.x1, dy = n.y2 - n.y1;
    var ll = dx * dx + dy * dy;
    if (ll < 1) return distPt(p.x, p.y, n.x1, n.y1);
    var t = ((p.x - n.x1) * dx + (p.y - n.y1) * dy) / ll;
    t = Math.max(0, Math.min(1, t));
    return distPt(p.x, p.y, n.x1 + t * dx, n.y1 + t * dy);
  }
  // topmost first: later notes sit on top, so scan backwards. Arrow
  // ENDPOINTS win over the shaft — grabbing an end stretches/rotates.
  function hitAt(p){
    for (var i = notes.length - 1; i >= 0; i--){
      var n = notes[i];
      if (n.kind === 'count'){
        // 6.212.0 — the badge moves as a whole; no handle to resize
        if (distPt(p.x, p.y, n.x, n.y) <= countR() + handleR() * 0.5) return { note: n, part: 'move' };
        continue;
      }
      if (n.kind === 'mag'){
        // 6.213.0 — the dot on its right edge sets the radius; inside moves
        if (distPt(p.x, p.y, n.x + n.r, n.y) <= handleRFor(n)) return { note: n, part: 'rad' };
        if (distPt(p.x, p.y, n.x, n.y) <= n.r) return { note: n, part: 'move' };
        continue;
      }
      if (n.kind === 'arrow' || n.kind === 'line'){
        var hr = handleRFor(n);
        if (distPt(p.x, p.y, n.x1, n.y1) <= hr) return { note: n, part: 'p1' };
        if (distPt(p.x, p.y, n.x2, n.y2) <= hr) return { note: n, part: 'p2' };
        if (segDist(p, n) <= handleR()) return { note: n, part: 'move' };
      } else {
        var b = noteBox(n);
        // 6.188.0 — the SIZE handle, bottom-right, checked before the box
        // so a small note is still resizable rather than only movable
        if (distPt(p.x, p.y, b.x + b.w, b.y + b.h) <= handleRFor(n))
          return { note: n, part: 'size' };
        // …and the box itself is grown to the handle radius, so a one-word
        // label on a 4K shot is a target rather than a dare
        var pad = handleR() * 0.5;
        if (p.x >= b.x - pad && p.x <= b.x + b.w + pad
            && p.y >= b.y - pad && p.y <= b.y + b.h + pad)
          return { note: n, part: 'move' };
      }
    }
    return null;
  }
  function snapNote(n){
    // 6.188.0 — `size` rides along for a text note, so ⌘Z undoes a resize
    // through the same generic 'set' op a move already used
    // 6.212.0 — every numeric field, whatever the kind: x/y/size for
    // text, the two ends of an arrow or line, x/y/w/h of an oval or a
    // highlight, x/y/n of a counter
    var o = {}, k;
    for (k in n) if (typeof n[k] === 'number') o[k] = n[k];
    return o;
  }

  // ---- the floating text input ----
  var editingNote = null, pendingPt = null;
  function textOpen(){ return tin && tin.style.display === 'block'; }
  function startText(note, p){
    commitText();
    editingNote = note || null;
    pendingPt = note ? null : p;
    var at = note ? { x: note.x, y: note.y - tsize() } : p;
    var r = cv.getBoundingClientRect();
    tin.style.left = Math.round(at.x * (r.width / cv.width)) + 'px';
    tin.style.top  = Math.round(at.y * (r.height / cv.height)) + 'px';
    tin.value = note ? (note.text || '') : '';
    tin.style.display = 'block';
    // 6.287.0 — the box he types in is the size of the box he will get:
    // as many rows as the text has lines, and as wide as the note wraps.
    var rows = (tin.value.split('\n').length) || 1;
    tin.rows = Math.max(1, Math.min(12, rows));
    if (note && typeof note.w === 'number' && note.w > 0 && cv && cv.width){
      tin.style.width = Math.round(note.w * (r.width / cv.width)) + 'px';
    } else {
      tin.style.width = '';
    }
    if (tin.focus) tin.focus();
  }
  function commitText(){
    if (!textOpen()) return;
    tin.style.display = 'none';
    // 6.287.0 — trim the ENDS only. A \n in the middle is his Return and
    // must survive; /^\s+|\s+$/ ate leading and trailing whitespace and
    // left the interior alone already, which is what we want, but \s
    // includes \n so a trailing blank line goes and an interior one stays.
    var v = (tin.value || '').replace(/^[ \t\n]+|[ \t\n]+$/g, '');
    if (editingNote){
      if (v === ''){
        var i = notes.indexOf(editingNote);
        if (i >= 0){ pushUndo({ op: 'del', note: editingNote, index: i }); notes.splice(i, 1); }
        if (sel === editingNote) sel = null;
      } else if (v !== editingNote.text){
        pushUndo({ op: 'set', note: editingNote, before: { text: editingNote.text } });
        editingNote.text = v;
      }
    } else if (v !== '' && pendingPt){
      // 6.287.0 — a NEW note is born with a width, so the corner handle
      // has something to shrink and the wrap rule is live from the first
      // character. An OLD note has none and keeps its one-line behaviour.
      var ns = tsize();
      var nn = { kind: 'text', x: pendingPt.x, y: pendingPt.y, text: v, size: ns };
      nn.w = Math.max(ns, Math.round(textW(octx || ctx, nn)));
      var n = nn;
      notes.push(n); sel = n;
      pushUndo({ op: 'add', note: n });
    }
    editingNote = null; pendingPt = null;
    redraw();
  }
  function cancelText(){
    if (!textOpen()) return;
    tin.style.display = 'none';
    editingNote = null; pendingPt = null;
  }

  // save: paint the notes into the pixels ONCE, render, then put the
  // clean pixels straight back — the notes stay editable if Lua ever
  // refuses the save and the editor stays open
  function saveIt(fmt){
    if (!ctx) return;
    commitText();
    var keep = ctx.getImageData(0, 0, cv.width, cv.height);
    drawAll(ctx, false);
    var url = fmt === 'jpg' ? cv.toDataURL('image/jpeg', JPEGQ)
                            : cv.toDataURL('image/png');
    ctx.putImageData(keep, 0, 0);
    say({ a: 'save', data: url, ext: fmt === 'jpg' ? 'jpg' : 'png' });
  }

  if (ctx) {
    var img = new Image();
    img.onload = function(){
      cv.width = img.naturalWidth; cv.height = img.naturalHeight;
      if (ov){ ov.width = cv.width; ov.height = cv.height; }
      ctx.drawImage(img, 0, 0);
      redraw();            // 6.189.0 — restored notes, if any
      sayCanvas();         // 6.258.0 — Lua does not guess how big this is
    };
    img.src = RESTOREIMG || ']] .. dataURI .. [[';

    // displayed size ≠ pixel size (CSS scales the canvas to fit), so
    // every mouse point is mapped through the live scale factor
    var drag = null, sx = 0, sy = 0;
    function toCanvas(e){
      var r = cv.getBoundingClientRect();
      return { x: (e.clientX - r.left) * (cv.width  / r.width),
               y: (e.clientY - r.top)  * (cv.height / r.height) };
    }
    var surface = ov || cv;   // the overlay sits on top and gets the mouse
    surface.addEventListener('mousedown', function(e){
      if (e.button !== 0) return;
      e.preventDefault();
      if (textOpen()){ commitText(); return; }   // click-away commits
      var p = toCanvas(e);
      // ⌘ 6.221.0 — HOLDING ⌘ IS THE EDIT TOOL, whatever tool is armed.
      // LL: "After I add a text box or any other item I am having trouble
      // editing the added items… if I hold down command while in the edit,
      // allow me to edit text boxes or any other tool addition." Two
      // things make it work: a ⌘-click on a TEXT box opens its words at
      // once (no double-click, no swapping back to the Text tool), and a
      // ⌘-click that MISSES creates nothing — the commonest way to make a
      // stray arrow is aiming at a mark and landing a pixel outside it.
      var editMode = !!e.metaKey;
      var hit = hitAt(p);
      if (hit){
        sel = hit.note;
        drag = { mode: (hit.part === 'move' || hit.part === 'size' || hit.part === 'rad') ? hit.part : 'end',
                 note: hit.note, part: hit.part, sx: p.x, sy: p.y,
                 before: snapNote(hit.note),
                 // 6.207.0 — LL: "I can't edit an existing text box. If I
                 // click on the text box, a new one is created instead."
                 // With the Text tool a CLICK on a text box (press and
                 // release without moving) opens it for editing; a drag
                 // still moves it. Decided on mouseup, where the two can be
                 // told apart. Screen coordinates, so a 4K shot in a small
                 // window does not turn a steady hand into a "drag".
                 clickEdit: ((tool === 'text' || editMode)
                             && hit.note.kind === 'text'),
                 cx: e.clientX, cy: e.clientY, moved: false };
        redraw();
        return;
      }
      // ⌘ held and nothing under the pointer: drop the selection and STOP.
      // Never a new note, never a rubber band — that is the promise.
      if (editMode){ if (sel){ sel = null; redraw(); } return; }
      if (tool === 'text'){ sel = null; redraw(); startText(null, p); return; }
      if (tool === 'arrow' || tool === 'line'){
        var n = { kind: tool, x1: p.x, y1: p.y, x2: p.x, y2: p.y };
        notes.push(n); sel = n;
        drag = { mode: 'end', note: n, part: 'p2', fresh: true };
        redraw();
        return;
      }
      // 6.212.0 — a box drawn from the press to the release, in any
      // direction: the corner drag normalises x/y/w/h as it goes
      // 6.213.0 — the magnifier: centre at the press, radius to the release
      if (tool === 'mag'){
        var nm = { kind: 'mag', x: p.x, y: p.y, r: 0 };
        notes.push(nm); sel = nm;
        drag = { mode: 'rad', note: nm, fresh: true };
        redraw();
        return;
      }
      // ✂️ 6.414.0 — ONE crop rectangle: a new drag REPLACES the old one,
      // and the replacement is undoable like any other delete. Two of
      // them would need a rule about which ⏎ meant, and there is no
      // obvious answer to "a crop of the first crop, or of the shot?".
      if (tool === 'crop'){
        var oldCrop = cropNote();
        if (oldCrop){
          var oi = notes.indexOf(oldCrop);
          if (oi >= 0){ pushUndo({ op: 'del', note: oldCrop, index: oi });
                        notes.splice(oi, 1); }
          if (sel === oldCrop) sel = null;
        }
      }
      if (tool === 'oval' || tool === 'hl' || tool === 'spot' || tool === 'crop'){
        var nb = { kind: tool, x: p.x, y: p.y, w: 0, h: 0 };
        notes.push(nb); sel = nb;
        drag = { mode: 'corner', note: nb, fresh: true, ox: p.x, oy: p.y };
        redraw();
        return;
      }
      // 6.212.0 — one click, one badge, the next number
      if (tool === 'count'){
        var nc = { kind: 'count', x: p.x, y: p.y, n: nextCount() };
        notes.push(nc); sel = nc;
        pushUndo({ op: 'add', note: nc });
        redraw();
        return;
      }
      if (sel){ sel = null; redraw(); }
      drag = { mode: 'band' }; sx = p.x; sy = p.y;
      band.style.display = 'block';
    });
    window.addEventListener('mousemove', function(e){
      if (!drag) return;
      // The button is not down any more, so the release landed somewhere
      // this page never hears about — another window, another Space, off
      // the screen. End the drag HERE, at this point, exactly as a
      // mouseup would: a shape that is too small is still discarded, a
      // real one is still undoable. `buttons` is a bitmask and 0 is the
      // only value that means "nothing held" (a `which`-style check
      // would read a bare move as button 1 and end every drag at once).
      if (typeof e.buttons === 'number' && e.buttons === 0){
        finishDrag(e); return;
      }
      if (drag.mode === 'band'){
        var r = cv.getBoundingClientRect();
        // the band is drawn in SCREEN space, anchor to pointer
        var ax = sx * (r.width / cv.width) + r.left;
        var ay = sy * (r.height / cv.height) + r.top;
        band.style.left   = Math.min(ax, e.clientX) + 'px';
        band.style.top    = Math.min(ay, e.clientY) + 'px';
        band.style.width  = Math.abs(e.clientX - ax) + 'px';
        band.style.height = Math.abs(e.clientY - ay) + 'px';
        return;
      }
      var p = toCanvas(e), n = drag.note;
      if (Math.abs(e.clientX - drag.cx) > 3 || Math.abs(e.clientY - drag.cy) > 3) drag.moved = true;
      // a click that wobbles a pixel is still a click: nothing moves until
      // the hand has really moved, so the words open instead of shifting
      if (drag.clickEdit && !drag.moved) return;
      if (drag.mode === 'move'){
        var dx = p.x - drag.sx, dy = p.y - drag.sy;
        if (n.kind === 'arrow'){
          n.x1 = drag.before.x1 + dx; n.y1 = drag.before.y1 + dy;
          n.x2 = drag.before.x2 + dx; n.y2 = drag.before.y2 + dy;
        } else { n.x = drag.before.x + dx; n.y = drag.before.y + dy; }
      } else if (drag.mode === 'corner'){
        n.x = Math.min(drag.ox, p.x); n.y = Math.min(drag.oy, p.y);
        n.w = Math.abs(p.x - drag.ox); n.h = Math.abs(p.y - drag.oy);
      } else if (drag.mode === 'rad'){
        n.r = Math.max(4, Math.round(distPt(p.x, p.y, n.x, n.y)));
      } else if (drag.mode === 'size'){
        if (n.kind === 'img'){
          // 6.213.0 — an image keeps its shape: the corner scales both sides
          var sc = Math.max(0.05, (drag.before.w + (p.x - drag.sx)) / Math.max(1, drag.before.w));
          n.w = Math.max(8, Math.round(drag.before.w * sc));
          n.h = Math.max(8, Math.round(drag.before.h * sc));
        } else if (n.kind === 'oval' || n.kind === 'hl' || n.kind === 'spot'
                   || n.kind === 'crop'){
          // 6.212.0 — the bottom-right corner follows the pointer; the
          // top-left stays put
          n.w = Math.max(4, Math.round(drag.before.w + (p.x - drag.sx)));
          n.h = Math.max(4, Math.round(drag.before.h + (p.y - drag.sy)));
        } else if (n.kind === 'text'){
          // ✏️ 6.287.0 — HIS OWN SUGGESTION, AND IT IS THE RIGHT SHAPE:
          // "I want the text to wrap as I make the text box smaller
          // instead of growing in size so I may need to hold shift down".
          // PLAIN drag moves the right edge and the words re-wrap to it;
          // ⇧drag is 6.188.0's glyph scale, unchanged. Two jobs on one
          // handle, and the modifier is what says which (6.248.0: two jobs
          // asked of one number cannot both be right).
          if (e.shiftKey){
            var d2 = ((p.x - drag.sx) + (p.y - drag.sy)) / 2;
            n.size = Math.max(10, Math.min(600, Math.round(drag.before.size + d2)));
          } else {
            var base = (typeof drag.before.w === 'number' && drag.before.w > 0)
                       ? drag.before.w : textW(octx || ctx, n);
            n.w = Math.max(n.size, Math.round(base + (p.x - drag.sx)));
          }
        } else {
          // 6.188.0 — drag the corner away from the note to grow it. The
          // anchor (n.x, n.y) does not move, so the text grows where it is
          // rather than wandering off under the pointer.
          var d2b = ((p.x - drag.sx) + (p.y - drag.sy)) / 2;
          n.size = Math.max(10, Math.min(600, Math.round(drag.before.size + d2b)));
        }
      } else {   // 'end' — one endpoint follows the mouse: stretch + rotate
        if (drag.part === 'p1'){ n.x1 = p.x; n.y1 = p.y; }
        else { n.x2 = p.x; n.y2 = p.y; }
      }
      redraw();
    });
    // 🚨 6.222.0 — ONE PLACE ENDS A DRAG, and more than one thing calls
    // it. LL: "if I miss a drag selection… the entire image looks
    // selected by some overlay pop-up and no matter I can't deflect
    // unless I escape and re-open." A mouseup that happens OUTSIDE this
    // window is never delivered to the page, so `drag` stayed set: every
    // later mousemove went on resizing the shape he had started —
    // a spotlight's veil growing to cover the whole picture, following
    // the pointer, with no button held and no way to put it down.
    function finishDrag(e){
      if (!drag) return;
      var d = drag; drag = null;
      if (d.mode === 'band'){
        band.style.display = 'none';
        var p = toCanvas(e);
        applyBlur(Math.min(sx, p.x), Math.min(sy, p.y),
                  Math.abs(p.x - sx), Math.abs(p.y - sy));
        return;
      }
      var n = d.note;
      if (d.fresh){
        var tiny = (n.kind === 'oval' || n.kind === 'hl' || n.kind === 'spot'
                    || n.kind === 'crop') ? (n.w < 4 || n.h < 4)
                 : (n.kind === 'mag') ? (n.r < 8)
                 : distPt(n.x1, n.y1, n.x2, n.y2) < 6;
        if (tiny){
          notes.splice(notes.indexOf(n), 1);   // a click, not a shape
          if (sel === n) sel = null;
        } else pushUndo({ op: 'add', note: n });
      } else {
        var changed = false, k;
        for (k in d.before){ if (d.before[k] !== n[k]){ changed = true; break; } }
        if (changed) pushUndo({ op: 'set', note: n, before: d.before });
        // 6.207.0 — a click, not a drag, on a text box with the Text tool:
        // open the words for editing right here
        if (d.clickEdit && !d.moved && !changed){ redraw(); startText(n); return; }
      }
      redraw();
    }
    window.addEventListener('mouseup', finishDrag);
    surface.addEventListener('dblclick', function(e){
      e.preventDefault();
      var hit = hitAt(toCanvas(e));
      if (hit && hit.note.kind === 'text'){ sel = hit.note; startText(hit.note); }
    });

    if (tin && tin.addEventListener) tin.addEventListener('keydown', function(e){
      if (e.stopPropagation) e.stopPropagation();
      // ⏎ 6.287.0 — LL: "I need to be able to use the return key in the
      // text box if I want to drop down a line." So ⏎ is a NEWLINE and
      // ⇧⏎ is done; clicking away still commits, as it always has. The
      // placeholder says both, because a key that used to finish and now
      // does not is the kind of change that reads as a bug.
      if (e.key === 'Enter' && e.shiftKey){ e.preventDefault(); commitText(); }
      else if (e.key === 'Escape'){ e.preventDefault(); cancelText(); }
    });

    window.addEventListener('keydown', function(e){
      if (textOpen()) return;   // the input's own handler owns the keys
      if (e.key === 'Escape') { e.preventDefault(); stashAndCancel(); }
      else if (e.metaKey && e.key === 'Enter') {
        e.preventDefault(); saveIt(e.shiftKey ? 'jpg' : 'png');
      }
      else if (e.metaKey && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault(); undoLast();
      }
      // 6.213.0 — the clipboard's image, and a fresh capture, both via Lua
      else if (e.metaKey && (e.key === 'v' || e.key === 'V')) { e.preventDefault(); say({ a: 'paste' }); }
      else if (e.metaKey && (e.key === 'a' || e.key === 'A')) { e.preventDefault(); say({ a: 'capture' }); }
      // 6.342.0 — ⌘D: drag an area, count DELAYSECS down, land THAT rect
      else if (e.metaKey && (e.key === 'd' || e.key === 'D')) { e.preventDefault(); say({ a: 'delay' }); }
      // 6.256.0 — ⌘F: the whole screen, now, with this window out of it
      else if (e.metaKey && (e.key === 'f' || e.key === 'F')) { e.preventDefault(); say({ a: 'full' }); }
      else if (e.metaKey && (e.key === 'o' || e.key === 'O')) { e.preventDefault(); say({ a: 'loadshot' }); }
      // 6.207.0 — ⏎ on a selected text box edits it (⌘⏎ is still save)
      else if (e.key === 'Enter' && !e.metaKey && sel && sel.kind === 'text') {
        e.preventDefault(); startText(sel);
      }
      // ✂️ 6.414.0 — ⏎ commits the crop. IT SITS AFTER THE TEXT BRANCH
      // ABOVE, and that ORDER is the whole rule: a selected text box
      // keeps the key it has had since 6.207.0, and everything else with
      // a rectangle drawn crops — because the hint on the rectangle says
      // ⏎ crops, and a key that silently does nothing when some other
      // mark is selected would be one more invisible condition (6.341.0).
      else if (e.key === 'Enter' && !e.metaKey && cropNote()) {
        e.preventDefault(); cropAsk();
      }
      else if ((e.key === 'Backspace' || e.key === 'Delete') && sel) {
        e.preventDefault();
        var i = notes.indexOf(sel);
        if (i >= 0){ pushUndo({ op: 'del', note: sel, index: i }); notes.splice(i, 1); }
        sel = null; redraw();
      }
      else if (!e.metaKey && !e.ctrlKey && !e.altKey) {
        if (e.key === 'b' || e.key === 'B') setTool('blur');
        else if (e.key === 't' || e.key === 'T') setTool('text');
        else if (e.key === 'a' || e.key === 'A') setTool('arrow');
        else if (e.key === 'l' || e.key === 'L') setTool('line');
        else if (e.key === 'o' || e.key === 'O') setTool('oval');
        else if (e.key === 'h' || e.key === 'H') setTool('hl');
        else if (e.key === 'c' || e.key === 'C') setTool('count');
        else if (e.key === 's' || e.key === 'S') setTool('spot');
        else if (e.key === 'm' || e.key === 'M') setTool('mag');
        else if (e.key === 'k' || e.key === 'K') setTool('crop');
      }
    });
  }
</script>
]]
    end

    -- ---- keeping the work across a close ---------------------------------
    -- Returns ok, why — it never throws and it never half-fills the slot:
    -- anything refused leaves ed.kept nil, so a later open restores the
    -- FILE rather than a fragment of an old session.
    function ed.rememberWork(path, img, notesJson)
        ed.kept = nil
        if not ed.keepOnClose then return false, "keeping is switched off" end
        if type(path) ~= "string" or path == "" then return false, "no image path" end
        img       = (type(img) == "string") and img or ""
        notesJson = (type(notesJson) == "string") and notesJson or ""
        -- The pattern is the whole of the safety check for the injection
        -- in buildHtml as well — keep the two in step.
        if not img:match("^data:image/png;base64,[A-Za-z0-9+/=]+$") then
            return false, "the page sent no usable image"
        end
        if #img > (tonumber(ed.keepMaxBytes) or 0) then
            return false, "the image is larger than the keep budget"
        end
        -- Notes are the cheap half and the blurs are already in the image,
        -- so an oversized notes payload costs the annotations, never the
        -- whole rescue.
        if notesJson == "" or #notesJson > (tonumber(ed.keepMaxNoteBytes) or 0) then
            notesJson = "[]"
        end
        ed.kept = { path = path, img = img, notes = notesJson }
        return true
    end

    -- ---- messages from the page ------------------------------------------
    local function handleMessage(body)
        if type(body) ~= "table" then return end
        if body.a == "save" then
            local data = tostring(body.data or "")
            -- png from ⌘⏎, jpeg from the "Small JPEG" path (6.88.0) —
            -- anything else is a malformed payload, refused before write
            local mime, b64 = data:match("^data:image/(%w+);base64,(.+)$")
            if not b64 or (mime ~= "png" and mime ~= "jpeg") then
                pcall(function() hs.alert.show("🖌 Save failed — bad image data", 3) end)
                warn("save message without a png/jpeg data URI")
                return
            end
            local ext = (mime == "jpeg") and "jpg" or "png"
            local bytes
            pcall(function() bytes = hs.base64.decode(b64) end)
            if not bytes or #bytes == 0 then
                pcall(function() hs.alert.show("🖌 Save failed — could not decode", 3) end)
                return
            end
            local outPath = ed.editedPathFor(ed.currentPath or ("screenshot." .. ext),
                                             ext)
            local f = io.open(outPath, "wb")
            if not f then
                pcall(function() hs.alert.show("🖌 Could not write " .. outPath, 4) end)
                return
            end
            f:write(bytes)
            f:close()
            -- 6.170.3: the copy runs off the main thread (screenshots'
            -- osascript task) when that module is here; the old sync
            -- decode + writeObjects stays as the fallback.
            local function tell(copied)
                pcall(function()
                    hs.alert.show(copied and "🖌 Saved (edited) · on the clipboard"
                                          or "🖌 Saved (edited) — clipboard copy failed", 2.5)
                end)
            end
            if core.has and core.has("screenshots.copyToPasteboard") then
                core.call("screenshots.copyToPasteboard", outPath, tell)
            else
                local copied = false
                pcall(function()
                    local img = hs.image.imageFromPath(outPath)
                    if img then copied = hs.pasteboard.writeObjects(img) and true end
                end)
                tell(copied)
            end
            say("saved " .. (outPath:match("[^/]+$") or outPath))
            ed.kept = nil   -- saved work is not lost work; a slot left
                            -- standing here would restore a STALE state
                            -- over the next open of the same shot
            ed.close()
        elseif body.a == "cancel" then
            -- 🗑 6.286.0 — a `ed.stopCloseBelt()` was written here and taken
            -- out again: ed.close() two lines down does it, on every path
            -- that reaches this branch, so no mutation could fail it. A
            -- guard no test can fail is dead code with a comment on it
            -- (6.199.0, and this project has made that call three times).
            local okKeep, whyKeep = ed.rememberWork(ed.currentPath, body.img,
                                                    body.notes)
            if okKeep then ed.closes.stashed = ed.closes.stashed + 1 end
            say(okKeep and "work kept for the next open of this shot"
                       or ("nothing kept — " .. tostring(whyKeep)))
            ed.close()
        elseif body.a == "dragStart" then
            -- 6.89.0 — the title-bar grab; Window Move drives the drag
            if _G.beginPanelDrag then _G.beginPanelDrag("screenshot editor") end
        elseif body.a == "paste" then
            local ok, why = ed.pasteImage()
            if not ok then pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end) end
        elseif body.a == "capture" then
            local ok, why = ed.addCapture()
            if not ok then pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end) end
        elseif body.a == "delay" then
            local ok, why = ed.addDelayed()
            if not ok then pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end) end
        elseif body.a == "full" then
            local ok, why = ed.addFullScreen()
            if not ok then pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end) end
        elseif body.a == "loadshot" then
            local ok, why = ed.loadPrior()
            if not ok then
                ed.lastGrowWhy = tostring(why)
                pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end)
            end
        elseif body.a == "crop" then
            -- ✂️ 6.414.0 — a refusal is SEEN, at the moment it happens
            -- (6.214.0), and it names the size rather than saying "no"
            local ok, why = ed.cropWith(body.x, body.y, body.w, body.h)
            if not ok then
                pcall(function() hs.alert.show("✂️ " .. tostring(why), 3) end)
            end
        elseif body.a == "size" then
            -- 6.258.0 — the page is the authority on its own canvas
            local w, h = tonumber(body.w), tonumber(body.h)
            if w and h and w > 0 and h > 0 then
                ed.canvasW, ed.canvasH, ed.pageSized = w, h, true
                -- ✂️ 6.414.0 — only a message that ASKS for it moves the
                -- window (additive, 6.299.0): the undo of a crop is the
                -- caller this exists for, and every older sender passes
                -- nothing and is unaffected.
                if body.fit then ed.resizeToCanvas(w, h) end
            end
        end
    end

    -- =====================================================================
    -- 🖼 6.258.0 — ⌘O: A PRIOR SHOT ONTO THIS ONE, AND THE CANVAS GROWS
    -- =====================================================================
    -- LL: "Allow me to load a prior screenshot on to the current
    -- screenshot and grow the canvas so that I can see both."
    --
    -- 🔑 GROW, NOT PASTE, AND THAT IS THE WHOLE DIFFERENCE. ⌘V and ⌘A
    -- already put an image ON the shot — scaled to 40% and floating over
    -- the pixels, which is right for "point at this" and wrong for "put
    -- these two side by side". This one makes ROOM: the canvas becomes
    -- big enough for both, the shot he was editing stays exactly where it
    -- was, and the loaded one is drawn at its OWN size in the new space.
    --
    -- 📐 THE OLD CONTENT NEVER MOVES, and that is a rule rather than a
    -- convenience: every note, blur, arrow and counter on the canvas is
    -- stored in CANVAS coordinates, so leaving the original at 0,0 means
    -- a grow cannot disturb one of them. Centring it — which would look
    -- tidier when the two shots are different widths — would move every
    -- mark he has already placed. Tidy is not worth that.
    --
    -- 🧭 WHICH WAY IT GROWS IS ARITHMETIC, NOT TASTE: along the SHORTER
    -- side, so two wide screenshots stack (2560x1440 twice over is
    -- 2560x2892, nearly square) rather than making a 5120-wide strip
    -- nothing can display. mouse_grid's 6.252.0 rule the other way up —
    -- there the LONGER side is the one worth splitting.

    -- PURE. Which way this canvas should grow, and why.
    function ed.growAxis(curW, curH)
        curW, curH = tonumber(curW) or 0, tonumber(curH) or 0
        if curW <= 0 or curH <= 0 then return nil, "the canvas has no size" end
        if curH < curW then
            return "down", "a wide shot grows downwards"
        end
        return "right", "a tall shot grows sideways"
    end

    -- PURE. The new canvas, and where the loaded shot lands in it. The
    -- canvas takes the WIDER (or taller) of the two so neither is
    -- cropped; the original keeps 0,0; the gap is surround, not image.
    function ed.growPlan(curW, curH, addW, addH, axis, gap)
        curW, curH = tonumber(curW) or 0, tonumber(curH) or 0
        addW, addH = tonumber(addW) or 0, tonumber(addH) or 0
        if curW <= 0 or curH <= 0 then return nil, "the canvas has no size" end
        if addW <= 0 or addH <= 0 then return nil, "that shot has no size" end
        gap = math.max(0, math.floor(tonumber(gap) or 0))
        if axis ~= "down" and axis ~= "right" then
            axis = ed.growAxis(curW, curH)
        end
        if axis == "right" then
            return { axis = "right",
                     w = curW + gap + addW,
                     h = math.max(curH, addH),
                     x = curW + gap, y = 0 },
                   ("%dx%d beside %dx%d"):format(addW, addH, curW, curH)
        end
        return { axis = "down",
                 w = math.max(curW, addW),
                 h = curH + gap + addH,
                 x = 0, y = curH + gap },
               ("%dx%d under %dx%d"):format(addW, addH, curW, curH)
    end

    -- ✂️ 6.414.0 — CROP, and the plan is Lua's for the same reason the
    -- grow's is: ONE copy of the rule, in the place the gate can drive
    -- it (6.258.0). The page hands over the rectangle it drew and does
    -- the pixels afterwards; it never decides what is legal.
    --
    -- PURE. Answers the rectangle to keep, and why — nil and a reason
    -- when there is nothing honest to do.
    -- 🚨 IT DOES NOT TRUST THE PAGE'S NORMALISATION. The corner drag
    -- already answers a positive w/h, and a service caller, a restored
    -- session or a later edit need not — so a negative side is turned
    -- round HERE, where the gate can prove it, rather than being assumed
    -- upstream (6.273.0: the weaker guard is the one nobody can see).
    -- 🔒 AND A RECTANGLE THAT COVERS THE WHOLE CANVAS IS REFUSED, which
    -- is the fixture a naive implementation agrees with on every other
    -- input (6.230.0): cropping to everything destroys the undo row's
    -- worth of pixels, resizes nothing, and reads as a key that did not
    -- work. The floor is the other refusal, and it NAMES THE SIZE,
    -- because "6 × 4" is the whole diagnosis of a mis-drag (6.336.0).
    function ed.cropPlan(cw, ch, x, y, w, h)
        cw, ch = math.floor(tonumber(cw) or 0), math.floor(tonumber(ch) or 0)
        if cw <= 0 or ch <= 0 then return nil, "the canvas has no size" end
        x, y = tonumber(x), tonumber(y)
        w, h = tonumber(w), tonumber(h)
        if not (x and y and w and h) then
            return nil, "drag a rectangle with the Crop tool (K) first"
        end
        -- a side dragged the other way is the same rectangle
        if w < 0 then x, w = x + w, -w end
        if h < 0 then y, h = y + h, -h end
        x, y = math.floor(x + 0.5), math.floor(y + 0.5)
        w, h = math.floor(w + 0.5), math.floor(h + 0.5)
        -- clamped INTO the canvas: a rectangle dragged off the edge is
        -- what the eye meant, and asking for pixels that are not there
        -- is a blank strip down one side
        if x < 0 then w, x = w + x, 0 end
        if y < 0 then h, y = h + y, 0 end
        if x > cw or y > ch then return nil, "that rectangle is off the shot" end
        w = math.min(w, cw - x)
        h = math.min(h, ch - y)
        local floorPx = math.max(1, math.floor(tonumber(ed.cropMin) or 32))
        if w < floorPx or h < floorPx then
            return nil, ("that rectangle is %d × %d — a crop is at least %d × %d")
                        :format(math.max(0, w), math.max(0, h), floorPx, floorPx)
        end
        if w >= cw and h >= ch then
            return nil, "that is the whole shot — there is nothing to crop away"
        end
        return { x = x, y = y, w = w, h = h },
               ("%d × %d kept out of %d × %d"):format(w, h, cw, ch)
    end

    -- PURE. The window a canvas of this size wants, clamped to a screen.
    -- 6.258.0 LIFTED this out of ed.open so the grow can ask the same
    -- question: two copies of this arithmetic is how a window that opens
    -- right comes to resize wrong (6.231.0, one function two callers).
    -- 🖼 6.270.0 — THE RAILS ARE RESERVED BEFORE THE IMAGE IS MEASURED,
    -- which is the whole of LL's "at a minimum, the canvas that the
    -- screenshot is placed on would be big enough to accommodate the tool
    -- buttons on each side". Two rails is 272 points that are not the
    -- picture, and a window sized for the picture alone puts them over it
    -- or squeezes it. The shot keeps the width it would have had; the
    -- WINDOW grows to carry the rails.
    -- 🔒 PURE, and the rail numbers arrive as ARGUMENTS with the config as
    -- the default (6.230.0), so the gate can drive a rail width this Mac
    -- has never shipped and prove the arithmetic rather than the constant.
    -- 📏 THE VERTICAL HALF IS A FLOOR, not padding: nine stacked tools
    -- need `railMinH`, so a tiny shot no longer opens a window too short
    -- to show its own toolbar. The rails scroll past that, they never clip.
    function ed.windowSizeFor(imgW, imgH, sf, opts)
        imgW, imgH = tonumber(imgW) or 0, tonumber(imgH) or 0
        if imgW <= 0 or imgH <= 0 then imgW, imgH = 900, 600 end
        sf = (type(sf) == "table" and sf.w and sf.h) and sf
             or { x = 0, y = 0, w = 1440, h = 900 }
        opts = (type(opts) == "table") and opts or {}
        local railW   = math.max(0, tonumber(opts.railW)    or tonumber(ed.railW)      or 0)
        local headerH = math.max(0, tonumber(opts.headerH)  or tonumber(ed.dragStripH) or 0)
        local railMin = math.max(0, tonumber(opts.railMinH) or tonumber(ed.railMinH)   or 0)
        local rails   = railW * 2
        -- 📐 6.407.0 — TWO CEILINGS, AND THE SMALLER WINS. A fraction
        -- alone is wrong on a very large display and an absolute alone is
        -- wrong on a small one, so both are asked and neither is trusted
        -- by itself. A frac of 0 or a cap of 0 from a settings typo must
        -- not produce a window of nothing, so each floors at something
        -- usable rather than being taken at its word.
        local frac = tonumber(opts.maxFrac) or tonumber(ed.maxFrac) or 0.80
        if frac <= 0 or frac > 1 then frac = 0.80 end
        local absW = math.max(1, tonumber(opts.maxW) or tonumber(ed.maxW) or 1600)
        local absH = math.max(1, tonumber(opts.maxH) or tonumber(ed.maxH) or 1100)
        local fracW, fracH = sf.w * frac, sf.h * frac
        local capW, capH   = math.min(fracW, absW), math.min(fracH, absH)
        local capWwhy = (absW < fracW) and "the maximum window width" or (tostring(math.floor(frac * 100)) .. "% of the screen")
        local capHwhy = (absH < fracH) and "the maximum window height" or (tostring(math.floor(frac * 100)) .. "% of the screen")
        -- The room left for the PICTURE is the window budget less the
        -- rails and the header; a budget narrower than its own rails
        -- would give a negative scale, so the picture floors at nothing
        -- rather than inverting.
        local roomW = math.max(1, capW - rails - 28)
        local roomH = math.max(1, capH - headerH - 28)
        local scale = math.max(0, math.min(1, roomW / imgW, roomH / imgH))
        local wantW = math.floor(imgW * scale) + 28 + rails
        local wantH = math.floor(imgH * scale) + headerH + 28
        -- 🖼 THE FLOOR IS THE TOOLS (6.270.0): nine stacked buttons plus
        -- the header, and enough width that the picture is not a sliver
        -- between two rails.
        local floorW = math.max(tonumber(ed.minW) or 720, rails + 180)
        local floorH = math.max(tonumber(ed.minH) or 320, railMin + headerH)
        local w, h = math.max(wantW, floorW), math.max(wantH, floorH)
        local whyW = (w > wantW) and "floored so the tool rails fit"
                     or ((scale < 1) and ("capped at " .. capWwhy) or "fitted to the picture")
        local whyH = (h > wantH) and "floored so the tool rails fit"
                     or ((scale < 1) and ("capped at " .. capHwhy) or "fitted to the picture")
        -- 🚨 AND THE SCREEN WINS. The floor above can push past the
        -- ceiling on a small display, and a window taller than the screen
        -- is a window whose buttons cannot be clicked — strictly worse
        -- than rails that scroll, which is what they already do.
        local roomOnScreen = 20
        if w > sf.w - roomOnScreen then
            w = math.max(1, math.floor(sf.w - roomOnScreen))
            whyW = "clamped to the screen — the left rail will scroll"
        end
        if h > sf.h - roomOnScreen then
            h = math.max(1, math.floor(sf.h - roomOnScreen))
            whyH = "clamped to the screen — the rails will scroll"
        end
        -- the third value is additive (6.299.0): both existing callers
        -- read two and are unchanged
        return w, h, whyW .. " × " .. whyH
    end

    -- 🔒 ONE DOOR, ONE SHAPE (6.213.0). Both ⌘V/⌘A's addImage and this
    -- release's growTo hand a data URI to WebKit inside a JavaScript
    -- string literal, so both ask the same question in the same place —
    -- a quote in a URI would end that literal, and a script WebKit cannot
    -- parse is dropped in SILENCE.
    function ed.imageURIok(url)
        url = tostring(url or "")
        if url:match("^data:image/%w+;base64,[A-Za-z0-9+/=]+$") then return true end
        return false, "not a usable image"
    end

    -- What the canvas measures right now, and WHO says so. Three states,
    -- because "the page told me 2560x1440" and "nobody has told me
    -- anything and I am using the file I opened" must not read alike.
    function ed.canvasSize()
        if ed.pageSized and (tonumber(ed.canvasW) or 0) > 0 then
            return ed.canvasW, ed.canvasH, "the page said so"
        end
        if (tonumber(ed.canvasW) or 0) > 0 then
            return ed.canvasW, ed.canvasH, "read off the file at open"
        end
        return nil, nil, "not known"
    end

    -- The window follows the canvas. A refusal here is cosmetic — the
    -- pixels are already there and the canvas scales to fit — so it is
    -- counted and never fails the grow.
    function ed.resizeToCanvas(w, h)
        if not ed.webview then return false, "the editor is not open" end
        local screen = core.resolveBaseScreen and core.resolveBaseScreen()
                       or (hs.screen and hs.screen.mainScreen and hs.screen.mainScreen())
        local sf = { x = 0, y = 0, w = 1440, h = 900 }
        pcall(function() if screen then sf = screen:frame() end end)
        local ww, wh = ed.windowSizeFor(w, h, sf)
        local ok = pcall(function()
            local f = ed.webview:frame()
            ed.webview:frame({ x = f.x, y = f.y, w = ww, h = wh })
        end)
        if not ok then return false, "the window would not resize" end
        return true
    end

    -- 🖼 The grow itself. Lua decides the geometry (PURE, above) and the
    -- page is GIVEN the numbers — it resizes, redraws the old pixels at
    -- 0,0 and draws the new shot at the offset. A page that worked the
    -- plan out for itself would be a second copy of the rule.
    function ed.growWith(url, addW, addH)
        if not ed.webview then return false, "the editor is not open" end
        local okURI, whyURI = ed.imageURIok(url)
        if not okURI then return false, whyURI end
        local curW, curH, who = ed.canvasSize()
        if not curW then
            return false, "the page has not said how big the canvas is"
        end
        local plan, why = ed.growPlan(curW, curH, addW, addH, nil, ed.growGap)
        if not plan then return false, why end

        ed.grows.asked = ed.grows.asked + 1
        -- 6.415.0 — the shot's OWN measured size rides along, so the mark
        -- is drawn at the size the room was planned for (additive, so a
        -- page that ignores the two extra arguments is unchanged).
        local js = ("growTo('%s', %d, %d, %d, %d, '%s', %d, %d)")
                   :format(tostring(url), plan.w, plan.h, plan.x, plan.y,
                           tostring(ed.growFill):gsub("'", ""),
                           math.floor(tonumber(addW) or 0),
                           math.floor(tonumber(addH) or 0))
        local okEval, err = pcall(function()
            if type(ed.webview.evaluateJavaScript) ~= "function" then
                error("no evaluateJavaScript", 0)
            end
            ed.webview:evaluateJavaScript(js)
        end)
        if not okEval then
            ed.grows.failed = ed.grows.failed + 1
            ed.lastGrowWhy = "could not hand the shot to the page (" .. tostring(err) .. ")"
            return false, ed.lastGrowWhy
        end
        ed.grows.landed = ed.grows.landed + 1
        -- 🖼 SAID AT THE MOMENT IT HAPPENS, and once (6.398.0 · 6.285.0).
        -- The shot lands as a mark he can DRAG now, which is the whole
        -- release and is invisible until he tries one — and a line he
        -- reads on every load is a line he stops reading.
        if not ed.growSaid then
            ed.growSaid = true
            pcall(function()
                hs.alert.show("🖼 Drag it where you want — it is a mark now."
                              .. "  ⌘Z undoes the whole thing.", 4)
            end)
        end
        ed.lastGrow = why .. " · " .. plan.axis .. " · canvas now "
                      .. plan.w .. "x" .. plan.h .. " (" .. who .. ")"
        -- The page will say its new size back; this is the belt, so a
        -- second ⌘O still has a number to work from if it does not.
        ed.canvasW, ed.canvasH = plan.w, plan.h
        ed.resizeToCanvas(plan.w, plan.h)
        return true
    end

    -- ✂️ The crop itself. The page asks, Lua decides, the page does the
    -- pixels — and only Lua can resize the WINDOW, which a crop needs:
    -- the canvas is scaled to fit, so a cropped shot left in the old
    -- window is drawn BIGGER and blurrier than it was.
    function ed.cropWith(x, y, w, h)
        if not ed.webview then return false, "the editor is not open" end
        local curW, curH, who = ed.canvasSize()
        if not curW then
            return false, "the page has not said how big the canvas is"
        end
        ed.crops.asked = ed.crops.asked + 1
        local plan, why = ed.cropPlan(curW, curH, x, y, w, h)
        if not plan then
            ed.crops.refused = ed.crops.refused + 1
            ed.lastCropWhy = why
            return false, why
        end
        local okEval, err = pcall(function()
            if type(ed.webview.evaluateJavaScript) ~= "function" then
                error("no evaluateJavaScript", 0)
            end
            ed.webview:evaluateJavaScript(("cropTo(%d, %d, %d, %d)")
                :format(plan.x, plan.y, plan.w, plan.h))
        end)
        if not okEval then
            ed.crops.refused = ed.crops.refused + 1
            ed.lastCropWhy = "could not ask the page to crop (" .. tostring(err) .. ")"
            return false, ed.lastCropWhy
        end
        ed.crops.landed = ed.crops.landed + 1
        ed.lastCrop = why .. " (" .. who .. ")"
        ed.lastCropWhy = nil
        -- the belt, as the grow has: the page says its new size back, and
        -- this means a second crop still has a number if it does not
        ed.canvasW, ed.canvasH = plan.w, plan.h
        ed.resizeToCanvas(plan.w, plan.h)
        return true
    end

    -- ⌘O — pick a prior shot. The list is the screenshots module's own
    -- (it owns that folder); this module keeps no second listing.
    function ed.loadPrior()
        if not ed.webview then return false, "the editor is not open" end
        if not (core.has and core.has("screenshots.list")) then
            return false, "Load shot needs the screenshots module, which is not loaded"
        end
        local list = core.call("screenshots.list")
        if type(list) ~= "table" then return false, "the screenshots folder could not be listed" end
        local rows, n = {}, 0
        for _, it in ipairs(list) do
            -- the shot he is already editing is not a prior shot
            if it.path ~= ed.currentPath then
                n = n + 1
                if n > (tonumber(ed.growRows) or 40) then break end
                rows[#rows + 1] = {
                    text = it.name,
                    subText = os.date("%Y-%m-%d %H:%M", tonumber(it.mtime) or 0)
                              .. "   ·   " .. math.floor((tonumber(it.size) or 0) / 1024) .. " KB",
                    path = it.path,
                }
            end
        end
        if #rows == 0 then return false, "no other screenshots in that folder" end

        local ch = hs.chooser.new(function(choice)
            _G.choosers.editorLoadShot = nil
            if not (choice and choice.path) then return end
            local b64 = readFileBase64(choice.path)
            if not b64 then
                pcall(function() hs.alert.show("🖌 Could not read " .. choice.path, 3) end)
                return
            end
            local w, h = 0, 0
            pcall(function()
                local im = hs.image.imageFromPath(choice.path)
                local sz = im and im:size()
                if sz then w, h = sz.w, sz.h end
            end)
            local ok, why = ed.growWith("data:image/png;base64," .. b64, w, h)
            if not ok then
                ed.lastGrowWhy = tostring(why)
                pcall(function() hs.alert.show("🖌 " .. tostring(why), 3) end)
            end
        end)
        if not ch then return false, "the picker could not open" end
        _G.choosers.editorLoadShot = ch
        pcall(function() ch:placeholderText("A prior screenshot to put beside this one") end)
        pcall(function() ch:choices(rows) end)
        if core.showPopup then core.showPopup(ch) else pcall(function() ch:show() end) end
        return true
    end

    -- 🖌 6.213.0 — an image INTO the page. One shape for both doors
    -- (clipboard and capture): a png/jpeg data URI, its size, pushed with
    -- evaluateJavaScript into addImage(). Returns ok, why — a refused
    -- URI never reaches WebKit (a script it cannot parse is dropped in
    -- silence, and the note would simply not appear).
    function ed.pushImage(url, w, h)
        if not ed.webview then return false, "the editor is not open" end
        url = tostring(url or "")
        local okURI, whyURI = ed.imageURIok(url)   -- 6.258.0: the ONE shape
        if not okURI then return false, whyURI end
        w, h = tonumber(w) or 0, tonumber(h) or 0
        if w <= 0 or h <= 0 then return false, "the image has no size" end
        local js = ("addImage('%s', %d, %d)"):format(url, math.floor(w), math.floor(h))
        local okEval, err = pcall(function()
            if type(ed.webview.evaluateJavaScript) ~= "function" then error("no evaluateJavaScript") end
            ed.webview:evaluateJavaScript(js)
        end)
        if not okEval then return false, "could not hand the image to the page (" .. tostring(err) .. ")" end
        ed.pushed = (ed.pushed or 0) + 1
        return true
    end

    -- ⌘V — the clipboard's image onto the shot
    function ed.pasteImage()
        local img
        pcall(function() img = hs.pasteboard.readImage() end)
        if not img then return false, "Nothing to paste — the clipboard has no image" end
        local url, size
        pcall(function() url = img:encodeAsURLString() end)
        pcall(function() size = img:size() end)
        if not url then return false, "the clipboard image could not be encoded" end
        return ed.pushImage(url, size and size.w, size and size.h)
    end

    -- ⌘A — drag an area of the screen; the capture lands on the shot
    function ed.addCapture()
        if not (core.has and core.has("screenshots.captureAreaTo")) then
            return false, "Add capture needs the screenshots module, which is not loaded"
        end
        local started = core.call("screenshots.captureAreaTo", function(path, why)
            if not path then
                pcall(function() hs.alert.show("🖌 Capture did not land — " .. tostring(why), 3) end)
                return
            end
            local b64 = readFileBase64(path)
            local w, h = 0, 0
            pcall(function()
                local im = hs.image.imageFromPath(path)
                local sz = im and im:size()
                if sz then w, h = sz.w, sz.h end
            end)
            local ok, whyPush = false, "the capture could not be read"
            if b64 then ok, whyPush = ed.pushImage("data:image/png;base64," .. b64, w, h) end
            if not ok then pcall(function() hs.alert.show("🖌 " .. tostring(whyPush), 3) end) end
        end)
        if started == false then return false, "the screen selector could not open" end
        return true
    end

    -- =====================================================================
    -- ⏲ 6.255.0 — ⌘D: A DELAYED FULL-SCREEN CAPTURE, ONTO THE SHOT
    -- =====================================================================
    -- LL: "Add a delayed screenshot feature with a delay of 5 seconds."
    --
    -- 🪟 THE EDITOR GETS OUT OF THE WAY, and that is not a nicety: a
    -- FULL-SCREEN grab taken with this window open is a picture of this
    -- window. ⌘A can be worked around by moving the editor; a whole-screen
    -- shot cannot. So the window hides for the countdown — which is also
    -- the only reason a delay is worth having, since the five seconds are
    -- what the menu / hover / dialog is arranged in.
    --
    -- 🚨 AND A HIDDEN WINDOW THAT NEVER COMES BACK IS HIS WORK GONE. It is
    -- not deleted — the notes, the blurs and the image are all still in a
    -- live page — but a panel he cannot see is indistinguishable from one,
    -- and he has no key that reopens it. So:
    --   · the BELT is armed BEFORE the window hides (6.246.0's ordering),
    --     in its own held slot (6.196.1), and brings it back at the
    --     countdown plus `delayGraceSecs` whatever happened to the capture;
    --   · a Mac that cannot arm that timer DOES NOT HIDE AT ALL — the shot
    --     contains the editor, which is a bad picture and not a lost one;
    --   · the belt's return takes the 🔔 door, because a window that came
    --     back late is a fault he should be told about, not a silence.

    -- PURE. May a screen grab start, and if not, WHY not — the refusals
    -- are different facts and the caller says which. `needDelay` is the
    -- PARAMETER that tells ⌘D from ⌘F, rather than a second plan that
    -- would drift: a countdown of zero is a broken ⌘D and a perfectly
    -- good ⌘F (6.196.0's choicesFrom rule, in a guard).
    -- 📐 6.342.0 — `what` is the SURFACE, and it is a parameter for the
    -- same reason `needDelay` is: ⌘D captures the area he drags and ⌘F
    -- captures the whole screen, and a plan that says "the whole screen"
    -- about both is a reason that lies on one of its two callers. Default
    -- unchanged, so every existing caller reads exactly as it did.
    function ed.grabPlan(open, canAsk, busy, secs, needDelay, what)
        what = what or "the whole screen"
        if not open then return false, "the editor is not open" end
        if not canAsk then
            return false, "A screen capture needs the screenshots module, which is not loaded"
        end
        if busy then return false, "a screen capture is already running" end
        secs = tonumber(secs) or 0
        if needDelay and secs <= 0 then
            return false, "the delay is set to 0 — use 🖥 Full screen instead"
        end
        if secs > 0 then
            return true, ("%d second(s), %s"):format(math.floor(secs), what)
        end
        return true, what .. ", now"
    end

    -- Never throws. Answers whether the window is hidden NOW, which is
    -- what the belt and the report both ask.
    function ed.hideForShot()
        if not ed.webview then return false end
        local ok = pcall(function() ed.webview:hide() end)
        if ok then ed.hidden = true end
        return ok
    end

    -- Idempotent, and the only way back. Called by the capture callback,
    -- by the belt, and by every refusal on the way in.
    function ed.showAgain()
        if not ed.webview then ed.hidden = false return false end
        -- 🚨 6.391.0 — THIS LINE LOOKED LIKE IT READ THE ANSWER AND DID
        -- NOT. pcall's first value is "it did not throw"; a webview that
        -- RETURNS false was recorded as a window that came back. This is
        -- the window ⌘D and ⌘F hide on purpose and the belt returns, so
        -- a wrong answer here is an editor he cannot see and did not close.
        local shown
        if _G.showWebviewSafely then
            shown = _G.showWebviewSafely(ed.webview, "Screenshot editor")
        else
            shown = pcall(function() ed.webview:show() end)
        end
        pcall(function() ed.webview:bringToFront(true) end)
        -- 6.251.0 — bringToFront RAISES; it does not make KEY, and only a
        -- key window is handed the keyboard. ONE attempt, not a chase: the
        -- window was key a moment ago, and a Mac that refuses is a click,
        -- named in the report rather than retried at it.
        pcall(function()
            local w = ed.webview:hswindow()
            if w then w:focus() end
        end)
        ed.hidden = false
        return shown
    end

    function ed.armDelayBelt(secs)
        if ed.delayTimer then pcall(function() ed.delayTimer:stop() end) end
        ed.delayTimer = nil
        local wait = num(secs, 5) + num(ed.delayGraceSecs, 3)
        pcall(function()
            ed.delayTimer = hs.timer.doAfter(wait, function()
                -- 📐 6.342.0 — A SELECTOR STILL OPEN IS OVER. ⌘D now
                -- waits on a hand, so the belt can fire with the overlay
                -- still up; bringing the window back under a live
                -- selector would put the editor in the very shot it hid
                -- to stay out of. Cancelling it resolves the run through
                -- the ordinary cancel path, which clears `hidden` and
                -- `delayBusy` — so the guard on the next line then
                -- returns and this belt does NOT also count a late
                -- return. A ⌘F run has no selector and this is a no-op.
                ed.stopRegion()
                if not (ed.hidden or ed.delayBusy) then return end
                ed.delays.late = ed.delays.late + 1
                ed.delayBusy = false
                ed.showAgain()
                if core.degrade then
                    core.degrade("Screenshot editor",
                        "the delayed capture never answered — the window is back")
                end
            end)
        end)
        return ed.delayTimer ~= nil
    end

    -- ⏲ ⌘D and 🖥 ⌘F are ONE body with two arguments. The only
    -- difference that matters is WHO waits: with a countdown,
    -- screencapture's own -T covers the time the window needs to leave
    -- the screen; without one, nothing does, so `hideSettleSecs` is a
    -- held timer in its OWN slot (6.196.1) between the hide and the ask.
    function ed.grabScreen(secs, needDelay)
        local canAsk = (core.has and core.has("screenshots.captureScreenTo")) and true or false
        local ok, why = ed.grabPlan(ed.webview ~= nil, canAsk,
                                    ed.delayBusy == true, secs, needDelay)
        if not ok then return false, why end

        secs = math.floor(num(secs, 0))
        local settle = needDelay and 0 or num(ed.hideSettleSecs, 0.4)
        local state = { answered = false }
        ed.delays.asked = ed.delays.asked + 1
        ed.delayBusy = true

        local hid = false
        if ed.hideForDelay then
            if ed.armDelayBelt(secs + settle) then
                hid = ed.hideForShot()
            else
                say("no timer to bring the window back — it stays on screen, "
                    .. "so the shot will contain the editor")
            end
        end
        if needDelay then
            pcall(function()
                hs.alert.show(("📸 Full screen in %d seconds — set it up…"):format(secs), 2.5)
            end)
        end

        local function landed(path, whyShot)
            state.answered = true
            ed.delayBusy = false
            ed.stopSettle()
            ed.showAgain()
            if not path then
                ed.delays.failed = ed.delays.failed + 1
                ed.lastDelayWhy = tostring(whyShot)
                if core.degrade then
                    core.degrade("Screenshot editor",
                        "the screen capture did not land — " .. tostring(whyShot))
                end
                return
            end
            local b64 = readFileBase64(path)
            local w, h = 0, 0
            pcall(function()
                local im = hs.image.imageFromPath(path)
                local sz = im and im:size()
                if sz then w, h = sz.w, sz.h end
            end)
            local okPush, whyPush = false, "the capture could not be read"
            if b64 then
                okPush, whyPush = ed.pushImage("data:image/png;base64," .. b64, w, h)
            end
            if okPush then
                ed.delays.landed = ed.delays.landed + 1
                ed.lastDelayWhy  = nil
            else
                ed.delays.failed = ed.delays.failed + 1
                ed.lastDelayWhy  = tostring(whyPush)
                if core.degrade then core.degrade("Screenshot editor", tostring(whyPush)) end
            end
        end

        local function ask()
            local started = core.call("screenshots.captureScreenTo", secs, landed)
            if started == false and not state.answered then
                ed.delayBusy = false
                ed.showAgain()
                if core.degrade then
                    core.degrade("Screenshot editor", "the capture could not be started")
                end
            end
        end

        -- 🚨 THE WINDOW HAS TO BE GONE BEFORE THE SHUTTER. With a
        -- countdown it always is; without one the ask waits a beat, and a
        -- Mac that cannot arm that beat asks straight away rather than
        -- never — a shot with the editor in it beats no shot at all.
        if hid and settle > 0 then
            ed.stopSettle()
            pcall(function() ed.settleTimer = hs.timer.doAfter(settle, ask) end)
            if not ed.settleTimer then ask() end
        else
            ask()
        end
        return true
    end

    function ed.stopSettle()
        if ed.settleTimer then pcall(function() ed.settleTimer:stop() end) end
        ed.settleTimer = nil
    end

    -- 📐 6.342.0 — the one way to end a ⌘D selector from outside it.
    -- A no-op unless a region grab is waiting on a rectangle, and it
    -- goes through the module that OWNS the selector rather than
    -- reaching for `shots.*` (there is no second copy of the teardown).
    function ed.stopRegion()
        if not ed.regionRunning then return end
        ed.regionRunning = false
        if core.has and core.has("screenshots.cancelSelect") then
            pcall(function() core.call("screenshots.cancelSelect") end)
        end
    end

    -- 📐 6.342.0 — ⌘D IS THE ⇧⌘5 SHAPE: drag the area, THEN the
    -- countdown, THEN that rectangle. LL asked for exactly this, on his
    -- own report of what 6.255.0 did ("⌘D says I have five seconds to
    -- setup, shows no crosshairs, and then … a screenshot of the desktop
    -- is placed on it").
    -- 🪜 TWO BELT LEGS, AND THAT IS THE WHOLE RISK IN THIS RELEASE.
    -- ⌘F and the old ⌘D both knew exactly how long the editor would be
    -- hidden, so ONE belt armed before the hide covered it (6.255.0).
    -- This one waits on a hand: the selector may be open for a second or
    -- a minute. So leg 1 is a long last resort for the drag, and the
    -- moment a rectangle exists leg 2 re-arms SHORT for the countdown and
    -- the shutter (6.304.0: one belt per leg, re-armed for the second —
    -- a single belt would either fire over a live selector or leave the
    -- window hidden a minute and a half after a capture had died).
    -- 🚨 AND THE SETTLE BEAT MATTERS HERE IN A WAY IT DID NOT BEFORE:
    -- the old ⌘D hid behind screencapture's own -T, so nothing of ours
    -- had to wait for the window to leave. Now the SELECTOR draws next,
    -- and a selector drawn over a window that has not gone yet is an
    -- area he drags around the editor (6.256.0's finding, one surface on).
    function ed.grabRegion(secs)
        local canAsk = (core.has and core.has("screenshots.captureRegionTo"))
                       and true or false
        local ok, why = ed.grabPlan(ed.webview ~= nil, canAsk,
                                    ed.delayBusy == true, secs, true,
                                    "the area you drag")
        if not ok then return false, why end

        secs = math.floor(num(secs, 0))
        local settle = num(ed.hideSettleSecs, 0.4)
        local state = { answered = false }
        ed.delays.asked = ed.delays.asked + 1
        ed.delayBusy = true
        ed.regionRunning = true

        local hid, belted = false, false
        if ed.hideForDelay then
            belted = ed.armDelayBelt(num(ed.regionGraceSecs, 90))
            if belted then
                hid = ed.hideForShot()
            else
                -- 6.255.0's rule, unchanged: a shot containing the editor
                -- is a bad picture and a window that cannot come back is
                -- lost work, so a Mac with no timer does not hide at all.
                say("no timer to bring the window back — it stays on screen, "
                    .. "so the area may contain the editor")
            end
        end

        local function picked(rect)
            -- 🚨 6.342.0's SWEEP FOUND THIS GUARD UNKILLABLE as
            -- `state.answered`, and the reason is the finding: the belt
            -- does NOT set that flag, so the one case it was meant to
            -- cover — leg 1 giving up while the selector is still open —
            -- walked straight past it. On a Mac with no
            -- `screenshots.cancelSelect` provider `stopRegion` cannot end
            -- the overlay, so he can still drag a rectangle a minute
            -- after being told the capture never answered; re-arming a
            -- belt and shouting a countdown for a run that is over is
            -- 6.304.0's generation problem in its simplest form. The
            -- run's own liveness is the fact to ask (6.273.0: when a fix
            -- lands on a line no mutation can kill, the line is not the
            -- finding, the missing check is).
            if not ed.delayBusy then return end
            if belted then ed.armDelayBelt(secs + settle) end
            ed.regionRunning = false   -- the selector is gone; the shot is next
            pcall(function()
                hs.alert.show(("📐 %d × %d in %d seconds — set it up…")
                              :format(math.floor(rect and rect.w or 0),
                                      math.floor(rect and rect.h or 0), secs), 2.5)
            end)
        end

        local function landed(path, whyShot, how)
            if state.answered then return end
            state.answered = true
            ed.regionRunning = false
            ed.delayBusy = false
            ed.stopSettle()
            ed.showAgain()
            -- 🚨 A CANCEL IS NOT A FAILURE and must not take the 🔔 door:
            -- he pressed Esc, or his drag was too small, and a tool that
            -- shouts about a decision he made is a tool he stops reading
            -- (6.269.0). Counted apart, said quietly, nothing degraded.
            if how == "cancelled" then
                ed.delays.cancelled = num(ed.delays.cancelled, 0) + 1
                pcall(function()
                    hs.alert.show("📐 Nothing captured — " .. tostring(whyShot)
                                  .. ". The editor is back.", 2.5)
                end)
                return
            end
            if not path then
                ed.delays.failed = ed.delays.failed + 1
                ed.lastDelayWhy = tostring(whyShot)
                if core.degrade then
                    core.degrade("Screenshot editor",
                        "the area capture did not land — " .. tostring(whyShot))
                end
                return
            end
            local b64 = readFileBase64(path)
            local w, h = 0, 0
            pcall(function()
                local im = hs.image.imageFromPath(path)
                local sz = im and im:size()
                if sz then w, h = sz.w, sz.h end
            end)
            local okPush, whyPush = false, "the capture could not be read"
            if b64 then
                okPush, whyPush = ed.pushImage("data:image/png;base64," .. b64, w, h)
            end
            if okPush then
                ed.delays.landed = ed.delays.landed + 1
                ed.lastDelayWhy  = nil
            else
                ed.delays.failed = ed.delays.failed + 1
                ed.lastDelayWhy  = tostring(whyPush)
                if core.degrade then core.degrade("Screenshot editor", tostring(whyPush)) end
            end
        end

        local function ask()
            local started = core.call("screenshots.captureRegionTo", secs, landed, picked)
            if started == false and not state.answered then
                ed.regionRunning = false
                ed.delayBusy = false
                ed.showAgain()
                if core.degrade then
                    core.degrade("Screenshot editor", "the capture could not be started")
                end
            end
        end

        if hid and settle > 0 then
            ed.stopSettle()
            pcall(function() ed.settleTimer = hs.timer.doAfter(settle, ask) end)
            if not ed.settleTimer then ask() end
        else
            ask()
        end
        return true
    end

    function ed.addDelayed()   return ed.grabRegion(ed.delaySecs)        end
    function ed.addFullScreen() return ed.grabScreen(0, false)           end

    -- 🔎 6.255.0 — THIS MODULE HAD NO REPORT, which is why a delayed
    -- capture that hid the window and did not come back would have been a
    -- photograph and a guess (6.228.0's four true reports that named
    -- nothing). Three states that must not read alike: never asked · asked
    -- and failed · landed — plus the belt's own count, because a window
    -- brought back by the belt means the capture never answered at all.
    function _G.screenshotEditorReport()
        local d = ed.delays or {}
        local L = { "🖌 SCREENSHOT EDITOR" }
        L[#L + 1] = "   window  : " .. (ed.webview
                        and ("open on " .. tostring(ed.currentPath or "?")
                             .. (ed.hidden and "  ⚠️ HIDDEN right now" or ""))
                        or "closed")
        L[#L + 1] = "   kept    : " .. (ed.kept
                        and ("work held for " .. tostring(ed.kept.path))
                        or "nothing kept from a cancel")
        -- 🚪 6.286.0 — WHICH DOOR, AND WHETHER THE WORK SURVIVED IT.
        -- "closed" used to be one fact; it was four, and three of them
        -- lost his marks without saying anything (6.196.1).
        local c = ed.closes or {}
        L[#L + 1] = string.format(
            "   closing : %d ask(ed) the page · %d handed work back · "
         .. "%d closed on the belt%s · %d closed at once (no page to ask)",
            c.asked or 0, c.stashed or 0, c.belt or 0,
            (c.belt or 0) > 0 and " ⚠️" or "", c.atOnce or 0)
        L[#L + 1] = "   ↳ last  : " .. tostring(c.last or "nothing has closed "
                        .. "the editor this session")
        if (c.belt or 0) > 0 then
            L[#L + 1] = "   ⚠️ a belt close means the page did not answer within "
                        .. tostring(ed.closeGraceSecs) .. "s — those marks were"
                        .. " not kept, and that is the bug to report"
        end
        -- 🖼 6.270.0 — the layout, and what it RESERVES. Printed because
        -- "the buttons are on top of the picture" and "the picture is
        -- squeezed" look the same in a screenshot and are opposite faults.
        L[#L + 1] = string.format(
            "   layout  : tools left · actions right · %d pt each rail, "
         .. "so a window reserves %d pt that is not the picture "
         .. "(floor %d pt tall, to fit the taller rail)",
            math.floor(num(ed.railW, 136)), math.floor(num(ed.railW, 136)) * 2,
            math.floor(num(ed.railMinH, 344)) + math.floor(num(ed.dragStripH, 54)))
        -- 📐 6.407.0 — THE CEILING, AND WHICH RULE DECIDED THIS WINDOW.
        -- "it is growing too big" and "it shrank until the tools were
        -- unusable" are opposite complaints about one function, and a
        -- size on its own cannot say which bound produced it.
        do
            local scr = core.resolveBaseScreen and core.resolveBaseScreen()
                        or (hs.screen and hs.screen.mainScreen and hs.screen.mainScreen())
            local okF, sf = pcall(function() return scr and scr:frame() end)
            sf = (okF and type(sf) == "table" and sf.w) and sf or { x = 0, y = 0, w = 1440, h = 900 }
            local frac = num(ed.maxFrac, 0.80)
            L[#L + 1] = ("   ceiling : %d%% of the screen (%d × %d here), and never more"
                      .. " than %d × %d points"):format(
                            math.floor(frac * 100), math.floor(sf.w * frac),
                            math.floor(sf.h * frac), math.floor(num(ed.maxW, 1600)),
                            math.floor(num(ed.maxH, 1100)))
            local cw, ch, cwhy = ed.canvasSize()
            if (tonumber(cw) or 0) > 0 then
                local ww, wh, why = ed.windowSizeFor(cw, ch, sf)
                L[#L + 1] = ("   sized   : %d × %d pt for a %d × %d shot — %s"):format(
                                ww, wh, math.floor(cw), math.floor(ch), tostring(why))
                if tostring(why):find("clamped to the screen", 1, true) then
                    L[#L + 1] = "   ↳ this screen cannot hold the tool rails at full height,"
                                .. " so the window is the screen's and the rails scroll"
                end
                L[#L + 1] = "   ↳ canvas : " .. tostring(cwhy)
            else
                L[#L + 1] = "   sized   : no shot has been opened this session"
            end
        end
        local asked = num(d.asked, 0)
        if asked == 0 then
            L[#L + 1] = "   capture : never asked this session (⌘D or ⌘F in the editor)"
        else
            L[#L + 1] = ("   capture : %d asked · %d landed · %d failed"):format(
                            asked, num(d.landed, 0), num(d.failed, 0))
            if ed.lastDelayWhy then
                L[#L + 1] = "   ↳ last failure: " .. tostring(ed.lastDelayWhy)
            end
        end
        -- 📐 6.342.0 — WHICH SHAPE ⌘D HAS, said outright. The release
        -- changed what the key DOES, and a build that still hides and
        -- shoots the whole screen looks identical in the report unless
        -- the report names the shape.
        L[#L + 1] = ("   ⌘D      : drag an area, then %d second(s), then that "
                     .. "rectangle%s"):format(
                        math.floor(num(ed.delaySecs, 5)),
                        num(d.cancelled, 0) > 0
                            and (" · " .. num(d.cancelled, 0)
                                 .. " cancelled (Esc, or a drag too small)")
                            or "")
        L[#L + 1] = ("   hide    : %s for the countdown%s"):format(
                        ed.hideForDelay and "hidden" or "LEFT ON SCREEN",
                        (num(d.late, 0) > 0)
                            and (" · ⚠️ brought back by the belt " .. num(d.late, 0)
                                 .. " time(s) — the capture never answered")
                            or "")
        -- 🖼 6.258.0 — the grow, and WHO says how big the canvas is. A
        -- size Lua read off the file and one the page confirmed are
        -- different facts, and only the second proves the bridge works.
        local g = ed.grows or {}
        local cw, chh, who = ed.canvasSize()
        L[#L + 1] = "   canvas  : " .. (cw
                        and (math.floor(cw) .. "x" .. math.floor(chh) .. " — " .. who)
                        or "not known — the page has said nothing and no file was read")
        if num(g.asked, 0) == 0 then
            L[#L + 1] = "   grow    : never asked this session (⌘O in the editor)"
        else
            L[#L + 1] = ("   grow    : %d asked · %d landed · %d failed"):format(
                            num(g.asked, 0), num(g.landed, 0), num(g.failed, 0))
            if ed.lastGrow then L[#L + 1] = "   ↳ last: " .. tostring(ed.lastGrow) end
        end
        -- 🖼 6.415.0 — WHAT A LOADED SHOT IS, said outright, for the
        -- same reason 6.342.0 names ⌘D's shape: a build that still bakes
        -- the pixels in looks identical in every count above.
        L[#L + 1] = "   ↳ ⌘O    : the loaded shot is a MARK — drag it anywhere, "
                    .. "even over the first; ⌫ removes it"
        if ed.lastGrowWhy then
            L[#L + 1] = "   ↳ last refusal: " .. tostring(ed.lastGrowWhy)
        end
        -- ✂️ 6.414.0 — counted apart from the grows, and a refusal names
        -- the SIZE it was given (6.336.0): "6 × 4" is the whole diagnosis
        -- of a mis-drag, where "refused" sends a reader nowhere.
        local c = type(ed.crops) == "table" and ed.crops or {}
        if num(c.asked, 0) == 0 then
            L[#L + 1] = "   crop    : never asked this session (K, drag, then ⏎)"
        else
            L[#L + 1] = ("   crop    : %d asked · %d cropped · %d refused"):format(
                            num(c.asked, 0), num(c.landed, 0), num(c.refused, 0))
            if ed.lastCrop then L[#L + 1] = "   ↳ last: " .. tostring(ed.lastCrop) end
            if ed.lastCropWhy then
                L[#L + 1] = "   ↳ last refusal: " .. tostring(ed.lastCropWhy)
            end
        end
        L[#L + 1] = ("   ↳ a crop is at least %d × %d, and never the whole shot")
                        :format(math.floor(num(ed.cropMin, 32)),
                                math.floor(num(ed.cropMin, 32)))
        L[#L + 1] = ("   settings: { screenshot_editor = { delaySecs = %d, hideForDelay = %s, "
                     .. "hideSettleSecs = %s } }")
                        :format(math.floor(num(ed.delaySecs, 5)),
                                tostring(ed.hideForDelay and true or false),
                                tostring(num(ed.hideSettleSecs, 0.4)))
        L[#L + 1] = "   ↳ if the keyboard does not come back with the window, click it once"
        local text = table.concat(L, "\n")
        print(text)
        return text
    end

    -- ---- window ----------------------------------------------------------
    -- 🚪 6.286.0 — THE ONE DOOR OUT, AND UNTIL NOW MOST DOORS SKIPPED THE
    -- RESCUE. LL, with an annotated screenshot: "Closing the screenshot
    -- editor dumps the most recent edits so I lose any changes."
    --
    -- 6.189.0 promises the opposite, and it was telling the truth about
    -- exactly ONE way out. The work lives in the PAGE — canvas pixels and
    -- a notes array — and the only thing that hands it back is the page's
    -- own `stashAndCancel()`, which posts { a = 'cancel', img, notes }.
    -- The Cancel button calls it. Nothing else did:
    --   · the Esc ROUTER called ed.close() straight out (6.93.0), which
    --     deletes the webview and with it the only copy of his marks;
    --   · ⇪⇧1 on another shot calls ed.open(), whose first line is
    --     ed.close() — so opening a second screenshot threw the first
    --     one's work away, silently;
    --   · `view:closeOnEscape(true)` let WebKit close the WINDOW behind
    --     Lua's back, racing the page's own Escape handler, so even the
    --     path that was meant to work was a coin toss.
    --
    -- 🔑 SO THE CLOSE IS ASYNCHRONOUS NOW, because the answer has to come
    -- from the page: ask, and close when it replies. A HELD belt
    -- (`ed.closeTimer`, its own slot — 6.196.1) closes anyway after
    -- `ed.closeGraceSecs`, so a page that cannot answer costs the marks
    -- and never the window. 6.255.0's shape, in the other direction.
    -- 📏 COST, NAMED: a Mac that cannot arm a timer closes at once, as
    -- before, and the report counts those apart.
    ed.closeGraceSecs = 0.4
    ed.closeTimer     = nil     -- HELD: an unreferenced timer never fires
    ed.closes = { asked = 0, stashed = 0, belt = 0, atOnce = 0, last = nil }

    function ed.stopCloseBelt()
        if ed.closeTimer then pcall(function() ed.closeTimer:stop() end) end
        ed.closeTimer = nil
    end

    -- PURE: given what this Mac can do, how should the editor be closed?
    -- Three answers and the reason for each, so the whole decision is
    -- provable with no Mac (6.264.0 — and the checks below drive the real
    -- path with each dependency taken away in turn).
    function ed.closePlan(hasPage, canAsk, canTimer)
        if not hasPage then return "now", "there is no editor open" end
        if not canAsk then
            return "now", "this Mac cannot ask the page for its work"
        end
        if not canTimer then
            return "askThenNow", "no timer to fall back on — the work is "
                .. "asked for, and the window closes either way"
        end
        return "ask", "asking the page to hand its work back first"
    end

    function ed.requestClose(why)
        local hasPage  = ed.webview ~= nil
        local canAsk   = hasPage and ed.webview.evaluateJavaScript ~= nil
        local canTimer = (hs.timer and hs.timer.doAfter) ~= nil
        local plan, reason = ed.closePlan(hasPage, canAsk, canTimer)
        ed.closes.last = tostring(why or "?") .. " — " .. reason
        if plan == "now" then
            if hasPage then ed.closes.atOnce = ed.closes.atOnce + 1 end
            ed.close()
            return true, reason
        end
        ed.closes.asked = ed.closes.asked + 1
        ed.stopCloseBelt()
        if plan == "ask" then
            -- 🚨 ARMED BEFORE THE ASK (6.246.0's ordering): a page that
            -- throws inside stashAndCancel must not leave a window nobody
            -- can close.
            pcall(function()
                ed.closeTimer = hs.timer.doAfter(ed.closeGraceSecs, function()
                    ed.closeTimer = nil
                    if not ed.webview then return end
                    ed.closes.belt = ed.closes.belt + 1
                    say("the page did not hand its work back in time — closing")
                    ed.close()
                end)
            end)
            -- 🚨 AND A doAfter THAT ANSWERS nil IS NOT A BELT (6.265.0: a
            -- dependency that REFUSES is not the same as one that is
            -- missing, and on a beta OS the second is the shape this
            -- config keeps meeting). No belt → close now, not never.
            if not ed.closeTimer then
                plan, reason = "askThenNow", "the belt timer was refused — "
                    .. "the work is asked for, and the window closes either way"
                ed.closes.last = tostring(why or "?") .. " — " .. reason
            end
        end
        pcall(function() ed.webview:evaluateJavaScript("stashAndCancel()") end)
        if plan == "askThenNow" then ed.close() end
        return true, reason
    end

    function ed.close()
        -- 🚨 6.256.0 — FOUND WHILE BUILDING ⌘F, and it was 6.255.0's wart:
        -- closing the editor mid-capture (⇪⇧1 on another shot is enough,
        -- and with the window hidden that is exactly what he would press)
        -- left `ed.hidden` set, so the belt woke up, found nothing to show
        -- and alerted "the delayed capture never answered" over an editor
        -- HE had closed. A teardown is not optional for a feature that
        -- holds two timers and a flag.
        ed.stopSettle()
        ed.stopCloseBelt()
        if ed.delayTimer then pcall(function() ed.delayTimer:stop() end) end
        ed.delayTimer, ed.delayBusy, ed.hidden = nil, false, false
        if ed.webview then
            pcall(function() ed.webview:delete() end)
            ed.webview = nil
        end
        ed.uc, ed.currentPath = nil, nil
        -- 6.258.0 — and the canvas this window was: a size left behind is
        -- a grow planned against a page that no longer exists.
        ed.canvasW, ed.canvasH, ed.pageSized = nil, nil, false
        if _G.choosers and _G.choosers.editorLoadShot then
            pcall(function() _G.choosers.editorLoadShot:hide() end)
            _G.choosers.editorLoadShot = nil
        end
    end

    function ed.open(path)
        if type(path) ~= "string" or path == "" then return false end
        -- 🚨 6.286.0 — ⇪⇧1 ON ANOTHER SHOT USED TO THROW THE FIRST ONE'S
        -- WORK AWAY. This line has always been ed.close(); the slot is
        -- keyed by path, so the marks would have come back on the next
        -- open of that shot — if anything had ever put them in it.
        -- requestClose cannot be awaited here (the new window has to open
        -- now), so the ask goes out and the close follows it; the page's
        -- reply lands a moment later and fills the slot for the shot it
        -- belongs to, which is what the path key is for.
        ed.requestClose("opening another shot")
        ed.close()
        if not (hs.webview and hs.webview.usercontent) then
            pcall(function() hs.alert.show("🖌 Editor needs WKWebView — not available", 3) end)
            return false
        end
        local b64 = readFileBase64(path)
        if not b64 then
            pcall(function() hs.alert.show("🖌 Could not read " .. path, 3) end)
            return false
        end

        -- size the window to the image, capped to the screen
        local screen = core.resolveBaseScreen and core.resolveBaseScreen()
                       or (hs.screen and hs.screen.mainScreen and hs.screen.mainScreen())
        local sf = { x = 0, y = 0, w = 1440, h = 900 }
        pcall(function() if screen then sf = screen:frame() end end)
        local imgW, imgH = 900, 600
        pcall(function()
            local img = hs.image.imageFromPath(path)
            local sz = img and img:size()
            if sz and sz.w > 0 then imgW, imgH = sz.w, sz.h end
        end)
        -- 6.258.0 — ONE piece of arithmetic, two callers (the grow
        -- resizes through the same function).
        local w, h = ed.windowSizeFor(imgW, imgH, sf)
        local rect = { x = sf.x + (sf.w - w) / 2, y = sf.y + (sf.h - h) / 2,
                       w = w, h = h }
        -- What the canvas will be until the page says otherwise. NOT
        -- marked as the page's word — a ⌘O before the page has spoken
        -- still has a number, and the report says where it came from.
        ed.canvasW, ed.canvasH, ed.pageSized = imgW, imgH, false

        local okUc, uc = pcall(hs.webview.usercontent.new, "shotEditor")
        if not (okUc and uc) then return false end
        ed.uc = uc    -- HELD: collect this and the JS bridge goes quiet
        pcall(function()
            uc:setCallback(function(msg)
                local ok, err = pcall(handleMessage, msg and msg.body)
                if not ok then warn("message handler — " .. tostring(err)) end
            end)
        end)

        local okV, view = pcall(hs.webview.new, rect, {}, uc)
        if not (okV and view) then ed.uc = nil return false end
        ed.webview, ed.currentPath = view, path
        pcall(function() view:windowTitle("Blur — " .. (path:match("[^/]+$") or path)) end)
        pcall(function() view:allowTextEntry(true) end)   -- ⌘Z/⌘⏎ need key status
        -- 🚨 6.286.0 — `closeOnEscape(true)` IS GONE. It let WebKit close
        -- the window itself on Escape, racing the page's own handler and
        -- leaving Lua holding a dead view with ed.currentPath still set —
        -- so even the path 6.189.0 built could lose the work, depending on
        -- which side won. Escape comes through the router now (below),
        -- which asks the page first.
        pcall(function() view:level(hs.drawing.windowLevels.floating) end)
        pcall(function()
            view:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" })
        end)
        -- The slot is keyed by path, so a different screenshot simply does
        -- not match and opens clean — no clearing, no staleness.
        local keep = (ed.kept and ed.kept.path == path) and ed.kept or nil
        pcall(function()
            view:html(ed.buildHtml("data:image/png;base64," .. b64, keep))
        end)
        if keep then
            pcall(function()
                hs.alert.show("🖌 Your last edits on this shot are back", 2)
            end)
            say("restored the work kept from the last close")
        end
        -- 🪟 6.391.0 — the shared door reads BOTH refusals (a throw and
        -- a false return). Guarded, so a build without it still opens.
        if _G.showWebviewSafely then
            _G.showWebviewSafely(view, "Screenshot editor")
        else
            pcall(function() view:show() end)
        end
        pcall(function() view:bringToFront(true) end)
        say("editing " .. (path:match("[^/]+$") or path))
        return true
    end

    -- 📐 6.221.0 — PURE: the top strip of a frame, which is what ⌘-drag
    -- may grab. Clamped to the window, so a frame shorter than the header
    -- is all strip rather than a rectangle taller than its own window.
    function ed.stripOf(f, h)
        if type(f) ~= "table" or not (f.x and f.y and f.w and f.h) then
            return nil
        end
        h = tonumber(h) or 0
        if h <= 0 then return nil end
        return { x = f.x, y = f.y, w = f.w, h = math.min(h, f.h) }
    end

    -- Never throws: window_move's tap calls this on every bare-⌘ click
    -- anywhere on the Mac, and a Hammerspoon whose webview cannot answer
    -- :frame() must cost the ⌘-drag, not the panel mover.
    function ed.dragStrip()
        if not ed.webview then return nil end
        local ok, f = pcall(function() return ed.webview:frame() end)
        if not ok then return nil end
        return ed.stripOf(f, ed.dragStripH)
    end

    -- ---- wiring ----------------------------------------------------------
    core.provide("screenshotEditor.open", function(p) return ed.open(p) end)

    -- 6.89.0 — listed for Window Move: ⌘-drag moves the editor, and the
    -- title grip above gives the bare-click drag where it is safe.
    -- 🚨 6.221.0 — THAT ⌘-DRAG IS NOW THE TITLE BAR ONLY. window_move's
    -- tap takes a bare-⌘ left-mouse-down ANYWHERE inside a listed panel's
    -- frame and begins a window drag, consuming the click — so ⌘ inside
    -- this window could never have reached the page, and LL's ⌘-click
    -- would have moved the editor instead of editing his text box. The
    -- window is not less movable: the header IS the drag handle (6.89.0's
    -- grip, a bare drag), and ⌘-drag still works on that same strip.
    -- GENERAL RULE: a panel whose PAGE wants ⌘ narrows the frame it lists
    -- here to the strip it is happy to be dragged by — `frame` answers
    -- "where does ⌘-drag grab this", not "where is this window".
    _G.movablePanels = _G.movablePanels or {}
    table.insert(_G.movablePanels, {
        name  = "screenshot editor",
        frame = function() return ed.dragStrip() end,
        move  = function(x, y)
            local f = ed.webview and ed.webview:frame()
            if f then ed.webview:frame({ x = x, y = y, w = f.w, h = f.h }) end
        end,
    })

    -- 🗂 6.116.0 — listed for the ⌘⌘ editor picker, and DELIBERATELY WITH
    -- NO `show`. This editor edits an image you have to have taken first;
    -- there is no cold-open of it, so the row exists to bring an editor
    -- that is already up back to the front — which is exactly the case
    -- where it is hardest to find, buried under whatever you took a
    -- screenshot OF. With the window closed the row says so and does
    -- nothing, which is honest; a `show` that opened an empty editor
    -- would not be.
    _G.editors = _G.editors or {}
    table.insert(_G.editors, {
        name  = "Screenshot Editor",
        key   = "⇪⇧1",
        what  = "only listed while one is open",
        order = 60,
        view  = function() return ed.webview end,
    })

    -- ⎋ 6.93.0 — in the escape router, so the cheat sheet closes AFTER the
    -- editor (its page keeps first claim on Esc for cancelling a text box).
    if _G.claimEscape then
        _G.claimEscape("shoteditor", nil,
            function() return ed.webview ~= nil end,
            -- 6.286.0 — was ed.close(), which deleted the webview and with
            -- it the only copy of his marks. This is the door he actually
            -- presses (LL, 6.189.0: "I hit escape 2 times and all my
            -- screenshot work wasn't saved").
            function() ed.requestClose("Esc") end)
    end

    _G.screenshotEditor = ed
    M.editor = ed
    M.config = ed
end

return M
