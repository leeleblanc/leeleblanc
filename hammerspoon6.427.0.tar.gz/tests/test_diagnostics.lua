-- Run from anywhere:  lua5.4 <this file> [path to ~/.hammerspoon]
-- HS   = the config being tested (init.lua + modules/)
-- HERE = this tests folder, which is where the extracted fixtures live
local HERE = (arg and arg[0] or ""):match("^(.*)[/\\]") or "."
local HS   = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
             or ((os.getenv("HOME") or ".") .. "/.hammerspoon")
-- Harness for §1.11 diagnostics, plus a whole-file audit of init.lua:
-- the removal of App Lock and the bug classes the audit went looking for
-- are asserted against the shipped text itself, not against a copy.
local printed, clip, written = {}, nil, {}
local realprint = print
print = function(...)
  local p = {}
  for i = 1, select("#", ...) do p[#p+1] = tostring((select(i, ...))) end
  table.insert(printed, table.concat(p, " "))
end
local NOW = 500
hs = {
  timer = { secondsSinceEpoch = function() return NOW end },
  json  = { decode = function(s)
      if s == '{"ok":true}' then return { ok = true } end
      error("Unable to parse JSON")
  end },
  fs = { attributes = function(p)
      if p == "/tmp/hs-test" then return { mode = "directory", size = 0 } end
      return { mode = "file", size = 42 }
  end },
  pasteboard = { setContents = function(t) clip = t ; return true end },
  alert = { show = function() end },
  hotkey = { bind = function() end },
  screen = { allScreens = function()
      return { { name = function() return "LG HDR 4K" end,
                 frame = function() return { x=0,y=0,w=3840,h=2160 } end } }
  end },
  window = { orderedWindows = function() NOW = NOW + 0.5; return { 1, 2, 3 } end },
  application = { frontmostApplication = function()
      return { name = function() return "Ghostty" end } end },
  host = { operatingSystemVersionString = function() return "macOS 26.1" end },
  processInfo = { version = "1.0.0" },
  accessibilityState = function() return true end,
}
hostTag, logsDir, backupDir, asanaEnabled = "TestMac", "/tmp/hs-test", "/tmp/hs-backup", true
altTab = { enabled = true, includeMinimized = false, maxWindows = 24, session = nil }
_G.autocorrectStatus = "ON (10970 fixes)"
_G.hotkeyBoundCount, _G.hotkeyConflictCount = 4, 0
_G.configVersion = "6.35.0"

local realopen = io.open
io.open = function(path, mode)
  if mode == "w" then
    return { write = function(_, t) written[path] = t end, close = function() end }
  end
  return realopen(path, mode)
end

-- The real file declares a no-op stub at the top and §1.11 EXTENDS it;
-- the harness has to stand in for that stub, and asserting the extend
-- (rather than replace) behaviour is itself part of the test below.
_G.diag = { verbose = false, trail = {}, errors = {}, marks = {},
            say = function() end, warn = function() end,
            err = function() end, mark = function() end }
_G.diag.trail[1] = "pre-existing entry from before §1.11 loaded"
-- 6.44.11 — RUNS THE SHIPPED FILE, NOT A COPY. tests/diag_test.lua was a
-- hand-extracted slice of §1.11 and had drifted out of step with init.lua
-- — it was no longer even a verbatim substring of it. Every check below
-- was therefore green against code that was not what ships. §1.11 now
-- lives in core/diagnostics.lua, so the suite loads that, the same way
-- init.lua does.
local DIAG_PATH = HS .. "/core/diagnostics.lua"
local diagChunk = assert(loadfile(DIAG_PATH),
                         "cannot load the shipped diagnostics: " .. DIAG_PATH)
diagChunk()({ logsDir = logsDir, hostTag = hostTag, asanaEnabled = asanaEnabled,
              backupDir = backupDir })
-- 6.145.2 — the global dies the moment the chunk has been handed the value.
-- Before the fix, diagnostics read `backupDir` as a GLOBAL — which this
-- harness defined (above) and init.lua never does, its backupDir being a
-- local — so this suite stayed green while every real Mac's report printed
-- "backup dir : not configured". With the global gone, the report below can
-- only know the path if it actually kept core.backupDir.
backupDir = nil
local keptEarly = _G.diag.trail[1] == "pre-existing entry from before §1.11 loaded"
io.open = realopen

local out = io.write
local pass, fail = 0, 0
local function check(name, cond, detail)
  if cond then pass = pass + 1; out("  ✅ ", name, "\n")
  else fail = fail + 1; out("  ❌ ", name, " — ", tostring(detail or ""), "\n") end
end
local function inReport(r, pat) return r:find(pat, 1, true) ~= nil end

out("\n=== 1. The trail records even when nobody is watching ===\n")
check("§1.11 EXTENDS the early stub instead of replacing it", keptEarly)
_G.diag.verbose = false
printed = {}
_G.diag.say("test", "quiet event")
check("event recorded to the trail", #_G.diag.trail >= 2)
check("...but NOT printed while verbose is off", #printed == 0, printed[1])
_G.diag.verbose = true
_G.diag.say("test", "loud event")
check("printed once verbose is on", #printed == 1, #printed)
_G.diag.verbose = false
for i = 1, 300 do _G.diag.say("flood", "event " .. i) end
check("trail is a RING BUFFER, not a leak", #_G.diag.trail == _G.diag.maxTrail, #_G.diag.trail)
check("...keeping the NEWEST entries", _G.diag.trail[#_G.diag.trail]:find("event 300"))

out("\n=== 2. Errors are captured, including from async callbacks ===\n")
check("hs.uncaughtErrorHandler is installed", type(hs.uncaughtErrorHandler) == "function")
hs.uncaughtErrorHandler("boom in a timer callback")
check("an uncaught error is recorded", #_G.diag.errors == 1, #_G.diag.errors)
check("...with the message", _G.diag.errors[1]:find("boom in a timer callback", 1, true) ~= nil)
for i = 1, 60 do _G.diag.err("err " .. i) end
check("error buffer is bounded too", #_G.diag.errors == _G.diag.maxErrors, #_G.diag.errors)

out("\n=== 3. safeJson: the major audit fix ===\n")
check("valid JSON decodes", (function()
  local d = _G.safeJson('{"ok":true}', "t"); return d and d.ok == true
end)())
check("an HTML proxy page returns nil instead of THROWING", (function()
  local ok, res = pcall(_G.safeJson, "<html>Sign in to the network</html>", "t")
  return ok and res == nil
end)())
check("...and says what actually arrived", (function()
  for _, l in ipairs(printed) do if l:find("not JSON", 1, true) then return true end end
end)())
check("an empty body returns nil, no throw", (function()
  local ok, res = pcall(_G.safeJson, "", "t"); return ok and res == nil
end)())
check("a nil body returns nil, no throw", (function()
  local ok, res = pcall(_G.safeJson, nil, "t"); return ok and res == nil
end)())

out("\n=== 4. Boot marks ===\n")
_G.diag.marks = {}
NOW = 502.5
_G.diag.mark("§3.12 hyper wired")
check("mark records elapsed since boot start", _G.diag.marks[1].at > 0, _G.diag.marks[1].at)
check("...under its own name", _G.diag.marks[1].name == "§3.12 hyper wired")

out("\n=== 5. The report has what I need to debug from ===\n")
local r = _G.diag.report()
for _, want in ipairs({
  "config version : 6.35.0", "macOS", "machine        : TestMac",
  "accessibility  : granted", "BOOT", "hyper wired", "SCREENS", "LG HDR 4K",
  "HOTKEYS", "global bound   : 4", "FEATURES", "Asana          : on",
  "Autocorrect    : ON", "⌥Tab switcher", "LIVE PROBE", "orderedWindows",
  "PATHS", "/tmp/hs-test", "ERRORS", "LAST 25 EVENTS", "END OF REPORT" }) do
  check("report contains: " .. want, inReport(r, want))
end
check("backup dir is the PASSED value, not a global only this harness sets",
  inReport(r, "backup dir     : /tmp/hs-backup"), r:match("backup dir[^\n]*"))
check("live probe TIMES the window enumeration (the beachball measure)",
  r:find("orderedWindows : 3 windows in %d") ~= nil)
check("a slow enumeration is flagged in the report", r:find("SLOW") ~= nil)
check("report says how to turn verbose on", inReport(r, "_G.diag.verbose = true"))

out("\n=== 6. ⇪⇧D delivers it three ways ===\n")
printed, clip, written = {}, nil, {}
io.open = function(path, mode)
  if mode == "w" then return { write = function(_, t) written[path] = t end, close = function() end } end
  return realopen(path, mode)
end
_G.diag.show()
io.open = realopen
check("printed to the Console", #printed >= 1)
check("copied to the clipboard", clip ~= nil and clip:find("DIAGNOSTIC REPORT", 1, true) ~= nil)
check("saved to the Logs folder, tagged per machine",
  written["/tmp/hs-test/diagnostics-TestMac.txt"] ~= nil,
  next(written))

out("\n=== 7. Whole-file audit of the shipped init.lua ===\n")
local INIT = HS .. "/init.lua"
local f = realopen(INIT, "r"); local text = f:read("*a"); f:close()
-- initText is init.lua ALONE, before the modules and core files are
-- appended below. It matters: a check like "init.lua loads the boot
-- report" against the CONCATENATED text passes even when init.lua stops
-- loading it, because core/boot_report.lua names itself in its own
-- header. Two mutations slipped through exactly that way before this
-- split existed. Anything asserting what init.lua itself does must use
-- initText; anything hunting a bug CLASS should use text, so the class
-- cannot escape by moving to another file.
local initText = text
-- ...and it has to ignore COMMENTS. "init.lua loads core/boot_report.lua"
-- stayed green under a mutation that pointed the loader at a file that
-- does not exist — because the comment ABOVE the loader says the name
-- too. A prose mention is not a call. Everything asserting that init.lua
-- DOES something goes through here.
local function initLive(needle, plain)
  for line in initText:gmatch("[^\n]+") do
    if not line:match("^%s*%-%-") and line:find(needle, 1, plain ~= false) then
      return line
    end
  end
end
-- The audit covers the MODULE FILES too, so a bug class cannot escape
-- it simply by having been moved out of init.lua.
-- ⚠️ READ FROM DISK, NOT RETYPED. A hand-copied list drifts the moment a
-- module is added — this one sat at 18 of 26 files for several releases,
-- so the audit below silently stopped covering a third of the config.
-- init.lua's own default profile is the source of truth for what SHIPS;
-- reading it is what test_integration already does for the same reason.
local MODS = {}
do
  local f = realopen(HS .. "/init.lua", "r")
  local src = f and f:read("*a") or ""
  if f then f:close() end
  -- 🚨 6.66.3 — READS BASE, NOT THE `default` PROFILE. init.lua used to
  -- carry three hand-typed module lists, one per machine, and this read
  -- one of them. When the restructure replaced them with a single BASE
  -- list this match returned nil, MODS came back EMPTY, no module source
  -- was appended, and SEVEN unrelated checks failed at once — none of
  -- them mentioning modules. A silent nil from a pattern is a bad way to
  -- learn that, which is why the guard below is now an assertion rather
  -- than an `or ""`.
  local block = src:match("local BASE = {(.-)\n}")
  for name in (block or ""):gmatch('"([%w_]+)"') do MODS[#MODS + 1] = name end
end
-- 🚨 FAIL LOUDLY IF THE LIST IS EMPTY. Every check below that greps
-- module source silently passes-or-fails on nothing when MODS is empty,
-- and the failures point anywhere but here.
check("the module list was read out of init.lua's BASE — an empty list "
      .. "here makes every module check below meaningless",
      #MODS >= 25, #MODS)
local moduleText = {}
for _, m in ipairs(MODS) do
  local mf = realopen(HS .. "/modules/" .. m .. ".lua", "r")
  if mf then moduleText[m] = mf:read("*a"); mf:close(); text = text .. "\n" .. moduleText[m] end
end
-- ...and the CORE files, for exactly the same reason. 6.44.11 lifted §1.11
-- and §1.6 out of init.lua, and the moment it did, every audit rule below
-- stopped covering them — the "uncaughtErrorHandler is wired" check failed
-- not because the wiring had gone but because the auditor had stopped
-- looking where it lives. An audit that shrinks when code moves is worse
-- than no audit, because it stays green while its coverage falls away.
local CORE = { "diagnostics", "cheatsheet", "boot_report" }
local coreText, coreFound = {}, {}
for _, c in ipairs(CORE) do
  local cf = realopen(HS .. "/core/" .. c .. ".lua", "r")
  if cf then
    coreText[c] = cf:read("*a"); cf:close()
    coreFound[c] = true
    text = text .. "\n" .. coreText[c]
  end
end
check("init.lua compiles", (loadfile(INIT)) ~= nil, select(2, loadfile(INIT)))
for _, m in ipairs(MODS) do
  local path = HS .. "/modules/" .. m .. ".lua"
  check("module compiles: " .. m, (loadfile(path)) ~= nil, select(2, loadfile(path)))
  check("module returns a contract: " .. m, (function()
    local ok, mod = pcall(dofile, path)
    return ok and type(mod) == "table" and type(mod.setup) == "function"
  end)())
end
-- Core files get the same treatment modules get. They are dofile'd by
-- init.lua at a fixed point rather than loaded by the §1.12 loader, so a
-- broken one is NOT isolated the way a broken module is — which is the
-- reason to check them harder, not less.
for _, c in ipairs(CORE) do
  local path = HS .. "/core/" .. c .. ".lua"
  check("core file present: " .. c, coreFound[c] == true, path)
  if coreFound[c] then
    check("core file compiles: " .. c, (loadfile(path)) ~= nil, select(2, loadfile(path)))
    check("core file returns an initialiser: " .. c, (function()
      local ok, fn = pcall(dofile, path)
      return ok and type(fn) == "function"
    end)())
  end
end
check("INIT.LUA ITSELF loads every core file — checked against init.lua alone, "
      .. "because a core file names itself in its own header",
  (function()
    -- The full loader expression, not the bare filename: each loader also
    -- prints a failure message naming its own file, so a check for
    -- "core/boot_report.lua" stayed green under a mutation that pointed
    -- loadfile at a path that does not exist. Only the real call counts.
    for _, c in ipairs(CORE) do
      if not initLive("hs.configdir .. '/core/" .. c .. ".lua'") then return false, c end
    end
    return true
  end)())
check("...and every one of those loads is inside a pcall, so a missing or "
      .. "broken core file degrades instead of killing the boot",
  (function()
    for _, guard in ipairs({ "diagOK", "csOK", "brOK" }) do
      if not initLive(guard) then return false, guard end
    end
    return true
  end)())
check("...and each failure prints, because a silent one looks like success",
  (function()
    for _, guard in ipairs({ "diagOK", "csOK", "brOK" }) do
      if not initLive("if not " .. guard .. " then") then return false, guard end
    end
    return true
  end)())
check("init.lua ASKS macOS about Accessibility rather than assuming it",
  initLive("pcall(function() axOK = hs.accessibilityState() end)") ~= nil)

check("the migrated sections are GONE from init.lua", (function()
  local f2 = realopen(INIT, "r"); local only = f2:read("*a"); f2:close()
  for _, gone in ipairs({ "1.7 DAILY BACKUP", "1.8 APP PEEK", "1.10 WINDOW SWITCHER",
                          "1.9 WINDOW ARRANGER", "3.11 GLOBAL COPY-ON-SELECT",
                          "6.5 COMMAND HISTORY", "3.7 APP WATCHER",
                          "3.8 FILE TRACKER", "3.9 AUTOCORRECT", "3.6 ACTIVITY TRACKER",
                          "3.10 APP UPDATE TRACKER", "3.5 ASANA COMMENTS",
                          "X.1 DOCUMENT WATCHER" }) do
    if only:find(gone, 1, true) then return false end
  end
  return true
end)())
check("modules never reach into init.lua's locals", (function()
  for m, body in pairs(moduleText) do
    for line in body:gmatch("[^\n]+") do
      if not line:match("^%s*%-%-") then
        -- these must arrive via core, never as free-floating globals
        for _, forbidden in ipairs({ "popupScreenKeys", "resolveBaseScreen%(",
                                     "logsDir", "backupDir" }) do
          if line:find(forbidden) and not line:find("core%.") then return false, m end
        end
      end
    end
  end
  return true
end)())
local function liveCode(pattern)      -- matches outside comment lines
  for line in text:gmatch("[^\n]+") do
    if not line:match("^%s*%-%-") and line:find(pattern) then return line end
  end
end
check("no App Lock code remains", not liveCode("appLock"), liveCode("appLock"))
check("no App Lock section header", not text:find("6.6 APP LOCK", 1, true))
check("no PIN prompt code", not liveCode("appLockChallenge"))
-- 6.139.0 — the exclusion moved from a quoted shell string to the
-- rebuild kit's exclude TABLE, which is applied to every rsync the
-- backup runs. The claim is unchanged: the leftover PIN hash from the
-- removed App Lock must never reach a cloud copy.
check("applock.json is STILL excluded from backups (leftovers never sync)",
  text:find('"applock.json"', 1, true) ~= nil)
check("no unprotected hs.json.decode on network replies",
  not liveCode("hs%.json%.decode%(body%)") and not liveCode("hs%.json%.decode%(b%)")
  and not liveCode("hs%.json%.decode%(responseBody%)"))
check("hs.window.filter is never CALLED (naming it in a changelog string is fine)",
  not liveCode("hs%%.window%%.filter%%.new") and not liveCode("window%%.filter%%.default"))
check("no discarded timer objects", not liveCode("^%s*hs%.timer%.do"))

-- 🚨 6.57.0 — THE HEADER DATE MUST TRACK THE VERSION.
-- The file carried "08-05-26" for a dozen releases while the version
-- marker moved on without it, so the one line a human reads first was
-- quietly wrong. Asserted here so it cannot drift again.
do
  local dateLine = initText:match("\n%-%- (%d%d%-%d%d%-%d%d) using Claude")
  check("init.lua's header carries an edited date", dateLine ~= nil, dateLine)
  check("...and it is marked as something that gets bumped, so the next "
        .. "person knows it is not decoration",
        initText:find("Bumped with every release", 1, true) ~= nil)
end

-- 🚨 6.57.0 — A MODULE MUST NOT CLAIM A HYPER KEY THAT §0.4 ALREADY
-- MIGRATES SOMETHING ONTO. This is the gap that let three working
-- shortcuts die silently. test_integration checks module-against-module
-- collisions, but §0.4's migration map lives in init.lua and was never
-- part of that comparison — so focus_mode took ⇪F from the file
-- tracker, workspaces took ⇪W from the summon-an-app picker, and bulk
-- rename took ⇪⇧R from reset-nudge-offset. Each printed ONE line at
-- boot and killed a feature. Never again.
do
  local migr = {}
  for old, mods, key in initText:gmatch('%["([^"]+)"%]%s*=%s*{%s*{([^}]*)}%s*,%s*"([^"]+)"%s*}') do
    -- Only entries whose OLD chord is still bound somewhere can actually
    -- claim the hyper key; a map entry nothing triggers is inert.
    migr[(mods:find("shift") and "shift|" or "|") .. key] = old
  end
  local claims, dupes = {}, {}
  for _, m in ipairs(MODS) do
    local src = moduleText[m]
    if src then
      -- resolve `x.key = "q"` style indirection
      local keyvals = {}
      for var, k in src:gmatch('(%w+%.%w*[Kk]ey)%s*=%s*"([%w]+)"') do keyvals[var] = k end
      for mods, k in src:gmatch('hyperAddShortcut%(%s*{([^}]*)}%s*,%s*([^,]+),') do
        k = k:gsub("%s+", "")
        local key = k:match('^"(.-)"$') or keyvals[k]
        if key then
          local tag = (mods:find("shift") and "shift|" or "|") .. key
          if migr[tag] then
            dupes[#dupes + 1] = tag .. " (" .. m .. " vs migrated "
                                .. migr[tag] .. ")"
          end
          claims[tag] = m
        end
      end
    end
  end
  check("🚨 NO MODULE CLAIMS A HYPER KEY THE MIGRATION MAP ALSO CLAIMS — "
        .. "the collision that silently killed ⇪F, ⇪W and ⇪⇧R",
        #dupes == 0, table.concat(dupes, "; "))
end

-- 🚨 6.53.0 — A BAD KEY NAME MUST NOT TAKE THE WHOLE CONFIG DOWN.
-- hs.hotkey.bind THROWS on a key macOS has no code for. A module's bad
-- key was always survivable (§1.12 runs every setup() in a pcall), but
-- init.lua's own binds are top level in the stretch that runs BEFORE the
-- loader — so one typo in an ✏️ EDIT HERE block took everything down:
-- no hotkeys, no modules, no cheat sheet, and the reason only in a
-- Console nobody had open. Audited from source: the sentry wraps
-- hs.hotkey.bind at file scope and has no harness to drive.
do
  local codeOnly = {}
  for line in initText:gmatch("[^\n]+") do
    codeOnly[#codeOnly + 1] = line:match("^%s*%-%-") and "" or line
  end
  local initCode = table.concat(codeOnly, "\n")

  local sentry = initCode:match("hs%.hotkey%.bind%s*=%s*function.-\nend")
  check("the hotkey sentry still wraps hs.hotkey.bind", sentry ~= nil)
  if sentry then
    -- ⚠️ THESE TWO HAVE TO BE PRECISE, and the first draft was not.
    -- "does pcall appear" and "does hyperBindStub appear" were both TRUE
    -- even with the guard removed, because the migration branch above
    -- already contains a pcall and already returns the stub. Restoring
    -- the unprotected bind failed only one of three assertions — two
    -- were reading neighbouring code. What actually distinguishes the
    -- fixed file is the ABSENCE of a bare tail call.
    check("🚨 THE REAL BIND IS NOT CALLED UNPROTECTED — a bare "
          .. "`return hsHotkeyBindOriginal(...)` lets an invalid key throw "
          .. "out of init.lua and take every feature with it",
          initCode:find("return%s+hsHotkeyBindOriginal%(") == nil)
    check("🚨 ...it is called inside a pcall that captures the result",
          initCode:find("pcall%(function%(%)%s*bound%s*=%s*hsHotkeyBindOriginal") ~= nil
          or initCode:find("bound%s*=%s*hsHotkeyBindOriginal") ~= nil)
    -- Returning nil would only move the failure: the caller's :enable()
    -- would then throw instead, which is the same death one line later.
    check("🚨 ...and a rejected key returns the inert stub, not nil — nil "
          .. "just moves the crash to the caller's :enable()", (function()
        local rejectAt = sentry:find("HOTKEY REJECTED")
        local stubAt   = sentry:find("_G%.hyperBindStub%(%)", rejectAt or 1)
        return rejectAt ~= nil and stubAt ~= nil and stubAt > rejectAt
    end)())
    check("...and the rejection is COUNTED and NAMED, so it is not silent",
          sentry:find("hotkeyRejected") ~= nil
          and sentry:find("HOTKEY REJECTED") ~= nil)
  end
end

-- 🚨 6.53.0 — ERROR REPORTING MUST NOT DEPEND ON A FILE THAT CAN FAIL.
-- hs.uncaughtErrorHandler is the ONLY place an error inside a timer,
-- HTTP reply or watcher can be seen — a pcall in whatever scheduled the
-- callback cannot catch it. It used to be installed only by
-- core/diagnostics.lua, which loads ~1,000 lines into boot and is
-- correctly pcall'd so a broken copy cannot stop the config. That left
-- errors vanishing silently (a) for all of early boot and (b) for the
-- entire session if that one file failed to load — precisely when you
-- most need reporting, and nothing announced the loss.
do
  -- ⚠️ THESE CHECKS COMPARE POSITIONS, SO THEY MUST READ CODE ONLY.
  -- The first version searched initText raw and failed on its own
  -- documentation: the comment above the fix names both
  -- "core/diagnostics.lua" and the old `err = function() end`, so the
  -- prose explaining the bug was mistaken for the bug. That is the exact
  -- trap this file warns about at the top — a prose mention is not a
  -- call — and it caught the person who wrote the warning.
  local codeOnly = {}
  for line in initText:gmatch("[^\n]+") do
    codeOnly[#codeOnly + 1] = line:match("^%s*%-%-") and "" or line
  end
  local initCode = table.concat(codeOnly, "\n")

  local initAt = initCode:find("hs%.uncaughtErrorHandler%s*=")
  check("🚨 init.lua INSTALLS AN UNCAUGHT ERROR HANDLER ITSELF",
        initAt ~= nil)
  local coreAt = initCode:find("core/diagnostics%.lua")
  check("🚨 ...and installs it BEFORE core/diagnostics.lua loads, or early "
        .. "boot keeps its silent window",
        initAt ~= nil and coreAt ~= nil and initAt < coreAt,
        tostring(initAt) .. " vs " .. tostring(coreAt))
  check("🚨 the stand-in diag RECORDS errors rather than discarding them — "
        .. "`err = function() end` is a no-op that loses every early error",
        initCode:find("err%s*=%s*function%(%s*%)%s*end") == nil)
  -- The recorder has to be bounded: an error inside a repeating timer
  -- fires forever, and an unbounded list grows until the Mac suffers.
  check("...and the recorder is bounded, so a repeating error cannot grow "
        .. "without limit",
        initCode:find("_G%.diag%.errors") ~= nil
        and initCode:find("table%.remove") ~= nil)
end

-- 📋 THE CLIPBOARD EDIT AUDIT MOVED, and became a better test.
-- 6.52.0 checked from SOURCE that the edit path copied to the clipboard
-- and that the cache was written before the pasteboard — because the
-- code was in init.lua with no harness to drive. 6.55.0 moved it to
-- modules/clipboard_history.lua, so tests/test_clipboard.lua now drives
-- the real functions and asserts the BEHAVIOUR instead of the text. A
-- source audit is what you write when you cannot run the thing; it is
-- not the goal.
check("no io.open used as a bare existence test", not liveCode("io%.open%b()%s*==%s*nil"))
check("uncaughtErrorHandler is wired in the real file",
  liveCode("hs%.uncaughtErrorHandler") ~= nil)
-- 6.44.11 — the boot report became rows + a formatter, so the old check
-- for the literal "Boot:     %.2fs" was asserting the layout, not the
-- fact. The fact is what matters: boot time is still reported.
check("boot report still reports total load time",
  text:find('{ "Boot",', 1, true) ~= nil and text:find("%%.2fs") ~= nil)

-- ── QUIET BOOT (6.44.11) ─────────────────────────────────────────────
-- Fourteen lines on every reload is not information, it is what you
-- scroll past. These assert the new contract: summarise what is right,
-- always print what is wrong, keep the full detail one call away.
check("a healthy boot summarises instead of printing every row",
  text:find("All green.", 1, true) ~= nil)
check("...and every row still carries a problem flag, so nothing silently "
      .. "drops out of the report",
  (function()
    local rows = text:match("local bootRows = (%b{})")
    if not rows then return false end
    local n = select(2, rows:gsub('{ "', ""))
    return n >= 9        -- Storage Data Backup Asana Autocorrect Hotkeys Boot Modules Hyper Access
  end)())
check("...problems print unconditionally, not only when verbose",
  text:find("if r%[3%] then problems") ~= nil)
check("...accessibility is a row now, not a straggler print underneath",
  text:find('{ "Access", axOK', 1, true) ~= nil
  and not liveCode('print%("   Access:'))
check("the full report is still reachable on demand",
  liveCode("function _G%.bootReport") ~= nil)
check("...and verbose mode PERSISTS, so it survives the reload you set it before",
  liveCode("hs%.settings%.set%(\"hsBootVerbose\"") ~= nil
  and liveCode("hs%.settings%.get%(\"hsBootVerbose\"") ~= nil)
check("hs.hotkey's own enable/disable chatter is turned down",
  liveCode("hs%.hotkey%.setLogLevel") ~= nil)
-- ── THE 6.42.0 REGRESSION GUARD ──────────────────────────────────────
-- When a section became a module, code left behind in init.lua kept
-- calling its functions by bare name. Lua does not object: the name just
-- becomes a nil GLOBAL, and nothing fails until the key is pressed. That
-- is exactly how ⇪0 crashed. This walks init.lua looking for calls to
-- any function that now lives inside a module file.
check("NO DANGLING CALLS: init.lua never calls a function that moved into a module",
  (function()
    local fh = realopen(INIT, "r"); local only = fh:read("*a"); fh:close()
    local defined = {}
    for line in only:gmatch("[^\n]+") do
      for n in line:gmatch("local%s+function%s+([%w_]+)") do defined[n] = true end
      for n in line:gmatch("^%s*function%s+([%w_]+)%s*%(") do defined[n] = true end
      for n in line:gmatch("local%s+([%w_]+)%s*=") do defined[n] = true end
    end
    local inModule = {}
    for m, body in pairs(moduleText) do
      for n in body:gmatch("local%s+function%s+([%w_]+)") do inModule[n] = m end
    end
    for line in only:gmatch("[^\n]+") do
      -- Strip string literals before scanning. The changelog notes in
      -- this file NAME the functions that moved, and prose inside a
      -- string is not a call — an earlier version of this guard flagged
      -- its own changelog entry, which is the same false-positive shape
      -- as matching a module name inside a comment.
      local code = line:gsub('"[^"]*"', '""')
      if not code:match("^%s*%-%-") then
        for n in code:gmatch("[%s,(=]([%l][%w_]+)%s*%(") do
          if inModule[n] and not defined[n] then
            return false
          end
        end
      end
    end
    return true
  end)())
check("cross-boundary calls go through the service registry",
      text:find("_G.service.call(", 1, true) ~= nil)
check("...and modules publish through core.provide",
      text:find("core.provide(", 1, true) ~= nil)
check("the service registry warns instead of throwing when a provider is missing",
      text:find("No provider for", 1, true) ~= nil)
check("a broken Homebrew is reported ONCE, not once per app",
      (moduleText.update_tracker or ""):find("updateTrackerBrewWarned", 1, true) ~= nil)
check("...and names the actual repair rather than blaming the cask token",
      (moduleText.update_tracker or ""):find("brew update --force", 1, true) ~= nil)

-- 🗂 6.101.0 — EVERY MODULE DECLARES ITS CHEAT SHEET FAMILY. The families
-- exist so ⇪/ reads as a map instead of an index, and the membership is
-- declared BY EACH MODULE rather than in a list inside cheatsheet.lua —
-- because a list over there drifts the moment a module is added, which is
-- the same trap this file's MODS list was rescued from in 6.66.3. The
-- fallback is honest (an unfiled module shows up under "NOT YET FILED"
-- rather than vanishing) but it is a safety net, not a destination: a new
-- module must not be able to reach a release without picking a family.
do
  local families, unfiled, unknown = {}, {}, {}
  do
    local cf = realopen(HS .. "/core/cheatsheet.lua", "r")
    local src = cf and cf:read("*a") or ""
    if cf then cf:close() end
    local block = src:match("cheatSheet%.families%s*=%s*{(.-)\n%s*}")
    for id in (block or ""):gmatch('id%s*=%s*"([%w_]+)"') do families[id] = true end
  end
  -- "auto" is a real family that lives in the loader rather than the list:
  -- those modules collapse into the RUNS ITSELF box instead of getting a
  -- band of their own.
  families.auto = true
  check("core/cheatsheet.lua declares a family list the audit can read",
        next(families) ~= nil and families.windows == true)
  for _, m in ipairs(MODS) do
    local fam = (moduleText[m] or ""):match("\n%s*family%s*=%s*\"([%w_]+)\"")
    if not fam then unfiled[#unfiled + 1] = m
    elseif not families[fam] then unknown[#unknown + 1] = m .. "=" .. fam end
  end
  check("🗂 every shipped module declares a cheat sheet family — a new one "
        .. "cannot reach a release unfiled", #unfiled == 0,
        table.concat(unfiled, ", "))
  check("...and every family it names actually exists in cheatSheet.families",
        #unknown == 0, table.concat(unknown, ", "))
  -- The automatic tools are the ones with no keys at all. Their one line
  -- in the RUNS ITSELF box IS their whole entry on the sheet, so a missing
  -- summary is a tool the sheet lists by name and cannot describe.
  local noSummary = {}
  for _, m in ipairs(MODS) do
    local body = moduleText[m] or ""
    if body:match("\n%s*family%s*=%s*\"auto\"")
       and not body:match("\n%s*summary%s*=%s*\"") then
      noSummary[#noSummary + 1] = m
    end
  end
  check("...and every family = \"auto\" module carries the one-line summary "
        .. "the RUNS ITSELF box prints for it", #noSummary == 0,
        table.concat(noSummary, ", "))
end

-- 🔑 6.102.0 — ONE OWNER PER ⇪ KEY on the cheat sheet. Cross-references
-- are welcome — App Launcher pointing at ⇪W, Begone at ⇪⇧T — but a row
-- that puts the bare key in its KEY CELL claims it, and with the sheet
-- grouped by family the same key then renders as two different tools in
-- two different bands. The convention: the owner writes "⇪W"; everyone
-- else writes "vs ⇪W" / "via ⇪W" / "in ⇪W" so the reference reads as
-- one. Single letters only, on purpose: pad keys and named keys are
-- documented from two angles by design (numpad's map next to each
-- tool's own rows), and policing those would outlaw the good kind.
do
  local owner, dupes = {}, {}
  for _, m in ipairs(MODS) do
    local body = moduleText[m] or ""
    for _, pat in ipairs({ '{%s*"(⇪[A-Z])"%s*,', '{%s*"(⇪⇧[A-Z])"%s*,' }) do
      for key in body:gmatch(pat) do
        if owner[key] and owner[key] ~= m then
          dupes[#dupes + 1] = key .. " (" .. owner[key] .. " + " .. m .. ")"
        end
        owner[key] = owner[key] or m
      end
    end
  end
  -- The probes are MODULE-owned keys (mouse grid, chrome history) on
  -- purpose: ⇪⇧D and friends live in core/ and init.lua's builtin
  -- groups, which this audit deliberately does not read.
  check("🔑 the audit sees the single-letter ⇪ keys at all",
        owner["⇪X"] ~= nil and owner["⇪Y"] ~= nil)
  check("every single-letter ⇪/⇪⇧ key is claimed by exactly ONE module's "
        .. "cheat entries — cross-references say 'vs/via/in' instead",
        #dupes == 0, table.concat(dupes, ", "))
end


-- =====================================================================
-- 7b. THE ALERT WRAPPER SWEEPS ITS OWN WRECKAGE (6.100.1)
-- =====================================================================
-- LL's phantom window, 08-18-26: hs.alert.show threw mid-draw (the
-- 6.56.0 NSRemoteView collision), the 6.88.0 pcall caught it, and an
-- empty bordered pill sat on screen for hours because nothing cleaned
-- up the half-drawn frame. The fix sweeps and retries — and a grep
-- cannot prove a retry retries, so the block is lifted out of the
-- shipped source and RUN against an hs.alert that throws.
out("\n=== 7b. The alert wrapper, executed (6.100.1) ===\n")
do
  local s  = initText:find("_G.rawAlertShow = _G.rawAlertShow", 1, true)
  local em = "end end -- alert wrap"
  local e  = initText:find(em, 1, true)
  check("the alert-wrap block is findable (both anchors present)",
        s ~= nil and e ~= nil and e > s)
  if s and e then
    local block = initText:sub(s, e + #em - 1)
    local shows, closed, timers, said = {}, 0, {}, {}
    local throwsLeft = 0
    local SB
    SB = {
      table = table, pcall = pcall, select = select, tostring = tostring,
      collectgarbage = function() end,
      print = function(m) said[#said + 1] = tostring(m) end,
      hs = {
        alert = {
          show = function(...)
            if throwsLeft > 0 then
              throwsLeft = throwsLeft - 1
              error("NSInternalInconsistencyException -[NSRemoteView "
                    .. "containingWindowWillOrderOnScreen:]")
            end
            shows[#shows + 1] = table.pack(...)
            return "uuid"
          end,
          closeAll = function() closed = closed + 1 end,
        },
        timer = {
          doAfter = function(delay, fn)
            local t = { delay = delay, fn = fn, stop = function() end }
            timers[#timers + 1] = t
            return t
          end,
        },
      },
    }
    SB._G = SB
    SB.canvasShowTimers = {}   -- init.lua defines this ABOVE the block
    local fn, lerr = load(block, "init-alert-wrap", "t", SB)
    check("the block compiles standalone", fn ~= nil, lerr)
    if fn then
      fn()
      check("_G.phantom is defined by the block", type(SB.phantom) == "function")

      -- 1) a throw is caught, and a retry is scheduled AND HELD
      throwsLeft = 1
      SB.hs.alert.show("💾 saved", 2)
      check("the throw did not escape, and nothing drew yet", #shows == 0)
      check("a retry was scheduled one run-loop turn later",
            #timers == 1 and timers[1].delay < 0.5,
            timers[1] and timers[1].delay)
      check("...and the timer object is HELD — an unreferenced timer is "
            .. "collected and never fires", SB.canvasShowTimers[1] == timers[1])

      -- 2) the retry sweeps FIRST, then re-shows the ORIGINAL arguments
      timers[1].fn()
      check("the sweep closed tracked alerts before retrying", closed >= 1, closed)
      check("the alert was shown on retry, arguments intact",
            #shows == 1 and shows[1][1] == "💾 saved" and shows[1][2] == 2,
            shows[1] and shows[1][1])

      -- 3) both attempts failing gives up LOUDLY and names the manual sweep
      throwsLeft = 2
      SB.hs.alert.show("again")
      timers[#timers].fn()
      check("a double failure prints the manual way out (_G.phantom)",
            (function()
              for _, m in ipairs(said) do
                if m:find("_G.phantom", 1, true) then return true end
              end
            end)() == true, said[#said])
      check("...and does not loop — the retry schedules no third timer",
            #timers == 2, #timers)

      -- 4) the manual sweep stands alone
      closed = 0
      SB.phantom(true)
      check("_G.phantom(true) sweeps quietly — closeAll, no new alert",
            closed == 1 and #shows == 1)
    end
  end
end


-- =====================================================================
-- 8. THE BOOT REPORT, EXECUTED (6.44.11)
-- =====================================================================
-- Section 7 greps the shipped text. That proves a string exists. It
-- cannot tell you whether a healthy boot actually stays quiet, or
-- whether a broken one actually speaks up — which is the whole contract.
-- So this runs the real file, repeatedly, and reads what it printed.
out("\n=== 8. Boot report, executed ===\n")
local BR_PATH = HS .. "/core/boot_report.lua"
local brChunk = loadfile(BR_PATH)
check("core/boot_report.lua loads", brChunk ~= nil, select(2, loadfile(BR_PATH)))

if brChunk then
  local lines = {}
  local realPrint2 = print
  print = function(...)
    local t = {}
    for i = 1, select("#", ...) do t[#t+1] = tostring((select(i, ...))) end
    lines[#lines+1] = table.concat(t, " ")
  end
  local SETTINGS = {}
  hs.settings = { get = function(k) return SETTINGS[k] end,
                  set = function(k, v) SETTINGS[k] = v end }
  _G.moduleLoaded, _G.moduleFailed = 18, 0
  _G.hotkeyBoundCount, _G.hotkeyConflictCount = 4, 0
  _G.hyperShortcutCount, _G.hyperForwardCount, _G.hyperConflictCount = 34, 32, 0
  _G.autocorrectStatus, _G.moduleProfileName, _G.moduleDir = "ON", "TestMac", "/m"

  local function run(over)
    lines = {}
    local cfg = { hostTag = "TestMac", cloudDir = "/cloud", logsDir = "/cloud/Logs",
                  backupDir = "/cloud/Backups", asanaEnabled = true,
                  secretsStatus = "loaded", axOK = true }
    for k, v in pairs(over or {}) do if v == false then cfg[k] = nil else cfg[k] = v end end
    local api = brChunk()(cfg)
    return table.concat(lines, "\n"), api
  end

  local healthy, api = run()
  check("a healthy boot prints 2 lines, not 14", #lines == 2, #lines .. ": " .. healthy)
  check("...and says so plainly", healthy:find("All green", 1, true) ~= nil)
  check("...naming host, modules and shortcuts",
    healthy:find("TestMac", 1, true) and healthy:find("18", 1, true)
    and healthy:find("34", 1, true))
  check("...and pointing at the full report rather than hiding it",
    healthy:find("bootReport", 1, true) ~= nil)
  check("...while still building every row underneath",
    type(api) == "table" and #api.rows >= 10, api and #api.rows)

  local faults = {
    { "a failed module",       nil, function() _G.moduleFailed = 3 end,        "Modules" },
    { "a hotkey conflict",     nil, function() _G.hotkeyConflictCount = 2 end, "Hotkeys" },
    { "a hyper conflict",      nil, function() _G.hyperConflictCount = 1 end,  "Hyper"   },
    { "missing Accessibility", { axOK = false }, nil,                          "Access"  },
    { "Asana off",             { asanaEnabled = false }, nil,                  "Asana"   },
    { "no OneDrive",           { cloudDir = false }, nil,                      "Storage" },
  }
  for _, f in ipairs(faults) do
    local sM, sH, sY = _G.moduleFailed, _G.hotkeyConflictCount, _G.hyperConflictCount
    if f[3] then f[3]() end
    local o = run(f[2])
    check("⚠️ " .. f[1] .. " is reported even on an otherwise clean boot",
      o:find(f[4], 1, true) ~= nil and o:find("⚠️", 1, true) ~= nil, o)
    check("...and it suppresses the \"All green\" line", o:find("All green", 1, true) == nil)
    _G.moduleFailed, _G.hotkeyConflictCount, _G.hyperConflictCount = sM, sH, sY
  end

  SETTINGS.hsBootVerbose = true
  local full = run()
  check("verbose mode prints the whole report", #lines >= 10, #lines)
  check("...including rows a quiet boot leaves out",
    full:find("Backup", 1, true) and full:find("Autocorrect", 1, true))
  SETTINGS.hsBootVerbose = nil

  run()
  check("bootVerbose() reads the stored preference", _G.bootVerbose() == false)
  _G.bootVerbose(true)
  check("...and writing it PERSISTS, surviving the next reload",
    SETTINGS.hsBootVerbose == true and _G.bootVerbose() == true)
  _G.bootVerbose(false)
  check("...and can be turned back off", SETTINGS.hsBootVerbose == false)

  print = realPrint2
end


-- =====================================================================
-- 8b. THE BOOT COST REPORT, EXECUTED (6.178.0)
-- =====================================================================
-- LL asked whether the config could be trimmed for size. It could not be
-- answered, because nothing measured the boot. This file turns the
-- per-module timings that already existed into a ranking. What is under
-- test is the CONTRACT: it must be silent on a fast boot, loud on a slow
-- one, must never change what loads, and must survive a Mac where the
-- timings, the file sizes or hs.timer are not there at all.
out("\n=== 8b. Boot cost, executed ===\n")
local BC_PATH = HS .. "/core/boot_cost.lua"
local bcChunk = loadfile(BC_PATH)
check("core/boot_cost.lua loads", bcChunk ~= nil, select(2, loadfile(BC_PATH)))

if bcChunk then
  local lines = {}
  local realPrint3 = print
  print = function(...)
    local t = {}
    for i = 1, select("#", ...) do t[#t+1] = tostring((select(i, ...))) end
    lines[#lines+1] = table.concat(t, " ")
  end
  local FIRED = {}
  local realTimer = hs.timer
  hs.timer = { secondsSinceEpoch = realTimer.secondsSinceEpoch,
               doAfter = function(_, fn) FIRED[#FIRED + 1] = fn; return { id = 1 } end }

  local function run(status, over)
    lines, FIRED = {}, {}
    _G.moduleStatus = status
    local api = bcChunk()(over or { moduleDir = "/m" })
    for _, fn in ipairs(FIRED) do fn() end
    return table.concat(lines, "\n"), api
  end

  -- a fast boot: nothing to say, so nothing is said
  local fast = {
    { name = "ui_style", ok = true, ms = 4 },
    { name = "vault",    ok = true, ms = 22, warmMs = 5, warmed = true },
    { name = "mouse_grid", ok = true, ms = 9 },
  }
  local quiet, api = run(fast)
  check("a fast boot prints NOTHING — a line you always see is a line you stop reading",
        quiet == "", quiet)
  check("...and the timer that would have printed it is held, not dropped",
        _G.bootCostTimer ~= nil)
  check("...while the numbers are still there to ask for", type(api) == "table" and type(api.gather) == "function")

  -- one slow module is enough to speak up
  local slow = {
    { name = "ui_style", ok = true, ms = 4 },
    { name = "text_expander", ok = true, ms = 420, warmMs = 900, warmed = true },
    { name = "vault", ok = true, ms = 30 },
  }
  local loud = run(slow)
  check("one slow module IS reported, even when the total is fine",
        loud:find("text_expander 420ms", 1, true) ~= nil, loud)
  check("...and the line points at the full ranking", loud:find("bootCostReport", 1, true) ~= nil)

  -- a slow total, with no single offender
  local many = {}
  for i = 1, 40 do many[i] = { name = "m" .. i, ok = true, ms = 60 } end
  local heavy = run(many)
  check("a slow TOTAL is reported even when no single module stands out",
        heavy:find("2400 ms across 40 modules", 1, true) ~= nil, heavy)

  -- the full report
  run(slow)
  lines = {}
  local n = _G.bootCostReport()
  local full = table.concat(lines, "\n")
  check("the report ranks every module, slowest first", n == 3
        and full:find("text_expander") < full:find("vault"), full)
  check("...and carries the warm phase, which runs AFTER the boot line",
        full:find("+900 ms warm", 1, true) ~= nil, full)
  check("...and the file size beside the time (42 bytes from the fs stub)",
        full:find("0K", 1, true) ~= nil)
  check("...and says plainly that size and speed are not the same thing",
        full:find("NOT the same thing", 1, true) ~= nil)

  -- a module that FAILED is still counted and marked, not quietly dropped
  lines = {}
  run({ { name = "broken", ok = false, ms = 12, err = "syntax error" } })
  lines = {}
  _G.bootCostReport()
  check("a module that failed to load is still in the ranking, marked",
        table.concat(lines, "\n"):find("⚠️ FAILED", 1, true) ~= nil)

  -- ---- it degrades, it never breaks ------------------------------------
  lines = {}
  run({})
  lines = {}
  local zero = _G.bootCostReport()
  check("no timings at all → it says so and returns 0, it does not throw",
        zero == 0 and table.concat(lines, "\n"):find("no module timings", 1, true) ~= nil)
  check("...and the boot line stays silent with nothing to measure",
        (function() local o = run({}) return o == "" end)())

  local realFs = hs.fs
  hs.fs = nil
  local okNoFs = pcall(function() run(slow); lines = {}; _G.bootCostReport() end)
  check("no hs.fs → the timings still rank, the sizes say '?' instead of failing",
        okNoFs and table.concat(lines, "\n"):find("sizes unavailable", 1, true) ~= nil)
  hs.fs = realFs

  hs.timer = { secondsSinceEpoch = realTimer.secondsSinceEpoch }
  local okNoTimer, outNoTimer = pcall(function()
    lines = {}
    _G.moduleStatus = slow
    bcChunk()({ moduleDir = "/m" })
    return table.concat(lines, "\n")
  end)
  check("no hs.timer.doAfter → it prints the line straight away rather than losing it",
        okNoTimer and outNoTimer:find("Boot cost", 1, true) ~= nil, tostring(outNoTimer))

  local okNoStatus = pcall(function()
    lines = {}
    _G.moduleStatus = nil
    bcChunk()({})
    _G.bootCostReport()
  end)
  check("no _G.moduleStatus at all (an older init.lua) costs nothing", okNoStatus)

  -- and the standing promise: it MEASURES, it does not decide
  local bcSrc = (function() local f = realopen(BC_PATH, "r"); local t = f:read("*a"); f:close(); return t end)()
  check("boot_cost.lua never loads, unloads or defers a module — it only reads",
        not bcSrc:find("loadfile", 1, true) and not bcSrc:find("loadModules", 1, true)
        and not bcSrc:find("dofile", 1, true))
  check("...and init.lua loads it in its own pcall, so a broken measurer never costs the boot",
        initLive("core/boot_cost.lua") ~= nil and initLive("bcOK") ~= nil)

  -- ---- 6.179.0: the history, one row per boot --------------------------
  -- The point of the history is the question "is it getting slower?", so
  -- what is under test is that a row is written once, read back, and
  -- COMPARED — and that every way the file can be missing, unwritable or
  -- mangled costs the comparison and nothing else.
  do
    local FILES, WRITES, BLOCK = {}, 0, false
    local realIo = io.open
    -- the degrade tests above left hs.timer without doAfter; the history
    -- rides a timer, so put the stub back before measuring it
    hs.timer = { secondsSinceEpoch = realTimer.secondsSinceEpoch,
                 doAfter = function(_, fn) FIRED[#FIRED + 1] = fn; return { id = 2 } end }
    -- and a truthful fs: a file EXISTS only once something wrote it, which
    -- is how the header-once rule is decided
    local realFs2 = hs.fs
    hs.fs = { attributes = function(pth)
        if FILES[pth] then return { mode = "file", size = #FILES[pth] } end
        return nil
    end }
    io.open = function(path, mode)
      if (mode or "r"):find("[wa]") then
        if BLOCK then return nil, "read-only file system" end
        WRITES = WRITES + 1
        local buf = { (mode or ""):find("a") and (FILES[path] or "") or "" }
        return { write = function(_, x) buf[#buf + 1] = x return true end,
                 -- a real append handle answers its own size, which is how
                 -- record() decides whether the header is already there
                 seek = function() return #table.concat(buf) end,
                 close = function() FILES[path] = table.concat(buf) end }
      end
      if FILES[path] == nil then return nil end
      local done = false
      return { read = function() if done then return nil end done = true return FILES[path] end,
               close = function() end }
    end

    local function fresh(over)
      lines, FIRED = {}, {}
      _G.moduleStatus = slow
      local api = bcChunk()(over or { moduleDir = "/m", logsDir = "/logs", hostTag = "TestMac" })
      for _, fn in ipairs(FIRED) do fn() end
      return api
    end

    local api = fresh()
    local FILE = "/logs/boot_cost-TestMac.csv"
    check("6.179.0: a boot appends one row to Logs/boot_cost-<Mac>.csv",
          type(FILES[FILE]) == "string" and select(2, FILES[FILE]:gsub("\n", "")) == 2,
          tostring(FILES[FILE]))
    check("...with a header first, so Excel opens it",
          FILES[FILE]:find("^when,version,profile,modules,loadMs,warmMs,slowest,slowestMs,epoch") ~= nil)
    check("...naming the slowest module of that boot",
          FILES[FILE]:find('"text_expander",420', 1, true) ~= nil, FILES[FILE])
    check("...and it is written a few seconds LATER, after the warm phase, on a held timer",
          _G.bootCostHistoryTimer ~= nil)

    local before = WRITES
    fresh()
    check("a second boot APPENDS — the header is not repeated and the first row survives",
          select(2, FILES[FILE]:gsub("\n", "")) == 3
          and select(2, FILES[FILE]:gsub("when,version", "")) == 1, FILES[FILE])
    check("...and appending is the only write, so the file can never shrink", WRITES == before + 1)

    local rows = api.readHistory(10)
    check("the history reads back", #rows == 2 and rows[1].loadMs == 454, #rows)
    check("...knowing which module was slowest", rows[1].slowest == "text_expander")
    check("the usual boot is a MEDIAN, so one bad boot does not move it", (function()
        local usual, n = api.usualMs({ { loadMs = 100 }, { loadMs = 110 }, { loadMs = 9000 } })
        return usual == 110 and n == 3
    end)())

    -- the drift line: slower than usual, even when under every threshold
    for i = 1, 6 do
      FILES[FILE] = FILES[FILE] .. string.format('"2026-09-0%d 08:00:00","6.179.0","Home",3,100,0,"vault",30,%d\n', i, i)
    end
    -- two modules at 120 ms: 240 ms total — under slowTotalMs (1500) and
    -- neither over slowModuleMs (150), so ONLY the drift can speak here
    _G.moduleStatus = { { name = "vault", ok = true, ms = 120 },
                        { name = "expander", ok = true, ms = 120 } }
    lines, FIRED = {}, {}
    bcChunk()({ moduleDir = "/m", logsDir = "/logs", hostTag = "TestMac" })
    for _, fn in ipairs(FIRED) do fn() end
    local drift = table.concat(lines, "\n")
    check("a boot well over what this Mac usually takes is reported even when it is under every absolute threshold",
          drift:find("usually takes 100", 1, true) ~= nil, drift)
    check("...and that comparison is made SECONDS after the boot, off the boot path — "
          .. "it is still a main-thread read of a OneDrive file, which the module says "
          .. "out loud as a known limit; what must never happen is doing it AT boot",
          (function()
              lines, FIRED = {}, {}
              bcChunk()({ moduleDir = "/m", logsDir = "/logs", hostTag = "TestMac" })
              local atBoot = table.concat(lines, "\n")     -- before any timer fires
              for _, fn in ipairs(FIRED) do fn() end
              return atBoot == "" and table.concat(lines, "\n"):find("usually takes", 1, true) ~= nil
          end)())

    -- ...and it stays quiet when the boot is normal for this Mac
    _G.moduleStatus = { { name = "vault", ok = true, ms = 120 } }
    lines, FIRED = {}, {}
    bcChunk()({ moduleDir = "/m", logsDir = "/logs", hostTag = "TestMac" })
    for _, fn in ipairs(FIRED) do fn() end
    check("a normal boot for this Mac still says nothing", table.concat(lines, "\n") == "",
          table.concat(lines, "\n"))

    -- ---- it degrades, it never breaks ----------------------------------
    lines, FIRED = {}, {}
    _G.moduleStatus = slow
    local noLogs = bcChunk()({ moduleDir = "/m" })
    for _, fn in ipairs(FIRED) do fn() end
    check("no Logs folder → no history, no error, and the report says so", (function()
        local okR, why = noLogs.record()
        lines = {}
        _G.bootCostReport()
        return okR == false and tostring(why):find("no Logs", 1, true)
               and table.concat(lines, "\n"):find("history: off", 1, true) ~= nil
    end)())

    BLOCK = true
    local api2 = fresh()
    check("an unwritable Logs folder costs the row, not the boot", (function()
        local okR, why = api2.record()
        return okR == false and tostring(why):find("read%-only")
    end)(), "no error surfaced")
    BLOCK = false

    check("...and the report SAYS it is not being written rather than claiming a first boot", (function()
        lines = {}
        _G.bootCostReport()
        local o = table.concat(lines, "\n")
        return o:find("NOT being written", 1, true) and o:find("read%-only")
    end)(), table.concat(lines, "\n"))

    FILES[FILE] = "not a csv at all\nnor is this\n"
    check("a mangled history file reads as no history rather than throwing",
          #api2.readHistory(10) == 0)
    check("...and a clean instance with no rows yet says there is nothing to compare", (function()
        lines, FIRED = {}, {}
        local clean = bcChunk()({ moduleDir = "/m", logsDir = "/logs", hostTag = "TestMac" })
        lines = {}
        _G.bootCostReport()
        return table.concat(lines, "\n"):find("nothing to compare", 1, true) ~= nil
    end)(), table.concat(lines, "\n"))

    -- 🚨 the file is append-only and uncapped, so the READ has to be bounded
    do
        local rows = {}
        for i = 1, 4000 do
            rows[#rows + 1] = string.format('"2026-01-01 00:00:00","6.179.0","Home",67,%d,0,"vault",30,%d', 100 + i, i)
        end
        FILES[FILE] = "when,version,profile,modules,loadMs,warmMs,slowest,slowestMs,epoch\n"
                      .. table.concat(rows, "\n") .. "\n"
        -- a file handle that can SEEK, which is what the real io.open gives
        local realIo2 = io.open
        io.open = function(path, mode)
            if (mode or "r"):find("[wa]") then return realIo2(path, mode) end
            local blob = FILES[path]
            if blob == nil then return nil end
            local pos = 0
            return {
                seek = function(_, whence, off)
                    if whence == "end" then pos = #blob + (off or 0)
                    elseif whence == "set" then pos = off or 0
                    end
                    return pos
                end,
                read = function() local r = blob:sub(pos + 1); pos = #blob; return r end,
                close = function() end,
            }
        end
        local t0 = os.clock()
        local got = api2.readHistory(10)
        local secs = os.clock() - t0
        io.open = realIo2
        check("a history of 4,000 boots still reads only its TAIL — the cost cannot grow with the file",
              #got == 10 and secs < 0.05, #got .. " rows in " .. string.format("%.3fs", secs))
        check("...and the ten it returns are the ten most RECENT, in order",
              got[10].loadMs == 4100 and got[1].loadMs == 4091,
              tostring(got[1] and got[1].loadMs) .. ".." .. tostring(got[10] and got[10].loadMs))
    end

    -- the header goes in ONCE, and that must not depend on hs.fs
    do
      local realFs3 = hs.fs
      hs.fs = nil
      FILES[FILE] = nil
      local api4 = fresh()
      api4.record(); api4.record()
      hs.fs = realFs3
      check("with no hs.fs at all the header is still written ONCE — the handle "
            .. "itself answers whether the file is empty",
            select(2, (FILES[FILE] or ""):gsub("when,version", "")) == 1,
            tostring(FILES[FILE]))
    end

    -- the writer must never emit a row the reader cannot read back
    do
        _G.moduleProfileName = 'we"ird, name'
        _G.moduleStatus = { { name = "a,b\nc", ok = true, ms = 12 } }
        FILES[FILE] = nil
        local api3 = fresh()
        _G.moduleProfileName = "TestMac"
        check("a name with a quote, a comma or a newline in it still reads back — "
              .. "the writer flattens what the reader cannot parse",
              #api3.readHistory(10) == 1, tostring(FILES[FILE]))
    end

    FILES[FILE] = nil
    check("no history file yet (a first boot) is not an error", #api2.readHistory(10) == 0)

    io.open = realIo
    hs.fs = realFs2
  end

  hs.timer = realTimer
  _G.moduleStatus = {}
  print = realPrint3
end


-- =====================================================================
-- 8c. THE KEY TRAIL, EXECUTED (6.179.0)
-- =====================================================================
-- Every hard bug in this config was reconstructed from memory days
-- later. The trail exists so the last few presses can be READ instead.
-- Under test: the ring really is a ring, a slow press is marked, a press
-- swallowed by the pause switch is marked as such rather than missing,
-- and — the promise that matters — no typed text can ever get in.
out("\n=== 8c. Key trail, executed ===\n")
local KT_PATH = HS .. "/core/key_trail.lua"
local ktChunk = loadfile(KT_PATH)
check("core/key_trail.lua loads", ktChunk ~= nil, select(2, loadfile(KT_PATH)))

if ktChunk then
  local lines = {}
  local realPrint4 = print
  print = function(...)
    local t = {}
    for i = 1, select("#", ...) do t[#t+1] = tostring((select(i, ...))) end
    lines[#lines+1] = table.concat(t, " ")
  end
  local CLOCK = 1000
  local realTimer2 = hs.timer
  hs.timer = { secondsSinceEpoch = function() return CLOCK end }

  local trail = ktChunk()({})
  check("it publishes the recorder init.lua calls", type(_G.keyTrailRecord) == "function")
  check("...and the report", type(_G.keyTrailReport) == "function")

  lines = {}
  local none = _G.keyTrailReport()
  check("with nothing pressed it says so and returns 0",
        none == 0 and table.concat(lines, "\n"):find("nothing pressed yet", 1, true) ~= nil)

  _G.keyTrailRecord("1", "scratch pad", 18)
  CLOCK = CLOCK + 30
  _G.keyTrailRecord("x", "mouse grid", 1420)
  CLOCK = CLOCK + 5
  _G.keyTrailRecord("shift+1", "paused", 0, "paused")
  CLOCK = CLOCK + 5
  _G.keyTrailRecord("y", "chrome history", 12, "threw")

  check("newest is FIRST — the last thing pressed is the first thing read",
        trail.rows[1].combo == "y" and trail.rows[#trail.rows].combo == "1")
  check("it counts what matters", trail.seen == 4 and trail.slow == 1
        and trail.threw == 1 and trail.paused == 1,
        trail.seen .. "/" .. trail.slow .. "/" .. trail.threw .. "/" .. trail.paused)

  lines = {}
  local n = _G.keyTrailReport()
  local report = table.concat(lines, "\n")
  check("the report prints every row", n == 4)
  check("a slow press is marked, with its milliseconds",
        report:find("1420 ms", 1, true) and report:find("⚠️ slow", 1, true), report)
  check("a press the PAUSE switch swallowed says so — a dead keyboard is explained, not a gap",
        report:find("⏸ paused — it did nothing", 1, true) ~= nil, report)
  check("a shortcut that threw is marked", report:find("⛔ THREW", 1, true) ~= nil)
  check("...and each row says how long ago it was, not a timestamp",
        report:find("40s ago", 1, true) and report:find("0s ago", 1, true), report)
  check("the summary counts the session", report:find("4 presses this session", 1, true) ~= nil)

  check("ages read in minutes and hours once they are older", (function()
      return trail.ago(59) == "59s ago" and trail.ago(134) == "2m 14s ago"
             and trail.ago(7300) == "2h 01m ago"
  end)(), trail.ago(134) .. " / " .. trail.ago(7300))

  check("a duration is never negative — the wall clock steps at login and on wake", (function()
      local t3 = ktChunk()({})
      local r1 = _G.keyTrailRecord("q", "test", -1200)
      local r2 = _G.keyTrailRecord("w", "test", 0 / 0)
      local ok = r1.ms == 0 and r2.ms == 0 and t3.slow == 0
      ktChunk()({})   -- back to a clean trail for the rows below
      trail = _G.keyTrail
      _G.keyTrailRecord("1", "scratch pad", 18)
      CLOCK = CLOCK + 30
      _G.keyTrailRecord("x", "mouse grid", 1420)
      CLOCK = CLOCK + 5
      _G.keyTrailRecord("shift+1", "paused", 0, "paused")
      CLOCK = CLOCK + 5
      _G.keyTrailRecord("y", "chrome history", 12, "threw")
      return ok
  end)())

  -- 🚨 the review's finding: a held key must not erase the incident
  do
    local t2 = ktChunk()({})
    _G.keyTrailRecord("shift+escape", "panic chord", 0)
    CLOCK = CLOCK + 1
    for _ = 1, 40 do _G.keyTrailRecord("x", "mouse grid", 0, "paused") end
    check("a key held down collapses to ONE row with a ×count, not forty",
          #t2.rows == 2 and t2.rows[1].times == 40, #t2.rows)
    check("...so the press that led up to the incident is still there to read",
          t2.rows[2].combo == "shift+escape", t2.rows[2] and t2.rows[2].combo)
    check("...and the session counts still count every one of them", t2.seen == 41)
    CLOCK = CLOCK + 60
    _G.keyTrailRecord("x", "mouse grid", 0, "paused")
    check("...while the same key LATER is a new row — the merge is a burst, not a lifetime",
          #t2.rows == 3 and t2.rows[1].times == 1)
    lines = {}
    _G.keyTrailReport()
    check("...and the report shows the ×count", table.concat(lines, "\n"):find("×40", 1, true) ~= nil)
    -- back to the trail this section has been building
    ktChunk()({})
    _G.keyTrailRecord("1", "scratch pad", 18)
    CLOCK = CLOCK + 30
    _G.keyTrailRecord("x", "mouse grid", 1420)
    CLOCK = CLOCK + 5
    _G.keyTrailRecord("shift+1", "paused", 0, "paused")
    CLOCK = CLOCK + 5
    _G.keyTrailRecord("y", "chrome history", 12, "threw")
    trail = _G.keyTrail
  end

  -- the ring is a ring
  trail.keep = 5
  for i = 1, 20 do _G.keyTrailRecord("k" .. i, "test", 1) end
  check("the ring never grows past keep — it is memory, not a log",
        #trail.rows == 5 and trail.rows[1].combo == "k20" and trail.rows[5].combo == "k16",
        #trail.rows)
  check("...while the running counts keep counting", trail.seen == 24)

  -- 🔒 the promise
  local src = (function() local f = realopen(KT_PATH, "r"); local t = f:read("*a"); f:close(); return t end)()
  check("🔒 the trail never reads a keystroke: no eventtap, no keycodes, no pasteboard",
        not src:find("eventtap", 1, true) and not src:find("keyStroke", 1, true)
        and not src:find("pasteboard", 1, true) and not src:find("getCharacters", 1, true))
  check("🔒 ...and never writes anything: no file, no store, no settings",
        not src:find("io.open", 1, true) and not src:find("hs.settings", 1, true)
        and not src:find("os.remove", 1, true))
  check("🔒 ...and says both promises out loud, where the next reader will see them",
        src:find("no typed text", 1, true) and src:find("NEVER WRITES ANYTHING", 1, true) ~= nil)

  -- a caller that knows less still gets a row rather than an error
  check("a record with no arguments at all is a row, not a crash", (function()
      local ok, row = pcall(_G.keyTrailRecord)
      return ok and row.combo == "?" and row.source == "?" and row.ms == 0
  end)())

  -- and init.lua really calls it, on both paths
  check("init.lua records every hyper shortcut AFTER it has run, timed",
        initLive("_G.keyTrailRecord, combo, source, ms") ~= nil)
  check("...and records a press the pause switch swallowed, named by the module that owns the key",
        initLive('_G.hyperBound[combo]) or "paused", 0, "paused"') ~= nil)
  check("...both nil-guarded, so a Mac without the file keeps every shortcut", (function()
      local guards = 0
      for line in initText:gmatch("[^\n]+") do
        if not line:match("^%s*%-%-")
           and (line:find("if _G.keyTrailRecord then", 1, true)
                or line:find("if record and _G.keyTrailRecord then", 1, true)) then
          guards = guards + 1
        end
      end
      return guards == 2, guards
  end)())
  check("⏸ only the PRESSED handler of a real shortcut records a paused press — "
        .. "released, repeat and the forwarded chords do not, or one held key "
        .. "would write fifteen rows a second",
        initLive("hyperPauseWrap(combo, pressedFn, source ~= \"chord\")") ~= nil
        and initLive("hyperPauseWrap(combo, releasedFn)") ~= nil
        and initLive("if record and _G.keyTrailRecord then") ~= nil)
  check("🔎 a shortcut that throws keeps its full traceback — xpcall, not a bare "
        .. "pcall, or the module frames between the key and the throw are gone",
        initLive("xpcall(ranFn, debug.traceback, ...)") ~= nil
        and initLive("ok, r = pcall(ranFn, ...)") ~= nil)
    check("...and the panic chord, which hyperBind never sees, records itself — "
        .. "as a PLAIN row, because a hs.hotkey chord is not a ⇪ shortcut", (function()
      local f = realopen(HS .. "/modules/power_tools.lua", "r")
      local pt = f:read("*a"); f:close()
      return pt:find('_G.keyTrailRecord, "⌃⌥⌘⇧Esc", "panic chord", 0', 1, true) ~= nil
             and pt:find('#failed > 0 and "threw" or nil, true)', 1, true) ~= nil
  end)())
  check("...and a plain row really prints without a ⇪ in front of it", (function()
      local t4 = ktChunk()({})
      _G.keyTrailRecord("⌃⌥⌘⇧Esc", "panic chord", 0, nil, true)
      _G.keyTrailRecord("1", "scratch pad", 5)
      lines = {}
      _G.keyTrailReport()
      local o = table.concat(lines, "\n")
      return o:find("⇪1", 1, true) and not o:find("⇪⌃⌥⌘⇧Esc", 1, true)
  end)())
  check("...and the report is ONE print, so core/console.lua's gate cannot eat a row "
        .. "(test_console proves it against the real gate)", (function()
      lines = {}
      _G.keyTrailReport()
      return #lines == 1, #lines
  end)())

  hs.timer = realTimer2
  print = realPrint4
end


-- =====================================================================
-- 9. WORK-MAC SAFETY: NO ADMIN, NO SYSTEM WRITES, NO SURPRISES
-- =====================================================================
-- The work MacBook is the primary machine and carries NO admin rights.
-- Everything below is a standing guarantee, not a one-time audit: if a
-- future change adds a privileged operation, a write outside $HOME, or
-- a call to a binary that is not on the list, this suite fails before
-- the change ever reaches that Mac.
out("\n=== 9. Work-Mac safety (no admin rights) ===\n")

-- The scan reads STRING LITERALS as code, and it must: my own mutation
-- test proved the point by hiding a sudo inside "sudo mkdir -p " and the
-- scanner caught it. The one exception is the changelog note, which is
-- prose written to a CSV and never executed — a paragraph describing
-- "no sudo, no launchctl" failed the very check it was describing. So
-- that single assignment is excluded BY NAME, and nothing else is.
local function safetyCode(pattern)
  for line in text:gmatch("[^\n]+") do
    if not line:match("^%s*%-%-")
       and not line:match("currentNotes%s*=")
       and not line:match("unusedNotes[%w_]*%s*=")
       and line:find(pattern) then
      return line
    end
  end
end

-- 9a. NOTHING ELEVATES. sudo, an AppleScript asking for administrator
-- privileges, or a chown would each need an admin password the work Mac
-- does not have — and would be an IT red flag besides.
for _, forbidden in ipairs({
  { "sudo",                          "runs a command as root" },
  { "with administrator privileges", "AppleScript's password prompt" },
  { "do shell script.*admin",        "AppleScript shell escalation" },
  { "chown",                         "changes file ownership" },
  { "launchctl",                     "installs or loads a launch daemon" },
  { "security add%-generic%-password", "writes to the login keychain" },
  { "csrutil",                       "touches System Integrity Protection" },
  { "spctl",                         "touches Gatekeeper" },
}) do
  check("never " .. forbidden[2] .. " (" .. forbidden[1] .. ")",
        not safetyCode(forbidden[1]), safetyCode(forbidden[1]))
end

-- 9b. EVERY EXTERNAL BINARY IS ON A KNOWN LIST. An unexpected one is not
-- automatically wrong, but it is something I must have decided on
-- deliberately rather than let drift in.
local ALLOWED_BINARIES = {
  ["/usr/bin/curl"]      = "Asana API + attachment upload (ships with macOS)",
  ["/usr/bin/shortcuts"] = "image OCR via your own Shortcut (ships with macOS)",
  ["/usr/bin/hidutil"]   = "Caps Lock -> hyper remap, per-user (ships with macOS)",
  ["/usr/bin/open"]      = "relaunch an app you asked to reopen (ships with macOS)",
  -- ☁️ 6.367.0 — AND THIS ONE IS A DELIBERATE NON-READ, which is the
  -- reason it is a binary at all. `xattr -s` lists an extended
  -- attribute's NAMES; it does not open the file's contents, so it
  -- cannot hydrate a OneDrive placeholder — and hydrating one is a
  -- download, which on the main thread is the 72-second freeze the
  -- stall guard killed on 2026-10-12 (6.357.0). Names only, never
  -- values: a value can be anything, including bytes. Out of process,
  -- bounded, with a killer timer (6.170.1).
  ["/usr/bin/xattr"]     = "list an extended attribute's NAMES, to ask "
                        .. "whether \"Always keep on device\" is readable "
                        .. "at all — never its values, never the file "
                        .. "(ships with macOS)",
  -- 6.140.0 — screen_veil joined as a second caller: the grayscale
  -- read-back READS com.apple.universalaccess after relaying ⌥⌘F5. It
  -- never writes it — test_features 4b pins that structurally, and the
  -- 9a launchctl/killall bans above already fence off 6.82.0's other
  -- failed routes.
  ["/usr/bin/defaults"]  = "read an app's version from its plist + the "
                        .. "grayscale preference read-back (ships with macOS)",
  -- 🚨 6.65.1 — AND THIS ONE IS A DELIBERATE, LOAD-BEARING CHOICE, which
  -- is exactly what this list exists to record. Every AppleScript in this
  -- config used to run IN PROCESS via hs.osascript.applescript, which
  -- sends Apple Events on Hammerspoon's main thread. An Objective-C
  -- exception from that machinery ABORTS the application, and a Lua
  -- pcall cannot catch it — pcall catches Lua errors, and an ObjC
  -- exception is not one. It crashed LL's Mac on macOS 26.6.1.
  -- Shelling out to the SAME AppleScript means the worst case is a child
  -- process exiting non-zero. The extra binary is the price, and it is
  -- one Apple ships.
  ["/usr/bin/osascript"] = "Finder selection + Finder comment tags, OUT OF "
                        .. "PROCESS so an Apple Event cannot abort us (ships with macOS). "
                        -- 6.146.0 — and the 📎 default-apps tool: its -l JavaScript
                        -- bridge is the only route from here to the LaunchServices
                        -- set-handler API, same binary, same out-of-process safety.
                        .. "Also 📎's LaunchServices read/write via -l JavaScript",
  -- 6.139.0 — the backup no longer goes through a shell at all (rsync is
  -- run directly, argument array); zsh stays reviewed for the two callers
  -- below, each of which passes a fixed command of its own.
  ["/bin/zsh"]           = "universal actions' open-with lines + update "
                        .. "tracker's version checks (ships with macOS)",
  ["/usr/bin/rsync"]     = "the daily backup / rebuild kit copies, run "
                        .. "directly with an argument array (ships with macOS)",
  -- 6.92.0 — ⇪Y reads Chrome's History database. Chrome keeps the live
  -- file locked, so a COPY is queried — by Apple's own sqlite3, out of
  -- process (hs.task), because a 100 MB history must never block the
  -- keyboard. /bin/sh choreographs the copy-then-query; every path
  -- reaches it as a POSITIONAL argument, never interpolated into the
  -- script, which is what makes "Application Support" safe unquoted.
  ["/usr/bin/sqlite3"]   = "⇪Y queries a COPY of Chrome's History (ships with macOS)",
  ["/bin/sh"]            = "chrome_history's copy-then-query runner + the "
                        .. "6.96.0 search-index build script (ships with macOS)",
  -- 6.96.0 — Doc Keywords reads a .docx's text. A .docx IS a zip with
  -- the text at word/document.xml; unzip -p streams that one member to
  -- stdout in a child process — no Word automation, nothing installed,
  -- and a corrupt file is a child exiting non-zero, never a hang here.
  ["/usr/bin/unzip"]     = "doc_keywords reads word/document.xml from a "
                        .. ".docx, OUT OF PROCESS (ships with macOS)",
  -- 6.93.0 — ⇪I asks SPOTLIGHT which files were opened: mdfind finds
  -- them (kMDItemLastUsedDate is stamped only when an app opens a file
  -- FOR the user — the whole plist-exclusion design), mdls reads each
  -- hit's opened/modified dates. Same /bin/sh positional-args runner.
  ["/usr/bin/mdfind"]    = "⇪I finds recently opened/changed files (ships with macOS)",
  ["/usr/bin/mdls"]      = "⇪I reads opened/modified dates per file (ships with macOS)",
  -- 6.86.0 — the ⇪4 screenshot capture. The same binary ⌘⇧4 itself uses;
  -- run with -i to a file in the OneDrive folder, which is what lets one
  -- keystroke both SAVE and COPY where macOS natively only does one.
  ["/usr/sbin/screencapture"] = "⇪4 capture to OneDrive + clipboard (ships with macOS)",
  -- 6.88.0 — ⌃⏎ on a panel history row: re-encode a PNG screenshot as a
  -- small JPEG next to the original. sips is Apple's own image tool.
  ["/usr/bin/sips"] = "⌃⏎ compress screenshot to jpg (ships with macOS)",
  -- 6.120.0 — THE NETWORK TOOLS (⇪6). Four diagnostics LL asked for by
  -- name. Every one ships with macOS and every one is run with bounded
  -- arguments (ping -c, traceroute -m/-w) so it cannot run forever.
  -- ⚠️ The host is passed as a POSITIONAL ARGUMENT to hs.task, never
  -- interpolated into a shell line, so a hostname containing shell
  -- metacharacters is only ever a hostname that will not resolve.
  ["/sbin/ping"]             = "⇪6 ping, bounded by -c (ships with macOS)",
  ["/usr/bin/nslookup"]      = "⇪6 DNS lookup (ships with macOS)",
  ["/usr/sbin/traceroute"]   = "⇪6 traceroute, bounded by -m and -w (ships with macOS)",
  -- The two halves of a DNS flush. The second needs to signal a root
  -- process and therefore CANNOT succeed without admin — the module runs
  -- both, checks both, and reports which one worked, because a half
  -- flush reported as a flush is the failure that wastes an afternoon.
  ["/usr/bin/dscacheutil"]   = "⇪6 flush, half 1 · ⇪⇧6 reverse-resolves each "
                            .. "remote IP, no privileges (ships with macOS)",
  ["/usr/bin/killall"]       = "⇪6 flush, half 2 — needs admin, reported when it "
                            .. "fails rather than hidden (ships with macOS)",
  -- 6.154.0 — THE NETWORK REPORT (⇪6 🩺 / 🧹). Fourteen READ-ONLY questions
  -- in one shell run, every binary shipped by Apple and reaching the
  -- script as a positional argument. None of them is ever run with a
  -- verb that changes anything — test_net_tools pins the banned verbs
  -- (setairportpower, setdnsservers, route flush, arp -d, sudo…) by name.
  ["/usr/bin/dig"]           = "⇪6 timed DNS lookups, the DNS race, the public IP "
                            .. "asked of OpenDNS (ships with macOS)",
  ["/sbin/route"]            = "⇪6 `route -n get default` — the router, read only (ships with macOS)",
  ["/usr/sbin/networksetup"] = "⇪6 hardware ports + the Wi-Fi network — -list/-get only, "
                            .. "never -set (ships with macOS)",
  ["/sbin/ifconfig"]         = "⇪6 `ifconfig -l` — interface names for the tunnel count "
                            .. "(ships with macOS)",
  ["/usr/sbin/scutil"]       = "⇪6 resolvers (--dns) and VPN configurations (--nc list) "
                            .. "(ships with macOS)",
  ["/usr/sbin/arp"]          = "⇪6 `arp -a` — devices on the LAN, never -d (ships with macOS)",
  ["/usr/sbin/netstat"]      = "⇪6 `netstat -rn` — the routing table (ships with macOS)",
  ["/usr/sbin/ipconfig"]     = "⇪6 getifaddr / getsummary — the IP per interface, never "
                            .. "`set` (ships with macOS)",
  -- 6.120.0 — THE MAC PANEL (⇪7). Everything About This Mac shows.
  -- sysctl, sw_vers and df answer instantly and run on the keypress;
  -- system_profiler takes SECONDS and ioreg a tenth of one, so those two
  -- run out of process and fill themselves in when they land.
  ["/usr/sbin/sysctl"]         = "⇪7 chip, memory, model id, boot time (ships with macOS)",
  ["/usr/bin/sw_vers"]         = "⇪7 macOS version and build (ships with macOS)",
  ["/bin/df"]                  = "⇪7 free disk — `df -k` says its unit in its own "
                              .. "name, which hs.fs.freeSpace does not (ships with macOS)",
  ["/usr/sbin/system_profiler"] = "⇪7 the model's MARKETING name, async because it "
                              .. "takes 1-3 SECONDS (ships with macOS)",
  ["/usr/sbin/ioreg"]          = "⇪7 serial number (ships with macOS)",
  ["/usr/bin/grep"]            = "⇪7 picks the serial line out of ioreg; 6.172.0 the vault's [[link]] index (ships with macOS)",
  ["/usr/bin/find"]            = "6.172.0 the vault's note list — in hs.task, so a OneDrive placeholder never blocks the main thread (ships with macOS)",
  ["/bin/cat"]                 = "6.174.0 the vault reads a TEMPLATE's body in hs.task — a OneDrive placeholder would stall a main-thread read (ships with macOS)",
  -- ☁️ 6.368.0 — AND THIS ONE IS A DELIBERATE NON-READ, like xattr above.
  -- `stat` answers st_size and st_blocks — the LOGICAL size and the bytes
  -- really ALLOCATED — and that difference is the only thing on this Mac
  -- that can tell a file from a OneDrive placeholder WITHOUT OPENING IT.
  -- It is run by `find -exec`, one child for many files, in an hs.task
  -- with a killer timer: the alternative is stat'ing twenty thousand
  -- files on the main thread, which is the cost 6.228.0 exists to fear.
  ["/usr/bin/stat"]            = "☁️ the OneDrive watch reads each file's "
                              .. "size and ALLOCATED blocks — never its "
                              .. "contents, because reading a placeholder "
                              .. "downloads it (ships with macOS)",
  -- 6.120.0 — ⇪⇧` REVEALS GHOSTTY'S FOLDER. A terminal's directory
  -- belongs to the SHELL, not the window, and is published nowhere a
  -- neighbouring process can read. The window title is tried first
  -- because it names the FRONT window; this pipeline is the fallback
  -- when the title is not a path.
  ["/usr/bin/pgrep"]         = "⇪⇧` finds Ghostty's child shells (ships with macOS)",
  ["/usr/sbin/lsof"]         = "⇪⇧` reads a shell's cwd · ⇪⇧6 lists every app's "
                            .. "live connections, one snapshot per press (ships with macOS)",
  ["/usr/bin/xargs"]         = "⇪⇧` feeds one pid to lsof (ships with macOS)",
  ["/usr/bin/sed"]           = "⇪⇧` extracts the n-prefixed path (ships with macOS)",
  ["/usr/bin/tail"]          = "⇪⇧` takes the newest shell (ships with macOS)",
  -- 6.119.0 — ⇪⇧; lists and ends processes. Two ps calls joined on pid,
  -- because comm and args both contain spaces and one call leaves no
  -- separator a pattern can find.
  ["/bin/ps"]                = "⇪⇧; the process list, twice (ships with macOS)",
  ["/bin/kill"]              = "⇪⇧; ends one — four names refused outright, "
                            .. "under ⌥ as well (ships with macOS)",
  ["/opt/homebrew/bin/brew"] = "OPTIONAL update checks, admin install",
  ["/usr/local/bin/brew"]    = "OPTIONAL update checks, admin install",
  -- the no-admin Homebrew prefixes, which are $HOME-relative in the source
  -- (home .. "/homebrew/bin/brew") and so arrive here without the prefix
  ["/homebrew/bin/brew"]        = "OPTIONAL, under $HOME — the no-admin install",
  ["/.homebrew/bin/brew"]       = "OPTIONAL, under $HOME — the no-admin install",
  ["/.local/homebrew/bin/brew"] = "OPTIONAL, under $HOME — the no-admin install",
}
-- 🚨 6.133.0 — OPTIONAL BINARIES ARE A SEPARATE TABLE, NOT AN ENTRY IN
-- THE ONE ABOVE. ⇪8 looks for WordNet's `wn`, which does NOT ship with
-- macOS — so filing it under ALLOWED_BINARIES would have silenced 9c by
-- asserting something untrue. The claim 9c makes is the one that matters
-- on a managed Mac and it must stay exactly true: every binary this
-- config REQUIRES is one macOS already ships. Anything here is one it
-- can do without, the way it does without brew — the feature degrades
-- and says so, and nothing else changes.
local OPTIONAL_BINARIES = {
  -- ~/bin/wn arrives here as "/bin/wn": the search path is built as
  -- home .. "/bin/wn", so the quoted fragment in the source looks like a
  -- system path to this scan. It is not one.
  ["/bin/wn"] = "OPTIONAL, under $HOME — WordNet for ⇪8; without it the "
             .. "define panel hands off to Dictionary.app instead",
}
local seen, unexpected = {}, {}
for line in text:gmatch("[^\n]+") do
  if not line:match("^%s*%-%-") then
    for path in line:gmatch('"(/[%w%./_%-]+)"') do
      -- only executables: a path handed to hs.task/os.execute, not data
      if path:match("^/usr/bin/") or path:match("^/bin/") or path:match("^/sbin/")
         or path:match("^/usr/sbin/") or path:match("brew$") then
        seen[path] = true
        if not (ALLOWED_BINARIES[path] or OPTIONAL_BINARIES[path]) then
          unexpected[#unexpected+1] = path
        end
      end
    end
  end
end
check("no external binary outside the reviewed list",
      #unexpected == 0, table.concat(unexpected, ", "))
check("...and the list is not empty (the scan actually ran)", next(seen) ~= nil)

-- 9c. EVERY BINARY USED IS ONE macOS ALREADY SHIPS, except brew, which
-- is optional. This is the claim that matters for a managed Mac: the
-- config installs nothing and depends on nothing IT has to approve.
for path in pairs(seen) do
  if not (path:match("brew$") or OPTIONAL_BINARIES[path]) then
    check("ships with macOS: " .. path, ALLOWED_BINARIES[path] ~= nil)
  end
end

-- 9d. BREW IS OPTIONAL, AND ITS ABSENCE IS HANDLED. If IT blocks it, or
-- it is simply not installed, the config must lose one feature and say
-- so — not fail, not retry forever, not nag.
local ut = moduleText.update_tracker or ""
-- 6.87.0 carve-out: the screenshots module LOOKS UNDER the brew prefixes
-- for zbarimg (the optional QR decoder) — it checks file existence and
-- runs zbarimg itself, never brew. Lines mentioning zbar are that lookup;
-- any OTHER brew reference in it still fails here.
-- 6.139.0 — daily_backup joins update_tracker as a legitimate brew
-- RUNNER: the rebuild kit's Brewfile comes from `brew bundle dump`, the
-- manifest asks `brew list --cask` who it already owns, and adoption
-- asks `brew search`. All three go through hs.task with argument
-- arrays, all three stand down when brew is absent, and the module's
-- own suite (test_daily_backup §7) proves the degradation. Any brew
-- reference in any OTHER module still fails here.
check("brew is RUN only from update_tracker and daily_backup (screenshots "
      .. "may look under the brew prefixes for zbarimg)", (function()
  for name, body in pairs(moduleText) do
    if name ~= "update_tracker" and name ~= "daily_backup" then
      for line in body:gmatch("[^\n]+") do
        -- 6.120.0 — power_tools joins the same carve-out. ⇪5 reads QR
        -- codes and asks screenshots.lua for the zbarimg path by service
        -- name rather than keeping a second copy of the search list; the
        -- ONLY place it says "brew" is the sentence that tells you how to
        -- install the decoder when there isn't one. Any OTHER brew
        -- reference in either module still fails here.
        -- 6.133.0 — define.lua joins the same carve-out for the same
        -- reason. ⇪8 looks under the brew prefixes for `wn` and runs wn
        -- itself; the only place it says "brew" other than those paths
        -- is the sentence telling you how to install WordNet when there
        -- isn't one. Any OTHER brew reference in any of the three still
        -- fails here.
        -- 6.154.0 — net_tools joins the carve-out on the same terms. ⇪6's
        -- 🚀 speed test looks under the brew prefixes for speedtest-cli
        -- and runs it itself; the only other place it says "brew" is the
        -- install command the row copies when there isn't one. Any OTHER
        -- brew reference in it still fails here.
        if not line:match("^%s*%-%-") and line:find("brew", 1, true)
           and not ((name == "screenshots" or name == "power_tools")
                    and line:lower():find("zbar", 1, true))
           and not (name == "define"
                    and (line:lower():find("wordnet", 1, true)
                         or line:find("/bin/wn", 1, true)))
           and not (name == "net_tools"
                    and line:lower():find("speedtest", 1, true))
           -- 6.216.0 — bluetooth joins on the same terms: ⇪⇧7 looks under
           -- the brew prefixes for blueutil and runs blueutil itself; the
           -- only other "brew" is the install command the top row copies
           -- when there isn't one. Any OTHER brew reference still fails.
           and not (name == "bluetooth"
                    and line:lower():find("blueutil", 1, true)) then
          return false, name
        end
      end
    end
  end
  for line in initText:gmatch("[^\n]+") do
    if not line:match("^%s*%-%-") and not line:match("currentNotes%s*=")
       and line:find("brew", 1, true) then return false, "init.lua" end
  end
  return true
end)())
check("...a missing brew is reported, not thrown", ut:find("no Homebrew found", 1, true) ~= nil)
check("...and every brew lookup is wrapped so a blocked shell cannot raise",
      (function()
        for line in ut:gmatch("[^\n]+") do
          if not line:match("^%s*%-%-") and line:find("hs.execute", 1, true)
             and not line:find("pcall", 1, true) then
            -- allowed only if the enclosing line is inside a pcall block;
            -- the shipped code wraps each one, so a bare call is a fail
            local before = ut:sub(1, ut:find(line, 1, true))
            if not before:sub(-400):find("pcall", 1, true) then return false, line end
          end
        end
        return true
      end)())
check("...the no-admin install locations are searched FIRST",
      (function()
        local iHome = ut:find('home %.%. "/homebrew/bin/brew"')
        local iOpt  = ut:find('"/opt/homebrew/bin/brew"')
        return iHome ~= nil and iOpt ~= nil and iHome < iOpt
      end)())

-- 9e. NOTHING IS WRITTEN OUTSIDE THE USER'S OWN DIRECTORY. Every write
-- target is built from logsDir or configDir, both of which resolve under
-- $HOME (OneDrive lives at ~/Library/CloudStorage/...).
check("every file written is under the user's home directory", (function()
  for line in text:gmatch("[^\n]+") do
    if not line:match("^%s*%-%-") then
      local target = line:match('io%.open%(%s*"(/[^"]+)"%s*,%s*"[wa]')
      if target then return false, target end        -- a hard-coded absolute write
    end
  end
  return true
end)())
check("...and the log root itself is $HOME-based on both branches",
      initLive('logsDir   = cloudDir .. "/Logs"')
      and initLive('logsDir   = hs.configdir .. "/logs"'))

-- 9f. THE REMAP IS PER-USER AND ITS REFUSAL IS HANDLED. hidutil
-- property --set affects only the logged-in user and needs no password,
-- but a managed Mac can still refuse it. That must cost the hyper key
-- and nothing else.
check("the Caps Lock remap is a per-user hidutil property set, not a daemon",
      initLive('"property", "--set"') ~= nil and not safetyCode("launchctl"))
check("...and a refusal is caught and explained, not fatal",
      initText:find("hidutil could not remap", 1, true) ~= nil
      and initText:find("Everything else still works", 1, true) ~= nil)

-- 9g. THE ONLY HOST THIS CONFIG CONTACTS IS ASANA.
-- The first version of this check failed on shottr.cc and was WRONG to.
-- There is a difference worth keeping straight: a host the config talks
-- to by itself, versus a vendor download page handed to your browser
-- because you selected that row and pressed Enter. The second is you
-- clicking a link. Only the first is network activity this config
-- initiates, and that is what is asserted here.
-- 🚨 6.133.0 — THE RULE GAINED ITS FIRST EXCEPTION, AND GOT STRICTER
-- FOR IT. ⇪8 can ask dictionaryapi.dev for a definition. Widening this
-- to "these hosts" would have retired the only property worth having,
-- so the exception is NAMED and the thing now asserted is the one that
-- actually protects the work Mac: the shipped default must be OFF, and
-- the fetch must be gated on the same switch. A host in this table is a
-- host you can turn on; it is not a host this config contacts.
local OPT_IN_HOSTS = {
  ["api.dictionaryapi.dev"] = { module = "define", switch = "allowNetwork" },
}
check("the only host the config CONTACTS unasked is Asana",
      (function()
        local hosts = {}
        for line in text:gmatch("[^\n]+") do
          if not line:match("^%s*%-%-") then
            -- a URL is only "contacted" if it reaches an HTTP call or curl
            if line:find("hs.http", 1, true) or line:find("asyncPost", 1, true)
               or line:find("curl", 1, true) or line:find("api.", 1, true) then
              for h in line:gmatch('https://([%w%.%-]+)') do hosts[h] = true end
            end
          end
        end
        for h in pairs(hosts) do
          if h ~= "app.asana.com" and not OPT_IN_HOSTS[h] then return false, h end
        end
        return next(hosts) ~= nil        -- and the scan must have found it
      end)())
-- 🚨 AND EVERY OPT-IN HOST SHIPS OFF. This is the check that replaces
-- what the old wording promised. A default flipped to true — by an
-- edit, a merge, or a good intention — turns a tool that sends nothing
-- anywhere into one that sends the words you are writing to a third
-- party, silently, on a managed machine. It fails the gate instead.
for host, spec in pairs(OPT_IN_HOSTS) do
  local body = moduleText[spec.module] or ""
  -- ⚠️ CODE ONLY. The first version of this check searched the raw file
  -- and failed on the module's own refusal message — the sentence that
  -- tells you how to switch the provider ON contains the assignment as
  -- text. A sentry that cannot tell an instruction from a string would
  -- have been silenced by rewording the message, which is exactly the
  -- wrong lesson. Comments and string literals come out first, the same
  -- way the showPopup audit strips comments before counting calls.
  local code = body:gsub("%-%-[^\n]*", ""):gsub('"[^"\n]*"', '""')
  check("🚨 " .. host .. " is OFF in the shipped source ("
        .. spec.module .. "." .. spec.switch .. " = false)",
        code:find("%." .. spec.switch .. "%s*=%s*false") ~= nil
        and code:find("%." .. spec.switch .. "%s*=%s*true") == nil,
        code:match("[%w_]*%." .. spec.switch .. "%s*=%s*%w+"))
  check("..." .. host .. "'s fetch is gated on that switch, so turning it "
        .. "off really stops it", (function()
          for line in body:gmatch("[^\n]+") do
            if not line:match("^%s*%-%-") and line:find("asyncGet", 1, true) then
              -- the guard is the line above it in the same function
              local at = body:find(line, 1, true)
              return body:sub(math.max(1, at - 400), at)
                         :find("if not " .. "d%." .. spec.switch) ~= nil
            end
          end
          return false
        end)())
  check("..." .. host .. " is reachable only through a provider that "
        .. "reports itself unavailable when the switch is off",
        body:find("available = function%(%) return d%." .. spec.switch) ~= nil)
end
check("...every OTHER url is only ever handed to your browser, never fetched",
      (function()
        local ut2 = moduleText.update_tracker or ""
        -- the vendor pages live in one table and are opened from one place
        if not ut2:find("hs.urlevent.openURL(choice.url)", 1, true) then return false end
        for line in ut2:gmatch("[^\n]+") do
          if not line:match("^%s*%-%-") and line:find("https://", 1, true) then
            -- a vendor row is data: `url = "https://..."`, never a call
            if not line:find('url%s*=%s*"https://') then return false, line end
          end
        end
        return true
      end)())
check("...and those vendor pages open only on a row YOU selected",
      (moduleText.update_tracker or ""):find("hs.urlevent.openURL(choice.url)", 1, true) ~= nil)
check("...and it is off entirely without secret.lua",
      initLive("asanaEnabled") ~= nil and initText:find("secret.lua", 1, true) ~= nil)


-- =====================================================================
-- 10. CAPABILITIES, EXECUTED — the two-Mac contract (6.44.13)
-- =====================================================================
-- One init.lua runs on a personal Mac with admin rights and a managed
-- work Mac with none. This block drives BOTH profiles through the real
-- file and reads what it says, because "works on both Macs" is a claim
-- that can only be checked by asking it as both Macs.
out("\n=== 10. Capabilities, executed ===\n")
local CAP_PATH = HS .. "/core/capabilities.lua"
local capChunk = loadfile(CAP_PATH)
check("core/capabilities.lua loads", capChunk ~= nil, select(2, loadfile(CAP_PATH)))

if capChunk then
  local AX = true
  hs.accessibilityState = function() return AX end

  local function asMac(cfg, globals)
    -- A LIST, not a table of nils. `{ brewPathInUse = nil }` stores
    -- nothing at all — pairs() never yields a nil value — so the reset
    -- silently did nothing and the previous Mac's brew path leaked into
    -- the next profile, reporting brew ON for a Mac that has none. The
    -- same trap that makes `#` unreliable on a list with holes.
    for _, k in ipairs({ "hyperRemapOK", "hyperRemapWhy",
                         "ocrShortcutAvailable", "brewPathInUse",
                         -- 6.196.0 — secure input is state like the rest of
                         -- them, and a leaked reading from the previous Mac
                         -- is the exact trap the loop above exists for.
                         "secureInput" }) do
      _G[k] = nil
    end
    _G.moduleLoaded, _G.moduleFailed = 18, 0
    for k, v in pairs(globals or {}) do _G[k] = v end
    local base = { cloudDir = "/cloud", logsDir = "/cloud/Logs",
                   backupDir = "/cloud/Backups", hostTag = "TestMac",
                   asanaEnabled = true, secretsStatus = "loaded",
                   hyperEnabled = true }
    for k, v in pairs(cfg or {}) do if v == false then base[k] = nil else base[k] = v end end
    capChunk()(base)
    local caps, by = _G.capabilities(), {}
    for _, c in ipairs(caps) do by[c.key] = c end
    return by, _G.capabilityReport()
  end

  -- ---- the personal Mac: everything on ------------------------------
  AX = true
  local home, homeReport = asMac({}, { hyperRemapOK = true, ocrShortcutAvailable = true,
                                       brewPathInUse = "/opt/homebrew/bin/brew",
                                       secureInput = { on = false, checks = 1 } })
  for _, k in ipairs({ "cloud", "backup", "asana", "ax", "hyper", "ocr", "brew",
                       "modules", "secureinput" }) do
    check("personal Mac — " .. k .. " reports ON", home[k] and home[k].state == "ON",
          home[k] and home[k].state)
  end
  check("...and the report says so in one line",
        homeReport:find("Everything this config can do", 1, true) ~= nil)
  check("...with no cost lines, because nothing is degraded",
        homeReport:find("↳", 1, true) == nil)

  -- ---- 🔒 secure input: three states, and the ON one is the point ----
  -- 6.196.0. Chrome held Secure Input for four hours while every other
  -- row on this report said ON, so this row is the one that has to be
  -- right in all three of its states — and "ON" here means the CAPABILITY
  -- is off, which is the inversion most likely to be got backwards.
  do
    local si = asMac({}, { hyperRemapOK = true, ocrShortcutAvailable = true,
                           brewPathInUse = "/b",
                           secureInput = { on = true, app = "Google Chrome" } })
    check("🚨 secure input HELD reports the capability as OFF — the row is "
          .. "'can anything else read the keyboard', so a held lock is a "
          .. "capability lost, not gained",
          si.secureinput and si.secureinput.state == "OFF",
          si.secureinput and si.secureinput.state)
    check("...and it NAMES the app, which is the whole reason it exists — "
          .. "'something has your keyboard' is not actionable",
          (si.secureinput.why or ""):find("Google Chrome", 1, true) ~= nil,
          si.secureinput.why)
    check("...and its cost says other apps are affected too — that is how "
          .. "LL can tell this from a fault in here",
          (si.secureinput.cost or ""):find("OTHER APPS", 1, true) ~= nil)

    -- ---- the parser, against LL's own ioreg output ----------------
    -- 🚨 THIS IS THE REAL LINE from LL's Mac on 2026-09-09, trimmed only
    -- of the fields around it. A parser tested against a string invented
    -- here proves the invention, not the format.
    local REAL = '"IOConsoleUsers" = ({"kCGSSessionOnConsoleKey"=Yes,'
      .. '"kCGSSessionUserNameKey"="leeleblanc","kCGSSessionSecureInputPID"=94680,'
      .. '"kCGSSessionUserIDKey"=501})'
    check("🔒 the parser finds the PID in real ioreg output",
          _G.secureInputParse(REAL) == 94680, _G.secureInputParse(REAL))
    check("🚨 ...and a PID of 0 reads as NOBODY, not as process 0 — that is "
          .. "macOS saying the lock is clear, and reporting it as held "
          .. "would cry wolf on every healthy Mac forever",
          _G.secureInputParse('"kCGSSessionSecureInputPID"=0,') == nil)
    check("...output with no such key reads as clear",
          _G.secureInputParse('"kCGSSessionUserIDKey"=501') == nil)
    check("...and a failed command (nil, not a string) never throws",
          _G.secureInputParse(nil) == nil)

    -- ---- 🚨 THE CRASH (6.196.1) ------------------------------------
    -- 6.196.0 held BOTH ioreg probes in one global. The broad fallback is
    -- started from inside the narrow probe's own callback, so starting it
    -- dropped the only reference to the task whose callback was running —
    -- hs.task's finaliser then tore down the NSTask and the callback block
    -- underneath the live frame. A use-after-free: Hammerspoon died
    -- natively, no Lua error, nothing in the Console, and only when a GC
    -- cycle happened to land in that window. On a healthy Mac the narrow
    -- probe finds nothing EVERY time, so that fallback is the normal path.
    --
    -- This is asserted against the SOURCE because the fault is ownership,
    -- not behaviour: a stub hs.task is garbage-collected by nobody, so a
    -- functional test of this passes just as happily with the bug in.
    local capsSrc
    do
        local cf = realopen(HS .. "/core/capabilities.lua", "r")
        if cf then capsSrc = cf:read("*a") ; cf:close() end
    end
    check("🔒 capabilities.lua is readable for the ownership checks",
          capsSrc and #capsSrc > 2000)
    check("🚨 the two ioreg probes are held in SEPARATE slots — one shared "
          .. "global meant starting the fallback released the task whose "
          .. "callback was still running, and that crashed Hammerspoon",
          -- 6.304.0: this named the right rule and matched one exact
          -- SHAPE of it (`= hs.task`), so a single global assigned from
          -- anything else walked straight past. The plural is safe: in
          -- `_G.secureInputTasks =` the character after "Task" is "s",
          -- which is neither whitespace nor "=".
          capsSrc and not capsSrc:match("_G%.secureInputTask%s*="),
          "a single-slot assignment is back")
    -- 6.248.0, third time: this asserted ADJACENCY ("...[slot] = hs.task")
  -- and went red in 6.304.0 on a change that kept the rule perfectly —
  -- reading :start()'s return put an expression between the two halves.
  -- The RULE is that the caller names the slot, so that is what is asked.
  check("...and the slot is chosen by the caller, so the narrow and broad "
          .. "probes cannot land on the same one by accident",
          capsSrc and capsSrc:match("_G%.secureInputTasks%[slot%]%s*="))
    check("🚨 ...and the fallback is STEPPED OFF the narrow callback before "
          .. "it starts — never start a task from inside another task's "
          .. "callback, or its owner can be released under the live frame",
          capsSrc and capsSrc:match("secureInputHop%s*=%s*hs%.timer%.doAfter"))
    check("...and that hop timer is HELD in _G (6.155.0 — an unreferenced "
          .. "timer is collected and a collected timer never fires)",
          capsSrc and capsSrc:match("_G%.secureInputHop%s*="))
    -- A probe that STARTS and never finishes must not read the same as one
    -- that was never attempted: that is precisely what the crash looked
    -- like from outside, and why it survived a release.
    check("🚨 a started probe is counted separately from a completed one",
          capsSrc and capsSrc:match("secureInput%.started"))

    local un = asMac({}, { hyperRemapOK = true, ocrShortcutAvailable = true,
                           brewPathInUse = "/b" })
    check("...and an unprobed Mac reports UNKNOWN, never a confident 'off' "
          .. "— the probe is async and a guess here would be the same lie "
          .. "the boot line told for four hours",
          un.secureinput and un.secureinput.state == "UNKNOWN",
          un.secureinput and un.secureinput.state)
  end

  -- ---- 🚨 THE WEDGE (6.304.0) ---------------------------------------
  -- siBusy lets one probe run at a time, and was cleared in exactly one
  -- place: finish(), reachable only from a task callback. So a probe
  -- that could never finish shut the feature down for the whole session
  -- — silently, with the state reading "not probed yet" and the 60 s
  -- timer ticking straight into the short-circuit. LL's Mac: started 1 ·
  -- checks 0, nine ticks after boot, and again the next day.
  --
  -- DRIVEN, NOT GREPPED. 6.290.0's rule is that the stub must answer what
  -- macOS answers — and 6.265.0's is that driving a path with the
  -- dependency MISSING is not the same as driving it with the dependency
  -- REFUSING. The old stub had no hs.task at all, so siProbe took its
  -- "hs.task is unavailable" branch on every run and the entire probe
  -- body — every line this release fixes — was unreachable by the gate.
  do
    local beltSrc
    do
      local bf = realopen(HS .. "/core/capabilities.lua", "r")
      if bf then beltSrc = bf:read("*a") ; bf:close() end
    end
    local realTask, realTimerSave = hs.task, hs.timer
    local T = { newCalls = 0, started = {}, cb = nil, cbs = {}, startOK = true,
                afters = {}, order = {}, doAfterThrows = false }
    hs.task = {
      new = function(_, cb, args)
        T.newCalls = T.newCalls + 1
        T.order[#T.order + 1] = "task.new"
        -- narrow is `-k IOConsoleUsers`, broad is the whole `-l` dump.
        -- Keeping them apart matters: the BROAD probe is the normal path
        -- on a healthy Mac, and it is the one whose late callback reaches
        -- finish() directly.
        local kind = "narrow"
        for _, a in ipairs(args or {}) do if a == "-l" then kind = "broad" end end
        T.cbs[kind] = cb
        local task = {}
        -- :start() REFUSES BY RETURNING FALSE (libtask.m, task_launch).
        -- A stub that returns the task unconditionally is gentler than
        -- macOS and certifies the bug (6.290.0).
        function task:start()
          if T.startOK then T.cb = cb ; T.started[#T.started + 1] = true ; return self end
          return false
        end
        return task
      end,
    }
    hs.timer = {
      secondsSinceEpoch = realTimerSave and realTimerSave.secondsSinceEpoch,
      doEvery = function() return { stop = function() end } end,
      doAfter = function(secs, fn)
        if T.doAfterThrows then error("no timers on this Mac", 0) end
        T.order[#T.order + 1] = "doAfter"
        -- A STOPPED TIMER DOES NOT FIRE. Storing `fn` raw let a test fire
        -- one that had been stopped, which macOS never does — the stub
        -- being gentler than the provider in the other direction
        -- (6.290.0). Wrapping it means "fire it anyway" is a faithful
        -- question: nothing happens, exactly as on a Mac.
        local t = { stopped = false, secs = secs }
        t.fn = function(...) if not t.stopped then return fn(...) end end
        function t:stop() self.stopped = true end
        T.afters[#T.afters + 1] = t
        return t
      end,
    }
    local function freshMac()
      T.newCalls, T.started, T.cb, T.cbs = 0, {}, nil, {}
      T.afters, T.order = {}, {}
      asMac({}, { hyperRemapOK = true, ocrShortcutAvailable = true, brewPathInUse = "/b" })
      T.newCalls, T.started, T.cb, T.cbs = 0, {}, nil, {}  -- drop the boot probe's
      T.afters, T.order = {}, {}
    end
    -- The belt is the timer with a real delay; the HOP that steps the
    -- broad probe off the narrow callback is a doAfter(0). Told apart by
    -- their delay, because both land in the same recorder.
    local function pick(want)
      for i = #T.afters, 1, -1 do
        local a = T.afters[i]
        if (want == "belt") == ((a.secs or 0) > 0) then return a end
      end
    end
    local function belt() return pick("belt") end
    local function hop()  return pick("hop")  end
    local function capture(fn)
      printed = {}
      pcall(fn)
      return table.concat(printed, "\n")
    end

    -- 1. THE HEADLINE: a refused launch must not wedge the next probe.
    T.startOK = false
    freshMac()
    _G.secureInputCheck()
    local afterFirst = _G.secureInput.started
    _G.secureInputCheck()
    check("🚨 macOS REFUSING to launch ioreg does not wedge the probe — "
          .. "hs.task:start() says no by RETURNING FALSE, not by throwing, "
          .. "so the pcall around it succeeded, finish() was never called "
          .. "and siBusy stayed true for the whole session",
          _G.secureInput.started == afterFirst + 1,
          "started went " .. tostring(afterFirst) .. " -> "
          .. tostring(_G.secureInput.started) .. " (a second probe never ran)")
    check("...and the refusal is COUNTED as a refusal, not just a failure — "
          .. "refused and never-answered want different fixes (6.196.1)",
          (_G.secureInput.refused or 0) >= 1, tostring(_G.secureInput.refused))
    check("...and the state stays UNKNOWN rather than reading a confident "
          .. "'off' off a probe that never ran",
          _G.secureInput.on == nil, tostring(_G.secureInput.on))
    check("🔎 ...and `checks` does NOT move on a failure — it counts "
          .. "COMPLETIONS, and started-vs-checks is the fingerprint that "
          .. "named this bug. Bumping it here makes a Mac where every "
          .. "probe is refused read `started N \u{b7} checks N`, which "
          .. "looks like health (6.196.1)",
          (_G.secureInput.checks or 0) == 0, tostring(_G.secureInput.checks))

    -- 2. A task that starts and never answers: the belt must end it.
    T.startOK = true
    freshMac()
    _G.secureInputCheck()
    local hung = _G.secureInput.started
    _G.secureInputCheck()
    check("...and while a probe really is in flight the next one is still "
          .. "short-circuited — the one-at-a-time rule is not what broke",
          _G.secureInput.started == hung, tostring(_G.secureInput.started))
    check("🛟 a probe that never answers has a BELT armed on it",
          belt() ~= nil and belt().fn ~= nil)
    if belt() and belt().fn then belt().fn() end
    check("🚨 ...and when the belt fires the wedge clears, so the NEXT "
          .. "probe runs — one hung ioreg used to cost the session",
          (function()
            local before = _G.secureInput.started
            _G.secureInputCheck()
            return _G.secureInput.started == before + 1, tostring(before)
          end)())
    check("...and a never-answered probe is counted apart from a refused one",
          (_G.secureInput.timeouts or 0) >= 1, tostring(_G.secureInput.timeouts))

    -- A belt left running after a probe ANSWERS fires later and books a
    -- timeout against a probe that worked — an instrument inventing the
    -- fault it was built to find.
    freshMac()
    _G.secureInputCheck()
    local liveBelt, before = belt(), _G.secureInput.timeouts or 0
    if T.cbs.narrow then T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 77') end
    check("🛟 ...and a probe that ANSWERS stops its own belt, or the belt "
          .. "fires later and books a timeout against a probe that worked",
          liveBelt and liveBelt.stopped == true)
    if liveBelt and liveBelt.fn then liveBelt.fn() end
    check("...proven by firing it anyway: no phantom timeout is counted",
          (_G.secureInput.timeouts or 0) == before,
          tostring(_G.secureInput.timeouts) .. " vs " .. tostring(before))

    -- 3. ORDER, not presence (6.220.0): a belt armed after the ask is no
    -- belt at all for the case where :start() itself blocks.
    freshMac()
    _G.secureInputCheck()
    check("🚨 the belt is armed BEFORE ioreg is asked for, not after",
          T.order[1] == "doAfter" and T.order[2] == "task.new",
          table.concat(T.order, ","))

    -- 4. A stale callback must not close somebody else's probe.
    -- Driven through the BROAD probe on purpose. The narrow callback has
    -- a guard of its own, so a stale NARROW answer never reaches finish()
    -- and proves nothing about finish's own generation check — and broad
    -- is the normal path on a healthy Mac anyway (the narrow form finds
    -- nothing every time). The first version of this drove narrow and
    -- survived its own mutation.
    freshMac()
    _G.secureInputCheck()
    if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end  -- narrow finds nothing
    if hop() and hop().fn then hop().fn() end                  -- ...so broad starts
    local staleCb = T.cbs.broad
    check("...and a narrow probe that finds nothing falls back to the broad "
          .. "one, which is the path a healthy Mac takes every time",
          staleCb ~= nil)
    if belt() and belt().fn then belt().fn() end     -- probe 1 times out
    _G.secureInputCheck()                            -- probe 2 starts
    local duringTwo = _G.secureInput.started
    if staleCb then staleCb(nil, 'kCGSSessionSecureInputPID" = 4242') end
    check("🚨 a callback arriving AFTER its own belt fired does NOT close "
          .. "the probe that is running now — without the generation "
          .. "check it is the same wedge wearing a different hat",
          (function()
            local before = _G.secureInput.started
            _G.secureInputCheck()   -- must be short-circuited: probe 2 is live
            return _G.secureInput.started == before,
                   "a stale answer ended probe " .. tostring(duringTwo)
          end)())
    check("...and the stale answer is not applied to the state either",
          _G.secureInput.pid ~= 4242, tostring(_G.secureInput.pid))

    -- The NARROW callback carries its own generation check, and it is not
    -- covered by the one in finish(): a stale narrow answer with no pid
    -- never reaches finish at all — it arms _G.secureInputHop. Assigning
    -- that slot drops the reference to the LIVE probe's hop timer, and an
    -- unreferenced timer is collected and never fires (6.155.0), so the
    -- running probe would lose its broad fallback and sit until its own
    -- belt. 6.273.0: a line no mutation can kill means the check is
    -- missing, not that the line is spare.
    local function hops()
      local n = 0
      for _, a in ipairs(T.afters) do if (a.secs or 0) == 0 then n = n + 1 end end
      return n
    end
    freshMac()
    _G.secureInputCheck()                                   -- probe 1
    local staleNarrow = T.cbs.narrow
    if belt() and belt().fn then belt().fn() end             -- probe 1 times out
    _G.secureInputCheck()                                   -- probe 2
    if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end  -- probe 2 hops
    local hopsBefore = hops()
    if staleNarrow then staleNarrow(nil, "no pid here") end  -- probe 1 answers, late
    check("🚨 ...and a stale NARROW answer does not arm a second hop over "
          .. "the live probe's own — that slot holds the only reference to "
          .. "it, and a collected timer never fires (6.155.0)",
          hops() == hopsBefore,
          "hops went " .. tostring(hopsBefore) .. " -> " .. tostring(hops()))

    -- And the HOP carries a third one, for the sliver where the belt
    -- expires between arming the hop and the hop firing. Narrow: without
    -- it, a dead probe's hop starts a broad ioreg into the LIVE probe's
    -- broad slot, dropping the reference to its task — collected, never
    -- calls back, and that probe waits for its own belt. Same class as
    -- the two above, so it gets driven rather than trusted.
    freshMac()
    _G.secureInputCheck()                                    -- probe 1
    if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end -- arms probe 1's hop
    local staleHop = hop()
    if belt() and belt().fn then belt().fn() end              -- probe 1 times out
    _G.secureInputCheck()                                    -- probe 2 is live
    local madeBefore = T.newCalls
    if staleHop and staleHop.fn then staleHop.fn() end        -- probe 1's hop, late
    check("🚨 ...and a dead probe's HOP does not start a broad ioreg into "
          .. "the live probe's slot — that assignment drops the only "
          .. "reference to its task",
          T.newCalls == madeBefore,
          "tasks went " .. tostring(madeBefore) .. " -> " .. tostring(T.newCalls))

    -- 5. A Mac with no timers still probes, and SAYS it has no belt
    -- rather than implying one is there (6.196.1).
    T.doAfterThrows = true
    freshMac()
    _G.secureInputCheck()
    T.doAfterThrows = false
    check("...and a Mac that cannot arm a timer still probes, with the "
          .. "missing belt COUNTED rather than assumed",
          (_G.secureInput.noBelt or 0) >= 1 and T.newCalls >= 1,
          "noBelt=" .. tostring(_G.secureInput.noBelt) .. " tasks=" .. tostring(T.newCalls))

    -- 6. The three causes must be readable apart in the report.
    _G.secureInput.refused, _G.secureInput.timeouts = 2, 3
    local rep = capture(_G.secureInputReport)
    check("...and the report names the three causes apart, so one number "
          .. "does not stand for three different fixes",
          rep:find("REFUSED", 1, true) and rep:find("NEVER", 1, true),
          rep)
    _G.secureInput.refused, _G.secureInput.timeouts, _G.secureInput.noBelt = 0, 0, 0
    local quiet = capture(_G.secureInputReport)
    check("🔕 ...and a healthy Mac says none of it — a new instrument is "
          .. "silent when nothing is wrong, or it gets switched off "
          .. "long before it sees the fault it was built for (6.269.0)",
          not quiet:find("REFUSED", 1, true) and not quiet:find("NO belt", 1, true),
          quiet)

    check("🛟 ...and the belt is HELD in its own _G slot (6.196.1 — an "
          .. "unreferenced timer is collected and a collected timer "
          .. "never fires, and a shared slot is the use-after-free)",
          beltSrc and beltSrc:match("_G%.secureInputBelt%s*=%s*hs%.timer%.doAfter"))

    -- =================================================================
    -- 🔒 6.378.0 — THE FIRST READING OF **ON** SPEAKS
    -- =================================================================
    -- The announcement was gated on a CHANGE, and the first reading is
    -- not one: si.on is born nil. So a Mac where Secure Input was
    -- ALREADY HELD when this config started reported it to NOBODY, for
    -- ever — in the row that kills every tap and every hotkey with no
    -- error anywhere, and took his keyboard for four hours in 6.196.0.
    do
      freshMac()
      _G.secureInputCheck()
      local said = {}
      local realPrint = print
      print = function(s) said[#said + 1] = tostring(s) end
      if T.cbs.narrow then
        T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 4242')
      end
      print = realPrint
      local all = table.concat(said, "\n")
      check("🔒 a FIRST reading of ON is announced — there is no later "
            .. "change to announce, because it was already wrong when "
            .. "this config arrived",
            _G.secureInput.on == true
            and all:find("SECURE INPUT IS ON", 1, true) ~= nil, all)
      check("...and it says it was ALREADY held, so a keyboard that has "
            .. "never worked this session is explained",
            all:find("ALREADY held", 1, true) ~= nil, all)
      check("...and a first reading is NOT counted as a change — that "
            .. "number is how many times the state MOVED while watching",
            (_G.secureInput.changes or 0) == 0,
            tostring(_G.secureInput.changes))
      local rep2 = capture(_G.secureInputReport)
      check("...and the report tells 'already held at boot' from 'took it "
            .. "while we watched'",
            rep2:find("ALREADY HELD when this config started", 1, true) ~= nil,
            rep2)
    end

    -- 🔕 AND THE HEALTHY CASE STAYS SILENT, which is the half that keeps
    -- the warning worth reading: a first reading of OFF says nothing at
    -- all (6.269.0 — an instrument that talks on day one is switched off
    -- long before it sees the fault it was built for).
    do
      freshMac()
      _G.secureInputCheck()
      local said = {}
      local realPrint = print
      print = function(s) said[#said + 1] = tostring(s) end
      if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end
      if T.cbs.broad  then T.cbs.broad(nil, "no pid here")  end
      local hopNow = hop()
      if hopNow and hopNow.fn then hopNow.fn() end
      if T.cbs.broad then T.cbs.broad(nil, "no pid here") end
      print = realPrint
      local all = table.concat(said, "\n")
      check("🔕 a first reading of OFF says NOTHING — a line a minute "
            .. "saying 'still fine' is how a warning gets ignored",
            _G.secureInput.on == false
            and all:find("SECURE INPUT", 1, true) == nil
            and all:find("released", 1, true) == nil, all)
      local rep3 = capture(_G.secureInputReport)
      check("...and the report does not claim it was already held",
            rep3:find("ALREADY HELD", 1, true) == nil, rep3)
    end

    -- =================================================================
    -- 📋 6.421.0 — THE LOCK HANDS ITS REPORT TO THE CLIPBOARD
    -- =================================================================
    -- This is the worst of the three keyboard-killers: Secure Input stops
    -- every tap AND every hotkey dispatch system-wide (6.196.0), so he
    -- cannot press ⇪⇧Esc, cannot type `_G.secureInputReport()`, and
    -- cannot reach anything this config draws. The clipboard is the one
    -- channel still open — what is dead is the INPUT, not Hammerspoon, so
    -- the poll that just noticed this is still running and ⌘V is a
    -- shortcut macOS serves itself.
    -- 🔗 BOTH SIDES OF THE JOIN (6.388.0): test_panel_drag proves the DOOR
    -- in core/coexist.lua, and this proves the lock ASKS it.
    do
      local ASKED = {}
      local keptHand = _G.clipHandOff
      _G.clipHandOff = function(who, event, text)
        ASKED[#ASKED + 1] = { who = who, event = event, text = text }
        return true, "the whole report is on your clipboard — ⌘V sends it"
      end

      freshMac()
      _G.secureInputCheck()
      local said = {}
      local realPrint = print
      print = function(s) said[#said + 1] = tostring(s) end
      if T.cbs.narrow then T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 5151') end
      print = realPrint
      local all = table.concat(said, "\n")

      check("📋 a lock hands its report over", #ASKED == 1, #ASKED)
      check("📋 …and it hands over the REPORT, not the one-line warning",
            ASKED[1] and type(ASKED[1].text) == "string"
            and ASKED[1].text:find("SECURE INPUT", 1, true) ~= nil,
            ASKED[1] and ASKED[1].text:sub(1, 80) or "none")
      check("📋 …and the Console line SAYS so, so he knows ⌘V has it "
            .. "without being able to type anything",
            all:find("⌘V", 1, true) ~= nil, all)

      -- 🪪 A COUNTER, NOT THE APP NAME. The same app locking, letting go
      -- and locking again is a NEW event and must hand over again — which
      -- a name alone cannot say, because it has not changed.
      local first = ASKED[1] and ASKED[1].event
      -- 🚨 EACH ANSWER NEEDS ITS OWN PROBE. The first version of this
      -- section fed the callback of a probe that had already finished, and
      -- 6.304.0's generation guard refused it — correctly. A stale answer
      -- is exactly what that guard exists to turn away, so the harness has
      -- to ask for a fresh probe before every answer it supplies.
      _G.secureInputCheck()                                   -- let it go
      if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end
      local hopNow = hop()
      if hopNow and hopNow.fn then hopNow.fn() end
      if T.cbs.broad then T.cbs.broad(nil, "no pid here") end
      _G.secureInputCheck()                                   -- and lock again
      if T.cbs.narrow then T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 5151') end
      check("🪪 the SAME app locking a second time is a NEW event and hands "
            .. "over again — keyed on a counter, because the app's name has "
            .. "not changed and a name alone would read as a duplicate",
            #ASKED == 2 and ASKED[2].event ~= first,
            tostring(first) .. " -> " .. tostring(ASKED[2] and ASKED[2].event))

      -- 🔕 AND LETTING GO HANDS OVER NOTHING. The release is good news and
      -- the keyboard is back, so taking his clipboard for it would be the
      -- tool helping itself for no reason (6.269.0).
      local before = #ASKED
      _G.secureInputCheck()
      if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end
      local hop2 = hop()
      if hop2 and hop2.fn then hop2.fn() end
      if T.cbs.broad then T.cbs.broad(nil, "no pid here") end
      check("🔕 Secure Input RELEASING hands over nothing — the keyboard is "
            .. "back and he can type the command himself",
            #ASKED == before, #ASKED - before)

      -- 🚪 ORDER (6.220.0): the announcement is what he reads, and a
      -- hand-off that throws must cost the sentence and nothing else.
      _G.clipHandOff = function() error("the clipboard exploded", 0) end
      freshMac()
      _G.secureInputCheck()
      local said2 = {}
      print = function(s) said2[#said2 + 1] = tostring(s) end
      if T.cbs.narrow then T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 6262') end
      print = realPrint
      local all2 = table.concat(said2, "\n")
      check("🚪 a hand-off that THROWS still announces the lock, and simply "
            .. "does not claim the clipboard has the report",
            all2:find("SECURE INPUT IS ON", 1, true) ~= nil
            and all2:find("⌘V", 1, true) == nil, all2)

      -- a Hammerspoon with no door at all (an older core/coexist.lua)
      _G.clipHandOff = nil
      freshMac()
      _G.secureInputCheck()
      local said3 = {}
      print = function(s) said3[#said3 + 1] = tostring(s) end
      if T.cbs.narrow then T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 7373') end
      print = realPrint
      check("🛟 with no hand-off door at all the announcement is unchanged",
            table.concat(said3, "\n"):find("SECURE INPUT IS ON", 1, true) ~= nil,
            table.concat(said3, "\n"))

      -- 📠 and the report can be ASKED for its text — the mode the
      -- hand-off needs, which must not have cost the printing one.
      local asText = _G.secureInputReport(true)
      check("📠 _G.secureInputReport(true) RETURNS the text in silence",
            type(asText) == "string"
            and asText:find("SECURE INPUT", 1, true) ~= nil, tostring(asText))
      local printed = capture(_G.secureInputReport)
      check("📠 …and unasked it still PRINTS, exactly as before",
            printed:find("SECURE INPUT", 1, true) ~= nil, printed)

      _G.clipHandOff = keptHand
    end

    -- 🔁 AND A REAL CHANGE STILL ANNOUNCES BOTH WAYS. The asymmetry must
    -- not have cost the thing that already worked.
    do
      freshMac()
      _G.secureInputCheck()
      if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end
      local hopNow = hop()
      if hopNow and hopNow.fn then hopNow.fn() end
      if T.cbs.broad then T.cbs.broad(nil, "no pid here") end
      local said = {}
      local realPrint = print
      print = function(s) said[#said + 1] = tostring(s) end
      _G.secureInputCheck()
      if T.cbs.narrow then
        T.cbs.narrow(nil, 'kCGSSessionSecureInputPID" = 9191')
      end
      print = realPrint
      local all = table.concat(said, "\n")
      check("🔁 off → ON is still announced, and counted as a change",
            all:find("SECURE INPUT IS ON", 1, true) ~= nil
            and (_G.secureInput.changes or 0) == 1,
            tostring(_G.secureInput.changes) .. " " .. all)
      check("...and it does NOT claim it was already held at boot",
            all:find("ALREADY held", 1, true) == nil, all)
      said = {}
      print = function(s) said[#said + 1] = tostring(s) end
      _G.secureInputCheck()
      if T.cbs.narrow then T.cbs.narrow(nil, "no pid here") end
      local h2 = hop()
      if h2 and h2.fn then h2.fn() end
      if T.cbs.broad then T.cbs.broad(nil, "no pid here") end
      print = realPrint
      check("🔓 ON → off is still announced",
            table.concat(said, "\n"):find("released", 1, true) ~= nil,
            table.concat(said, "\n"))
    end

    hs.task, hs.timer = realTask, realTimerSave
    _G.secureInput = nil
  end

  -- ---- the work Mac: no admin, no brew, no OneDrive, no remap -------
  AX = false
  local work, workReport = asMac(
    { cloudDir = false, backupDir = false, asanaEnabled = false, secretsStatus = "missing" },
    { hyperRemapOK = false, hyperRemapWhy = "exit 1 — not permitted",
      ocrShortcutAvailable = false, brewPathInUse = nil })
  for _, k in ipairs({ "cloud", "backup", "asana", "ax", "hyper", "ocr", "brew" }) do
    check("work Mac — " .. k .. " reports OFF, not an error",
          work[k] and work[k].state == "OFF", work[k] and work[k].state)
  end
  check("work Mac — modules still load, so it is not all bad news",
        work.modules.state == "ON")
  check("every OFF capability says WHY", (function()
    for _, k in ipairs({ "cloud", "backup", "asana", "ax", "hyper", "ocr", "brew" }) do
      if not work[k].why or work[k].why == "" then return false, k end
    end
    return true
  end)())
  check("every OFF capability says what it COSTS you", (function()
    for _, k in ipairs({ "cloud", "backup", "asana", "ax", "hyper", "ocr", "brew" }) do
      if not work[k].cost or work[k].cost == "" then return false, k end
    end
    return true
  end)())
  check("...and brew's cost says plainly that nothing else uses it",
        work.brew.cost:find("NOTHING ELSE USES BREW", 1, true) ~= nil)
  check("...and the hyper failure carries hidutil's actual reason",
        work.hyper.why:find("not permitted", 1, true) ~= nil)
  check("the report counts what is degraded instead of burying it",
        workReport:find("not fully on", 1, true) ~= nil)

  -- ---- UNKNOWN is a real answer, not a synonym for OFF --------------
  AX = true
  local booting = asMac({}, {})   -- async probes have not reported yet
  check("a probe that has not finished is UNKNOWN, never OFF",
        booting.hyper.state == "UNKNOWN" and booting.ocr.state == "UNKNOWN",
        booting.hyper.state .. "/" .. booting.ocr.state)
  check("...because 'not answered yet' and 'this Mac cannot' need "
        .. "different reactions from me",
        booting.hyper.why:find("not reported back yet", 1, true) ~= nil)

  -- ---- a broken secret.lua is NOT the same as a missing one ---------
  local broke = asMac({ asanaEnabled = false, secretsStatus = "broken: unexpected symbol" },
                      {})
  check("a BROKEN secret.lua is distinguished from a missing one",
        broke.asana.why:find("EXISTS but failed", 1, true) ~= nil)
  check("...and says it is the fixable kind", broke.asana.cost:find("fixable", 1, true) ~= nil)

  -- ---- a partly-failed module load is PARTIAL, not ON or OFF --------
  local partial = asMac({}, { moduleLoaded = 15, moduleFailed = 3 })
  check("modules failing is PARTIAL — the rest still work",
        partial.modules.state == "PARTIAL" and partial.modules.why:find("3", 1, true))

  -- ---- hyperEnabled = false is a CHOICE, not a failure --------------
  local off = asMac({ hyperEnabled = false }, {})
  check("hyperEnabled = false reads as your choice, not a fault",
        off.hyper.why:find("your choice", 1, true) ~= nil)

  -- ---- accessibility unreadable -> UNKNOWN, and no crash ------------
  hs.accessibilityState = function() error("boom") end
  local axbad = asMac({}, {})
  check("an unreadable Accessibility state is UNKNOWN, and does not raise",
        axbad.ax.state == "UNKNOWN", axbad.ax.state)
  hs.accessibilityState = function() return AX end
end


-- =====================================================================
-- 11. THE DOCS AND TOOLS MUST TRACK THE CODE (6.44.13)
-- =====================================================================
-- Adding core/capabilities.lua left INSTALL.md saying "3 files",
-- hs-doctor.sh checking three names, and hs-install.sh refusing to
-- require the fourth. Three separate places silently out of step with
-- one new file — and the install script is the one thing standing
-- between a half-copied config and the primary work Mac. So the file
-- list is derived from DISK here, and anything that hard-codes it has
-- to agree.
out("\n=== 11. Docs and tools track the code ===\n")
local onDisk = {}
do
  local pipe = io.popen('ls "' .. HS .. '/core"/*.lua 2>/dev/null')
  if pipe then
    for line in pipe:lines() do
      local n = line:match("([^/]+)%.lua$")
      if n then onDisk[#onDisk + 1] = n end
    end
    pipe:close()
  end
end
table.sort(onDisk)
check("core/ has files to check", #onDisk > 0, #onDisk)

-- 🚨 6.58.0 — THE GAP THAT LET core/notices.lua SHIP BROKEN. Every one of
-- these files is loaded by init.lua as `chunk()(coreTable)`, which means
-- the file MUST `return function(core) ... end` — but nothing in this
-- suite ever checked that shape, because dofile()-ing a core file
-- directly in a test does not care what it returns. The only thing that
-- caught it was tools/hs-install.sh's independent verify step, on a real
-- install, after the fact. That is a real safety net doing its job, but
-- a bug it alone catches is a bug this suite should have caught first.
--
-- Two checks, and they are read from the SAME two places the real
-- failure came from: every file actually on disk in core/, and every
-- chunk()(...) call site actually in init.lua — not a retyped list of
-- either, for the same reason MODS above is read from disk now instead
-- of hand-copied.
for _, n in ipairs(onDisk) do
  -- readAll is defined further down this file; inlined here rather than
  -- reordering the suite around one check.
  local body = ""
  local f = realopen(HS .. "/core/" .. n .. ".lua", "r")
  if f then body = f:read("*a") or ""; f:close() end
  check("core/" .. n .. ".lua IS an initialiser — `return function(core)`, "
        .. "the exact shape hs-install.sh verifies before trusting an "
        .. "install", body:find("return function(core)", 1, true) ~= nil)
end

do
  local codeOnly = {}
  for line in initText:gmatch("[^\n]+") do
    codeOnly[#codeOnly + 1] = line:match("^%s*%-%-") and "" or line
  end
  local initCode = table.concat(codeOnly, "\n")
  for _, n in ipairs(onDisk) do
    -- Find this file's own loadfile(path) call, then confirm the chunk
    -- is CALLED WITH AN ARGUMENT close by — `chunk()(` for the normal
    -- case, or `chunk()` immediately followed by `({` on the next call
    -- for the multi-line table literals cheatsheet/capabilities use.
    local siteAt = initCode:find("core/" .. n .. "%.lua")
    if siteAt then
      local window = initCode:sub(siteAt, siteAt + 400)
      check("init.lua calls core/" .. n .. ".lua's chunk with an argument "
            .. "— a bare chunk() silently discards whatever function(core) "
            .. "expected to receive, exactly as core/notices.lua did",
            window:find("chunk%(%)%(") ~= nil, n)
    end
  end
end

local function readAll(p)
  local f = realopen(p, "r"); if not f then return nil end
  local t = f:read("*a"); f:close(); return t
end

local doctor  = readAll(HS .. "/tools/hs-doctor.sh")  or ""
local install = readAll(HS .. "/tools/hs-install.sh") or ""
local guide   = readAll(HS .. "/INSTALL.md")          or ""

check("hs-doctor.sh exists",  doctor  ~= "")
check("hs-install.sh exists", install ~= "")
check("INSTALL.md exists",    guide   ~= "")

-- hs-install.sh names the core files in TWO loops — once to refuse an
-- incomplete download, once to verify the result. A plain substring
-- search over the file passes when a name is dropped from one of them,
-- which is the worse half: the pre-check is what stops a half-copied
-- config reaching the work Mac. So both loops are pulled out and each
-- must list every file.
local installLoops = {}
for line in install:gmatch("[^\n]+") do
  if line:find("for n in ", 1, true) and line:find("boot_report", 1, true) then
    installLoops[#installLoops + 1] = line
  end
end
check("hs-install.sh still has both core loops (pre-check and verify)",
      #installLoops == 2, #installLoops)

for _, n in ipairs(onDisk) do
  check("hs-doctor.sh knows about core/" .. n,  doctor:find(n, 1, true)  ~= nil)
  check("hs-install.sh REQUIRES core/" .. n .. " in BOTH loops", (function()
    if #installLoops == 0 then return false end
    for _, loop in ipairs(installLoops) do
      if not loop:find(n, 1, true) then return false, loop end
    end
    return true
  end)())
  check("INSTALL.md documents core/" .. n,      guide:find(n, 1, true)   ~= nil)
  check("init.lua actually loads core/" .. n,
        initLive("hs.configdir .. '/core/" .. n .. ".lua'") ~= nil)
end

-- the counts printed to a human have to match reality too, or the
-- "expect N" line becomes a lie the moment a file is added
check("hs-doctor.sh's expected core count matches disk",
      doctor:find("expect " .. #onDisk .. ")", 1, true) ~= nil, #onDisk)
check("hs-install.sh's core count matches disk",
      install:find("all " .. #onDisk .. " present", 1, true) ~= nil, #onDisk)
check("INSTALL.md's core count matches disk",
      guide:find(tostring(#onDisk) .. " files, loaded directly", 1, true) ~= nil, #onDisk)

-- and the module count, for the same reason
local modCount = 0
do
  local pipe = io.popen('ls "' .. HS .. '/modules"/*.lua 2>/dev/null | wc -l')
  if pipe then modCount = tonumber(pipe:read("*a")) or 0; pipe:close() end
end
check("hs-doctor.sh's expected module count matches disk",
      modCount > 0 and doctor:find("expect " .. modCount .. ")", 1, true) ~= nil, modCount)
-- 🧪 6.367.0 — A SUITE THE GATE DOES NOT RUN IS GREEN AND MEASURES
-- NOTHING. run-tests.sh names its Lua suites in a hand-kept list, and a
-- new tests/test_*.lua that is never added to it sits there passing in
-- a file nobody executes — 6.313.0's "a sentry over a haystack it did
-- not prove it read" one layer out, and it happened on the very release
-- that added this check. The list going stale the OTHER way is already
-- caught: a name in it with no file prints "missing" on every run.
do
  local runner = readAll(HS .. "/tools/run-tests.sh") or ""
  check("the gate's own runner could be read — a sentry over an empty "
        .. "haystack is green and measures nothing", #runner > 1000, #runner)
  local missing = {}
  local pipe = io.popen('ls "' .. HS .. '/tests"/test_*.lua 2>/dev/null')
  if pipe then
    for line in pipe:lines() do
      local name = tostring(line):match("([^/]+)%.lua$")
      -- the page suites are .js and are run by their own stages; this is
      -- about the Lua list alone
      if name and not runner:find(" " .. name .. " ", 1, true)
             and not runner:find(" " .. name .. ";", 1, true) then
        missing[#missing + 1] = name
      end
    end
    pipe:close()
  end
  check("🧪 every tests/test_*.lua suite is NAMED in run-tests.sh — one "
        .. "that is not passes in a file nobody runs", #missing == 0,
        table.concat(missing, ", "))
end

check("INSTALL.md's module count matches disk",
      modCount > 0 and guide:find(modCount .. " files, loaded by", 1, true) ~= nil, modCount)

-- INSTALL.md has to name the things it tells you to type
for _, needed in ipairs({
  "hs-install.sh", "hs-doctor.sh", "run-tests.sh", "secret.lua",
  "asanaToken", "scutil --get ComputerName", "_G.capabilityReport()",
  "_G.bootVerbose(true)", "--rollback", "--dry-run",
}) do
  check("INSTALL.md tells you about: " .. needed, guide:find(needed, 1, true) ~= nil)
end
-- 6.105.0: the name moved to modules/ocr_engine.lua with the engine. The
-- point of the check is unchanged — INSTALL.md tells you to create an
-- Apple Shortcut by name, and if the code looks for a different string
-- you get a Mac where image OCR silently never runs.
check("INSTALL.md names the OCR shortcut EXACTLY as the code looks for it",
      guide:find("HS OCR", 1, true) ~= nil
      and (moduleText["ocr_engine"] or ""):find('shortcutName     = "HS OCR"',
                                                1, true) ~= nil)

-- =====================================================================
out("\n=== 11b. The release header is the shape the ceremony promises ===\n")
-- 6.212.0 — three releases shipped code without their words: the
-- ceremony script died in a backgrounded command and nothing here read
-- init.lua's header. Now the gate does. The three stamps agree, the two
-- inline NEW IN blocks are the two newest CHANGELOG entries in that
-- order, the trailer names the third, and CHANGELOG's top entry is the
-- version the config reports.
do
  local init = readAll(HS .. "/init.lua") or ""
  local log  = readAll(HS .. "/CHANGELOG.md") or ""
  local v7   = init:match("\n%-%- %.Hammerspoon ARCHITECTURE VERSION CONTROL: ([%d%.]+)")
  local vHdr = init:match("WHAT EACH TOOL DOES :: ARCHITECTURE VERSION CONTROL: ([%d%.]+)")
  local vG   = init:match('\n_G%.configVersion = "([%d%.]+)"')
  check("init.lua's three version stamps agree (line 7, the WHAT EACH TOOL DOES header, _G.configVersion)",
        v7 ~= nil and v7 == vHdr and v7 == vG, tostring(v7) .. " / " .. tostring(vHdr) .. " / " .. tostring(vG))
  local entries = {}
  for v in log:gmatch("\nNEW IN ([%d%.]+) ") do entries[#entries + 1] = v end
  check("CHANGELOG.md's top entry is the current version", entries[1] == v7, tostring(entries[1]) .. " vs " .. tostring(v7))
  local blocks = {}
  for v in init:gmatch("\n%-%- NEW IN ([%d%.]+) ") do blocks[#blocks + 1] = v end
  check("init.lua carries exactly TWO inline NEW IN blocks", #blocks == 2, #blocks)
  check("...the newest first — the current version", blocks[1] == v7, tostring(blocks[1]))
  check("...then the previous release, as CHANGELOG orders them", blocks[2] == entries[2],
        tostring(blocks[2]) .. " vs " .. tostring(entries[2]))
  local trailer = init:match("\n%-%- %(([%d%.]+) and earlier: see CHANGELOG%.md")
  check("...and the trailer names the third", trailer == entries[3], tostring(trailer) .. " vs " .. tostring(entries[3]))
  -- 6.217.0 — the plain-text feature list rides in every zip and is
  -- generated from the cheat sheets; a list stamped with an older
  -- version is a list built before this release's modules changed.
  local featureList = readAll(HS .. "/RESOLVED-FEATURE-REQUESTS.txt") or ""
  check("RESOLVED-FEATURE-REQUESTS.txt exists and names the config version init.lua reports",
        featureList:find("RESOLVED FEATURE REQUESTS — Hammerspoon config " .. tostring(entries[1]), 1, true) ~= nil,
        featureList:sub(1, 120))
  check("...and its release index carries the top CHANGELOG entry",
        featureList:find("\n  " .. tostring(entries[1]) .. "  ", 1, true) ~= nil)
  -- the recipe lives in the repo's .gitignore, which a shipped package
  -- does not carry — so that half is asked only where the file exists.
  local recipe = readAll(HS .. "/../.gitignore")
  check("...built by tools/build-feature-list.lua, which the zip recipe runs",
        (readAll(HS .. "/tools/build-feature-list.lua") or ""):find("RESOLVED-FEATURE-REQUESTS.txt", 1, true) ~= nil
        and (recipe == nil or recipe:find("build-feature-list.lua", 1, true) ~= nil))
  -- 🧪 6.271.0 — THE TEST PLAN RIDES IN EVERY ARCHIVE. LL: "if we want to
  -- score each release, I need a set of directions that explicitly state
  -- the steps that you want me to take to test each release." They
  -- EXISTED — seventy-two verify blocks over 1,451 lines in CLAUDE.md —
  -- and CLAUDE.md is not in the package, so not one of them ever reached
  -- him and he was left walking the cheat sheet inventing his own tests.
  -- A plan stamped with an older version is worse than none: he would run
  -- the wrong steps and report a pass on something that was not built.
  local testPlan = readAll(HS .. "/TESTING.md") or ""
  check("TESTING.md exists and names the config version init.lua reports",
        testPlan:find("# TESTING — how to score release " .. tostring(entries[1]), 1, true) ~= nil,
        testPlan:sub(1, 120))
  check("...and it carries this release's own steps, not only older ones",
        testPlan:find("\n## " .. tostring(entries[1]) .. "\n", 1, true) ~= nil,
        tostring(entries[1]))
  check("...and it tells him HOW to report back, or the steps produce a "
        .. "verdict instead of data",
        testPlan:find("PASS", 1, true) ~= nil and testPlan:find("FAIL", 1, true) ~= nil
        and testPlan:find("BLOCKED", 1, true) ~= nil)
  check("...built by tools/build-test-plan.lua, which the archive recipe runs",
        (readAll(HS .. "/tools/build-test-plan.lua") or ""):find("TESTING.md", 1, true) ~= nil
        and (recipe == nil or recipe:find("build-test-plan.lua", 1, true) ~= nil))

  local newIn = init:find("\n%-%- NEW IN ") or math.huge
  local hdr   = init:find("WHAT EACH TOOL DOES :: ARCHITECTURE", 1, true) or 0
  check("the NEW IN blocks sit ABOVE the WHAT EACH TOOL DOES header, where the reader looks",
        newIn < hdr)
end

out(("\n%d passed, %d failed\n\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
