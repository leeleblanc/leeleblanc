-- =====================================================================
-- test_vault.lua — ⇪3: linked Markdown notes in OneDrive, backlinks, graph
-- =====================================================================
--     lua5.4 test_vault.lua [/path/to/hammerspoon]
--
-- The claims under test: the vault is <OneDrive>/Vault (local fallback
-- without OneDrive); the index comes from find + grep in hs.task, never
-- from reading every file; [[Target|alias]] / [[Target#h]] resolve to
-- Target case-insensitively; backlinks are the inverse of links and a
-- name with no file is "unresolved" (a hollow dot); opening a note reads
-- ONE file, a missing one is created with a heading; every keystroke
-- lands in Lua and the .md file is written after the debounce (tmp +
-- rename), at once on switching and closing; a save re-parses the note's
-- links without a rescan; ⌘D opens Daily/<date>.md; following a
-- Markdown link resolves relative to the note; ⌘K writes a relative
-- link; the page carries the row walker and the ⇪ keyup forward; the
-- prompt fallback still edits and saves; no eventtap, no hs.window read.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail = 0, 0
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else
        fail = fail + 1
        io.write("   ❌ " .. label .. (extra and ("  [" .. tostring(extra) .. "]") or "") .. "\n")
    end
end
local function out(s) io.write(s) end

-- ---- a controllable world ------------------------------------------------
-- 6.273.0: the REAL opener, kept before the fake replaces it, so
-- tests/service_registry.lua can still lift init.lua's own registry.
local REAL_OPEN = io.open
local FILES, WRITE_FAILS, READS = {}, false, {}
local WRITE_VANISHES = false
io.open = function(path, mode)
    mode = mode or "r"
    -- 🔬 6.321.0 — THE HARNESS MODELS "a" BEFORE THE FEATURE USES IT
    -- (6.290.0, and 6.313.0 learned the same thing about "w"). Until
    -- now an append fell through to the READ branch and answered nil
    -- for a path the virtual disk had never heard of, so the bin's
    -- index could not be written AT ALL from the gate and every check
    -- about it would have been green over a feature that does nothing.
    -- "a" appends and creates; "w" truncates. Both can be refused.
    if mode:find("a") then
        if WRITE_FAILS then return nil end
        local buf = {}
        -- 🔬 VARARGS, as io's own write takes them. A stub that keeps only
        -- the first argument silently drops every separator a caller
        -- passes alongside its payload — here, the newline that makes the
        -- index one row per delete instead of one long line (6.290.0).
        return { write = function(_, ...) for _, x in ipairs({ ... }) do buf[#buf + 1] = x end return true end,
                 close = function() FILES[path] = (FILES[path] or "") .. table.concat(buf) end }
    end
    if mode:find("w") then
        if WRITE_FAILS then return nil end
        local buf = {}
        return { write = function(_, ...) for _, x in ipairs({ ... }) do buf[#buf + 1] = x end return true end,
                 close = function()
                     -- 🔬 a write that REPORTS SUCCESS and lands nothing:
                     -- a full disk, a refused rename. 6.265.0's
                     -- distinction — MISSING is not REFUSING — and this
                     -- is the third shape, SILENTLY DOING NOTHING.
                     if not WRITE_VANISHES then FILES[path] = table.concat(buf) end
                 end }
    end
    READS[#READS + 1] = path
    if FILES[path] == nil then return nil end
    local content, done = FILES[path], false
    return { read = function() if done then return nil end done = true return content end,
             close = function() end }
end
os.rename = function(a, b)
    if FILES[a] == nil then return nil, "no such file" end
    FILES[b] = FILES[a]; FILES[a] = nil
    return true
end
-- 🔬 os.remove over the SAME virtual disk, so a purge can be DRIVEN
-- rather than grepped for, and a refusal can be driven too.
local REMOVE_FAILS = false
os.remove = function(path)
    if REMOVE_FAILS then return nil, "refused" end
    if FILES[path] == nil then return nil, "no such file" end
    FILES[path] = nil
    return true
end

local ALERTS, PROVIDED, WEBVIEWS, PROMPTS, TIMERS, PRINTED, TASKS, OPENED, SETTINGS = {}, {}, {}, {}, {}, {}, {}, {}, {}
local DEGRADES = {}
local PROMPT_ANSWERS = {}
local UC_CALLBACK, EVALS = nil, {}
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    PRINTED[#PRINTED + 1] = table.concat(p, " ")
end

local function newWebviewStub(rect)
    local v = { rect = rect, _style = 0, deleted = false, shown = 0, htmlSet = nil }
    function v:windowTitle(t) self.title = t return self end
    function v:allowTextEntry(x) self.textEntry = x return self end
    function v:alpha(a) self.alphaSet = a return self end
    function v:closeOnEscape(x) return self end
    function v:level(l) return self end
    function v:behaviorAsLabels(b) return self end
    function v:windowStyle(x) if x ~= nil then self._style = x end return self._style end
    -- 🔬 6.323.0 — :html() REPLACES THE DOCUMENT, and that is the whole
    -- fact this module now turns on: a new document means a new
    -- <textarea>, and a new element has an EMPTY undo stack. A stub that
    -- quietly overwrites a string models the VALUE and not the EVENT, so
    -- "did this rebuild the page?" was unaskable from the gate (6.290.0).
    function v:html(h) self.htmlSet = h; self.htmlSets = (self.htmlSets or 0) + 1 return self end
    function v:show() self.shown = self.shown + 1 return self end
    function v:hide() return self end
    function v:bringToFront() return self end
    function v:delete() self.deleted = true return self end
    function v:frame(f) if f then self.rect = f end return self.rect end
    function v:evaluateJavaScript(js) EVALS[#EVALS + 1] = js return self end
    return v
end
-- 🪜 6.324.0 — the hop drain (test_anchors' shape). A hop is a
-- doAfter(0): the turn a task callback steps off onto before it starts
-- the next task or releases a slot.
local DRAIN_HOPS = true
local function drainHops()
    for _ = 1, 8 do                      -- a chain of hops, bounded
        local fired = 0
        local snapshot = {}
        for i = 1, #TIMERS do snapshot[i] = TIMERS[i] end
        for _, t in ipairs(snapshot) do
            if t.kind == "after" and t.delay == 0 and not t.stopped and not t.fired then
                t.fired = true
                fired = fired + 1
                pcall(t.fn)
            end
        end
        if fired == 0 then break end
    end
end

local function mkTimer(kind, delay, fn)
    local t = { kind = kind, delay = delay, fn = fn, stopped = false }
    function t:stop() self.stopped = true end
    function t:fire() if not self.stopped then self.fn() end end
    TIMERS[#TIMERS + 1] = t
    return t
end

hs = {
    webview = {
        windowMasks = { nonactivating = 128 },
        usercontent = { new = function(name)
            local uc = { name = name }
            function uc:setCallback(fn) UC_CALLBACK = fn end
            return uc
        end },
        new = function(rect) local v = newWebviewStub(rect); WEBVIEWS[#WEBVIEWS + 1] = v; return v end,
    },
    screen = { mainScreen = function() return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end } end },
    drawing = { windowLevels = { floating = 5 } },
    alert = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    dialog = {
        textPrompt = function(title, msg, dflt)
            PROMPTS[#PROMPTS + 1] = { title = title, msg = msg, dflt = dflt }
            local a = table.remove(PROMPT_ANSWERS, 1) or { "Cancel", "" }
            return a[1], a[2]
        end,
        chooseFileOrFolder = function() return { ["1"] = "file:///Users/ll/OneDrive/Documents/Plans/Q4%20plan.pdf" } end,
    },
    timer = {
        doAfter = function(d, fn) return mkTimer("after", d, fn) end,
        doEvery = function(d, fn) return mkTimer("every", d, fn) end,
    },
    fs = {
        mkdir = function() return true end,
        -- 🚨 TWO VALUES, AND THE ITERATOR NEEDS ITS STATE (6.311.0's
        -- tenth payment of 6.193.0): hs.fs.dir answers (iterator,
        -- dirobj) and the iterator RAISES when called without the
        -- dirobj. A stub returning one stateless closure works either
        -- way and hides a whole class of caller bug.
        dir = function(d)
            local names = { ".", ".." }
            local prefix = d .. "/"
            for path in pairs(FILES) do
                local rest = path:sub(#prefix + 1)
                if path:sub(1, #prefix) == prefix and not rest:find("/") then
                    names[#names + 1] = rest
                end
            end
            table.sort(names)
            local obj, i = { __dir = d }, 0
            return function(state)
                if state ~= obj then
                    error("bad argument #1 to 'for iterator' "
                          .. "(directory metatable expected, got nil)", 0)
                end
                i = i + 1
                return names[i]
            end, obj
        end,
    },
    mouse = { absolutePosition = function() return { x = 300, y = 300 } end },
    eventtap = { checkMouseButtons = function() return { left = false } end },
    settings = { get = function(k) return SETTINGS[k] end, set = function(k, x) SETTINGS[k] = x end },
    task = { new = function(bin, cb, args)
        -- 🪜 6.324.0 — A CALLBACK'S FRAME UNWINDS, AND THEN THE RUN LOOP
        -- FIRES WHAT IT ARMED. The module now steps off a task callback
        -- with a doAfter(0) before starting the next task or letting a
        -- slot go (6.196.1), so a harness that never fires those timers
        -- would stop the scan chain dead after one step. This wrapper
        -- delivers the callback and THEN drains the zero-delay timers —
        -- the same order macOS uses, and the thing being tested (that
        -- nothing is cleared INSIDE the frame) stays observable, because
        -- DRAIN_HOPS can be switched off to look.
        local t = { bin = bin, cb = nil, args = args, started = false, terminated = false }
        t.cb = function(...)
            local r = { pcall(cb, ...) }
            if DRAIN_HOPS then drainHops() end
            if not r[1] then error(r[2], 0) end
            return table.unpack(r, 2)
        end
        function t:start() self.started = true return true end
        -- 6.174.0 — A KILLED RUN EXITS TOO (chrome_history's 6.148.0
        -- lesson): terminate() still delivers the callback, with the
        -- signal's exit code. The stub does the same, so the suite sees
        -- what the real hs.task would do.
        function t:terminate()
            self.terminated = true
            if self.cb then pcall(self.cb, 15, "", "") end
        end
        TASKS[#TASKS + 1] = t
        return t
    end },
    open = function(p) OPENED[#OPENED + 1] = p return true end,
    urlevent = { openURL = function(u) OPENED[#OPENED + 1] = u return true end },
}

_G.diag = { say = function() end, warn = function() end }
local CLAIMED_ESC = {}
_G.claimEscape = function(name, _, present, close) CLAIMED_ESC[name] = { present = present, close = close } end
_G.movablePanels, _G.editors = {}, {}
local HYPER, WRITE_WARNS, EXPECTED, SEEN = {}, {}, {}, {}
_G.hyperExpectRelease = function(secs, who) EXPECTED[#EXPECTED + 1] = { secs = secs, who = who } return true end
_G.hyperReleaseSeen = function(who) SEEN[#SEEN + 1] = who return true end
local CORE = {
    cloudDir = "/Users/ll/OneDrive", logsDir = "/Users/ll/OneDrive/Logs",
    provide = function(n, f) PROVIDED[n] = f end,
    hyperAddShortcut = function(mods, key, fn, src)
        HYPER[table.concat(mods or {}, "+") .. "|" .. tostring(key)] = { fn = fn, src = src }
    end,
    warnWriteFailed = function(what) WRITE_WARNS[#WRITE_WARNS + 1] = what end,
    -- 🔬 6.322.0 — THE DOOR EXISTS IN THE STUB NOW. This core table had no
    -- `degrade`, so every `if type(core.degrade) == "function"` in the
    -- module took its no-door fallback and the 🔔 door was never once
    -- exercised from this suite — 6.278.0's hole, third time (6.301.0
    -- found the same one in test_task_creator). A stub that is quieter
    -- than our own core hides every failure path that reports through it.
    degrade = function(tool, why)
        DEGRADES[#DEGRADES + 1] = { tool = tool, why = why }
        return false, why
    end,
}

local mod = dofile(HS .. "/modules/vault.lua")
mod.setup(CORE)
local v = _G.vault
local VAULT = "/Users/ll/OneDrive/Vault"
local function msg(m) v.handleMessage(m) end
local function lastTimer(kind)
    for i = #TIMERS, 1, -1 do if TIMERS[i].kind == kind and not TIMERS[i].stopped then return TIMERS[i] end end
end
local function lastTask(bin)
    for i = #TASKS, 1, -1 do if TASKS[i].bin:match(bin) then return TASKS[i] end end
end
-- 6.174.0 — the newest task of a binary whose ARGS carry a flag (find /
-- the link grep / the tag greps / search / tasks / mentions share bins)
local function taskArgs(t) return t and table.concat(t.args, " ") or "" end
local function lastTaskWith(bin, needle)
    for i = #TASKS, 1, -1 do
        if TASKS[i].bin:match(bin) and taskArgs(TASKS[i]):find(needle, 1, true) then return TASKS[i] end
    end
end
local function countTasks(bin)
    local n = 0
    for _, t in ipairs(TASKS) do if t.bin:match(bin) then n = n + 1 end end
    return n
end
-- the scan chain since 6.174.0: after the LINK grep answers, a TAG grep and
-- then a FRONT-MATTER grep follow; this feeds both "no match"
local function finishTagGreps(tagOut, fmOut)
    local tg = lastTaskWith("grep", "-rHoIE")
    if tg then tg.cb(tagOut and 0 or 1, tagOut or "", "") end
    local fg = lastTaskWith("grep", "^---")
    if fg then fg.cb(fmOut and 0 or 1, fmOut or "", "") end
end

-- =======================================================================
out("1) the doors in — ⇪3, the folder, escape claim, services, no forbidden calls\n")
-- =======================================================================
check("⇪3 is claimed for the vault", HYPER["|3"] ~= nil and HYPER["|3"].src == "vault")
check("the vault is <OneDrive>/Vault", v.dir == VAULT, v.dir)
check("the escape router knows 'vault'", CLAIMED_ESC.vault ~= nil)
check("an editors row and a movable panel row exist", #_G.editors == 1 and #_G.movablePanels == 1)
check("vault.show / open / rescan / report are published",
      PROVIDED["vault.show"] and PROVIDED["vault.open"] and PROVIDED["vault.rescan"] and PROVIDED["vault.report"])
check("the cheat sheet names ⇪3, ⇪N and Obsidian", mod.cheatsheet.title:find("⇪3") and mod.cheatsheet.title:find("⇪N") and (function()
    for _, e in ipairs(mod.cheatsheet.entries) do if e[1] == "Obsidian" then return true end end end)())
do
    local src = io.open(HS .. "/modules/vault.lua") and "" or ""
    local f = io.open(HS .. "/modules/vault.lua", "r")
    local real = nil
    -- the stubbed io.open only knows FILES; read the source through the real loader instead
    local chunk = loadfile(HS .. "/modules/vault.lua")
    check("the module compiles", chunk ~= nil)
    local rf = io.popen and io.popen("cat '" .. HS .. "/modules/vault.lua'")
    real = rf and rf:read("a") or ""
    if rf then rf:close() end
    check("no eventtap is created (the page's keydown is the only key handler)", not real:find("hs%.eventtap%.new"))
    check("no hs.window read", not real:find("hs%.window%."))
    check("the index comes from find and grep in hs.task", real:find("hs%.task%.new, v%.FIND") and real:find("hs%.task%.new, v%.GREP"))
    check("every timer is held (doAfter/doEvery results assigned)", not real:find("\n%s*hs%.timer%.do"))
end
do
    local other = dofile(HS .. "/modules/vault.lua")
    other.setup({ logsDir = "/logs", provide = function() end, hyperAddShortcut = function() end })
    check("without OneDrive the vault is <logsDir>/vault", other.config.dir == "/logs/vault", other.config.dir)
    mod.setup(CORE); v = _G.vault    -- back to the OneDrive world
end

-- =======================================================================
out("2) links — targets, resolution, backlinks, unresolved\n")
-- =======================================================================
check("[[Target|alias]] and [[Target#Heading]] both resolve to Target",
      v.linkTarget("Target|shown") == "Target" and v.linkTarget(" Target#Part 2 ") == "Target")
local ls = v.linksIn("see [[Alpha]] and [[beta|B]] then [[alpha#top]] and [[Gamma]]")
check("linksIn dedupes case-insensitively and keeps order", #ls == 3 and ls[1] == "Alpha" and ls[2] == "beta" and ls[3] == "Gamma", table.concat(ls, ","))

-- =======================================================================
out("3) the index — find, then grep, both off the main thread\n")
-- =======================================================================
READS = {}
local ok = v.scan("test")
check("scan starts a find task on the vault folder", ok == true and lastTask("find") and lastTask("find").started and lastTask("find").args[1] == VAULT)
check("find prunes .obsidian", table.concat(lastTask("find").args, " "):find("%.obsidian") ~= nil)
check("scanning flag is up and a second scan is refused", v.scanning == true and select(2, v.scan("again")) == "already scanning")
lastTask("find").cb(0, VAULT .. "/Alpha.md\n" .. VAULT .. "/Projects/Beta.md\n" .. VAULT .. "/Gamma.md\n", "")
check("three notes indexed, sorted by name, found case-insensitively",
      #v.notes == 3 and v.notes[1].name == "Alpha" and v.notes[2].name == "Beta" and v.find("beta") and v.find("BETA").rel == "Projects/Beta.md")
check("the grep task followed, excluding .obsidian", lastTask("grep") and lastTask("grep").started
      and table.concat(lastTask("grep").args, " "):find("exclude%-dir=%.obsidian") ~= nil)
lastTask("grep").cb(0, VAULT .. "/Alpha.md:[[Beta|B]]\n" .. VAULT .. "/Alpha.md:[[Gamma]]\n" .. VAULT .. "/Projects/Beta.md:[[alpha]]\n" .. VAULT .. "/Gamma.md:[[Delta]]\n", "")
do  -- 6.174.0 — two more greps follow the links: #tags (-o, the wide shape), then front-matter tags:
    local tg = lastTask("grep")
    check("6.174.0: a TAG grep follows the link grep (-rHoIE, the wide #shape, not the [[ pattern)",
          tg and tg.started and taskArgs(tg):find("-rHoIE", 1, true) and taskArgs(tg):find("#[^[:space:]#]+", 1, true)
          and taskArgs(tg):find("exclude-dir=.obsidian", 1, true) and not taskArgs(tg):find("\\[\\[", 1, true), taskArgs(tg))
    check("…the scan is still running while it does", v.scanning == true and v.tagTask == tg)
    tg.cb(1, "", "")
    local fg = lastTask("grep")
    -- 6.185.0 — it asks for the opening --- and reads the WHOLE block, so
    -- one grep builds both the tag index and the query FIELDS
    check("…then a FRONT-MATTER grep (-m 1 -A 30, the opening ---)", fg and fg ~= tg and fg.started
          and taskArgs(fg):find("-m 1 -A 30", 1, true) and taskArgs(fg):find("^---[[:space:]]*$", 1, true)
          and taskArgs(fg):find("^tags?:", 1, true) == nil and v.fmTask == fg, taskArgs(fg))
    fg.cb(1, "", "")
    check("…and both fields are released when the chain ends", v.tagTask == nil and v.fmTask == nil)
end
check("scan finished: links per note", v.scanning == false and v.scanErr == nil and #v.links["Alpha.md"] == 2 and v.links["Projects/Beta.md"][1] == "alpha")
check("backlinks are the inverse (Alpha ← Beta, Beta ← Alpha)",
      v.backlinks.alpha and v.backlinks.alpha[1] == "Projects/Beta.md" and v.backlinks.beta and v.backlinks.beta[1] == "Alpha.md")
check("Delta has no file: unresolved, remembered by name", v.unresolved.delta and v.unresolved.delta.name == "Delta" and v.unresolved.delta.from[1] == "Gamma.md")
check("no note file was READ to build the index", #READS == 0, #READS)
do
    local g = v.graphJson()
    check("graph JSON has 4 nodes (3 notes + 1 ghost) and 4 edges", select(2, g:gsub("{n:", "")) == 4 and g:find('ghost:1') and select(2, g:gsub("%[%d+,%d+%]", "")) == 4, g)
end
do
    v.scan("grep fails")
    lastTask("find").cb(0, VAULT .. "/Alpha.md\n", "")
    lastTask("grep").cb(2, "", "grep: boom")
    check("a grep error is reported, not swallowed", v.scanErr and v.scanErr:find("grep exited 2"), v.scanErr)
    v.scan("no links")
    lastTask("find").cb(0, VAULT .. "/Alpha.md\n" .. VAULT .. "/Projects/Beta.md\n" .. VAULT .. "/Gamma.md\n", "")
    lastTask("grep").cb(1, "", "")
    finishTagGreps()
    check("grep exit 1 (no matches) is a clean empty scan", v.scanErr == nil and next(v.links) == nil)
    lastTask("find").cb(0, "", "")   -- restore the earlier links for the rest
    v.scan("restore")
    lastTask("find").cb(0, VAULT .. "/Alpha.md\n" .. VAULT .. "/Projects/Beta.md\n" .. VAULT .. "/Gamma.md\n", "")
    lastTask("grep").cb(0, VAULT .. "/Alpha.md:[[Beta|B]]\n" .. VAULT .. "/Alpha.md:[[Gamma]]\n" .. VAULT .. "/Projects/Beta.md:[[alpha]]\n" .. VAULT .. "/Gamma.md:[[Delta]]\n", "")
    finishTagGreps()
end

-- =======================================================================
out("4) opening, typing, saving — one file read, tmp + rename, debounce\n")
-- =======================================================================
FILES[VAULT .. "/Alpha.md"] = "# Alpha\n\nsee [[Beta|B]] and [[Gamma]]\n"
FILES[VAULT .. "/Projects/Beta.md"] = "# Beta\n\nsee [[alpha]]\n"
READS = {}
check("opening Alpha reads exactly that file", v.openNote("alpha") and #READS == 1 and READS[1] == VAULT .. "/Alpha.md" and v.doc.text:find("^# Alpha"))
check("it is remembered as the last note", SETTINGS["vault.lastNote"] == "Alpha.md")
msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n\nsee [[Beta|B]] and [[Gamma]] and [[Delta]]\n", sel = 5 })
check("a keystroke lands in Lua at once and nothing is on disk yet", v.doc.text:find("%[%[Delta%]%]") and v.dirty and FILES[VAULT .. "/Alpha.md"]:find("Delta") == nil)
check("the outgoing links are live before any save", #v.links["Alpha.md"] == 3 and v.links["Alpha.md"][3] == "Delta")
local st = lastTimer("after")
check("one held debounce timer of saveDelay", st and st.delay == v.saveDelay and v.saveTimer == st)
st:fire()
check("the .md file is written after the debounce, via tmp + rename",
      FILES[VAULT .. "/Alpha.md"]:find("Delta") and FILES[VAULT .. "/Alpha.md.tmp"] == nil and v.saves == 1 and not v.dirty)
check("Delta now has two backlinkers (Gamma and Alpha)", v.unresolved.delta and #v.unresolved.delta.from == 2)
do
    msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n\nchanged\n", sel = 3 })
    WRITE_FAILS = true
    lastTimer("after"):fire()
    check("a failed write is said once, counted, and the text stays in Lua",
          v.saveFails == 1 and v.lastSaveErr and #WRITE_WARNS == 1 and #ALERTS >= 1 and ALERTS[#ALERTS]:find("NOT SAVED") and v.doc.text:find("changed"))
    -- 🚨 6.316.0 — AND A DIFFERENT CAUSE SPEAKS AGAIN. The gate was one
    -- per-session boolean, so the SECOND kind of failure went unsaid for
    -- the rest of the day — on the folder that holds his writing. Every
    -- other input agrees with the old code; the one that separates them
    -- is a second failure with a DIFFERENT reason (6.230.0).
    local nAlV = #ALERTS
    v.saveNow()
    check("...the SAME cause does not alert twice in the streak", #ALERTS == nAlV)
    WRITE_FAILS = false
    local keptRenameV = os.rename
    os.rename = function() return nil, "refused" end
    local okV = v.saveNow()
    os.rename = keptRenameV
    check("...but a DIFFERENT cause alerts again (the per-session boolean was the bug)",
          okV == false and #ALERTS > nAlV
          and ALERTS[#ALERTS]:find("rename failed", 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    WRITE_FAILS = false
    msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n\nchanged twice\n", sel = 3 })
    lastTimer("after"):fire()
    check("the next keystroke retries and clears the error", v.lastSaveErr == nil and FILES[VAULT .. "/Alpha.md"]:find("changed twice"))
end
check("a message for another note's rel never overwrites the open one",
      (function() msg({ a = "edit", rel = "Other.md", text = "stray", sel = 0 }); return not v.doc.text:find("stray") end)())

-- =======================================================================
out("5) new notes, daily notes, following links\n")
-- =======================================================================
check("opening a name with no file creates it with a heading and saves at once",
      v.openNote("New Idea") and FILES[VAULT .. "/New Idea.md"] == "# New Idea\n\n" and v.find("new idea") ~= nil)
check("the new note joined the index (4 notes)", #v.notes == 4)
check("switching away saved the previous note first (Alpha on disk holds its last text)", FILES[VAULT .. "/Alpha.md"]:find("changed twice"))
check("a slash in a name becomes a dash (no folder escape)", v.openNote("a/b:c") and v.doc.rel == "a-b-c.md")
local today = os.date("%Y-%m-%d")
check("⌘D opens Daily/<date>.md with the day as heading",
      v.openDaily() and v.doc.rel == "Daily/" .. today .. ".md" and FILES[VAULT .. "/Daily/" .. today .. ".md"]:find("^# %a+ %d+ %a+ %d%d%d%d"))
check("following [[Delta]] creates Delta (the ghost becomes a note)",
      v.follow("Delta|shown", false) and v.doc.rel == "Delta.md" and v.unresolved.delta == nil and v.backlinks.delta and #v.backlinks.delta == 1)
v.openNote("Beta")
check("following a relative Markdown file link resolves against the note's folder and opens it",
      v.follow("../Docs/Q4%20plan.pdf", true) and OPENED[#OPENED] == VAULT .. "/Docs/Q4 plan.pdf", OPENED[#OPENED])
check("an http link opens as a URL", v.follow("https://example.com/x", true) and OPENED[#OPENED] == "https://example.com/x")
check("a relative .md link opens that note instead of the app",
      v.follow("../Alpha.md", true) and v.doc.rel == "Alpha.md")
do
    local link = v.linkFile()
    check("⌘K writes a Markdown link relative to the note (up out of the vault into OneDrive)",
          link == "[Q4 plan.pdf](../Documents/Plans/Q4%20plan.pdf)", link)
end

-- =======================================================================
out("6) the window — page contents, walker, ⇪ keyup, hide saves\n")
-- =======================================================================
v.show()
local view = WEBVIEWS[#WEBVIEWS]
check("⇪3 opens one webview, shown, non-activating applied",
      view and view.shown == 1 and v.nonActivatingApplied == true and view.title == "Hamsidian")
check("the hyper watchdog is told to expect a release", EXPECTED[#EXPECTED] and EXPECTED[#EXPECTED].who == "the vault")
-- 6.181.0 — 0.9, because LL asked for it in those words ("make the
-- Scorp pad 90% black"). 6.175.2 had settled on solid after three
-- passes; this is the fourth and it is settled the other way. The
-- 6.175.2 TEETH stay, tested from the other side: at exactly 1 the
-- module must still not call view:alpha() at all — asking macOS for an
-- alpha of 1 is how a window ends up on a translucency path it does not
-- need — and below 1 it must actually set it, or the number is a lie.
check("6.181.1: the window is 97% opaque by default", v.alpha == 0.97, tostring(v.alpha))
check("…and below 1 the alpha is really SET on the window",
      math.abs((view.alphaSet or 0) - 0.97) < 0.001, tostring(view.alphaSet))
do
    v.hide("t"); v.alpha = 1; v.show()
    local solid = WEBVIEWS[#WEBVIEWS]
    check("…and at exactly 1 it is never set at all (the 6.175.2 guard holds)",
          solid.alphaSet == nil, tostring(solid.alphaSet))
    v.hide("t"); v.alpha = 0.97; v.show()
    view = WEBVIEWS[#WEBVIEWS]
end
check("a scan runs on open and a held rescan timer is armed", lastTask("find") and lastTask("find").started and v.rescanTimer and v.rescanTimer.kind == "every")
local h = view.htmlSet or ""
check("the page lists every note and the open one", h:find("NOTES = %[") and h:find('"Alpha"') and h:find('"New Idea"') and h:find('CUR = "Alpha.md"'))
check("the page carries the row walker block", h:find("function rowKey") and h:find("function moveSel") and h:find("function rowAct") and h:find("e%.altKey || !inText%(%)"))
check("the page forwards an F18 keyup", h:find("a:'f18up'"))
check("the page has the [[ autocomplete and ⌘⏎ follow", h:find("function autocomplete") and h:find("function linkAtCaret") and h:find("a:'follow'"))
check("the page has the graph canvas and force layout", h:find('id="cv"') and h:find("function graphStart") and h:find("GRAPH = {nodes:"))
-- 6.191.0 — 14 px (LL: "Make all font 14pt"), and the window grew to
-- carry it. The derived sizes come off it, so a placeholder left
-- unreplaced would show up as a literal FS1px/FS2px in the page.
check("text is 14 px and no placeholder survives",
      h:find("font%-size:14px") and h:find("font%-size:13px") and h:find("font%-size:12px")
      and not h:find("FS%d?px") and not h:find("FSLABEL") and not h:find("TIPGAPPX"))
-- 🔎 THE POINT of 6.191.0's font change: the window has THREE sizes and
-- the SMALL one was the complaint. Every size must be within 2 of the
-- base — the old 13/11/10 step fails this by construction, so a revert
-- to it cannot pass.
check("…and nothing in the window is more than 2 px under the base", (function()
    for n in h:gmatch("font%-size:(%d+)px") do
        if (14 - tonumber(n)) > 2 or tonumber(n) > 14 then return false end
    end
    return true
end)())
check("…and the window grew with the bigger type", v.width == 1560 and v.height == 1010,
      tostring(v.width) .. "x" .. tostring(v.height))
-- A SMALL base must still not drive a label to nothing: the steps floor
-- at 10 px rather than marching down with fs.
check("a tiny fontSize floors the derived sizes at 10 px", (function()
    local was = v.fontSize
    v.fontSize = 10
    local ok, small = pcall(v.buildHtml)
    v.fontSize = was
    if not ok or type(small) ~= "string" then return false end
    for n in small:gmatch("font%-size:(%d+)px") do
        if tonumber(n) < 10 then return false end
    end
    return small:find("font%-size:10px") ~= nil
end)())
-- 🖱 6.191.0 — LL: "My mouse cursor blacks the icon tools tip." The tip
-- is positioned off the hovered ELEMENT's rect, never off the pointer,
-- so the cursor arrow can no longer sit on top of it. Anchoring back to
-- e.clientX/e.clientY in the tip block fails this.
check("the tooltip is placed off the button, not the pointer",
      h:find("function tipEl") and h:find("a%.bottom %+ TIPGAP")
      and h:find("a%.left %+ %(a%.width %- r%.width%) / 2")
      and h:find("TIPGAP = %d+"))
check("backlinks pane lists Beta for Alpha", h:find('← Beta'))
-- 🏷 6.181.0 — LL asked for tool tips on the pad's icons. Every button
-- already carried a title="", and a non-activating WKWebView panel does
-- not reliably raise the native box, so the page paints its own. These
-- check the layer exists AND that there is something for it to show.
check("the page has its own tooltip layer, fed by the titles already there",
      h:find('id="tip"', 1, true) and h:find("getAttribute('data-tip')", 1, true)
      and h:find("removeAttribute('title')", 1, true) and h:find("#tip{position:fixed", 1, true))
check("...and every header icon has a title for it to show",
      select(2, h:gsub('<button[^>]-title="', "")) >= 8,
      tostring(select(2, h:gsub('<button[^>]-title="', ""))))
msg({ a = "f18up", rel = "Alpha.md", text = v.doc.text, sel = 0 })
check("f18up reaches hyperReleaseSeen", SEEN[#SEEN] == "the vault")
msg({ a = "graph", rel = "Alpha.md", text = v.doc.text, sel = 0 })
check("⌘G switches the page to the graph view", v.view == "graph" and view.htmlSet:find('<body class="graph"'))
msg({ a = "graph", rel = "Alpha.md", text = v.doc.text, sel = 0 })
check("⌘G again returns to the editor", v.view == "edit")
-- 6.195.0 — the page's "+ new note" row. ONE creation path: it must reach
-- the SAME v.newNote() ⌘N calls, not a second one that can drift from it.
do
    local was, called = v.newNote, false
    v.newNote = function() called = true; return true end
    msg({ a = "newnote", rel = "Alpha.md", text = v.doc.text, sel = 0 })
    v.newNote = was
    check("the + new note row goes through v.newNote — the same door as ⌘N", called)
end
msg({ a = "open", name = "Gamma", rel = "Alpha.md", text = v.doc.text, sel = 0 })
check("a row click opens that note in the same window", v.doc.rel == "Gamma.md" and view.htmlSet:find('CUR = "Gamma.md"'))
msg({ a = "linkfile", rel = "Gamma.md", text = "# Gamma\n", sel = 8 })
check("⌘K inserts the link into the page at the caret", EVALS[#EVALS] and EVALS[#EVALS]:find('insertAtCaret%("%[Q4 plan.pdf%]'), EVALS[#EVALS])
msg({ a = "edit", rel = "Gamma.md", text = "# Gamma\n\nunsaved", sel = 3 })
msg({ a = "esc", rel = "Gamma.md", text = "# Gamma\n\nunsaved", sel = 3 })
check("Esc closes, saves the pending text, stops the rescan timer",
      v.webview == nil and view.deleted and FILES[VAULT .. "/Gamma.md"] == "# Gamma\n\nunsaved" and v.rescanTimer == nil)
check("the escape router's present() is false once closed", CLAIMED_ESC.vault.present() == false)
do
    v.show()
    check("⇪3 again reopens", v.webview ~= nil)
    v.show()
    check("⇪3 while open closes (toggle)", v.webview == nil)
end

-- =======================================================================
out("7) degrade — no webview, the prompt still edits and saves\n")
-- =======================================================================
do
    local saved = hs.webview
    hs.webview = nil
    PROMPT_ANSWERS = { { "Save", "# Gamma\n\nfrom the prompt" } }
    v.show()
    check("without a webview the prompt edits the open note and saves it",
          #PROMPTS >= 1 and FILES[VAULT .. "/Gamma.md"] == "# Gamma\n\nfrom the prompt", FILES[VAULT .. "/Gamma.md"])
    hs.webview = saved
end
do
    local r = _G.vaultReport()
    check("the report names the folder, the note count and Obsidian", r:find(VAULT, 1, true) and r:find("notes  : 7") and r:find("Obsidian"), r)
    check("the report shows the alpha and how to make it solid again",
          r:find("alpha 0.97 (see-through; vault = { alpha = 1 } for solid)", 1, true) ~= nil, r)
end

-- =======================================================================
out("8) 6.173.0 — the Scorp Pad's tabs live in this window\n")
-- =======================================================================
do
    -- a stand-in for scratch_pad's brain: tabs, history, the filing hooks
    local PAD = { viaVault = true, tabs = {}, history = {}, historyRows = 200, active = nil, sets = {}, saves = 0,
                  closedHost = 0, sent = 0, kinds = { capture = { badge = "🗒", label = "Capture", hint = "⌘W queues this" } } }
    local n = 0
    function PAD.newTab(text, kind) n = n + 1; local t = { id = "t" .. n, text = text or "", kind = kind }; PAD.tabs[#PAD.tabs + 1] = t; PAD.active = t.id; return t end
    function PAD.findTab(id) for i, t in ipairs(PAD.tabs) do if t.id == id then return t, i end end end
    function PAD.activeTab() return PAD.active and PAD.findTab(PAD.active) or PAD.tabs[1] end
    function PAD.titleOf(t) local f = t.text:match("[^\n]*"); if f == "" then return (PAD.kinds[t.kind or ""] or {}).label or "Scratch" end return f end
    function PAD.kindOf(t) return t and t.kind and PAD.kinds[t.kind] or nil end
    function PAD.setText(id, text) local t = PAD.findTab(id); if t then t.text = text; PAD.sets[#PAD.sets + 1] = id .. "=" .. text end return t ~= nil end
    function PAD.closeTab(id) local t, i = PAD.findTab(id); if not t then return false end table.remove(PAD.tabs, i)
        if t.text ~= "" then table.insert(PAD.history, 1, { id = t.id, text = t.text, title = PAD.titleOf(t), closedAt = 0 }) end
        if #PAD.tabs == 0 then PAD.newTab("") end
        if PAD.active == id then PAD.active = PAD.tabs[math.min(i, #PAD.tabs)].id end return true end
    function PAD.restore(id) for i, h in ipairs(PAD.history) do if h.id == id then table.remove(PAD.history, i); PAD.newTab(h.text); return true end end return false end
    function PAD.onHostClose() PAD.closedHost = PAD.closedHost + 1 end
    function PAD.send() PAD.sent = PAD.sent + 1; return true, "sent" end
    function PAD.saveNow() PAD.saves = PAD.saves + 1 end
    PAD.newTab("groceries\nmilk [[Alpha]]"); PAD.newTab("", "capture"); PAD.active = "t1"
    _G.scratchPad = PAD

    check("without the pad module, v.sp() is nil and nothing here changes", (function() local keep = _G.scratchPad; _G.scratchPad = nil; local r = v.sp(); _G.scratchPad = keep; return r == nil end)())
    check("scratch_pad.viaVault = false keeps the pad's own window", (function() PAD.viaVault = false; local r = v.sp(); PAD.viaVault = true; return r == nil end)())
    check("v.sp() finds the pad", v.sp() == PAD)

    v.openNote("Gamma")
    check("⇪1 (toggleScratch) with the window closed opens it on the active tab",
          v.toggleScratch() and v.webview ~= nil and v.doc and v.doc.scratch == "t1" and v.doc.rel == "scratch:t1")
    local h = v.webview.htmlSet
    check("📝 6.333.0 — ONE section heading, with the tab rows and the "
          .. "notes both under it: he asked twice to stop seeing two lists",
          h:find("🕸 HAMSIDIAN", 1, true) ~= nil
          and h:find("📝 SCRATCH", 1, true) == nil
          and h:find("🕸 NOTES</li>", 1, true) == nil
          and h:find('TABS = [{id:"t1",t:"groceries"', 1, true) ~= nil
          and h:find("HASPAD = true", 1, true) ~= nil
          and h:find("new tab ⌘T", 1, true) ~= nil)
    check("a Capture tab row carries its badge and kind", h:find('{id:"t2",t:"Capture",b:"🗒",k:"capture"}', 1, true) ~= nil)
    -- 🗑 6.254.0 — LL: "I don't need capture or append." The two + rows
    -- are hidden by default and the PAD owns the switch, so this window
    -- only asks. An existing Capture TAB is still drawn (above) — the
    -- door is what closed, not the room.
    check("🗑 the + Capture / + Append rows are off by default",
          h:find("var KINDROWS = false", 1, true) ~= nil
          and h:find("+ new tab ⌘T", 1, true) ~= nil)
    -- 🚨 AND THE PAGE MUST ACTUALLY ASK. A flag the render ignores is
    -- 6.220.0's rule in a new costume: the declaration can be perfect
    -- while the rows are pushed unconditionally, and a check that only
    -- reads the declaration passes. Both pushes must sit INSIDE the
    -- guard — measured by position, which is a counting question.
    do
        local guard = h:find("if (KINDROWS) {", 1, true)
        local cap   = h:find('data-tab="+capture"', 1, true)
        local app   = h:find('data-tab="+append"', 1, true)
        check("...and the page pushes them ONLY inside that guard",
              guard ~= nil and cap ~= nil and app ~= nil
              and cap > guard and app > guard
              and h:find('data-tab="+capture"', guard + 1, true) ~= nil
              and select(2, h:gsub('data%-tab="%+capture"', "")) == 1,
              tostring(guard) .. "/" .. tostring(cap))
    end
    do
        local was = _G.scratchPad.showKindRows
        _G.scratchPad.showKindRows = true
        local h2 = v.buildHtml and v.buildHtml() or html()
        check("...and the switch puts them back",
              h2:find("var KINDROWS = true", 1, true) ~= nil)
        _G.scratchPad.showKindRows = was
    end
    check("the header says 📝 Hamsidian, offers ⌘W and → Asana now", h:find("📝 Hamsidian", 1, true) and h:find("→ Asana now", 1, true) and h:find("a:'tabclose'", 1, true))
    check("the right pane shows the tab's links out (Alpha) and HISTORY, not backlinks",
          h:find("HISTORY", 1, true) and h:find('data-name="Alpha">→ Alpha', 1, true) and not h:find("BACKLINKS", 1, true))
    -- 6.174.0 — the spare newline after the start tag: HTML discards one
    -- there, so a note beginning with a blank line reaches the page whole
    check("the textarea holds the tab's text", h:find("<textarea", 1, true) and h:find(">\ngroceries\nmilk [[Alpha]]</textarea>", 1, true))
    local writes = 0
    for k in pairs(FILES) do if k:find("scratch", 1, true) then writes = writes + 1 end end
    msg({ a = "edit", rel = "scratch:t1", text = "groceries\nmilk, eggs", sel = 5 })
    check("typing into a tab goes to the pad's setText, never to a file", PAD.sets[#PAD.sets] == "t1=groceries\nmilk, eggs" and v.doc.text == "groceries\nmilk, eggs" and not v.dirty and writes == 0)
    check("v.links never learns a scratch rel", v.links["scratch:t1"] == nil)
    msg({ a = "tabnew", rel = "scratch:t1", text = "groceries\nmilk, eggs", sel = 5 })
    check("⌘T makes a new tab and opens it", #PAD.tabs == 3 and v.doc.scratch == "t3")
    msg({ a = "tabnth", n = "1", rel = "scratch:t3", text = "", sel = 0 })
    check("⌘1 opens the first tab", v.doc.scratch == "t1")
    msg({ a = "tabcycle", d = 1, rel = "scratch:t1", text = v.doc.text, sel = 0 })
    check("⌃Tab cycles to the next tab", v.doc.scratch == "t2")
    msg({ a = "tabcycle", d = -1, rel = "scratch:t2", text = "", sel = 0 })
    check("⌃⇧Tab cycles back", v.doc.scratch == "t1")
    msg({ a = "tabclose", tid = "t1", rel = "scratch:t1", text = v.doc.text, sel = 0 })
    check("⌘W closes the tab into the history and opens the pad's next active tab",
          PAD.history[1] and PAD.history[1].id == "t1" and #PAD.tabs == 2 and v.doc.scratch == PAD.active and v.webview.htmlSet:find('data-hist="t1"', 1, true))
    msg({ a = "restore", rid = "t1", rel = v.doc.rel, text = v.doc.text, sel = 0 })
    check("a history click restores the tab and opens it", #PAD.history == 0 and #PAD.tabs == 3 and v.doc.text == "groceries\nmilk, eggs")
    msg({ a = "send", rel = v.doc.rel, text = v.doc.text, sel = 0 })
    check("→ Asana now is the pad's own send", PAD.sent == 1)
    msg({ a = "open", name = "Gamma", rel = v.doc.rel, text = v.doc.text, sel = 0 })
    check("a note row from a tab opens the note; the header is the Vault's again",
          v.doc.rel == "Gamma.md" and v.webview.htmlSet:find("🕸 Hamsidian", 1, true) and v.webview.htmlSet:find("BACKLINKS", 1, true))
    check("…and the tabs are still listed in the one section (6.333.0)",
          v.webview.htmlSet:find("🕸 HAMSIDIAN", 1, true) ~= nil
          and v.webview.htmlSet:find("HASPAD = true", 1, true) ~= nil)
    check("⇪1 with a note open jumps to the tabs (no close)", v.toggleScratch() and v.webview ~= nil and v.doc.scratch ~= nil)
    check("⇪1 with a tab open closes the window and lets the pad file its kind tabs",
          v.toggleScratch() and v.webview == nil and PAD.closedHost == 1)
    msg({ a = "pin" })
    check("📌 pins: remembered, and the escape router stands aside", v.pinned == true and SETTINGS["vault.pinned"] == true)
    v.show()
    check("…while pinned, the router's present() is false with the window open", v.webview ~= nil and CLAIMED_ESC.vault.present() == false)
    local before = v.webview
    msg({ a = "esc", rel = v.doc.rel, text = v.doc.text, sel = 0 })
    check("Esc on a pinned window only hands the keys back", v.webview == before)
    msg({ a = "pin" })
    v.hide()
    -- 6.177.0 — ⌘⇧S hands the export to the pad, and survives its absence
    PAD.exports = 0
    function PAD.exportAll(why) PAD.exports = PAD.exports + 1; return true, "2 notes → /od/Vault/Scratch" end
    msg({ a = "export" })
    check("6.177.0: ⌘⇧S asks the pad to export — the vault does none of the work", PAD.exports == 1)
    check("...and it says on screen where the notes went",
          tostring(ALERTS[#ALERTS]):find("/od/Vault/Scratch", 1, true) ~= nil, tostring(ALERTS[#ALERTS]))
    do
        local keep = _G.scratchPad; _G.scratchPad = nil
        local ok = pcall(msg, { a = "export" })
        _G.scratchPad = keep
        check("...and with no pad loaded it says so instead of throwing",
              ok and tostring(ALERTS[#ALERTS]):find("not loaded", 1, true) ~= nil, tostring(ALERTS[#ALERTS]))
    end
    PAD.exportAll = nil
    local okNo = pcall(msg, { a = "export" })
    check("...an old pad without the export still costs nothing", okNo == true)

    -- 6.180.0 — the anchors half: vault.link writes ONE line under the
    -- heading, vault.names lists the notes, and follow() opens an
    -- absolute link (including one whose file has moved).
    do
        local ok, why = PROVIDED["vault.link"]("Anchored", "- [Contract](file:///a/b.docx)")
        check("6.180.0: vault.link creates the note and writes the line under the heading", (function()
            local t = v.doc and v.doc.text or ""
            return ok and t:find("## Linked", 1, true) and t:find("- [Contract](file:///a/b.docx)", 1, true)
        end)(), v.doc and v.doc.text)
        local again = select(2, PROVIDED["vault.link"]("Anchored", "- [Contract](file:///a/b.docx)"))
        check("...and the SAME link twice is one line, not two",
              again == "already linked"
              and select(2, (v.doc.text):gsub("%- %[Contract%]", "")) == 1, again)
        PROVIDED["vault.link"]("Anchored", "- [Second](file:///a/c.docx)")
        check("...a second link goes under the same heading, newest first",
              v.doc.text:find("## Linked\n%- %[Second%]") ~= nil, v.doc.text)
        check("...and it refuses politely with nothing to link",
              PROVIDED["vault.link"]("Anchored", "") == false)
        local names = PROVIDED["vault.names"]()
        check("vault.names lists the notes for the anchors picker",
              type(names) == "table" and #names > 0, names and #names)
    end
    do
        OPENED = {}
        v.follow("file:///tmp/does-not-matter.txt", true)
        check("6.180.0: an absolute file:// link is opened as a FILE, not joined onto the note's folder",
              (OPENED[#OPENED] or ""):find("^/tmp/does%-not%-matter%.txt") ~= nil
              or (ALERTS[#ALERTS] or ""):find("not where the link says", 1, true) ~= nil,
              tostring(OPENED[#OPENED] or ALERTS[#ALERTS]))
        v.follow("message://%3Cabc@example.com%3E", true)
        check("...and a scheme only its own app understands is handed to macOS",
              (OPENED[#OPENED] or ""):find("^message://") ~= nil, OPENED[#OPENED])
    end

    -- 🚚 6.273.0 — MOVE SURVIVAL, DRIVEN FOR THE FIRST TIME. The mirror
    -- of the anchors bug lived here: `local okS, res = _G.service.call
    -- ("anchors.resolve", path)` read TWO values from a provider that
    -- answers ONE, so `res` was always nil and a moved file could never
    -- be found. The mutation restoring it did not fail a single check,
    -- because this suite never stubbed `_G.service` AND its hs.fs had no
    -- `attributes` — so `gone` was false on every path and the whole
    -- branch was unreachable. 6.193.0 twice over: a stub gentler than the
    -- real provider hides the class, and the fix is untestable until the
    -- stub answers what a Mac answers.
    do
        local keepSvc, keepAttrs = _G.service, hs.fs.attributes
        local REG = dofile(HS .. "/tests/service_registry.lua")(HS, REAL_OPEN)
        check("🚚 the registry was LIFTED out of init.lua, not stood in for",
              REG.src ~= nil)
        _G.service = REG.service
        -- A real hs.fs.attributes answers nil for a path that is gone.
        hs.fs.attributes = function(pth)
            if pth == "/tmp/it-moved.docx" then return nil end
            return { mode = "file" }
        end

        local asked = {}
        REG.provide("anchors.resolve", function(pth)
            asked[#asked + 1] = pth
            return "/tmp/found/it-moved.docx"   -- the REAL signature: ONE value
        end)

        OPENED, ALERTS = {}, {}
        local moved = v.follow("file:///tmp/it-moved.docx", true)
        check("🚚 6.273.0: a link whose file has moved ASKS anchors.resolve",
              asked[1] == "/tmp/it-moved.docx", tostring(asked[1]))
        check("🚚 ...and opens the path it ANSWERED, not the dead one",
              moved == true and OPENED[#OPENED] == "/tmp/found/it-moved.docx",
              tostring(OPENED[#OPENED]))
        check("🚚 ...and says it moved, so a redirect is never silent",
              (ALERTS[#ALERTS] or ""):find("Moved", 1, true) ~= nil,
              tostring(ALERTS[#ALERTS]))

        -- 🔎 And a resolver with no answer must still be the honest
        -- refusal — the state this branch reported on every Mac until now.
        REG.service.registry["anchors.resolve"] = function() return nil end
        OPENED, ALERTS = {}, {}
        local dead = v.follow("file:///tmp/it-moved.docx", true)
        check("🚚 ...a resolver with nothing to say leaves the link honestly broken",
              dead == false and #OPENED == 0
              and (ALERTS[#ALERTS] or ""):find("not where the link says", 1, true) ~= nil,
              tostring(ALERTS[#ALERTS]))

        hs.fs.attributes = keepAttrs
        _G.service = keepSvc
    end

    check("the report has the scratch line", _G.vaultReport():find("scratch: 3 tabs shown here", 1, true) ~= nil)
    _G.scratchPad = nil
end

-- =======================================================================
out("9) 6.174.0 — tags: the grammar, the front matter, the index from two more greps\n")
-- =======================================================================
local WARNS = {}
_G.diag.warn = function(_, m) WARNS[#WARNS + 1] = tostring(m) end
local function same(a, b)
    if #a ~= #b then return false end
    for i = 1, #a do if a[i] ~= b[i] then return false end end
    return true
end
check("tagOk: letters, digits with a non-digit, nested, trailing punctuation off, Unicode",
      v.tagOk("Work") == "Work" and v.tagOk("2024") == nil and v.tagOk("2024-plan") == "2024-plan" and v.tagOk("a/b.") == "a/b"
      and v.tagOk("café") == "café" and v.tagOk("") == nil and v.tagOk("x)") == "x" and v.tagOk("a b") == nil)
do
    local got = v.tagsIn("---\ntags: [Work, home/x]\n  - extra\n---\n# H\ntext #Work #2024 a#b [[N#h]] https://x/y#z #café.\n```\n#code\n```\n#Done\n")
    check("tagsIn: front matter (inline + list item), body tags, no heading / number / [[N#h]] / URL / fenced tag, first-seen case",
          same(got, { "Work", "home/x", "extra", "café", "Done" }), table.concat(got, ","))
    check("tagsIn: `tags: a, b`, `tags: a b`, `tag: a`, quotes and a leading # stripped, YAML list form",
          same(v.tagsIn("---\ntags: a, b\n---\n"), { "a", "b" }) and same(v.tagsIn("---\ntags: a b\n---\n"), { "a", "b" })
          and same(v.tagsIn("---\ntag: '#solo'\n---\n"), { "solo" }) and same(v.tagsIn("---\ntags:\n  - one\n  - \"two\"\nother: x\n  - three\n---\n"), { "one", "two" }))
    check("tagsIn: no closing --- means no front matter (the lines are body)", same(v.tagsIn("---\ntags: a\n#b\n"), { "b" }))
    check("tagsIn: a ~~~ fence hides tags too; case-insensitive dedupe keeps the first spelling",
          same(v.tagsIn("~~~\n#hidden\n~~~\n#Tag #tag #TAG\n"), { "Tag" }))
end
-- the scan, with tags: Alpha open and carrying #Work live
FILES[VAULT .. "/Alpha.md"] = "# Alpha\n\nsee [[Beta|B]] and [[Gamma]] #Work\n"
v.openNote("Alpha")
READS = {}
local NOTES9 = VAULT .. "/Alpha.md\n" .. VAULT .. "/Projects/Beta.md\n" .. VAULT .. "/Gamma.md\n" .. VAULT .. "/Delta.md\n"
    .. VAULT .. "/New Idea.md\n" .. VAULT .. "/Daily.md\n" .. VAULT .. "/Templates/Meeting.md\n" .. VAULT .. "/Daily/" .. today .. ".md\n"
local LINKS9 = VAULT .. "/Alpha.md:[[Beta|B]]\n" .. VAULT .. "/Alpha.md:[[Gamma]]\n" .. VAULT .. "/Projects/Beta.md:[[alpha]]\n" .. VAULT .. "/Gamma.md:[[Delta]]\n"
v.scanning = false
check("a scan starts (find → link grep → tag grep)", v.scan("tags") == true)
lastTask("find").cb(0, NOTES9, "")
lastTaskWith("grep", "\\[\\[").cb(0, LINKS9, "")
local tg = lastTaskWith("grep", "-rHoIE")
check("the tag grep is HELD and started", tg and v.tagTask == tg and tg.started)
tg.cb(0, VAULT .. "/Alpha.md: #Work\n" .. VAULT .. "/Gamma.md:#work/deep\n" .. VAULT .. "/Gamma.md: #2024\n/elsewhere/x.md:#no\n", "")
check("the tag index is NOT assigned before the chain ends (only the open note's live #Work exists)", v.tags["work/deep"] == nil and v.tags.work.count == 1 and v.scanning == true)
local fg = lastTaskWith("grep", "^---")
check("the front-matter grep is HELD and started", fg and v.fmTask == fg and fg.started)
fg.cb(0, VAULT .. "/Projects/Beta.md:1:---\n" .. VAULT .. "/Projects/Beta.md-2-tags: [Home, \"#Work\"]\n" .. VAULT .. "/Projects/Beta.md-3-  - listed\n" .. VAULT .. "/Projects/Beta.md-4-status: reading\n" .. VAULT .. "/Projects/Beta.md-5-rating: 5\n" .. VAULT .. "/Projects/Beta.md-6----\n--\n" .. VAULT .. "/Gamma.md:70:---\n" .. VAULT .. "/Gamma.md-71-tags: late\n", "")
check("scan finished with tags: #work counts Alpha, Beta (front matter) and Gamma (nested child)",
      v.scanning == false and v.scanErr == nil and v.tags.work and v.tags.work.count == 3, v.tags.work and v.tags.work.count)
check("work/deep is its own tag on Gamma only", v.tags["work/deep"] and #v.tags["work/deep"].rels == 1 and v.tags["work/deep"].rels[1] == "Gamma.md")
check("front matter: the inline list and the `- listed` item both count", v.tags.home and v.tags.home.count == 1 and v.tags.listed and v.tags.listed.count == 1)
check("#2024 is a number, `tags:` on line 70 is not front matter, /elsewhere is not the vault",
      v.tags["2024"] == nil and v.tags.late == nil and v.tags.no == nil)
check("the display name is the first-seen spelling and the list is by count", v.tags.work.name == "Work" and v.tagList[1].key == "work" and v.tagList[1].count == 3)
check("no note file was READ for the tags", #READS == 0, #READS)
check("tagsOf never learns a scratch rel and the open note's entry is live", v.tagsOf["Alpha.md"] and v.tagsOf["Alpha.md"][1] == "Work")
check("the two greps share one line counter (4 tag lines + 9 front-matter lines)", v.tagLines == 13, v.tagLines)
-- 6.185.0 — the SAME grep that built the tags built the FIELDS. No second
-- pass over the vault, no note read, and the answer is per note.
check("6.185.0: the front-matter FIELDS are indexed off the same grep",
      v.fmOf["Projects/Beta.md"] and v.fmOf["Projects/Beta.md"].status == "reading"
      and v.fmOf["Projects/Beta.md"].rating == "5", v.fmOf["Projects/Beta.md"])
check("…tags are NOT duplicated into the fields — they already travel as g:[…]",
      v.fmOf["Projects/Beta.md"].tags == nil and v.fmOf["Projects/Beta.md"].tag == nil)
check("…a --- that is not on line 1 opens nothing (it is a divider in someone's prose)",
      v.fmOf["Gamma.md"] == nil, v.fmOf["Gamma.md"])
check("…and STILL no note file was read to learn any of it", #READS == 0, #READS)
check("v.fmFields lists every key seen, by count then name",
      #v.fmFields == 2 and v.fmFields[1].name == "rating" and v.fmFields[1].count == 1
      and v.fmFields[2].name == "status", v.fmFields)
-- v.fmIn is the Lua twin for the OPEN note: exact, live, and the only
-- place a note's own text is parsed for fields
check("v.fmIn reads one note's front matter: scalars, a list joined, tags skipped", (function()
    local f = v.fmIn("---\ntitle: Deep Work\ntags: [a, b]\nstatus: reading\ngenre:\n  - focus\n  - craft\n---\n# body\nstatus: not this\n")
    return f.title == "Deep Work" and f.status == "reading" and f.genre == "focus, craft" and f.tags == nil, f
end)())
check("v.fmIn refuses a block with no closing --- — that is body text, not front matter",
      next(v.fmIn("---\nstatus: reading\nand then prose\n")) == nil)
check("v.fmIn refuses a --- that is not the first line", next(v.fmIn("# Title\n---\nstatus: x\n---\n")) == nil)
-- 6.186.0 — and the shape that actually proves the line-1 rule: a note with
-- NO front matter whose second line reads like a field and which has a ---
-- divider further down. Drop the line-1 test and this one grows a field.
check("…and a heading, a colon line and a divider below are not front matter either",
      next(v.fmIn("# Title\nstatus: x\n---\nprose\n")) == nil)
check("a value longer than fmMaxLen is CLAMPED, so one paragraph cannot bloat the page",
      #(v.fmIn("---\nnote: " .. string.rep("x", 400) .. "\n---\n").note or "") == v.fmMaxLen)
check("a note with more than fmMaxFields keys keeps the first fmMaxFields, and does not grow", (function()
    local L = { "---" }
    for i = 1, 40 do L[#L + 1] = "k" .. i .. ": v" .. i end
    L[#L + 1] = "---"
    local f, n = v.fmIn(table.concat(L, "\n") .. "\n"), 0
    for _ in pairs(f) do n = n + 1 end
    return n == v.fmMaxFields and f.k1 == "v1", n
end)())
do
    -- a failed tag grep is optional: links stay, the scan finishes, a warn line says so
    local before = v.tags.work.count
    v.scan("tags fail")
    lastTask("find").cb(0, NOTES9, "")
    lastTaskWith("grep", "\\[\\[").cb(0, LINKS9, "")
    lastTaskWith("grep", "-rHoIE").cb(2, "", "grep: boom")
    check("tag grep exit 2: a warn line, no scanErr, links intact, scan finished, tags untouched",
          v.scanning == false and v.scanErr == nil and #v.links["Alpha.md"] == 2 and WARNS[#WARNS]:find("tags: grep exited 2", 1, true)
          and v.tags.work.count == before, WARNS[#WARNS])
    -- a failed front-matter grep keeps what the tag grep found
    v.scan("fm fail")
    lastTask("find").cb(0, NOTES9, "")
    lastTaskWith("grep", "\\[\\[").cb(0, LINKS9, "")
    lastTaskWith("grep", "-rHoIE").cb(0, VAULT .. "/Gamma.md:#only\n", "")
    lastTaskWith("grep", "^---").cb(2, "", "grep: boom")
    check("front-matter grep exit 2: the inline tags are kept, the scan finishes", v.scanning == false and v.tags.only and v.tags.home == nil, WARNS[#WARNS])
    -- back to the full index
    v.scan("tags again")
    lastTask("find").cb(0, NOTES9, "")
    lastTaskWith("grep", "\\[\\[").cb(0, LINKS9, "")
    lastTaskWith("grep", "-rHoIE").cb(0, VAULT .. "/Alpha.md: #Work\n" .. VAULT .. "/Gamma.md:#work/deep\n", "")
    lastTaskWith("grep", "^---").cb(0, VAULT .. "/Projects/Beta.md:1:---\n" .. VAULT .. "/Projects/Beta.md-2-tags: [Home, \"#Work\"]\n" .. VAULT .. "/Projects/Beta.md-3-  - listed\n" .. VAULT .. "/Projects/Beta.md-4-status: reading\n" .. VAULT .. "/Projects/Beta.md-5-rating: 5\n" .. VAULT .. "/Projects/Beta.md-6----\n", "")
    check("…restored", v.tags.work.count == 3 and v.tags.home ~= nil)
    check("…and the FIELDS came back with them — one grep, both indexes",
          v.fmOf["Projects/Beta.md"] and v.fmOf["Projects/Beta.md"].status == "reading" and #v.fmFields == 2, v.fmFields)
end
-- live: a keystroke changes the open note's tags at once, the index on save
msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n#Fresh\n", sel = 3 })
check("typing #Fresh into Alpha is in tagsOf before any save", same(v.tagsOf["Alpha.md"], { "Fresh" }))
lastTimer("after"):fire()
check("the save rebuilds the index: #fresh exists, #work dropped to 2", v.tags.fresh and v.tags.fresh.count == 1 and v.tags.work.count == 2)
check("tagsJson is the list in count order", v.tagsJson():find('^%[{k:"work",n:"Work",c:2}'), v.tagsJson())
check("notesJson rows carry g:[tags] and tpl:1 for a template",
      v.notesJson():find('{n:"Alpha",r:"Alpha.md",g:["fresh"],l:[]}', 1, true) and v.notesJson():find('{n:"Meeting",r:"Templates/Meeting.md",g:[],l:[],tpl:1}', 1, true), v.notesJson())
-- 6.183.0 — l: the KEYS a note links out to. A query's FROM [[Note]] is
-- answered in the page, so the row has to carry them; without this the
-- page cannot tell which notes point at anything.
check("notesJson carries each note's outgoing link KEYS, lower-cased, for FROM [[Note]]", (function()
    local keep = v.links["Gamma.md"]
    v.links["Gamma.md"] = { "Alpha", "Delta Two" }
    local out = v.notesJson()
    v.links["Gamma.md"] = keep
    return out:find('{n:"Gamma",r:"Gamma.md",g:["work/deep"],l:["alpha","delta two"]}', 1, true) ~= nil, out
end)())
check("setNotes drops the tags of a note that vanished", (function()
    local keep = v.tagsOf["Gamma.md"]
    v.setNotes({ "Alpha.md", "Projects/Beta.md" })
    local gone = v.tagsOf["Gamma.md"] == nil and v.tags["work/deep"] == nil
    local rels = {}
    for line in NOTES9:gmatch("[^\n]+") do rels[#rels + 1] = line:sub(#VAULT + 2) end
    v.setNotes(rels); v.tagsOf["Gamma.md"] = keep; v.rebuildTags()
    return gone and v.tags["work/deep"] ~= nil
end)())
v.show()
local h9 = WEBVIEWS[#WEBVIEWS].htmlSet or ""
check("the page carries TAGS, TAGROWS, TEMPLATES, TPLDIR, MODE and the new load state",
      h9:find('TAGS = [{k:"work",n:"Work",c:2}', 1, true) and h9:find("TAGROWS = 15", 1, true)
      and h9:find('TEMPLATES = [{n:"Meeting",r:"Templates/Meeting.md"}]', 1, true) and h9:find('TPLDIR = "Templates"', 1, true)
      and h9:find('MODE = "notes"', 1, true) and h9:find("SMARTLISTS = true", 1, true) and h9:find("LINEH = 14 * 1.5", 1, true)
      and h9:find("CARETLINE = 0", 1, true) and h9:find("CARETHEAD = null", 1, true) and h9:find("DAILY = null", 1, true)
      and not h9:find("FSNUM", 1, true), h9:match("var TAGS[^\n]*"))
check("the report counts the tags and names the top ones", _G.vaultReport():find("tags   : 5 tags on 3 notes · top #work 2 · #fresh 1 · #home 1", 1, true) ~= nil, _G.vaultReport():match("tags   :[^\n]*"))
check("…and says so when there are none", (function()
    local keep = v.tagsOf; v.tagsOf = {}; v.rebuildTags()
    local r = _G.vaultReport():find("tags   : none yet — type #word in a note", 1, true) ~= nil
    v.tagsOf = keep; v.rebuildTags()
    return r
end)())
-- 6.185.0 — the fields line, in all three states it can be in
check("the report names the front-matter FIELDS a query can WHERE on",
      _G.vaultReport():find("fields : 2 on 1 notes · rating 1 · status 1 — a query can WHERE on any of them", 1, true) ~= nil,
      _G.vaultReport():match("fields :[^\n]*"))
check("…says so when there are none, with the shape to type",
      (function()
          local keep = v.fmOf; v.fmOf = {}; local kf = v.fmFields; v.fmFields = {}
          local r = _G.vaultReport():find("fields : none yet — put `status: reading` under a --- line", 1, true) ~= nil
          v.fmOf, v.fmFields = keep, kf
          return r
      end)())
-- IT DEGRADES, IT NEVER BREAKS: a failed grep must not read as "no fields"
check("…and NAMES the failure when the front-matter grep is what went wrong",
      (function()
          local keep, kf = v.fmOf, v.fmFields
          v.fmOf, v.fmFields, v.fmErr = {}, {}, "grep exited 2: boom"
          local r = _G.vaultReport():find("fields : none — the front-matter grep failed (grep exited 2: boom)", 1, true) ~= nil
          v.fmOf, v.fmFields, v.fmErr = keep, kf, nil
          return r
      end)(), _G.vaultReport():match("fields :[^\n]*"))
check("search and tasks report lines before any use", _G.vaultReport():find("search : never (⌘⇧F)", 1, true) and _G.vaultReport():find("tasks  : not listed yet (⌘⇧K)", 1, true))

-- =======================================================================
out("10) 6.174.0 — templates: Templates/*.md, moment tokens, {{cursor}}, /bin/cat in a task\n")
-- =======================================================================
check("v.templates() lists Templates/Meeting.md and nothing else", #v.templates() == 1 and v.templates()[1].rel == "Templates/Meeting.md")
check("templateByName matches by rel under Templates/ (case-insensitive)", v.templateByName("meeting") and v.templateByName("meeting").rel == "Templates/Meeting.md")
check("a ROOT note named Daily never shadows a template", v.find("daily") ~= nil and v.templateByName("Daily") == nil)
check("isTemplateRel is case-insensitive", v.isTemplateRel("templates/x.md") == true and v.isTemplateRel("Alpha.md") == false)
local T = os.time({ year = 2026, month = 9, day = 6, hour = 14, min = 5, sec = 9 })
check("momentFormat: YYYY-MM-DD", v.momentFormat("YYYY-MM-DD", T) == "2026-09-06", v.momentFormat("YYYY-MM-DD", T))
check("momentFormat: dddd D MMMM YYYY", v.momentFormat("dddd D MMMM YYYY", T) == "Sunday 6 September 2026", v.momentFormat("dddd D MMMM YYYY", T))
check("momentFormat: ddd DD MMM YY", v.momentFormat("ddd DD MMM YY", T) == "Sun 06 Sep 26", v.momentFormat("ddd DD MMM YY", T))
check("momentFormat: HH:mm:ss and h:mm A", v.momentFormat("HH:mm:ss", T) == "14:05:09" and v.momentFormat("h:mm A", T) == "2:05 PM", v.momentFormat("h:mm A", T))
check("momentFormat: [literal], m/s, Q and dd copy through", v.momentFormat("[Day] D, YY", T) == "Day 6, 26" and v.momentFormat("m/s", T) == "5/9"
      and v.momentFormat("Q", T) == "Q" and v.momentFormat("dd", T) == "dd" and v.momentFormat("[open", T) == "[open")
do
    local filled, caret = v.fillTemplate("# {{title}}\n{{date}} {{time}} {{ date }} {{date:}} {{date:YYYY}} {{nope}} {{title\n100%\n{{cursor}}x{{cursor}}", { title = "Meeting", when = T })
    local want = "# Meeting\n2026-09-06 14:05 2026-09-06 2026-09-06 2026 {{nope}} {{title\n100%\nx"
    check("fillTemplate: title, date, time, spaces, empty format, a format, unknown and unclosed stay, % survives, cursors vanish",
          filled == want, filled)
    check("…the caret is where the FIRST {{cursor}} was", caret == #"# Meeting\n2026-09-06 14:05 2026-09-06 2026-09-06 2026 {{nope}} {{title\n100%\n", caret)
    local f2, c2 = v.fillTemplate("{{cursor}}")
    check("a lone {{cursor}} → empty text, caret 0", f2 == "" and c2 == 0)
    local f3, c3 = v.fillTemplate("plain")
    check("no cursor → nil caret", f3 == "plain" and c3 == nil)
    local n = #PRINTED
    check("Templater <% %> is left verbatim and said once in the Console",
          v.fillTemplate("<% tp.x %>", { name = "Templates/Meeting.md" }) == "<% tp.x %>" and #PRINTED == n + 1 and PRINTED[#PRINTED]:find("Templater", 1, true) and PRINTED[#PRINTED]:find("Templates/Meeting.md", 1, true))
end
-- ⌘⇧T: insert at the caret
v.openNote("Alpha")
READS = {}
local catsBefore = countTasks("cat")
msg({ a = "tplinsert", name = "Meeting", rel = "Alpha.md", text = v.doc.text, sel = 0 })
local ct = lastTask("cat")
check("⌘⇧T starts /bin/cat on the template, HELD, with a 10 s held timer and a hint on the page",
      countTasks("cat") == catsBefore + 1 and ct.args[1] == VAULT .. "/Templates/Meeting.md" and ct.started and v.catTask == ct
      and v.catTimer and v.catTimer.kind == "after" and v.catTimer.delay == 10 and EVALS[#EVALS]:find('^vaultHint%("fetching'), EVALS[#EVALS])
local tm = v.catTimer
ct.cb(0, "## {{title}}\n{{cursor}}- ", "")
check("the body lands as insertAtCaret(head, tail) split at {{cursor}}, {{title}} = the note's name",
      EVALS[#EVALS] == 'insertAtCaret("## Alpha\\n","- ")', EVALS[#EVALS])
check("…task released, timer stopped, no file read on the main thread", v.catTask == nil and v.catTimer == nil and tm.stopped and #READS == 0)
msg({ a = "tplinsert", name = "Meeting", rel = "Alpha.md", text = v.doc.text, sel = 0 })
ct = lastTask("cat")
v.catTimer:fire()
check("no answer in 10 s: the task is terminated and LL is told", ct.terminated and v.catTask == nil and ALERTS[#ALERTS]:find("did not arrive", 1, true), ALERTS[#ALERTS])
msg({ a = "tplinsert", name = "Meeting", rel = "Alpha.md", text = v.doc.text, sel = 0 })
local first = lastTask("cat")
msg({ a = "tplinsert", name = "Meeting", rel = "Alpha.md", text = v.doc.text, sel = 0 })
local n = #EVALS
first.cb(0, "late", "")
check("a superseded fetch is terminated and its late answer changes nothing", first.terminated and #EVALS == n)
lastTask("cat").cb(0, "x", "")
v.openNote("Alpha")
msg({ a = "tplinsert", name = "Meeting", rel = "Alpha.md", text = v.doc.text, sel = 0 })
ct = lastTask("cat")
v.openNote("Gamma")
ct.cb(0, "## late", "")
check("a template that arrives after switching notes is not inserted", not EVALS[#EVALS]:find("insertAtCaret", 1, true), EVALS[#EVALS])
check("⌘⇧T with an unknown template alerts", (function() msg({ a = "tplinsert", name = "Nope" }); return ALERTS[#ALERTS]:find('no template named "Nope"', 1, true) ~= nil end)())
do
    local keep = v.doc; v.doc = nil
    msg({ a = "tplinsert", name = "Meeting" })
    check("⌘⇧T with no note open alerts", ALERTS[#ALERTS]:find("open a note first", 1, true) ~= nil, ALERTS[#ALERTS])
    v.doc = keep
end
-- ⌘⇧N: a new note from a template
PROMPT_ANSWERS = { { "Create", "Standup" } }
msg({ a = "tplnew", name = "Meeting", rel = v.doc.rel, text = v.doc.text, sel = 0 })
check("⌘⇧N prompts 'New note from Meeting' and fetches the template", PROMPTS[#PROMPTS].title == "New note from Meeting" and lastTask("cat").args[1] == VAULT .. "/Templates/Meeting.md")
lastTask("cat").cb(0, "## {{title}}\n{{cursor}}- ", "")
check("the note is created from the filled template and opened", FILES[VAULT .. "/Standup.md"] == "## Standup\n- " and v.doc.rel == "Standup.md")
check("the page gets the caret as CARETHEAD once", WEBVIEWS[#WEBVIEWS].htmlSet:find('CARETHEAD = "## Standup\\n"', 1, true) ~= nil)
v.render()
check("…and the next render has CARETHEAD = null", WEBVIEWS[#WEBVIEWS].htmlSet:find("CARETHEAD = null", 1, true) ~= nil)
-- 6.190.0 — LL: "Can I get a window that is larger than this? I can't see
-- what I'm typing?" hs.dialog.textPrompt is a stock macOS alert whose
-- width is AppKit's, so ⌘N now asks IN THE PAGE, where the field is the
-- window's width. The system dialog stays as the degrade, never the
-- default.
local promptsBefore = #PROMPTS
msg({ a = "tplnew", name = "" })
check("🚨 ⌘N asks IN THE PAGE, not in a macOS alert",
      (EVALS[#EVALS] or ""):find('askName("new"', 1, true) ~= nil, EVALS[#EVALS])
check("...and no system dialog is raised at all", #PROMPTS == promptsBefore,
      PROMPTS[#PROMPTS] and PROMPTS[#PROMPTS].title)
-- the answer comes back as a message, and ONE code path makes the note
-- 🚨 6.203.0 — as the PAGE really sends it: say() stamps the open note
-- onto `text` on every message, so the typed name rides under `name`.
-- These four used to pass the name as `text`, which is the stub being
-- gentler than the page — and it is why ⌘N could be wrong for thirteen
-- releases with a green suite over it.
msg({ a = "named", kind = "new", name = "Typed In The Window",
      text = (v.doc and v.doc.text) or "", rel = v.doc and v.doc.rel })
check("...and the typed name creates the note",
      FILES[VAULT .. "/Typed In The Window.md"] ~= nil
      and v.doc.rel == "Typed In The Window.md", v.doc.rel)
-- an empty answer must not create a file called ".md"
local filesBefore = 0
for _ in pairs(FILES) do filesBefore = filesBefore + 1 end
msg({ a = "named", kind = "new", name = "   ", text = (v.doc and v.doc.text) or "" })
local filesAfter = 0
for _ in pairs(FILES) do filesAfter = filesAfter + 1 end
check("🚨 an empty name writes NOTHING (createNamed refuses, and openNote\n"
   .. "        refuses again behind it)", filesAfter == filesBefore
   and v.createNamed("   ") == false)
-- and the page failing to draw the bar falls back rather than dying
PROMPT_ANSWERS = { { "Create", "From The Fallback" } }
msg({ a = "namefail", kind = "new" })
check("a page that cannot draw the bar falls back to the dialog",
      PROMPTS[#PROMPTS].title == "New note"
      and FILES[VAULT .. "/From The Fallback.md"] ~= nil)
-- and with NO page at all, ⌘N is still the dialog and still works
do
  local keptView = v.webview
  v.webview = nil
  PROMPT_ANSWERS = { { "Create", "No Web View Here" } }
  v.newNote()
  check("🚨 with no web view ⌘N still works — the dialog is the DEGRADE",
        PROMPTS[#PROMPTS].title == "New note"
        and FILES[VAULT .. "/No Web View Here.md"] ~= nil)
  v.webview = keptView
end

-- =======================================================================
-- 6.203.0 — 🚨 A NAME THAT CANNOT BECOME A FILE IS REFUSED, AND SAID
-- =======================================================================
-- LL pasted a whole block into this bar. safeName took it — it maps "/"
-- ":" "\" and strips a trailing .md, and has never had a LENGTH —
-- openNote returned TRUE, and saveNow then failed on a path macOS cannot
-- hold. Nothing was written, and the only message was an hs.alert drawn
-- UNDER this window: "I enter a title and … I don't see that anything
-- was created."
do
    local function nameOf(x) local n = v.nameCheck(x) return n end
    local function whyOf(x)  local _, w = v.nameCheck(x) return w end

    check("an ordinary name is handed back untouched, with nothing to say",
          nameOf("Quarterly plan") == "Quarterly plan" and whyOf("Quarterly plan") == nil)

    -- THE BUG, the size LL actually pasted
    local huge = "Collect" .. string.rep("x", 3000)
    local before = 0 ; for _ in pairs(FILES) do before = before + 1 end
    local okH, whyH = v.createNamed(huge)
    local after = 0 ; for _ in pairs(FILES) do after = after + 1 end
    check("🚨 6.203.0 — a 3,007-character paste is REFUSED, never truncated:\n"
       .. "        nothing is written, and the reason carries both numbers",
          okH == false and after == before and type(whyH) == "string"
          and whyH:find("3007", 1, true) and whyH:find("248", 1, true), whyH)
    msg({ a = "named", kind = "new", name = huge, text = (v.doc and v.doc.text) or "" })
    check("🚨 …and the refusal is said IN THE BAR, under the field he typed in —\n"
       .. "        never in an hs.alert, which draws UNDER this window",
          (EVALS[#EVALS] or ""):find("prSay(", 1, true) ~= nil
          and (EVALS[#EVALS] or ""):find("248", 1, true) ~= nil, EVALS[#EVALS])

    -- BYTES, not characters — the filesystem counts bytes and so must we
    local emoji = string.rep("😀", 100)             -- 100 characters, 400 bytes
    check("🚨 the budget is BYTES: 100 emoji is 100 characters and 400 bytes, and\n"
       .. "        400 does not fit 248 (a clamp counting CHARACTERS waves this\n"
       .. "        straight through to the write that fails)",
          #emoji == 400 and nameOf(emoji) == "")
    check("…and the reason says both, because \"100 characters\" does not read as\n"
       .. "        too long for 248",
          (whyOf(emoji) or ""):find("100 characters (400 bytes)", 1, true) ~= nil, whyOf(emoji))

    -- the boundary, from both sides, and where the number comes from
    check("248 bytes is taken and 249 is not — the budget is 255 minus the longest\n"
       .. "        thing saveNow ever writes beside the note, \".md.tmp\"",
          nameOf(string.rep("a", 248)) == string.rep("a", 248)
          and nameOf(string.rep("a", 249)) == ""
          and v.nameMaxBytes == 255 - #".md.tmp")

    -- newlines: macOS would TAKE that file name, which is the trap
    local n2, w2 = v.nameCheck("Two\nLine\tName")
    check("🚨 newlines and tabs become spaces — macOS accepts a file name with a\n"
       .. "        newline in it, and that note could never be typed or linked again",
          n2 == "Two Line Name" and type(w2) == "string"
          and w2:find("line breaks", 1, true) ~= nil, n2)
    check("…and such a name still CREATES, on one line: a clean-up is not a refusal",
          v.createNamed("Made\nOn\nOne Line") == true
          and FILES[VAULT .. "/Made On One Line.md"] ~= nil)

    -- the rules that were already rules are still the rules
    check("\"/\" and \":\" still become \"-\" (6.174.0, unchanged)", nameOf("a/b:c") == "a-b-c")
    check("a name of nothing but dots has nothing usable in it — and that reads\n"
       .. "        DIFFERENTLY from an empty box, because he did type something",
          nameOf("...") == ""
          and (whyOf("...") or ""):find("nothing usable", 1, true) ~= nil, whyOf("..."))
    check("…and a box holding only newlines and tabs is an EMPTY box, not a bad one",
          nameOf("\n\t\r\n") == "" and whyOf("\n\t\r\n") == "a note needs a name")
    check("…while \"///\" is a NAME, not a refusal: separators map to \"-\" and\n"
       .. "        \"---\" is a file macOS will happily hold (6.174.0, unchanged)",
          nameOf("///") == "---")
    check("a blank name asks for one rather than blaming him",
          nameOf("") == "" and whyOf("") == "a note needs a name")
    check("a leading dot is stripped — a hidden note is one find never indexes",
          nameOf(".hidden") == "hidden")

    -- 🔑 THE GUARD IS AT THE DOOR, so every other creation path has it too
    local okO, whyO = v.openNote(string.rep("z", 400))
    check("🚨 openNote ITSELF refuses it — ⌘D, ⌘⇧N, ⌘⇧E, a [[link]] follow and a\n"
       .. "        search row all arrive there, and a check in createNamed alone is\n"
       .. "        one the other five quietly stop matching",
          okO == false and type(whyO) == "string" and whyO:find("248", 1, true) ~= nil, whyO)

    -- the degrade says it too, in the one channel that IS visible there
    do
        local keptView2 = v.webview
        v.webview = nil
        PROMPT_ANSWERS = { { "Create", string.rep("q", 500) } }
        local okN = v.newNote()
        check("🚨 the system-dialog degrade refuses the same name and ALERTS the same\n"
           .. "        reason — with no window of ours up, an alert is what he can see",
              okN == false and (ALERTS[#ALERTS] or ""):find("248", 1, true) ~= nil, ALERTS[#ALERTS])
        v.webview = keptView2
    end

    -- a name it TAKES must not summon the bar's voice
    local evalsWere = #EVALS
    msg({ a = "named", kind = "new", name = "A Perfectly Good Name",
          text = (v.doc and v.doc.text) or "" })
    local spoke = false
    for i = evalsWere + 1, #EVALS do
        if EVALS[i]:find("prSay(", 1, true) then spoke = true end
    end
    check("a name it takes says NOTHING in the bar — the re-render takes the bar\n"
       .. "        with it", spoke == false
          and FILES[VAULT .. "/A Perfectly Good Name.md"] ~= nil)
end
msg({ a = "tplnone" })
check("no templates yet → an alert naming the folder", ALERTS[#ALERTS]:find("No templates yet", 1, true) and ALERTS[#ALERTS]:find("/Templates", 1, true))
PROMPT_ANSWERS = { { "Create", "Alpha" } }
catsBefore = countTasks("cat")
msg({ a = "tplnew", name = "Meeting" })
check("an existing name is refused: alert, the note opens untouched, no fetch",
      ALERTS[#ALERTS]:find("already exists", 1, true) and v.doc.rel == "Alpha.md" and countTasks("cat") == catsBefore)
-- ⌘D and ‹ › with Templates/Daily.md
do
    -- the index keys notes by NAME (one Daily per vault): the root Daily.md must go first
    local rels = {}
    for _, nn in ipairs(v.notes) do if nn.rel ~= "Daily.md" then rels[#rels + 1] = nn.rel end end
    rels[#rels + 1] = "Templates/Daily.md"
    v.setNotes(rels)
    check("the report names the daily template once it is indexed", _G.vaultReport():find("templates: 2 in Templates/ · daily template: Templates/Daily.md", 1, true) ~= nil, _G.vaultReport():match("templates:[^\n]*"))
    catsBefore = countTasks("cat")
    msg({ a = "daily" })
    check("⌘D on an EXISTING daily note opens it as is — never re-templated", v.doc.rel == "Daily/" .. today .. ".md" and countTasks("cat") == catsBefore)
    local tomorrow = os.date("%Y-%m-%d", os.time() + 86400)
    msg({ a = "dayshift", d = 1, rel = v.doc.rel, text = v.doc.text, sel = 0 })
    check("› onto a day with no note fetches Templates/Daily.md", countTasks("cat") == catsBefore + 1 and lastTask("cat").args[1] == VAULT .. "/Templates/Daily.md")
    lastTask("cat").cb(0, "# {{title}}\n{{date:dddd}}\n", "")
    check("the new daily note is the filled template: {{title}} = the date, {{date:}} for THAT day",
          FILES[VAULT .. "/Daily/" .. tomorrow .. ".md"] == "# " .. tomorrow .. "\n" .. os.date("%A", os.time() + 86400) .. "\n" and v.doc.rel == "Daily/" .. tomorrow .. ".md",
          FILES[VAULT .. "/Daily/" .. tomorrow .. ".md"])
    rels[#rels] = nil
    v.setNotes(rels)
    check("without a daily template the report says none", _G.vaultReport():find("daily template: none", 1, true) ~= nil)
    local keep = v.templatesDir; v.templatesDir = "Nowhere"
    check("no templates at all → the report says where to put them", _G.vaultReport():find("templates: none — put .md files in Nowhere/", 1, true) ~= nil, _G.vaultReport():match("templates:[^\n]*"))
    v.templatesDir = keep
end

-- =======================================================================
out("11) 6.174.0 — search inside every note: debounce, one held grep, terms in Lua\n")
-- =======================================================================
do
    local Tq = v.searchTerms('quarterly "big plan" tag:#Work path:Daily')
    check("searchTerms: terms, a quoted phrase, tag: (# off, lowercased), path:", same(Tq.terms, { "quarterly", "big plan" }) and Tq.tag == "work" and Tq.path == "daily")
    check("searchTerms: file: is path:, an unclosed quote runs to the end", v.searchTerms("file:X").path == "x" and v.searchTerms('"a b').terms[1] == "a b")
end
v.openNote("Alpha")
local grepsBefore = countTasks("grep")
msg({ a = "mode", m = "search" })
check("entering search mode starts no grep", v.mode == "search" and countTasks("grep") == grepsBefore)
msg({ a = "search", q = "plan" })
check("a keystroke arms a held 0.3 s timer, no grep yet", countTasks("grep") == grepsBefore and v.searchTimer and v.searchTimer.kind == "after" and v.searchTimer.delay == 0.3)
local st1 = v.searchTimer
msg({ a = "search", q = "plan " })
check("the next keystroke stops the first timer and arms a new one", st1.stopped and v.searchTimer ~= st1)
v.searchTimer:fire()
local sg = lastTask("grep")
check("the grep: -rniIHF, -m 20, -e plan, the vault, not the [[ pattern; HELD; searching",
      countTasks("grep") == grepsBefore + 1 and taskArgs(sg):find("-rniIHF", 1, true) and taskArgs(sg):find("-m 20", 1, true)
      and taskArgs(sg):find("-e plan " .. VAULT, 1, true) and not taskArgs(sg):find("\\[\\[", 1, true) and v.searchTask == sg and v.searching == true, taskArgs(sg))
sg.cb(0, VAULT .. "/Alpha.md:3:the big plan\n" .. VAULT .. "/Gamma.md:9:no plan here\n/elsewhere/x.md:1:plan\n", "")
check("two rows (the stray path skipped), note · line · text", #v.searchRows == 2 and v.searchRows[1].n == "Alpha" and v.searchRows[1].r == "Alpha.md"
      and v.searchRows[1].l == 3 and v.searchRows[1].x == "the big plan")
check("the rows reach the page by eval, no rebuild, with the query they answer",
      EVALS[#EVALS]:find('^setRows%("search", %[{n:"Alpha",r:"Alpha.md",l:3,x:"the big plan"}') and EVALS[#EVALS]:find(', false, "plan "%)$'), EVALS[#EVALS])
check("lastSearch and the counters", v.lastSearch.hits == 2 and v.lastSearch.files == 2 and v.searches == 1 and v.searching == false and v.searchTask == nil)
v.searchQuery = 'plan "big"'; v.runSearch()
check("AND: the longest term goes to grep", taskArgs(lastTask("grep")):find("-e plan ", 1, true) ~= nil)
lastTask("grep").cb(0, VAULT .. "/Alpha.md:3:the big plan\n" .. VAULT .. "/Gamma.md:9:no plan here\n", "")
check("…the other terms are checked in Lua: Alpha only", #v.searchRows == 1 and v.searchRows[1].r == "Alpha.md")
v.searchQuery = "plan tag:fresh"; v.runSearch()
lastTask("grep").cb(0, VAULT .. "/Alpha.md:3:the big plan\n" .. VAULT .. "/Gamma.md:9:no plan here\n", "")
check("tag:fresh keeps only notes tagged fresh", #v.searchRows == 1 and v.searchRows[1].r == "Alpha.md")
v.searchQuery = "plan path:gam"; v.runSearch()
lastTask("grep").cb(0, VAULT .. "/Alpha.md:3:the big plan\n" .. VAULT .. "/Gamma.md:9:no plan here\n", "")
check("path:gam keeps only rels containing it", #v.searchRows == 1 and v.searchRows[1].r == "Gamma.md")
grepsBefore = countTasks("grep")
v.searchQuery = "tag:fresh"; v.runSearch()
check("operators only: no grep, the note NAMES that pass, line 0", countTasks("grep") == grepsBefore and #v.searchRows == 1 and v.searchRows[1].n == "Alpha" and v.searchRows[1].l == 0)
v.searchQuery = "plan"; v.runSearch()
local s1 = lastTask("grep")
v.runSearch()
check("a second search terminates the first grep", s1.terminated and v.searchTask ~= s1)
s1.cb(0, VAULT .. "/Alpha.md:3:late\n", "")
check("…and its late answer changes nothing", v.searching == true and #v.searchRows == 1)
v.setMode("notes")
check("leaving search mode clears the rows and the task", v.searchRows[1] == nil and v.searchTask == nil and v.mode == "notes")
msg({ a = "mode", m = "search" })
msg({ a = "search", q = "  " })
check("an empty box: no timer, an empty list on the page", v.searchTimer == nil and EVALS[#EVALS] == 'setRows("search", [], false, "")', EVALS[#EVALS])
do
    local lines = {}
    for i = 1, 205 do lines[#lines + 1] = VAULT .. "/Alpha.md:" .. i .. ":plan " .. i end
    v.searchQuery = "plan"; v.runSearch()
    lastTask("grep").cb(0, table.concat(lines, "\n") .. "\n", "")
    check("205 hits → 200 rows and a 'more' flag on the page", #v.searchRows == 200 and v.searchMore == true and EVALS[#EVALS]:find(', true, "plan"%)$'))
    local long = "plan " .. string.rep("a", 114) .. "🙂" .. string.rep("b", 180)
    v.runSearch()
    lastTask("grep").cb(0, VAULT .. "/Alpha.md:1:" .. long .. "\n", "")
    local x = v.searchRows[1].x
    check("a snippet is cut to ≤120 bytes without splitting a UTF-8 character", #x <= 122 and utf8.len(x) ~= nil and x:sub(-3) == "…", #x)
    v.searchQuery = "zzz"; v.runSearch()
    lastTask("grep").cb(0, VAULT .. "/Alpha.md:1:" .. string.rep("x", 100) .. " zzz tail\n", "")
    check("…and starts ≤30 chars before the term, with … where it was cut", v.searchRows[1].x:find("^…") and v.searchRows[1].x:find("zzz", 1, true) ~= nil, v.searchRows[1].x)
    v.searchQuery = "plan"; v.runSearch()
    lastTask("grep").cb(2, "", "grep: boom")
    check("grep exit 2 → searchErr, no rows, the report shows ⚠️", v.searchErr and v.searchErr:find("grep exited 2", 1, true) and #v.searchRows == 0
          and _G.vaultReport():find("search : \"plan\" → 0 hits in 0 notes", 1, true) and _G.vaultReport():find("⚠️ grep exited 2", 1, true), _G.vaultReport():match("search :[^\n]*"))
    v.runSearch()
    lastTask("grep").cb(1, "", "")
    check("grep exit 1 is a clean 'no hit'", v.searchErr == nil and #v.searchRows == 0)
end
msg({ a = "open", name = "Gamma", line = 9 })
check("⏎ on a hit opens the note with CARETLINE = 9 on the page, still in search mode",
      v.doc.rel == "Gamma.md" and WEBVIEWS[#WEBVIEWS].htmlSet:find("CARETLINE = 9", 1, true) and v.mode == "search"
      and WEBVIEWS[#WEBVIEWS].htmlSet:find('MODE = "search"', 1, true) and _G.vaultReport():find("· mode: search", 1, true))
v.render()
check("…and the next render has CARETLINE = 0", WEBVIEWS[#WEBVIEWS].htmlSet:find("CARETLINE = 0", 1, true) ~= nil)
msg({ a = "search", q = "x" })
v.hide()
check("closing the window leaves search mode and drops its task and timer", v.mode == "notes" and v.searchTask == nil and v.searchTimer == nil and v.searchQuery == "")
v.show()
check("the vault.search service runs a search from the Console", (function()
    local ok = PROVIDED["vault.search"]("plan")
    return ok == true and v.mode == "search" and lastTask("grep") and taskArgs(lastTask("grep")):find("-e plan", 1, true)
end)())
v.setMode("notes")

-- =======================================================================
out("12) 6.174.0 — tasks: every open - [ ] in one grep, the open note refreshed from its text\n")
-- =======================================================================
do
    local ts = v.tasksIn("- [ ] a\n  * [ ] b\n+ [ ] c\n3. [ ] d\n- [x] done\n-[ ] no\n")
    check("tasksIn: -, *, + and 1. markers with [ ]; [x] and a missing space are not open",
          #ts == 4 and ts[1].line == 1 and ts[2].line == 2 and ts[3].line == 3 and ts[4].line == 4
          and ts[1].text == "a" and ts[2].text == "b" and ts[3].text == "c" and ts[4].text == "d")
end
msg({ a = "mode", m = "tasks" })
local tk = lastTask("grep")
check("entering ☑ starts the task grep: -rnHIE with the ERE, HELD, listing",
      v.mode == "tasks" and taskArgs(tk):find("-rnHIE", 1, true) and taskArgs(tk):find("^[[:space:]]*([-*+]|[0-9]+\\.) \\[ \\]", 1, true)
      and v.tasksTask == tk and v.tasksListing == true, taskArgs(tk))
local TASKOUT = VAULT .. "/Groceries.md:4:- [ ] buy milk\n" .. VAULT .. "/Alpha.md:2:  * [ ] call\n" .. VAULT .. "/Templates/Meeting.md:3:- [ ] agenda\n" .. VAULT .. "/Alpha.md:5:1. [ ] later\n"
tk.cb(0, TASKOUT, "")
check("3 rows (the template skipped), sorted by note then line, the marker stripped",
      #v.taskRows == 3 and v.taskRows[1].r == "Alpha.md" and v.taskRows[1].l == 2 and v.taskRows[2].l == 5 and v.taskRows[3].r == "Groceries.md" and v.taskRows[3].x == "buy milk")
check("the rows reach the page and the listing is stamped", EVALS[#EVALS]:find('^setRows%("tasks", %[{n:"Alpha"') and v.lastTasks ~= nil and v.tasksListing == false and v.tasksTask == nil, EVALS[#EVALS])
msg({ a = "tasks" })
local tk2 = lastTask("grep")
check("↻ inside the view runs a new grep and terminates the old one", tk2 ~= tk and v.tasksTask == tk2)
local nRows = #v.taskRows
tk.cb(0, VAULT .. "/Stale.md:1:- [ ] stale\n", "")
check("a stale answer changes nothing", #v.taskRows == nRows and v.taskRows[1].r ~= "Stale.md")
tk2.cb(0, TASKOUT, "")
v.openNote("Alpha")
msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n- [ ] one\n- [x] done\n- [ ] two\n", sel = 3 })
local evalsBefore = #EVALS
lastTimer("after"):fire()
check("a save while ☑ is up refreshes the OPEN note's rows from its text — no grep",
      #v.taskRows == 3 and v.taskRows[1].r == "Alpha.md" and v.taskRows[1].l == 2 and v.taskRows[1].x == "one" and v.taskRows[2].l == 4
      and v.taskRows[3].r == "Groceries.md" and #EVALS == evalsBefore + 1 and EVALS[#EVALS]:find('^setRows%("tasks"') and countTasks("grep") == countTasks("grep"))
v.setMode("notes")
msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n- [ ] one\n", sel = 3 })
evalsBefore = #EVALS
lastTimer("after"):fire()
check("…in notes mode the same save evaluates nothing", #EVALS == evalsBefore)
msg({ a = "mode", m = "tasks" })
lastTask("grep").cb(0, TASKOUT, "")
grepsBefore = countTasks("grep")
msg({ a = "rescan" })
check("↻ (rescan) in tasks mode starts a task grep", countTasks("grep") == grepsBefore + 1 and taskArgs(lastTask("grep")):find("-rnHIE", 1, true) ~= nil)
lastTask("grep").cb(1, "", "")
check("exit 1: no tasks, no error", #v.taskRows == 0 and v.tasksErr == nil)
lastTask("grep").cb(2, "", "grep: boom")
msg({ a = "tasks" })
lastTask("grep").cb(2, "", "grep: boom")
check("exit 2: tasksErr, shown in the report", v.tasksErr and _G.vaultReport():find("tasks  : 0 open in 0 notes · listed", 1, true) and _G.vaultReport():find("⚠️ grep exited 2", 1, true))
msg({ a = "tasks" })
lastTask("grep").cb(0, TASKOUT, "")
check("the report counts open tasks and notes", _G.vaultReport():find("tasks  : 3 open in 2 notes · listed", 1, true) ~= nil, _G.vaultReport():match("tasks  :[^\n]*"))
check("the vault.tasks service lists from the Console", PROVIDED["vault.tasks"]() == true and v.mode == "tasks")
v.setMode("notes")

-- =======================================================================
out("13) 6.174.0 — unlinked mentions: whole-word grep -l, minus self, backlinkers and templates\n")
-- =======================================================================
v.openNote("Alpha")
local mg = lastTask("grep")
check("opening Alpha starts a mentions grep (-rliwIF -e Alpha), HELD, pending for key alpha",
      taskArgs(mg):find("-rliwIF", 1, true) and taskArgs(mg):find("-e Alpha " .. VAULT, 1, true) and v.mentionTask == mg
      and v.unlinked.pending == true and v.unlinked.key == "alpha", taskArgs(mg))
mg.cb(0, VAULT .. "/Alpha.md\n" .. VAULT .. "/Projects/Beta.md\n" .. VAULT .. "/Gamma.md\n" .. VAULT .. "/Templates/Meeting.md\n", "")
check("Gamma is the one unlinked mention (Alpha itself, Beta the backlinker and the template drop out)",
      same(v.unlinked.rels, { "Gamma.md" }) and v.unlinked.pending == false and v.mentionTask == nil)
check("…and the page gets it by eval, keyed to the note", EVALS[#EVALS] == 'setMentions([{n:"Gamma",r:"Gamma.md"}], "alpha", "")', EVALS[#EVALS])
v.render()
check("a rebuild pre-fills the pane from Lua", WEBVIEWS[#WEBVIEWS].htmlSet:find('UNLINKED MENTIONS · 1</h4><ul id="unl"><li class="lnk" data-name="Gamma" title="Gamma.md">≈ Gamma</li>', 1, true) ~= nil)
check("the report has the mentions line", _G.vaultReport():find("mentions: 1 unlinked for Alpha.md · extracts: 0 · random: 0", 1, true) ~= nil, _G.vaultReport():match("mentions:[^\n]*"))
v.openNote("Alpha")
mg = lastTask("grep")
v.openNote("Gamma")
check("opening another note terminates the probe", mg.terminated and v.unlinked.key == "gamma" and v.unlinked.pending == true)
local n13 = #EVALS
mg.cb(0, VAULT .. "/Delta.md\n", "")
check("…and its answer is discarded", v.unlinked.key == "gamma" and v.unlinked.rels[1] == nil and #EVALS == n13)
check("the report says it is looking", _G.vaultReport():find("mentions: looking for Gamma.md", 1, true) ~= nil)
grepsBefore = countTasks("grep")
v.openNote("Brand New")
check("a note created this instant starts no probe", countTasks("grep") == grepsBefore and v.unlinked.key ~= "brand new")
check("…and the report says so", _G.vaultReport():find("mentions: not searched for Brand New.md (new note)", 1, true) ~= nil, _G.vaultReport():match("mentions:[^\n]*"))
do
    FILES[VAULT .. "/Bo.md"] = "# Bo\n"
    local rels = {}
    for _, nn in ipairs(v.notes) do rels[#rels + 1] = nn.rel end
    rels[#rels + 1] = "Bo.md"
    v.setNotes(rels)
    grepsBefore = countTasks("grep")
    v.openNote("Bo")
    check("a two-letter name is not searched for", countTasks("grep") == grepsBefore and v.unlinked.why == "too short" and v.unlinked.pending == false)
    check("…said in the report", _G.vaultReport():find("mentions: not searched for Bo.md (name too short)", 1, true) ~= nil)
end
v.openNote("Alpha")
do
    local lines = {}
    for i = 1, 51 do lines[#lines + 1] = VAULT .. "/M" .. string.format("%02d", i) .. ".md" end
    lastTask("grep").cb(0, table.concat(lines, "\n") .. "\n", "")
    check("51 files → the first 50, marked 'more'", #v.unlinked.rels == 50 and v.unlinked.more == true and EVALS[#EVALS]:find(', "alpha", "more"%)$'))
end
v.openNote("Alpha")
lastTask("grep").cb(2, "", "grep: boom")
check("a grep error is kept, not alerted", v.unlinked.why and v.unlinked.why:find("grep exited 2", 1, true) and EVALS[#EVALS]:find('"grep exited 2: grep: boom"%)$'))
v.openNote("Alpha")
lastTask("grep").cb(1, "", "")
check("no mention: an empty answer", v.unlinked.rels[1] == nil and v.unlinked.why == nil and _G.vaultReport():find("mentions: none for Alpha.md", 1, true))

-- =======================================================================
out("14) 6.174.0 — extract the selection into a new note\n")
-- =======================================================================
msg({ a = "edit", rel = "Alpha.md", text = "# Alpha\n\nkeep this\nmove me\n", sel = 3 })
lastTimer("after"):fire()
PROMPT_ANSWERS = { { "Create", "" } }
msg({ a = "extract", head = "# Alpha\n\nkeep this\n", selText = "move me" })
check("the prompt offers the first line as the name", PROMPTS[#PROMPTS].title == "Extract to a new note" and PROMPTS[#PROMPTS].dflt == "move me", PROMPTS[#PROMPTS].dflt)
check("the source keeps [[move me]] where the selection was, saved at once", FILES[VAULT .. "/Alpha.md"] == "# Alpha\n\nkeep this\n[[move me]]\n", FILES[VAULT .. "/Alpha.md"])
check("the new note is # name + the selection, and it opens", FILES[VAULT .. "/move me.md"] == "# move me\n\nmove me\n" and v.doc.rel == "move me.md" and v.extracts == 1)
msg({ a = "extract", head = "", selText = "  " })
check("no selection → an alert", ALERTS[#ALERTS]:find("select some text first", 1, true) ~= nil)
local snap = FILES[VAULT .. "/move me.md"]
msg({ a = "extract", head = "wrong", selText = "move me" })
check("a page whose text disagrees with Lua's copy is refused, nothing written", ALERTS[#ALERTS]:find("the text changed", 1, true) and FILES[VAULT .. "/move me.md"] == snap)
PROMPT_ANSWERS = { { "Create", "Gamma" } }
msg({ a = "extract", head = "# move me\n\n", selText = "move me" })
check("an existing name is refused, nothing written", ALERTS[#ALERTS]:find('a note named "Gamma" already exists', 1, true) and FILES[VAULT .. "/move me.md"] == snap and v.doc.rel == "move me.md")
PROMPT_ANSWERS = { { "Cancel", "" } }
msg({ a = "extract", head = "# move me\n\n", selText = "move me" })
check("Cancel writes nothing", FILES[VAULT .. "/move me.md"] == snap and v.extracts == 1)
do
    local keep = v.doc
    v.doc = { scratch = "x", rel = "scratch:x", name = "x", text = "hello" }
    msg({ a = "extract", head = "", selText = "hello" })
    check("a scratch tab cannot extract", ALERTS[#ALERTS]:find("not a scratch tab", 1, true) ~= nil)
    v.doc = keep
end
msg({ a = "edit", rel = "move me.md", text = "# move me\n\n- [ ] Buy list\nmilk\n", sel = 3 })
PROMPT_ANSWERS = { { "Cancel", "" } }
msg({ a = "extract", head = "# move me\n\n", selText = "- [ ] Buy list\nmilk" })
check("the default name strips the list marker and box", PROMPTS[#PROMPTS].dflt == "Buy list", PROMPTS[#PROMPTS].dflt)
-- 6.203.0 — the same impossible name, at the door that writes FIRST
do
    msg({ a = "edit", rel = "move me.md", text = "# move me\n\nkeep this\n", sel = 3 })
    v.saveNow()
    local kept = FILES[VAULT .. "/move me.md"]
    PROMPT_ANSWERS = { { "Create", string.rep("L", 600) } }
    local okE = msg({ a = "extract", head = "# move me\n\n", selText = "keep this" })
    check("🚨 6.203.0 — ⌘⇧E refuses an impossible name BEFORE the [[link]] goes in:\n"
       .. "        the note LL was working in is byte-for-byte what it was, and the\n"
       .. "        reason is alerted (this door saves the open note, THEN creates)",
          FILES[VAULT .. "/move me.md"] == kept
          and (ALERTS[#ALERTS] or ""):find("248", 1, true) ~= nil, ALERTS[#ALERTS])
end

-- =======================================================================
out("15) 6.174.0 — daily ‹ ›: the day before / after, no template\n")
-- =======================================================================
check("dailyEpochOf reads Daily/YYYY-MM-DD.md and nothing else",
      os.date("%Y-%m-%d", v.dailyEpochOf("Daily/2026-09-06.md")) == "2026-09-06" and v.dailyEpochOf("Alpha.md") == nil and v.dayOf("daily/2026-09-06.md") == "2026-09-06")
msg({ a = "daily" })
local yesterday = os.date("%Y-%m-%d", os.time() - 86400)
msg({ a = "dayshift", d = -1, rel = v.doc.rel, text = v.doc.text, sel = 0 })
check("‹ opens the day before, created with the weekday heading",
      v.doc.rel == "Daily/" .. yesterday .. ".md" and FILES[VAULT .. "/Daily/" .. yesterday .. ".md"] == "# " .. os.date("%A %d %B %Y", os.time() - 86400) .. "\n\n", v.doc.rel)
local todayText = FILES[VAULT .. "/Daily/" .. today .. ".md"]
msg({ a = "dayshift", d = 1, rel = v.doc.rel, text = v.doc.text, sel = 0 })
check("› from there opens today's note unchanged", v.doc.rel == "Daily/" .. today .. ".md" and FILES[VAULT .. "/Daily/" .. today .. ".md"] == todayText)
local hd = WEBVIEWS[#WEBVIEWS].htmlSet
check("a daily note's page knows the days either side", hd:find('DAILY = {prev:"' .. yesterday .. '",next:"' .. os.date("%Y-%m-%d", os.time() + 86400) .. '"}', 1, true) ~= nil, hd:match("var DAILY[^\n]*"))
check("…and its header wears ‹ yesterday · tomorrow › (dayshift buttons)",
      hd:find('title="Previous day ⌘⇧[">‹ ' .. yesterday .. '</button>', 1, true) ~= nil
      and hd:find('title="Next day ⌘⇧]">' .. os.date("%Y-%m-%d", os.time() + 86400) .. ' ›</button>', 1, true) ~= nil)
v.openNote("Alpha"); v.render()
msg({ a = "dayshift", d = -1 })
check("‹ › with a plain note open only alerts", v.doc.rel == "Alpha.md" and ALERTS[#ALERTS]:find("open a daily note first", 1, true) ~= nil)
check("…and its page has DAILY = null", WEBVIEWS[#WEBVIEWS].htmlSet:find("DAILY = null", 1, true) ~= nil)

-- =======================================================================
out("16) 6.174.0 — a random note, never a template, never this one\n")
-- =======================================================================
math.randomseed(1)
do
    local okAll, prev = true, v.doc.rel
    for _ = 1, 10 do
        msg({ a = "random" })
        if v.doc.rel == prev or v.isTemplateRel(v.doc.rel) then okAll = false end
        prev = v.doc.rel
    end
    check("ten ⌘⇧R never reopen the same note nor a template", okAll and v.randoms == 10, v.doc.rel)
    local rels = {}
    for _, nn in ipairs(v.notes) do rels[#rels + 1] = nn.rel end
    v.setNotes({ "Alpha.md", "Templates/Meeting.md" })
    v.openNote("Alpha")
    msg({ a = "random" })
    check("only templates and the open note left → an alert", ALERTS[#ALERTS]:find("nothing else to open", 1, true) and v.doc.rel == "Alpha.md" and v.randoms == 10)
    v.setNotes(rels)
    check("the report counts extracts and randoms", _G.vaultReport():find("· extracts: 1 · random: 10", 1, true) ~= nil)
end

-- =======================================================================
out("17) 6.174.0 — the doors: no new hyper key, the source sentries, the page's contract\n")
-- =======================================================================
do
    local n17 = 0
    for k in pairs(HYPER) do n17 = n17 + 1 end
    check("still ONE hyper key (⇪3) — ⇪⇧T / ⇪⇧U / ⇪⇧Z untouched", n17 == 1 and HYPER["|3"] ~= nil)
    local rf = io.popen("cat '" .. HS .. "/modules/vault.lua'")
    local real = rf and rf:read("a") or ""
    if rf then rf:close() end
    local _, taskNews = real:gsub("pcall%(hs%.task%.new", "")
    check("exactly SIX task births: find, link grep, tag grep, front-matter "
          .. "grep, heading grep (6.328.0), startTask", taskNews == 6, taskNews)
    check("no hs.json, no eventtap, no hs.window, every timer held", not real:find("hs%.json") and not real:find("hs%.eventtap%.new")
          and not real:find("hs%.window%.") and not real:find("\n%s*hs%.timer%.do"))
    check("templates are read by /bin/cat in a task, never io.open", real:find('CAT             = "/bin/cat"', 1, true) and not real:find("io%.open%(rec"))
    check("vault.search and vault.tasks are published", PROVIDED["vault.search"] ~= nil and PROVIDED["vault.tasks"] ~= nil)
    local names = {}
    for _, e in ipairs(mod.cheatsheet.entries) do names[e[1]] = e[2] end
    check("the cheat sheet names the new keys", names["#tag"] and names["⌘⇧F"] and names["⌘⇧K · ⌘L"] and names["⌘⇧N · ⌘⇧T"] and names["⌘⇧E · ⌘⇧R"]
          and names["⌘F · ⌘O · ↑↓ ⏎"] and names["OUTLINE · ≈"] and names["⌘N · ⌘D"]:find("Templates/Daily.md", 1, true))
    check("the summary grew", mod.summary:find("tags, templates, full-text search, tasks", 1, true) ~= nil)
    v.render()
    local hp = WEBVIEWS[#WEBVIEWS].htmlSet
    check("the page has the Lua → page state and the mentions pane; one script block; insertAtCaret takes a tail",
          hp:find('var SEARCH = {q:"", rows:[], more:false, err:"", busy:false}', 1, true) and hp:find("var TASKS = {rows:[", 1, true)
          and hp:find('var UNL = {key:"alpha"', 1, true) and hp:find('id="unlh"', 1, true) and hp:find('id="unl"', 1, true)
          and hp:find("function insertAtCaret(str, tail)", 1, true) and select(2, hp:gsub("<script", "")) == 1 and not hp:find("FS%d?px") and not hp:find("FSNUM"))
    -- the page itself (6.174.0): the ids, the globals and the functions Lua and the JS suite rely on
    local function has(...) for _, needle in ipairs({ ... }) do if not hp:find(needle, 1, true) then return false, needle end end return true end
    check("the page has the mode strip, the 🔎 ☑ buttons, the footer, chips and outline", has('id="mode"', 'id="sbtn"', 'id="kbtn"', 'id="foot"', 'id="chips"', 'id="outline"', 'id="hint"'))
    check("…the page-side globals", has('MODE = "notes"', 'TEMPLATES = [', 'TPLDIR = "Templates"', 'SMARTLISTS = true', 'LINEH = 14 * 1.5', 'TAGROWS = 15', 'CURKEY = "alpha"', 'DAILY = '))
    check("…the Lua → page entry points and the page's own helpers", has("function setRows", "function setMentions", "function vaultHint", "function gotoLine", "function toggleTask", "function tplPick", "function setMode", "function tagsOf", "function drawOutline", "function drawFoot"))
    check("…the messages the new keys send", has("a:'tplnew'", "a:'tplinsert'", "a:'search'", "a:'dayshift'", "a:'extract'", "a:'random'", "a:'mode'", "a:'tplnone'"))
    -- 🚨 6.335.0 — ASSERT THE RULE, NOT THE LITERAL (6.248.0, sixth time).
    -- This matched the whole selector as one string, so adding the bin's
    -- rows to the walker failed a check written to prove there is ONE
    -- walker — red with nothing to say about the change it exists to
    -- guard. The rule is: exactly one ROWSEL, and every kind of row this
    -- page draws is in it.
    check("every row kind walks with the ONE row walker (ROWSEL)",
          (function()
              local n, sel = 0, nil
              for m in hp:gmatch("ROWSEL = '([^']*)'") do n = n + 1; sel = m end
              if n ~= 1 then return false, n .. " ROWSEL assignments" end
              for _, kind in ipairs({ "data-name", "data-tab", "data-tag", "data-un" }) do
                  if not sel:find("#rows li[" .. kind .. "]", 1, true) then
                      return false, kind .. " is not in the walker"
                  end
              end
              return true
          end)())
    check("the chips sit first in the right pane, the OUTLINE last, after the mentions",
          hp:find('<div id="links"><div id="chips" hidden></div><h4>LINKS OUT</h4>', 1, true) ~= nil and hp:find('<h4>OUTLINE</h4><ul id="outline"></ul></div>', 1, true) ~= nil
          and hp:find('<ul id="unl">', 1, true) < hp:find('<h4>OUTLINE</h4>', 1, true))
    -- 6.183.0 — 🔎 QUERY sits between the mentions and the outline, and it
    -- ships HIDDEN: a note with no query block must look exactly as it did.
    check("6.183.0: the 🔎 QUERY block sits after the mentions and before the outline, hidden until a note has one",
          hp:find('<div id="qbox" hidden><h4 id="qh">🔎 QUERY</h4><ul id="qres"></ul></div>', 1, true) ~= nil
          and hp:find('<ul id="unl">', 1, true) < hp:find('id="qbox"', 1, true)
          and hp:find('id="qbox"', 1, true) < hp:find('<h4>OUTLINE</h4>', 1, true))
    -- BOTH DIRECTIONS of the bridge, read off the code: every a:'x' the page can send has a
    -- handleMessage branch; every function Lua evals exists on the page
    local missing = {}
    for act in hp:gmatch("a:'([%w_]+)'") do
        if not real:find('a == "' .. act .. '"', 1, true) then missing[#missing + 1] = act end
    end
    check("every action the page sends has a Lua branch", #missing == 0, table.concat(missing, ","))
    local noFn = {}
    for fn in real:gmatch("v%.eval%([\"']([%a_]+)%(") do
        if not hp:find("function " .. fn .. "(", 1, true) then noFn[#noFn + 1] = fn end
    end
    check("every function Lua evals is defined on the page", #noFn == 0, table.concat(noFn, ","))
    -- a scratch tab's page: no note panes, the footer and the tag rows still there
    if v.sp() then
        v.openScratch(nil); v.render()
        local hs17 = WEBVIEWS[#WEBVIEWS].htmlSet
        local markup = hs17:match("^(.-)<script>") or ""
        check("a scratch tab's page has no chips, outline or mentions pane — the footer stays",
              not markup:find('id="chips"', 1, true) and not markup:find("OUTLINE", 1, true) and not markup:find("UNLINKED", 1, true) and markup:find('id="foot"', 1, true) ~= nil)
        v.openNote("Alpha"); v.render()
    end
end

-- =======================================================================
out("18) 6.174.0 review — the killed task, the note the index has not seen,\n")
out("    link-safe names, the stale filter and the page handshake\n")
-- =======================================================================
do
    v.openNote("Alpha"); v.render()
    -- (a) a terminated task's exit (15) is not an answer
    v.setMode("tasks")                       -- starts the ☑ grep
    local tt = v.tasksTask
    v.tasksErr, v.lastTasks = nil, nil
    v.hide()                                 -- terminates it: the stub fires cb(15, …)
    check("closing the window mid-☑-grep is not reported as a grep failure",
          v.tasksErr == nil and v.lastTasks == nil and tt ~= nil and tt.terminated == true, tostring(v.tasksErr))
    v.open(); v.openNote("Alpha")
    local mt = lastTaskWith("grep", "-rliwIF")
    v.hide()
    check("…nor is a terminated mentions grep", v.unlinked.why == nil and mt ~= nil and mt.terminated == true, tostring(v.unlinked.why))
    v.open(); v.openNote("Alpha"); v.render()
    local before = #ALERTS
    v.insertTemplate("Meeting")
    local ct, tm = lastTask("cat"), v.catTimer
    if tm then tm.fn() end                   -- the 10 s timeout fires and kills the read
    check("a template that never arrives says so ONCE, not twice",
          ct ~= nil and ct.terminated == true and #ALERTS == before + 1
          and ALERTS[#ALERTS]:find("did not arrive", 1, true) ~= nil, table.concat(ALERTS, " | ", before + 1))

    -- (b) a note the index has not seen yet is OPENED, never seeded over
    local rel = VAULT .. "/Daily/2026-09-05.md"
    FILES[rel] = "# Friday\n\nyesterday's words\n"
    v.notes, v.byKey = {}, {}                -- as after a reload, before the find lands
    v.openNote("2026-09-05", "Daily", "# seeded\n\n")
    check("a note the index does not know is read off disk, not overwritten",
          v.doc.text == "# Friday\n\nyesterday's words\n" and v.doc.created ~= true
          and FILES[rel] == "# Friday\n\nyesterday's words\n", v.doc.text)
    v.scan("restore"); lastTask("find").cb(0, table.concat({
        VAULT .. "/Alpha.md", VAULT .. "/Beta.md", VAULT .. "/Templates/Meeting.md" }, "\n"), "")
    local lg = lastTaskWith("grep", "%[%[") ; if lg then lg.cb(1, "", "") end
    finishTagGreps()

    -- (c)(d) a name that has to survive [[ ]]
    v.openNote("Alpha"); v.setText("keep ## Q3 plan #work\nmore\n")
    PROMPT_ANSWERS[1] = { "Create", "" }     -- take the offered default
    v.extract("keep ", "## Q3 plan #work\nmore\n")
    check("an extracted name keeps no character that [[links]] cannot address",
          PROMPTS[#PROMPTS].dflt == "Q3 plan work" and v.doc.name == "Q3 plan work"
          and FILES[VAULT .. "/Alpha.md"]:find("[[Q3 plan work]]", 1, true) ~= nil, PROMPTS[#PROMPTS].dflt)
    check("…and the link resolves to the note that was just created",
          v.linkTarget("Q3 plan work") == v.doc.name, v.linkTarget("Q3 plan work"))
    v.openNote("Alpha"); v.setText("Xcode tips\nrest\n")
    PROMPT_ANSWERS[1] = { "Cancel", "" }
    v.extract("", "Xcode tips\nrest\n")
    check("a selection starting with an X keeps it (the [ ] box comes off whole)",
          PROMPTS[#PROMPTS].dflt == "Xcode tips", PROMPTS[#PROMPTS].dflt)
    v.openNote("Alpha"); v.setText("- [x] done thing\n")
    PROMPT_ANSWERS[1] = { "Cancel", "" }
    v.extract("", "- [x] done thing\n")
    check("…and a ticked task line still loses its box", PROMPTS[#PROMPTS].dflt == "done thing", PROMPTS[#PROMPTS].dflt)

    -- (e) the notes filter never reaches the ☑ box
    v.openNote("Alpha"); v.filter = "alp"; v.setMode("tasks"); v.render()
    -- 🧪 the FILTER BOX IS ASKED FOR ITS VALUE, not for a literal run of
    -- attributes (6.263.0): this read `id="q" placeholder="…" value=""`
    -- as one string and failed the day spellcheck="false" went in between,
    -- on a check about an empty box.
    check("a rebuild in ☑ TASKS mode leaves the box empty, not on the notes filter",
          (function()
              local h = WEBVIEWS[#WEBVIEWS].htmlSet or ""
              local at = h:find('id="q"', 1, true)
              local shut = at and h:find(">", at, true)
              local tag = shut and h:sub(at, shut) or ""
              return tag:find('placeholder="filter notes', 1, true) ~= nil
                     and tag:find('value=""', 1, true) ~= nil
          end)())
    v.setMode("notes"); v.render()

    -- (f) a note that starts with a blank line reaches the page whole
    v.openNote("Alpha"); v.setText("\n# after a blank line\n"); v.render()
    check("a leading blank line survives the textarea (the spare newline HTML eats)",
          WEBVIEWS[#WEBVIEWS].htmlSet:find(">\n\n# after a blank line", 1, true) ~= nil)

    -- (g) the page says when it is ready, and gets what arrived meanwhile
    v.openNote("Alpha")
    v.unlinked = { key = v.doc.key, rels = { "Gamma.md" }, pending = false, why = nil, more = false }
    EVALS[#EVALS + 1] = "sentinel"
    msg({ a = "ready" })
    check("the page's ready handshake re-sends the mentions answer it missed",
          EVALS[#EVALS]:find('setMentions([{n:"Gamma",r:"Gamma.md"}], "alpha"', 1, true) ~= nil, EVALS[#EVALS])
    check("the page announces itself when its load sequence ends",
          WEBVIEWS[#WEBVIEWS].htmlSet:find("say({a:'ready'})", 1, true) ~= nil)
end

-- =====================================================================
-- 6.186.0 — 🗂 THE BOARD WRITES. withField is pure (text in, text out) so
-- every shape it must survive is provable without a disk; setField is the
-- only place the vault rewrites a note it is not editing, so it is held to
-- one field of one file, and to refusing anything it should not touch.
-- =====================================================================
out("\n6.186.0 — the board's write\n")
do
    local W = v.withField
    check("a note with no front matter gets a block, and keeps every byte it had",
          W("# Alpha\n\nbody\n", "status", "doing") == "---\nstatus: doing\n---\n\n# Alpha\n\nbody\n",
          W("# Alpha\n\nbody\n", "status", "doing"))
    check("an existing key is REPLACED in place — the other keys and the body do not move",
          W("---\nstatus: todo\nrating: 5\n---\n\n# A\n", "status", "done")
              == "---\nstatus: done\nrating: 5\n---\n\n# A\n",
          W("---\nstatus: todo\nrating: 5\n---\n\n# A\n", "status", "done"))
    check("a key the block has not got is ADDED before the closing ---",
          W("---\nrating: 5\n---\n\n# A\n", "status", "done") == "---\nrating: 5\nstatus: done\n---\n\n# A\n",
          W("---\nrating: 5\n---\n\n# A\n", "status", "done"))
    check("an empty value REMOVES the key — the 'no status' column really clears it",
          W("---\nstatus: todo\nrating: 5\n---\n\n# A\n", "status", "") == "---\nrating: 5\n---\n\n# A\n",
          W("---\nstatus: todo\nrating: 5\n---\n\n# A\n", "status", ""))
    check("…and when it was the only key the whole block goes, not an empty --- ---",
          W("---\nstatus: todo\n---\n\n# A\n", "status", "") == "# A\n",
          W("---\nstatus: todo\n---\n\n# A\n", "status", ""))
    check("clearing a field a note has not got changes NOTHING — no block is written to delete from",
          W("# A\n\nbody\n", "status", "") == "# A\n\nbody\n")
    check("a --- further down is a divider, not front matter — the file is left alone",
          W("# A\n\n---\n\nmore\n", "status", "done"):find("^%-%-%-\nstatus: done") ~= nil
              and W("# A\n\n---\n\nmore\n", "status", "done"):find("# A\n\n---\n\nmore\n", 1, true) ~= nil)
    check("an opening --- with no closing one is not front matter and is not rewritten",
          W("---\nstatus: todo\n\n# A\n", "status", "done") == "---\nstatus: todo\n\n# A\n")
    check("a tags: LIST under the key it replaces is not left behind as orphan items",
          W("---\nstatus: todo\n  - one\n  - two\nrating: 5\n---\n", "status", "done")
              == "---\nstatus: done\nrating: 5\n---\n",
          W("---\nstatus: todo\n  - one\n  - two\nrating: 5\n---\n", "status", "done"))
    check("a value YAML would read as structure is QUOTED, and fmIn reads it back whole",
          W("---\na: 1\n---\n", "status", "in: progress"):find('status: "in: progress"', 1, true) ~= nil
              and v.fmIn(W("---\na: 1\n---\n", "status", "in: progress")).status == "in: progress",
          W("---\na: 1\n---\n", "status", "in: progress"))
    check("a value can never break the block open — a newline in it becomes a space",
          select(2, W("---\na: 1\n---\n", "status", "one\n---\nnot a block"):gsub("\n%-%-%-", "")) == 1,
          W("---\na: 1\n---\n", "status", "one\n---\nnot a block"))
    check("a value longer than fmMaxLen is clamped there too, not only on the way in",
          #(v.fmIn(W("---\na: 1\n---\n", "status", string.rep("x", 400))).status or "") == v.fmMaxLen)
    check("a key that is not a field name is refused and the text comes back untouched",
          W("---\na: 1\n---\n", "sta tus", "x") == "---\na: 1\n---\n")

    -- ---- setField: the write itself ------------------------------------
    FILES[VAULT .. "/Projects/Beta.md"] = "---\nstatus: todo\n---\n\n# Beta\n\nbody\n"
    v.openNote("Alpha")
    local writes0, moves00 = v.saves, v.moves
    local ok = v.setField("Projects/Beta.md", "status", "done")
    check("a card moved on ANOTHER note rewrites that file, and only that line",
          ok and FILES[VAULT .. "/Projects/Beta.md"] == "---\nstatus: done\n---\n\n# Beta\n\nbody\n",
          FILES[VAULT .. "/Projects/Beta.md"])
    check("…the note you were editing is untouched and still open",
          v.doc.rel == "Alpha.md" and v.saves == writes0)
    check("…and the index knows AT ONCE, so the board redraws without a rescan",
          v.fmOf["Projects/Beta.md"].status == "done")
    check("…and the move is COUNTED, which is what lets the report say the board writes",
          v.moves == moves00 + 1, v.moves .. " vs " .. moves00)
    check("…no half-written file is left behind", FILES[VAULT .. "/Projects/Beta.md.tmp"] == nil)
    do
        local rep = {}
        local old_print = print
        print = function(s) rep[#rep + 1] = tostring(s) end
        _G.vaultReport()
        print = old_print
        check("the report says the board writes, how often, and what it last moved",
              rep[1]:find("board  : groups by status", 1, true) ~= nil
                  and rep[1]:find("Projects/Beta.md · status = done", 1, true) ~= nil, rep[1])
    end

    -- moving the note that is OPEN goes through the editor, not behind it
    v.openNote("Alpha")
    v.setText("---\nstatus: todo\n---\n\n# Alpha\n")
    v.saveNow()
    check("moving the card of the note you have OPEN changes the text you are looking at",
          v.setField("Alpha.md", "status", "doing") and v.doc.text:find("status: doing", 1, true) ~= nil
              and FILES[VAULT .. "/Alpha.md"]:find("status: doing", 1, true) ~= nil, v.doc.text)

    -- refusals: named, counted, and nothing written
    local fails0 = v.moveFails
    local before = FILES[VAULT .. "/Projects/Beta.md"]
    -- the traversal target EXISTS and is readable: a refusal that only
    -- happens because the file was missing would prove nothing at all
    FILES["/Users/ll/OneDrive/secret.md"] = "---\nstatus: private\n---\n"
    local okT, whyT = v.setField("../secret.md", "status", "x")
    check("a path that climbs out of the vault is refused BY THE PATH, and the file it aimed at is untouched",
          okT == false and tostring(whyT):find("not a note in the vault", 1, true) ~= nil
              and FILES["/Users/ll/OneDrive/secret.md"] == "---\nstatus: private\n---\n", tostring(whyT))
    check("a path that is not a note is refused", v.setField("Projects/Beta.txt", "status", "x") == false)
    check("tags are refused here — they are written in the note, not dragged",
          v.setField("Projects/Beta.md", "tags", "x") == false)
    check("a field name that is not one is refused", v.setField("Projects/Beta.md", "sta tus", "x") == false)
    check("…and not one of those refusals wrote anything",
          FILES[VAULT .. "/Projects/Beta.md"] == before)
    local okR, whyR = v.setField("Nowhere/Missing.md", "status", "x")
    check("a note that is not on disk is refused BY NAME, never created behind your back",
          okR == false and tostring(whyR):find("could not read") ~= nil
              and FILES[VAULT .. "/Nowhere/Missing.md"] == nil, tostring(whyR))
    check("every refusal is counted, so the report can say so", v.moveFails > fails0)

    -- a refused write on a real note does not lie about having moved
    v.openNote("Gamma")
    local moves0 = v.moves
    WRITE_FAILS = true
    local okW, whyW = v.setField("Projects/Beta.md", "status", "todo")
    WRITE_FAILS = false
    check("a file that will not open is a refusal, not a silent success",
          okW == false and tostring(whyW):find("cannot open") ~= nil and v.moves == moves0, tostring(whyW))

    -- the message path: the page names the note, Lua decides
    v.openNote("Alpha")
    FILES[VAULT .. "/Projects/Beta.md"] = "---\nstatus: todo\n---\n"
    local alphaWas = FILES[VAULT .. "/Alpha.md"]
    msg({ a = "kmove", card = "Projects/Beta.md", field = "status", value = "done",
          rel = "Alpha.md", text = v.doc.text })
    check("a kmove message from the page moves exactly that one card",
          FILES[VAULT .. "/Projects/Beta.md"]:find("status: done", 1, true) ~= nil)
    check("🚨🚨 6.203.0 — …and the note that is OPEN is untouched. The card rode\n"
       .. "        under `rel` until now, and say() overwrites `rel` with the open\n"
       .. "        note on every message — so the one view in this module that\n"
       .. "        WRITES had been writing to whichever note happened to be open",
          FILES[VAULT .. "/Alpha.md"] == alphaWas, "Alpha.md changed")
    local alerts0 = #ALERTS
    msg({ a = "kmove", card = "Projects/Beta.md", field = "tags", value = "x",
          rel = "Alpha.md", text = v.doc.text })
    check("a kmove the module refuses SAYS so rather than failing quietly", #ALERTS > alerts0)

    -- ⌘⇧B and the view itself
    v.openNote("Alpha")
    msg({ a = "board" })
    check("the board takes the whole window — the note list and the panes stand down",
          v.view == "board" and WEBVIEWS[#WEBVIEWS].htmlSet:find('<body class="board"', 1, true) ~= nil
              and WEBVIEWS[#WEBVIEWS].htmlSet:find("body.board #ed,body.board #links,body.board #side{display:none}", 1, true) ~= nil)
    msg({ a = "board" })
    check("…and ⌘⇧B again puts the note back", v.view == "edit")

    -- the standing promise, restated where it can break
    local rf = io.popen and io.popen("cat '" .. HS .. "/modules/vault.lua'")
    local real = rf and rf:read("a") or ""
    if rf then rf:close() end
    check("the board's write is the ONLY new one: no path here touches the note's body",
          real:find("function v%.setField") ~= nil and real:find("v%.withField") ~= nil)
    check("the cheat sheet knows ⌘⇧B, so a key that moved can never go stale here",
          real:find("⌘⇧B", 1, true) ~= nil)
end

out("\n6.214.0 — HAMSIDIAN: the name LL sees changed, nothing he can lose did\n")
do
    -- Visible strings only, as the Scorp Pad was done in 6.171.0. The
    -- rows below hold BOTH halves: a mutation that renames the module id,
    -- the settings key, the report global or the folder fails here, and
    -- so does one that leaves "Vault" in a string LL reads.
    local rf = io.popen and io.popen("cat '" .. HS .. "/modules/vault.lua'")
    local real = rf and rf:read("a") or ""
    if rf then rf:close() end
    check("the module NAME (boot report, cheat sheet owner, hint card) is Hamsidian", mod.name == "Hamsidian")
    check("the cheat sheet's title says HAMSIDIAN and still names ⇪3 / ⇪N",
          tostring(mod.cheatsheet.title):find("🕸 HAMSIDIAN", 1, true) ~= nil and tostring(mod.cheatsheet.title):find("⇪3 / ⇪N", 1, true) ~= nil)
    v.openNote("Alpha")
    -- ✏️ 6.252.1 — ONE WINDOW, ONE NAME. The pad side reads 📝 Hamsidian
    -- and the notes side 🕸 Hamsidian: the ICON is what tells them apart
    -- now, which is the minimal wording that answers "Scorp pad should be
    -- named Hamsidian" without making two identical headers.
    check("the window header reads 🕸 Hamsidian on a note and 📝 Hamsidian on a tab",
          WEBVIEWS[#WEBVIEWS].htmlSet:find('<span class="name">🕸 Hamsidian</span>', 1, true) ~= nil
              and real:find('"📝 Hamsidian"', 1, true) ~= nil
              -- COMMENTS may still say Scorp (they are the history, and
              -- 6.214.0 set that precedent for the notes' own rename).
              -- What must be gone is every VISIBLE one.
              and real:find('"📝 Scorp Pad"', 1, true) == nil
              and real:find('"the Scorp Pad is not loaded"', 1, true) == nil)
    check("the report's first line is 🕸 Hamsidian — ⇪3", tostring(_G.vaultReport()):find("🕸 Hamsidian — ⇪3", 1, true) == 1)
    check("no Console line, alert or window title says Vault any more (the folder and comments may)",
          real:find('"🕸 Vault', 1, true) == nil and real:find('windowTitle("Vault")', 1, true) == nil
              and real:find('textPrompt, "Vault"', 1, true) == nil)
    -- the half that must NOT move
    check("_G.vault and _G.vaultReport are still the globals", _G.vault == v and type(_G.vaultReport) == "function")
    check("the folder is still <OneDrive>/Vault — a rename there would strand every note", tostring(v.dir):match("/Vault$") ~= nil)
    check("the settings key is still `vault` (the file is modules/vault.lua; a profile line keeps working)",
          real:find("settings = { vault = {", 1, true) ~= nil)
    check("the source says why: visible strings only, and names what stays", real:find("VISIBLE STRINGS ONLY", 1, true) ~= nil)
end

-- =====================================================================
out("\n6.277.0 — ⇪3 PUTS YOU BACK IN THE NOTE YOU WERE IN\n")
-- =====================================================================
-- LL: "Opening and closing Hamsidian puts me back on Scratch 1 and not
-- the note I was working on. If I had 1000s of notes, I would have to
-- find that note each time to work on it again. Since I might not
-- remember, that's asking a lot of me."
--
-- 🔎 `vault.lastNote` has been WRITTEN on every open for releases and
-- v.open() consulted it only `if not v.doc` — while v.doc survives
-- hide(). One ⇪N pins it to a scratch tab for the whole session, so
-- every ⇪3 after that renders the tab. The memory was correct and
-- unreachable. These checks drive the state he actually had.
do
    v.hide()
    v.openNote("Alpha")
    check("the note he was in is remembered as he works",
          SETTINGS["vault.lastNote"] == "Alpha.md")

    -- 🎯 HIS EXACT STATE: a scratch tab left in v.doc by an earlier ⇪N,
    -- surviving a close, with the note still remembered underneath it.
    v.hide()
    v.doc = { scratch = "s1", name = "Scratch 1", rel = "scratch:s1", text = "" }
    v.show()
    check("🎯 ⇪3 opens on ALPHA, not on the scratch tab that was pinned "
          .. "in v.doc — the whole of what LL reported",
          v.doc ~= nil and v.doc.rel == "Alpha.md",
          v.doc and tostring(v.doc.rel))
    check("...and it says so, in the report's own words",
          tostring(v.lastPlaceState):find("Alpha.md", 1, true) ~= nil,
          tostring(v.lastPlaceState))
    v.hide()

    -- 🚨 A REMEMBERED NOTE THAT IS GONE MUST NOT BE RE-CREATED. openNote
    -- seeds a missing file, so restoring through it naively would answer
    -- "you deleted that note" by writing it back out — a silent
    -- resurrection in the one folder that holds his writing.
    SETTINGS["vault.lastNote"] = "Vanished.md"
    SETTINGS["vault.recentNotes"] = nil        -- 6.327.0: nothing behind it
    v.doc = nil
    local before = FILES[VAULT .. "/Vanished.md"]
    local okG, whyG = v.goToLastNote()
    check("🚨 a remembered note this vault no longer holds is NOT "
          .. "re-created — nothing is written back into the folder",
          okG == false and before == nil
          and FILES[VAULT .. "/Vanished.md"] == nil, tostring(whyG))
    check("...and the state names it rather than reading like a fresh "
          .. "vault — 'gone' and 'never had one' are different facts",
          tostring(v.lastPlaceState):find("deleted", 1, true) ~= nil,
          tostring(v.lastPlaceState))
    check("...and the report prints the ⚠️ for it", (function()
        local r = _G.vaultReport()
        return r:find("back to:", 1, true) ~= nil
               and r:find("could not put you back", 1, true) ~= nil
    end)())

    -- nothing remembered at all: honest, and still not a scratch tab
    SETTINGS["vault.lastNote"] = nil
    v.doc = nil
    local okN = v.goToLastNote()
    check("a vault with nothing remembered says exactly that",
          okN == false
          and tostring(v.lastPlaceState):find("nothing remembered", 1, true) ~= nil,
          tostring(v.lastPlaceState))

    -- 🔑 AND ⇪N IS UNCHANGED. Each door restores its own side; a single
    -- shared "last place" would land ⇪3 back on Scratch 1 whenever the
    -- tabs were used last, which is the complaint being fixed.
    SETTINGS["vault.lastNote"] = "Alpha.md"
    v.hide()
    v.doc = nil
    local okS, whyS = v.openScratch(nil)
    -- The pad is not loaded in this suite, so ⇪N's door REFUSES by name
    -- here. Either way the rule is the same and it is the one that
    -- matters: the tabs door must never quietly become a second notes
    -- door. Asserting "it opened a tab" would pass only where the pad
    -- happens to be loaded and would say nothing about the rule.
    check("⇪N's door goes to the tabs or refuses by name — it NEVER "
          .. "falls through to the remembered note, or the notes door "
          .. "restoring notes has turned the tabs door into a second one",
          (okS == true and v.doc ~= nil and v.doc.scratch ~= nil)
          or (okS == false and type(whyS) == "string" and whyS ~= ""
              and (v.doc == nil or v.doc.rel ~= "Alpha.md")),
          tostring(okS) .. " / " .. tostring(whyS)
          .. " / " .. tostring(v.doc and v.doc.rel))

    -- one door: a caller reaching v.open() directly still gets it back
    v.hide()
    v.doc = nil
    v.open()
    check("v.open() on its own restores too — the restore lives in ONE "
          .. "function, not a second copy beside it (6.231.0)",
          v.doc ~= nil and v.doc.rel == "Alpha.md",
          v.doc and tostring(v.doc.rel))
    v.hide()
end

-- =====================================================================
out("\n6.280.0 — 🗑 A NOTE CAN BE DELETED, AND IT GOES SOMEWHERE\n")
-- =====================================================================
-- LL, twice: "I don't understand why there is no delete. Can you fix
-- this?" and "I have an ever growing entries list in Hamsidian … I don't
-- have an x at the end of the line. How do I delete an entry?"
--
-- 🚨 NEVER os.remove. An unrecoverable delete of his writing is the one
-- failure in this config with no way back, so the whole design is that
-- the note MOVES and the report says where.
do
    local before = pass + fail
    v.hide()
    FILES[VAULT .. "/Doomed.md"] = "# Doomed\n\nsome writing\n"
    FILES[VAULT .. "/Keeper.md"] = "# Keeper\n\nsee [[Doomed]]\n"
    -- 🔎 THE INDEX IS BUILT BY THE MODULE, not assembled here. Hand-filling
    -- v.links and v.backlinks would prove only that the check can read a
    -- table the check just wrote (6.203.0) — openNote is the real door and
    -- it is what fills byKey, links and the backlinks together.
    v.openNote("Doomed")
    v.openNote("Keeper")

    -- the bounds first: a delete is the one place they have to hold
    check("🔒 an empty name is refused", select(1, v.deleteNote("")) == false)
    -- 🧪 AND THE FIXTURE HAS TO MAKE THE GUARD THE ONLY THING REFUSING.
    -- The first version passed "../../../etc/passwd", which no fixture
    -- holds — so "no such note" refused it and deleting the bound changed
    -- nothing. A file that really IS readable at the escaping path is the
    -- only input that tells the two refusals apart (6.230.0: pick the
    -- input where the right and wrong implementations must differ).
    FILES[VAULT .. "/../Outside.md"] = "# Outside\n\nnot yours to move\n"
    local okEsc, whyEsc = v.deleteNote("../Outside.md")
    check("🔒 a path that leaves the vault is refused EVEN WHEN the file "
          .. "is really there — the bound is what refuses it, not the "
          .. "absence of the file",
          okEsc == false and tostring(whyEsc):find("out of the vault", 1, true) ~= nil
          and FILES[VAULT .. "/../Outside.md"] ~= nil, tostring(whyEsc))
    check("🔒 a file that is not a note is refused",
          select(1, v.deleteNote("Doomed.txt")) == false)
    check("🔒 a note that is not there is refused, and says which",
          select(1, v.deleteNote("Nope.md")) == false)
    check("...and none of those touched anything on disk",
          FILES[VAULT .. "/Doomed.md"] ~= nil)

    local ok, where, links = v.deleteNote("Doomed.md")
    check("🗑 the note is deleted", ok == true, tostring(where))
    check("🚨 ...and it is MOVED, not erased — it is in .trash, and this "
          .. "is the rule the whole release turns on",
          type(where) == "string" and where:find("/.trash/", 1, true) ~= nil
          and FILES[where] ~= nil, tostring(where))
    check("...the original is gone from the vault", FILES[VAULT .. "/Doomed.md"] == nil)
    check("...and the copy in .trash still holds every word",
          tostring(FILES[where]):find("some writing", 1, true) ~= nil)
    check("🔗 ...and it counts what still links to it — the fact that "
          .. "would have changed his mind, which he cannot see from the "
          .. "row he clicked", links == 1, tostring(links))

    -- ↩️ THE WAY BACK (6.199.0)
    check("↩️ _G.vaultUndelete() puts it back under its own name",
          _G.vaultUndelete() == true
          and FILES[VAULT .. "/Doomed.md"] ~= nil
          and tostring(FILES[VAULT .. "/Doomed.md"]):find("some writing", 1, true) ~= nil)
    check("...and a second undelete with nothing to undo says so rather "
          .. "than throwing", select(1, _G.vaultUndelete()) == false)

    -- 🕰 two notes of the same name must not overwrite each other in the
    -- trash, or the delete becomes unrecoverable through the back door
    local n1 = v.trashNameFor("Ideas.md", 1700000000)
    local n2 = v.trashNameFor("Ideas.md", 1700000061)
    check("🕰 two deletes of the same name land on different files",
          n1 ~= n2, n1 .. " vs " .. n2)
    check("...and a note in a subfolder cannot collide with one at the "
          .. "root either", v.trashNameFor("a/b/Ideas.md", 1700000000) ~= n1)
    check("...and what lands in .trash is still a .md",
          n1:match("%.md$") ~= nil, n1)

    -- the open note is not left pointing at a file that is gone
    v.openNote("Doomed")
    check("the note under test is open", v.doc ~= nil and v.doc.rel == "Doomed.md")
    v.deleteNote("Doomed.md")
    check("🚨 deleting the note you are IN does not leave the editor "
          .. "pointing at a file that no longer exists",
          v.doc == nil or v.doc.rel ~= "Doomed.md",
          v.doc and tostring(v.doc.rel))
    check("...and the report names where it went, not just a count",
          (function()
              local r = _G.vaultReport()
              return r:find("deleted:", 1, true) ~= nil
                     and r:find(".trash", 1, true) ~= nil
                     and r:find("vaultUndelete", 1, true) ~= nil
          end)())

    -- 🚨 THE PAGE: the ✕ must be asked BEFORE the row it sits inside, or
    -- the shared click handler OPENS the note on its way to deleting it
    -- (6.272.0 — there it PLAYED the track it was forgetting). Read from
    -- the module SOURCE, because this rule is about the ORDER of two
    -- branches and a rendered page cannot be asked about order.
    local src280 = (function()
        local f = REAL_OPEN(HS .. "/modules/vault.lua", "r")
        if not f then return "" end
        local t = f:read("*a"); f:close(); return t
    end)()
    check("SOURCE: a note row carries data-del with its REL, never its "
          .. "position — the list renumbers on every filter and an index "
          .. "would delete a different note than the one clicked",
          src280:find("data-del=", 1, true) ~= nil
          and src280:find("data-del=\"' + esc(x.r)", 1, true) ~= nil)
    local delAt = src280:find("var del = li.getAttribute('data-del');", 1, true)
    local actAt = src280:find("else rowAct(li); });", 1, true)
    check("🚨 SOURCE: the ✕ is read BEFORE rowAct is reached, and returns",
          delAt ~= nil and actAt ~= nil and delAt < actAt
          and src280:find("say({a:'notedel', del: del}); return;", 1, true) ~= nil,
          tostring(delAt) .. " vs " .. tostring(actAt))
    -- 🚨 WITH COMMENTS STRIPPED (6.262.0, and the first run of this check
    -- went red for exactly that reason): the comment explaining the rule
    -- quotes the very call it forbids, so a bare grep can never pass on a
    -- healthy tree — and a sentry that is red when nothing is wrong is one
    -- that gets deleted within a week (6.269.0).
    local code280 = src280:gsub("%-%-%[%[.-%]%]", " "):gsub("%-%-[^\n]*", " ")
    -- 🚨 6.321.0 — THE SENTRY NAMES THE RULE, NOT THE WORD, and that
    -- distinction is the whole of this edit. What 6.280.0 promised is
    -- that A NOTE IS NEVER ERASED: the ✕ moves it to .trash and the
    -- only way back out is a restore. The bin's 180-day purge DOES call
    -- os.remove — on a file that was deleted half a year ago and has
    -- been recoverable every day since, which is the opposite of the
    -- failure this sentry exists to prevent. Forbidding the WORD would
    -- have meant either no purge at all or a sentry switched off
    -- (6.269.0), so it forbids the THING: every os.remove in this file
    -- must take a path built from v.trashDir(), and nothing else.
    local removes = {}
    for call in code280:gmatch("os%.remove%b()") do removes[#removes + 1] = call end
    check("🚨 SOURCE: every os.remove in this module takes a path inside "
          .. ".trash — a note is never erased, only moved there and, after "
          .. "180 days, purged from there",
          #removes > 0 and (function()
              for _, c in ipairs(removes) do
                  if not c:find("v.trashDir()", 1, true) then return false, c end
              end
              return true
          end)(), table.concat(removes, " | "))
    check("🚨 ...and the vault's own folder is never handed to one: no "
          .. "os.remove is built from v.dir",
          (function()
              for _, c in ipairs(removes) do
                  if c:find("v%.dir") then return false end
              end
              return true
          end)(), table.concat(removes, " | "))
    check("...and the check reads code, not comments: the rule's own "
          .. "comment names os.remove and must not trip it",
          src280:find("os.remove", 1, true) ~= nil)

    local ran = (pass + fail) - before
    check("§6.280.0 ran all of its checks (" .. ran .. " of 18+)", ran >= 18, ran)
end

-- =======================================================================
out("\n6.316.0 — 🚨 A FAILED SAVE GOES THROUGH EVERY CHANNEL, AND STAYS SAID\n")
-- =======================================================================
-- Everything above drives the FALLBACK — this suite has no `_G.notices`,
-- which is the Mac where notices did not load and the module speaks for
-- itself. The path that actually runs on his Mac is the OTHER one, and a
-- stub that does not carry notSaved is gentler than the provider in
-- exactly the direction that would hide it (6.290.0).
do
    local before = pass + fail
    local NS, OK = {}, {}
    local keptNotices = _G.notices
    _G.notices = {
        notSaved = function(tool, what, path, why)
            NS[#NS + 1] = { tool = tool, what = what, path = path, why = why }
            return false, why
        end,
        saveOK      = function(tool) OK[#OK + 1] = tool ; return true end,
        unsavedLines = function()
            return #NS > #OK and { "🚨 NOT SAVED — Hamsidian: a note", "   do something" } or {}
        end,
        record = function() return true end,
    }
    v.openNote("Alpha")
    v.setText("# Alpha\n\nchannelled\n")
    WRITE_FAILS = true
    local nAlertsBefore = #ALERTS
    v.saveNow()
    check("with notices loaded the module goes through the ONE door, not its own alert",
          #NS == 1 and NS[1].tool == "Hamsidian" and (NS[1] or {}).why ~= nil
          and (NS[1].path or ""):find("Alpha.md", 1, true) ~= nil
          and #ALERTS == nAlertsBefore,
          tostring(#NS) .. "/" .. tostring(#ALERTS - nAlertsBefore))
    -- 🚨 the helper answers FALSELY rather than indexing a nil: a
    -- mutation that stops notSaved being called must FAIL this check,
    -- not end the run with "0 failed" never printed (6.186.0).
    local function nsWhat() return (NS[1] and NS[1].what) or "" end
    check("…and it names the NOTE, so the report says which writing is at risk",
          nsWhat():find("Alpha", 1, true) ~= nil, nsWhat())
    -- 🚨 THE BLOCK IS FIRST, found by the mutation sweep: a report that
    -- buries "your writing is not on disk" under twenty lines of tag
    -- counts is a report he reads the top of and closes.
    local rep = _G.vaultReport()
    check("🚨 _G.vaultReport() puts the live NOT SAVED block FIRST, above the folder line",
          (function()
              local at   = rep:find("NOT SAVED", 1, true)
              local head = rep:find("🕸 Hamsidian", 1, true)
              return at ~= nil and head ~= nil and at < head
          end)(), rep:sub(1, 80))
    WRITE_FAILS = false
    v.setText("# Alpha\n\nchannelled twice\n")
    v.saveNow()
    check("a real write clears it through the same door — never by the module itself",
          #OK == 1 and OK[1] == "Hamsidian"
          and _G.vaultReport():find("NOT SAVED", 1, true) == nil)
    _G.notices = keptNotices
    local ran = (pass + fail) - before
    check("§6.316.0 ran all of its checks (" .. ran .. " of 4)", ran >= 4, ran)
end

-- ---------------------------------------------------------------------------
-- §6.320.0 — A NAME WITH AN ELLIPSIS IN IT IS NOT A PATH ESCAPE
--
-- LL could not delete a note and was told "that path leaves the vault",
-- which was not true of his note. The guard was a SUBSTRING test for two
-- dots, so every title carrying an ellipsis was refused as a directory
-- escape — by the ✕ and, silently, by the board's drag.
-- ---------------------------------------------------------------------------
do
    local before = pass + fail

    -- 🧪 THE FIXTURE THAT BITES is the one where a substring test and a
    -- component walk must DISAGREE (6.230.0). Every ordinary name agrees.
    check("🗂 a name holding an ellipsis is INSIDE the vault "
          .. "(the substring test refused it; the component walk does not)",
          v.relInside("Notes/Hmm... ok.md") == true)
    check("🗂 …and so is a name that is nothing but dots in the middle",
          v.relInside("a..b.md") == true and v.relInside("....md") == true)

    -- and the thing the guard is actually for still cannot get through
    check("🔒 a .. folder step is refused", select(1, v.relInside("../Outside.md")) == false)
    check("🔒 …in the middle of a path too", select(1, v.relInside("Notes/../../x.md")) == false)
    check("🔒 …and a bare .. on its own", select(1, v.relInside("..")) == false)
    check("🔒 an absolute path is refused", select(1, v.relInside("/etc/passwd")) == false)
    check("🔒 a backslash is refused", select(1, v.relInside("Notes\\x.md")) == false)
    check("🔒 an empty name is refused", select(1, v.relInside("")) == false)
    check("🔒 nil is refused rather than thrown at", select(1, v.relInside(nil)) == false)

    -- 🚨 EVERY REFUSAL SAYS WHICH, or the message is the one he could not
    -- act on. Three causes, three different sentences.
    local _, w1 = v.relInside("../x.md")
    local _, w2 = v.relInside("/x.md")
    local _, w3 = v.relInside("")
    check("🔎 the three refusals name three different causes",
          w1 ~= w2 and w2 ~= w3 and w1 ~= w3
          and tostring(w1):find("..", 1, true) ~= nil
          and tostring(w2):find("absolute", 1, true) ~= nil,
          tostring(w1) .. " / " .. tostring(w2) .. " / " .. tostring(w3))

    -- 🚨 TWO CALLERS, ONE RULE (6.231.0). The board's write carried the
    -- identical substring test, so a card for such a note snapped back.
    local relDots = "Hmm... ok.md"
    FILES[VAULT .. "/" .. relDots] = "---\nstatus: todo\n---\n\n# Hmm... ok\n"
    v.setNotes({ relDots })
    local okF, whyF = v.setField(relDots, "status", "done")
    check("🗂 the BOARD can move a card whose note name holds an ellipsis",
          okF == true, tostring(whyF))
    check("…and the field really changed on disk",
          FILES[VAULT .. "/" .. relDots]:find("status: done", 1, true) ~= nil,
          FILES[VAULT .. "/" .. relDots])
    check("🔒 the board still refuses a .. step",
          select(1, v.setField("../Outside.md", "status", "done")) == false)

    -- and the ✕ itself, end to end
    local okD, whereD = v.deleteNote(relDots)
    check("🗑 the ✕ can delete a note whose name holds an ellipsis",
          okD == true, tostring(whereD))

    local ran = (pass + fail) - before
    check("§6.320.0 ran all of its checks (" .. ran .. " of 14)", ran >= 14, ran)
end

-- =======================================================================
out("\n6.321.0 — 🗑 THE RECYCLE BIN: FIFTY-FIVE NOTES THAT WERE ALWAYS THERE\n")
-- =======================================================================
-- LL: "This is horrible not having an undeleted or recycled bin or trash
-- that I can restore from" — after _G.vaultUndelete() answered true once
-- and "nothing to undelete" every time after, over a .trash folder
-- holding fifty-five recoverable notes. The data was never the gap.
do
    local before = pass + fail
    local TRASH = VAULT .. "/.trash"

    -- ---- PURE: the name carries the clock ---------------------------------
    local r = v.trashRowOf("Notes-Ideas  2026-10-04 152233.md")
    check("🕰 a trash filename parses back into its name and when it went",
          r ~= nil and r.name == "Notes-Ideas"
          and os.date("%Y-%m-%d %H:%M:%S", r.at) == "2026-10-04 15:22:33",
          r and (r.name .. " @ " .. os.date("%Y-%m-%d %H:%M:%S", r.at)) or "nil")
    check("🔒 a file that is not one of ours parses to nothing — and is "
          .. "therefore never listed and never purged",
          v.trashRowOf("just-a-note.md") == nil
          and v.trashRowOf(".index") == nil
          and v.trashRowOf("Ideas  2026-13-99 999999.md") ~= nil)

    -- ---- PURE: the index --------------------------------------------------
    local idx = v.trashIndexOf("1700000000\tdelete\tA  2026-01-01 000000.md\tNotes/A.md\n"
                               .. "garbage line with no tabs\n"
                               .. "1700000001\tedit\tB  2026-01-01 000001.md\tB.md\n")
    check("📎 the index maps a trash file to where it came FROM",
          idx["A  2026-01-01 000000.md"].rel == "Notes/A.md"
          and idx["B  2026-01-01 000001.md"].kind == "edit")
    check("📎 …and a malformed line is skipped, never fatal — this file is "
          .. "read on a path that must answer while it is half-written",
          idx["A  2026-01-01 000000.md"] ~= nil and idx["B  2026-01-01 000001.md"] ~= nil)

    -- ---- PURE: what a purge is due to take --------------------------------
    local now  = os.time()
    local rows = {
        { file = "Old.md",    name = "Old",    at = now - 200 * 86400 },
        { file = "Fresh.md",  name = "Fresh",  at = now - 10 * 86400 },
        { file = "Edge.md",   name = "Edge",   at = now - 180 * 86400 },
        { file = "NoClock.md",name = "NoClock",at = nil },
    }
    local due = v.trashDue(rows, now, 180, 200)
    check("🧹 a row over the window is due, one inside it is not",
          #due == 2 and due[1].name == "Old" and due[2].name == "Edge", #due)
    check("🚨 a row whose clock could not be read is NEVER purged — it fails "
          .. "closed, because the cost of being wrong here is his writing",
          (function() for _, d in ipairs(due) do if d.name == "NoClock" then return false end end
           return true end)())
    check("📏 the sweep is BOUNDED and the bound bites",
          #v.trashDue(rows, now, 1, 2) == 2, #v.trashDue(rows, now, 1, 2))

    -- ---- end to end: delete three, list three, restore the middle one -----
    FILES[VAULT .. "/Keep.md"]        = "# Keep\n"
    FILES[VAULT .. "/Notes/Deep.md"]  = "# Deep\n\nin a folder\n"
    FILES[VAULT .. "/Flat.md"]        = "# Flat\n"
    FILES[VAULT .. "/Third.md"]       = "# Third\n"
    v.setNotes({ "Keep.md", "Notes/Deep.md", "Flat.md", "Third.md" })
    v.deleteNote("Notes/Deep.md")
    v.deleteNote("Flat.md")
    v.deleteNote("Third.md")

    local list = v.trashList()
    check("🗑 the bin lists every note in it — not just the last one, which "
          .. "is the whole defect: v.trashed is ONE slot",
          list ~= nil and #list >= 3, list and #list or "nil")
    check("🗑 …newest first", list[1].at >= list[#list].at)

    -- 🚨 THE FIXTURE THAT BITES the index is a note in a FOLDER: its trash
    -- name is flattened to "Notes-Deep", which is indistinguishable from a
    -- note really called that, so restoring off the filename alone would
    -- put it back in the wrong place — silently (6.230.0: pick the input
    -- where the two implementations must differ).
    local deep
    for _, row in ipairs(list) do if row.name == "Notes-Deep" then deep = row end end
    check("📎 the row for a note that lived in a folder knows its real path",
          deep ~= nil and deep.known == true and deep.rel == "Notes/Deep.md",
          deep and tostring(deep.rel) or "no row")

    local okR, whereR = _G.vaultRestore("Notes-Deep")
    check("↩️ it comes back to ITS OWN FOLDER, not the vault root",
          okR == true and whereR == "Notes/Deep.md"
          and FILES[VAULT .. "/Notes/Deep.md"] == "# Deep\n\nin a folder\n",
          tostring(whereR))
    check("↩️ …and it is out of the bin",
          (function() for _, row in ipairs(v.trashList()) do
               if row.name == "Notes-Deep" then return false end end return true end)())

    -- 🚨 A RESTORE NEVER OVERWRITES. A note written since the delete is his
    -- newer work, and replacing it is the same loss wearing the fix's name.
    FILES[VAULT .. "/Flat.md"] = "# Flat\n\nI wrote this AFTER deleting the old one\n"
    local okO, whereO = _G.vaultRestore("Flat")
    check("🔒 a restore over a note that exists again lands BESIDE it, never on it",
          okO == true and whereO ~= "Flat.md"
          and FILES[VAULT .. "/Flat.md"]:find("AFTER deleting", 1, true) ~= nil
          and FILES[VAULT .. "/" .. whereO] == "# Flat\n", tostring(whereO))

    -- 🚨 BY NAME, NEVER BY NUMBER, and two of a name is a QUESTION
    FILES[VAULT .. "/Twin.md"] = "# Twin one\n"
    v.setNotes({ "Twin.md" }); v.deleteNote("Twin.md")
    FILES[VAULT .. "/Twin.md"] = "# Twin two\n"
    v.setNotes({ "Twin.md" }); v.deleteNote("Twin.md")
    -- 🚨 THE SWEEP'S OWN FINDING, and it is a real one: both deletes land
    -- in the SAME SECOND, which is the only input where the old naming
    -- and the new one must differ. trashNameFor's comment promised the
    -- timestamp stopped a second copy overwriting the first — true across
    -- seconds and false inside one, so one of the two was gone for good
    -- in the folder whose whole job is that nothing is.
    check("🚨 two deletes of one note in the SAME SECOND are two files in "
          .. "the bin — the second must not land on the first",
          (function()
               local n = 0
               for _, row in ipairs(v.trashList()) do if row.name == "Twin" then n = n + 1 end end
               return n == 2, n
           end)())
    check("🕰 …and the tie-break name still parses, or the collided note "
          .. "would be invisible in the bin and immune to the purge",
          v.trashRowOf("Twin  2026-10-04 205724 (2).md") ~= nil)

    local okT, whyT = _G.vaultRestore("Twin")
    local twins = 0
    for _, row in ipairs(v.trashList()) do if row.name == "Twin" then twins = twins + 1 end end
    check("🚨 two notes of one name in the bin is a question, not a guess — "
          .. "nothing is restored and both are still there",
          okT == false and whyT == "ambiguous" and twins == 2, tostring(whyT) .. " / " .. twins)
    check("…and the Console names them by date so he can pick one",
          PRINTED[#PRINTED]:find("2 notes in the bin are called", 1, true) ~= nil,
          PRINTED[#PRINTED])

    local okN = _G.vaultRestore("NothingLikeThis")
    check("🗑 a name the bin does not hold is refused, and says so", okN == false)

    -- ---- the purge --------------------------------------------------------
    -- a note deleted 200 days ago, written straight into the bin
    FILES[TRASH .. "/Ancient  " .. os.date("%Y-%m-%d %H%M%S", now - 200 * 86400) .. ".md"] = "# Ancient\n"
    local okDry, goneDry, dueDry = _G.vaultPurgeTrash()
    check("🧹 a plain call is a DRY RUN — it names what would go and takes nothing",
          okDry == true and goneDry == 0 and dueDry == 1
          and PRINTED[#PRINTED]:find("DRY RUN", 1, true) ~= nil, tostring(dueDry))
    check("…and the old note is still in the bin after it",
          (function() for _, row in ipairs(v.trashList()) do
               if row.name == "Ancient" then return true end end return false end)())

    local okP, goneP = _G.vaultPurgeTrash(true)
    check("🧹 (true) really purges, and only what is over the window",
          okP == true and goneP == 1, tostring(goneP))
    check("🚨 …and the notes deleted THIS SESSION are untouched by it",
          (function()
               local n = 0
               for _, row in ipairs(v.trashList()) do n = n + 1 end
               return n >= 2
           end)())

    -- ---- it fails safe ----------------------------------------------------
    local keptDir = hs.fs.dir
    -- (a) no lister on this Mac at all
    hs.fs.dir = nil
    local badRows, badWhy = v.trashList()
    check("🔎 a Mac with no folder lister answers nil AND a reason — never "
          .. "an empty bin, which reads as 'nothing to restore'",
          badRows == nil and tostring(badWhy):find("list", 1, true) ~= nil, tostring(badWhy))
    local okPB = _G.vaultPurgeTrash(true)
    check("🚨 …and a purge over a bin it could not read deletes NOTHING",
          okPB == false)

    -- (b) 🚨 THE BRANCH THE SWEEP FOUND UNDRIVEN, and it is the worst one
    -- in this release: a folder that EXISTS and REFUSES TO LIST. 6.265.0's
    -- distinction — driving a path with the dependency MISSING is not the
    -- same as driving it with the dependency REFUSING — and here the two
    -- have opposite consequences. Reading as "{}" would print "bin: empty"
    -- over fifty-five recoverable notes AND hand an empty due-list to a
    -- purge, which is the exact sentence this whole release exists to stop
    -- him seeing. A mutation returning {} survived until this check.
    local howManyBefore = 0
    hs.fs.dir = keptDir
    for _ in ipairs(v.trashList()) do howManyBefore = howManyBefore + 1 end
    hs.fs.dir = function() return function() error("Operation not permitted", 0) end, {} end
    local refRows, refWhy = v.trashList()
    check("🚨 a .trash folder that REFUSES to list is not an empty bin — nil "
          .. "and a reason, never {}",
          refRows == nil and refWhy ~= nil, tostring(refRows) .. " / " .. tostring(refWhy))
    local repRef = _G.vaultReport()
    check("🔎 …and the report says COULD NOT BE READ rather than 'empty'",
          repRef:find("bin    : ⚠️ COULD NOT BE READ", 1, true) ~= nil,
          repRef:match("bin    :[^\n]*"))
    local okRef = _G.vaultPurgeTrash(true)
    check("🚨 …and the purge over it takes nothing",
          okRef == false)
    local okAuto = v.purgeTrashOnce()
    check("🚨 …and so does the automatic one, which runs unattended",
          okAuto == false)
    hs.fs.dir = keptDir
    local howManyAfter = 0
    for _ in ipairs(v.trashList()) do howManyAfter = howManyAfter + 1 end
    check("🔒 …and every note is still in the bin afterwards",
          howManyAfter == howManyBefore, howManyBefore .. " → " .. howManyAfter)

    -- ---- the report --------------------------------------------------------
    local rep = _G.vaultReport()
    check("🔎 the report counts the bin off the FOLDER, not off this session's "
          .. "deletes — the number that made 55 recoverable notes invisible",
          rep:find("bin    : %d+ note%(s%) recoverable") ~= nil, rep:match("bin    :[^\n]*"))
    check("…and it names the door", rep:find("_G.vaultTrash()", 1, true) ~= nil)

    -- ---- the automatic half -------------------------------------------------
    FILES[TRASH .. "/Ancient2  " .. os.date("%Y-%m-%d %H%M%S", now - 400 * 86400) .. ".md"] = "# A2\n"
    v.trashPurge = false
    v.purgeTrashOnce()
    check("🔌 the automatic purge is a REAL switch: off means nothing goes",
          (function() for _, row in ipairs(v.trashList()) do
               if row.name == "Ancient2" then return true end end return false end)())
    v.trashPurge = true
    local okA, goneA = v.purgeTrashOnce()
    check("🧹 on, it takes the over-age row once",
          okA == true and goneA == 1, tostring(goneA))

    local ran = (pass + fail) - before
    check("§6.321.0 ran all of its checks (" .. ran .. " of 29)", ran >= 29, ran)
end

-- =======================================================================
out("\n6.322.0 — 🔒 A NOTE THAT COLLAPSES KEEPS ITS OLD TEXT\n")
-- =======================================================================
-- LL: "I highlighted the text in a note and accidentally deleted it all
-- and then I couldn't get any of that text back while the note remained
-- blank." Every link in the chain worked as written; nothing kept a copy.
do
    local before = pass + fail
    local long = string.rep("the quick brown fox. ", 20)   -- 420 chars

    -- ---- PURE: when is a shrink a mistake? ---------------------------------
    check("🔒 everything going at once is kept",
          select(1, v.shrinkGuard(long, "", 80, 0.25)) == true)
    check("🔒 …and so is a collapse to a handful of characters",
          select(1, v.shrinkGuard(long, "oops", 80, 0.25)) == true)
    check("🔕 an ordinary edit is NOT kept — a file per keystroke in a folder "
          .. "that syncs is the bug this would otherwise become",
          select(1, v.shrinkGuard(long, long .. "more", 80, 0.25)) == false
          and select(1, v.shrinkGuard(long, long:sub(1, 400), 80, 0.25)) == false)
    check("🔕 a note too short to matter is not kept",
          select(1, v.shrinkGuard("tiny", "", 80, 0.25)) == false)
    -- 🧪 THE FIXTURE THAT BITES the boundary: exactly at the share, and one
    -- character under it. Every other input agrees (6.230.0).
    local w = string.rep("x", 400)
    check("🔒 the boundary is a boundary: a quarter of 400 is a collapse, "
          .. "one character more is not",
          select(1, v.shrinkGuard(w, string.rep("x", 100), 80, 0.25)) == true
          and select(1, v.shrinkGuard(w, string.rep("x", 101), 80, 0.25)) == false)
    -- 🔎 and each refusal says WHICH, or the report cannot tell them apart
    local _, wA = v.shrinkGuard("tiny", "", 80, 0.25)
    local _, wB = v.shrinkGuard(long, long:sub(1, 400), 80, 0.25)
    local _, wC = v.shrinkGuard(long, long, 80, 0.25)
    check("🔎 the three refusals name three different causes",
          wA ~= wB and wB ~= wC and wA ~= wC, table.concat({ wA, wB, wC }, " / "))

    -- ---- end to end: his own keystroke ------------------------------------
    FILES[VAULT .. "/Essay.md"] = long
    v.setNotes({ "Essay.md" })
    v.openNote("Essay")
    v.shrinkLast, v.shrinkKept = nil, 0
    local keptBin = {}
    for _, row in ipairs(v.trashList()) do keptBin[row.file] = true end

    v.setText("")            -- select all, delete
    v.saveNow()

    check("🚨 the note really is empty on disk — this release does not stop "
          .. "that, it stops it being the END of the text",
          FILES[VAULT .. "/Essay.md"] == "", tostring(FILES[VAULT .. "/Essay.md"]))
    local fresh
    for _, row in ipairs(v.trashList()) do
        if not keptBin[row.file] and row.name == "Essay" then fresh = row end
    end
    check("🔒 …and the 420 characters are a file in the bin",
          fresh ~= nil and FILES[VAULT .. "/.trash/" .. fresh.file] == long,
          fresh and fresh.file or "no new row")
    check("🏷 …listed as a KEEP, not as a delete, so the bin can say which",
          fresh ~= nil and fresh.kind == "edit" and fresh.rel == "Essay.md",
          fresh and (tostring(fresh.kind) .. " / " .. tostring(fresh.rel)) or "nil")
    check("🔔 …and he is TOLD at the moment it happens, not a week later",
          ALERTS[#ALERTS]:find("lost most of its text", 1, true) ~= nil, ALERTS[#ALERTS])

    -- ↩️ and it comes back through the door he already has
    local okBack, whereBack = _G.vaultRestore("Essay")
    check("↩️ _G.vaultRestore brings the old text back BESIDE the emptied "
          .. "note, never over it",
          okBack == true and whereBack ~= "Essay.md"
          and FILES[VAULT .. "/" .. whereBack] == long
          and FILES[VAULT .. "/Essay.md"] == "", tostring(whereBack))

    -- ---- it must not flood the bin ----------------------------------------
    FILES[VAULT .. "/Essay2.md"] = long
    v.setNotes({ "Essay2.md" }); v.openNote("Essay2")
    v.shrinkLast = nil
    local n0 = #v.trashList()
    v.setText("")
    v.setText(long)          -- he retypes
    v.setText("")            -- and does it again, same minute
    local n1 = #v.trashList()
    check("🔕 one keep per note per window — holding ⌫ through a paragraph "
          .. "must not write a file per keystroke into a folder that syncs",
          n1 - n0 == 1, (n1 - n0))

    -- ---- a keep that FAILS is the one thing it must shout about -----------
    FILES[VAULT .. "/Essay3.md"] = long
    v.setNotes({ "Essay3.md" }); v.openNote("Essay3")
    v.shrinkLast, v.shrinkFails = nil, 0
    WRITE_FAILS = true
    v.setText("")
    WRITE_FAILS = false
    check("🚨 a keep that could not be written is COUNTED, not swallowed",
          v.shrinkFails == 1, v.shrinkFails)
    check("🔔 …and it takes the degrade door, naming that the text is NOT "
          .. "recoverable — the one sentence he needs at that moment",
          (function()
               for i = #DEGRADES, 1, -1 do
                   if tostring(DEGRADES[i].why):find("NOT recoverable", 1, true) then return true end
               end
               return false
           end)(), DEGRADES[#DEGRADES] and DEGRADES[#DEGRADES].why or "none")
    -- 🚨 THE SWEEP'S OWN FINDING: the belt that re-reads the keep after
    -- writing it survived its mutation, so it could have been deleted and
    -- the gate stayed green (6.273.0 — the line is not the finding, the
    -- missing check is). It is there for the shape io cannot report: the
    -- open succeeds, the write succeeds, and nothing lands.
    FILES[VAULT .. "/Essay4.md"] = long
    v.setNotes({ "Essay4.md" }); v.openNote("Essay4")
    v.shrinkLast, v.shrinkFails, v.shrinkKept = nil, 0, 0
    WRITE_VANISHES = true
    v.setText("")
    WRITE_VANISHES = false
    check("🚨 a keep whose write SAID it worked and landed nothing is caught "
          .. "by re-reading it — never counted as kept",
          v.shrinkFails == 1 and v.shrinkKept == 0, v.shrinkFails .. " / " .. v.shrinkKept)

    local rep3 = _G.vaultReport()
    check("🔎 …and the report says so in capitals, above the count of keeps "
          .. "that worked",
          rep3:find("could NOT be kept", 1, true) ~= nil, rep3:match("🚨[^\n]*"))

    local ran = (pass + fail) - before
    check("§6.322.0 ran all of its checks (" .. ran .. " of 16)", ran >= 16, ran)
end

-- =======================================================================
out("\n6.323.0 — ↩️ ⌘Z SURVIVES A SCAN\n")
-- =======================================================================
-- ⌘Z was never missing: the page lets it through and WebKit has always
-- undone a textarea. v.render() hands WebKit a NEW document, so the box
-- is a different element with an empty history — and every background
-- scan called it. His report: `scan : running · 65 so far`.
do
    local before = pass + fail

    -- ---- PURE: may a scan update in place? --------------------------------
    check("↩️ a scan with a note open and the editor showing updates the ROWS",
          select(1, v.scanRedraw(true, "edit", { rel = "A.md" })) == "rows")
    check("🚨 …and the graph and the board still REBUILD — they are drawn from "
          .. "the document, so a rows-only push would leave them stale",
          select(1, v.scanRedraw(true, "graph", { rel = "A.md" })) == "rebuild"
          and select(1, v.scanRedraw(true, "board", { rel = "A.md" })) == "rebuild")
    check("↩️ with no note open there is no undo to keep, so it rebuilds",
          select(1, v.scanRedraw(true, "edit", nil)) == "rebuild")
    check("↩️ with no window it does neither",
          select(1, v.scanRedraw(false, "edit", { rel = "A.md" })) == "none")
    local _, wR = v.scanRedraw(true, "graph", {})
    local _, wN = v.scanRedraw(false, "edit", {})
    check("🔎 each verdict says WHY, and the reasons differ", wR ~= wN and wR:find("graph", 1, true))

    -- ---- end to end: the scan must not replace the document ---------------
    FILES[VAULT .. "/Draft.md"] = "# Draft\n\nwords he is typing\n"
    v.setNotes({ "Draft.md" })
    v.openNote("Draft")
    v.open()                                  -- a window
    local W = WEBVIEWS[#WEBVIEWS]
    local htmlBefore = W.htmlSets or 0
    local evalsBefore = #EVALS
    v.rowRefresh, v.rebuilds = 0, 0

    v.scan("test")
    local ft = lastTask("find")
    ft.cb(0, "/Users/ll/OneDrive/Vault/Draft.md\n", "")
    local gt = lastTask("grep")
    if gt then gt.cb(1, "", "") end
    for _ = 1, 4 do
        local t = lastTask("grep")
        if t and not t.done then t.cb(1, "", "") end
    end

    check("🚨 the scan did NOT hand WebKit a new document — the <textarea> he "
          .. "is typing in is the SAME element, so its undo stack lives",
          (W.htmlSets or 0) == htmlBefore, htmlBefore .. " → " .. tostring(W.htmlSets))
    check("↩️ …it pushed the rows in by eval instead",
          v.rowRefresh >= 1 and v.rebuilds == 0
          and (function()
                   for i = #EVALS, evalsBefore + 1, -1 do
                       if EVALS[i]:find("^setIndex%(") then return true end
                   end
                   return false
               end)(), v.rowRefresh .. " / " .. v.rebuilds)

    -- 🚨 THE SWEEP'S OWN FINDING: the fallback when the push THROWS was
    -- undriven, so it could have been deleted and the gate stayed green
    -- (6.273.0). It is the branch that matters most on a beta OS —
    -- without it a Mac whose evaluateJavaScript refuses shows a left
    -- column that silently stops updating, for ever, with no error.
    -- 6.265.0: driving a path with the dependency MISSING is not the
    -- same as driving it with the dependency REFUSING.
    do
        local W3 = WEBVIEWS[#WEBVIEWS]
        local kept = W3.evaluateJavaScript
        W3.evaluateJavaScript = function() error("WebKit said no", 0) end
        local hb = W3.htmlSets or 0
        v.rowRefresh, v.rebuilds = 0, 0
        v.scan("throws")
        local ftx = lastTask("find")
        ftx.cb(0, "/Users/ll/OneDrive/Vault/Draft.md\n", "")
        for _ = 1, 5 do
            local t = lastTask("grep")
            if t and not t.done then t.cb(1, "", "") end
        end
        W3.evaluateJavaScript = kept
        check("🚨 a push that THROWS falls back to a full rebuild — a left "
              .. "column that silently stops updating is worse than a lost "
              .. "undo stack",
              v.rebuilds >= 1 and (W3.htmlSets or 0) > hb,
              v.rebuilds .. " / " .. hb .. " → " .. tostring(W3.htmlSets))
    end

    -- and the graph still rebuilds, which is the half that keeps it honest
    v.view = "graph"
    v.rowRefresh, v.rebuilds = 0, 0
    local W2 = WEBVIEWS[#WEBVIEWS]
    local htmlBefore2 = W2.htmlSets or 0
    v.scan("test2")
    local ft2 = lastTask("find")
    ft2.cb(0, "/Users/ll/OneDrive/Vault/Draft.md\n", "")
    for _ = 1, 5 do
        local t = lastTask("grep")
        if t and not t.done then t.cb(1, "", "") end
    end
    check("🚨 in the graph view a scan DOES rebuild — the rows-only push would "
          .. "leave the drawing stale",
          v.rebuilds >= 1 and (W2.htmlSets or 0) > htmlBefore2,
          v.rebuilds .. " / " .. htmlBefore2 .. " → " .. tostring(W2.htmlSets))
    v.view = "edit"

    -- ---- the report proves it on his Mac -----------------------------------
    local rep = _G.vaultReport()
    check("🔎 the report counts the two kinds of redraw APART — a release that "
          .. "claims it stopped rebuilding has to prove it",
          rep:find("⌘Z     : %d+ scan%(s%) updated the rows in place") ~= nil,
          rep:match("⌘Z[^\n]*"))
    check("📏 …and it NAMES the trade rather than leaving it to be found",
          rep:find("waits for the next full", 1, true) ~= nil)

    local ran = (pass + fail) - before
    check("§6.323.0 ran all of its checks (" .. ran .. " of 11)", ran >= 11, ran)
end

-- =======================================================================
out("\n6.324.0 — 🪜 THE SCAN NEVER CLEARS ITS OWN SLOT FROM INSIDE A CALLBACK\n")
-- =======================================================================
-- 6.196.1 killed this process natively, twice, with no Lua error and
-- nothing in the Console. 6.262.0 found the same two shapes in anchors
-- and NAMED vault.lua's scan chain as still carrying them. It did: the
-- front-matter grep's callback ends in finish(nil), whose first line
-- nil'd v.fmTask — the task whose callback was running — on the ORDINARY
-- SUCCESS PATH of every scan.
do
    local before = pass + fail

    -- 🔬 THE DRAIN GOES OFF, so the frame can be looked at from outside.
    DRAIN_HOPS = false
    FILES[VAULT .. "/Hop.md"] = "# Hop\n"
    v.scan("hoptest")
    local ft = lastTask("find")
    local heldFind = v.findTask
    ft.cb(0, VAULT .. "/Hop.md\n", "")
    check("🪜 the links grep is NOT started inside the find's callback — a "
          .. "hop is armed instead, and it is a HELD timer in its own slot",
          v.hops["scan-grep"] ~= nil
          and (lastTask("grep") == nil or lastTask("grep").started == false),
          tostring(v.hops["scan-grep"]))
    check("🔒 …and the find's own handle is still held while its callback runs",
          v.findTask == heldFind)
    drainHops()
    local gt = lastTask("grep")
    check("🪜 …and after the hop it really started",
          gt ~= nil and gt.started == true)

    gt.cb(0, "", "")
    check("🪜 the tags grep waits for a hop too",
          v.hops["scan-tags"] ~= nil)
    drainHops()
    local tt = lastTask("grep")
    tt.cb(1, "", "")
    check("🪜 …and so does the front-matter grep, while its handle is HELD",
          v.hops["scan-fm"] ~= nil and v.fmTask ~= nil)
    drainHops()

    -- 🚨 THE ONE THAT KILLED THE PROCESS: the last callback ends the scan,
    -- and ending the scan used to drop the reference to the task that
    -- callback is running inside.
    local fm = lastTask("grep")
    local heldFm = v.fmTask
    fm.cb(1, "", "")
    check("🚨 finish() does NOT nil the running task's slot inside its own "
          .. "callback — that is the native kill, with no Lua error and "
          .. "nothing in the Console",
          v.fmTask == heldFm and v.hops["scan-release"] ~= nil,
          tostring(v.fmTask) .. " / " .. tostring(v.hops["scan-release"]))
    check("…and the scan is over regardless — v.scanning is a plain boolean "
          .. "and is safe to clear in the frame",
          v.scanning == false)
    drainHops()
    check("🪜 …the slots are released one turn later",
          v.findTask == nil and v.grepTask == nil and v.tagTask == nil and v.fmTask == nil)
    DRAIN_HOPS = true

    -- 🚨 6.304.0 — hs.task:start() REFUSES BY RETURNING FALSE, and the
    -- links grep was the one site of four here not reading it. A pcall
    -- around it SUCCEEDS on a refusal, so the scan was left with
    -- v.scanning true for the rest of the session: the index silently
    -- stopped updating and every later v.scan() short-circuited.
    do
        local keptNew = hs.task.new
        local refuseNext = false
        hs.task.new = function(bin, cb, args)
            local t = keptNew(bin, cb, args)
            if refuseNext and bin:match("grep") then
                function t:start() self.started = false return false end
            end
            return t
        end
        v.scanning = false
        v.scan("refusal")
        refuseNext = true
        lastTask("find").cb(0, VAULT .. "/Hop.md\n", "")
        hs.task.new = keptNew
        check("🚨 a links grep that REFUSES to start ends the scan instead of "
              .. "wedging it — v.scanning must not be left true",
              v.scanning == false, tostring(v.scanning))
        check("…and the reason is recorded, not swallowed",
              tostring(v.scanErr):find("would not start", 1, true) ~= nil,
              tostring(v.scanErr))
    end

    -- 🛠 A MAC THAT CANNOT ARM A TIMER STILL SCANS. The hop is the safe
    -- path, not the feature — and the report SAYS the hop was missed
    -- rather than reading as health.
    do
        local keptAfter = hs.timer.doAfter
        hs.timer.doAfter = function() error("no timers on this Mac", 0) end
        v.hopsMissed = 0
        v.scanning = false
        v.scan("notimers")
        local ftn = lastTask("find")
        ftn.cb(0, VAULT .. "/Hop.md\n", "")
        hs.timer.doAfter = keptAfter
        check("🛠 with no timer the work still happens, on the old path",
              lastTask("grep") ~= nil and lastTask("grep").started == true)
        check("🔎 …and it is COUNTED as a missed hop, never reported as health",
              v.hopsMissed >= 1, v.hopsMissed)
        local rep = _G.vaultReport()
        check("🔎 …and the report carries the ⚠️",
              rep:find("could NOT step off", 1, true) ~= nil, rep:match("hops[^\n]*"))
    end

    local ran = (pass + fail) - before
    check("§6.324.0 ran all of its checks (" .. ran .. " of 13)", ran >= 13, ran)
end

-- =======================================================================
out("\n6.327.0 — 🔖 ⇪3 PUTS YOU BACK EVEN AFTER YOU DELETE THAT NOTE\n")
-- =======================================================================
-- His report: `back to: remembered yooooooooooooo.md — this vault no
-- longer holds it` with the ⚠️ under it. vault.lastNote is ONE slot; he
-- deleted the note he was last in and ⇪3 pointed at a grave from then
-- on, every press, until he happened to open another note.
do
    local before = pass + fail

    -- ---- PURE: the list after an open -------------------------------------
    check("🔖 newest first", v.recentPush({ "b.md" }, "a.md", 12)[1] == "a.md")
    check("🔖 no duplicates — re-opening a note MOVES it, never doubles it",
          (function()
               local l = v.recentPush({ "a.md", "b.md" }, "b.md", 12)
               return #l == 2 and l[1] == "b.md" and l[2] == "a.md"
           end)())
    check("📏 bounded, and the bound bites",
          #v.recentPush({ "a.md", "b.md", "c.md" }, "d.md", 2) == 2)
    check("🛟 an empty name changes nothing",
          #v.recentPush({ "a.md" }, "", 12) == 1)

    -- ---- end to end: his own sequence -------------------------------------
    FILES[VAULT .. "/One.md"]   = "# One\n"
    FILES[VAULT .. "/Two.md"]   = "# Two\n"
    FILES[VAULT .. "/Three.md"] = "# Three\n"
    v.setNotes({ "One.md", "Two.md", "Three.md" })
    SETTINGS["vault.recentNotes"], SETTINGS["vault.lastNote"] = nil, nil
    v.openNote("One") ; v.openNote("Two") ; v.openNote("Three")
    check("🔖 working through three notes remembers all three, newest first",
          (function()
               local l = v.recentList()
               return l[1] == "Three.md" and l[2] == "Two.md" and l[3] == "One.md"
           end)(), table.concat(v.recentList(), " · "))

    -- ✕ on a row that is NOT the open note: nothing walks the list here,
    -- so this is the only input the delete-time forget is load-bearing for
    v.openNote("Three")
    v.deleteNote("One.md")
    check("🗑 a ✕ on a row he is NOT in takes that note out of the memory "
          .. "too — nothing else walks the list on this path",
          (function()
               for _, r in ipairs(v.recentList()) do
                   if r == "One.md" then return false end
               end
               return true
           end)(), table.concat(v.recentList(), " · "))

    -- and the one he IS in
    v.deleteNote("Three.md")
    check("🗑 the delete takes it OUT of the memory, rather than leaving ⇪3 "
          .. "to discover the grave one press at a time",
          (function()
               for _, r in ipairs(v.recentList()) do
                   if r == "Three.md" then return false end
               end
               return true
           end)(), table.concat(v.recentList(), " · "))

    v.hide() ; v.doc = nil
    local okB = v.goToLastNote()
    check("🔖 ⇪3 lands on TWO — the note before the one he deleted — "
          .. "instead of the notes list",
          okB == true and v.doc and v.doc.rel == "Two.md",
          v.doc and tostring(v.doc.rel) or "nil")

    -- 🚨 AND IT STILL NEVER WRITES ONE BACK. The whole reason 6.277.0 is
    -- shaped this way: openNote SEEDS a missing file, so walking a list
    -- of remembered notes through it would resurrect every one he had
    -- deleted, silently, in the folder holding his writing.
    SETTINGS["vault.lastNote"] = "Ghost.md"
    SETTINGS["vault.recentNotes"] = { "Ghost2.md", "Ghost3.md" }
    v.doc = nil
    local okG = v.goToLastNote()
    check("🚨 a memory of nothing but deleted notes creates NONE of them",
          okG == false
          and FILES[VAULT .. "/Ghost.md"] == nil
          and FILES[VAULT .. "/Ghost2.md"] == nil
          and FILES[VAULT .. "/Ghost3.md"] == nil, tostring(v.lastPlaceState))
    check("🧹 …and they are pruned as they are passed, so the answer gets "
          .. "faster rather than slower and the ⚠️ does not return tomorrow",
          #v.recentList() == 0, table.concat(v.recentList(), " · "))
    check("🔎 …and the state says every one of them is gone, which is a "
          .. "different fact from 'nothing remembered yet'",
          tostring(v.lastPlaceState):find("has been deleted", 1, true) ~= nil,
          tostring(v.lastPlaceState))

    -- 🔕 and the ⚠️ is for a real failure only
    FILES[VAULT .. "/Four.md"] = "# Four\n"
    v.setNotes({ "One.md", "Two.md", "Four.md" })
    SETTINGS["vault.lastNote"] = nil
    SETTINGS["vault.recentNotes"] = { "Gone.md", "Four.md" }
    v.doc = nil
    v.goToLastNote()
    local rep = _G.vaultReport()
    check("🔕 skipping a deleted note and landing on the next is a SUCCESS "
          .. "and must not wear the warning — a ⚠️ he sees every day is a "
          .. "⚠️ he stops reading (6.269.0)",
          rep:find("could not put you back", 1, true) == nil
          and rep:find("it skipped the notes you deleted", 1, true) ~= nil,
          rep:match("back to:[^\n]*"))

    local ran = (pass + fail) - before
    check("§6.327.0 ran all of its checks (" .. ran .. " of 12)", ran >= 12, ran)
end

-- =======================================================================
out("\n6.328.0 — 🏷 THE LEFT COLUMN SHOWS THE NOTE'S OWN TITLE\n")
-- =======================================================================
-- LL: "Changing a title like # Add recycle bin does not change the title
-- in the lefthand column. I think it should." The column has always
-- shown the FILE NAME — which is what every link is keyed by, and not
-- what he calls the title.
do
    local before = pass + fail

    -- ---- PURE: the heading in a note's text -------------------------------
    check("🏷 the first `# ` heading is the title",
          v.headIn("# Add recycle bin\n\nsome words\n") == "Add recycle bin")
    check("🏷 …after front matter, not inside it",
          v.headIn("---\ntitle: x\n---\n\n# The Real One\n\nbody\n") == "The Real One")
    check("🚨 a `#tag` is not a heading — it has no space after the hash, "
          .. "and this vault is full of them",
          v.headIn("#scorp-pad some words\n") == nil)
    check("🚨 a `#` further down, after body text, is a SECTION not the "
          .. "note's title",
          v.headIn("just some words\n\n# Later Section\n") == nil)
    check("🛟 a note with no heading answers nil, never \"\"",
          v.headIn("plain words\n") == nil and v.headIn("") == nil
          and v.headIn(nil) == nil)
    check("✂️ it is trimmed", v.headIn("#    Spaced   \n") == "Spaced")

    -- ---- PURE: which of the three wins ------------------------------------
    v.fmOf, v.headOf = {}, {}
    check("📏 with nothing else, the FILE NAME",
          select(1, v.titleOf("A.md", "A")) == "A"
          and select(2, v.titleOf("A.md", "A")) == "file name")
    v.headOf["A.md"] = "A Heading"
    check("📏 a heading beats the file name",
          select(1, v.titleOf("A.md", "A")) == "A Heading"
          and select(2, v.titleOf("A.md", "A")) == "heading")
    v.fmOf["A.md"] = { title = "A Stated Title" }
    check("📏 …and a stated `title:` beats the heading — the note SAYING "
          .. "what it is called outranks a guess from its body",
          select(1, v.titleOf("A.md", "A")) == "A Stated Title"
          and select(2, v.titleOf("A.md", "A")) == "front matter")
    v.fmOf["A.md"] = { title = "   " }
    check("🛟 a blank `title:` is not a title",
          select(1, v.titleOf("A.md", "A")) == "A Heading")
    v.fmOf, v.headOf = {}, {}

    -- ---- the grep's answer -------------------------------------------------
    v.setHeadLines(VAULT .. "/One.md:1:# First One\n"
                   .. VAULT .. "/sub/Two.md:3:# Second\n"
                   .. VAULT .. "/One.md:9:# A later section\n")
    check("🏷 one row per note, and the FIRST heading wins",
          v.headOf["One.md"] == "First One" and v.headOf["sub/Two.md"] == "Second",
          tostring(v.headOf["One.md"]))

    -- ---- it rides into the page --------------------------------------------
    FILES[VAULT .. "/Renamed.md"] = "# Add recycle bin\n\nwords\n"
    v.setNotes({ "Renamed.md" })
    v.headOf = { ["Renamed.md"] = "Add recycle bin" }
    local j = v.notesJson()
    check("🏷 the row carries t: — what it is CALLED",
          j:find('t:"Add recycle bin"', 1, true) ~= nil, j)
    check("🚨 …and n: is STILL the file name, because that is what ⏎ opens "
          .. "and what every [[link]] resolves against",
          j:find('n:"Renamed"', 1, true) ~= nil, j)
    v.headOf = {}
    check("📏 a vault with no headings sends exactly the bytes it sent "
          .. "before — t: is only there when it differs",
          v.notesJson():find("t:", 1, true) == nil, v.notesJson())

    -- ---- and the open note follows him as he types -------------------------
    v.openNote("Renamed")
    v.open()
    local W = WEBVIEWS[#WEBVIEWS]
    local htmlBefore, evalsBefore = W.htmlSets or 0, #EVALS
    v.setText("# Something Else\n\nwords\n")
    check("🏷 typing a new heading updates the column AT ONCE — a scan is "
          .. "seconds away and he is typing now",
          v.headOf["Renamed.md"] == "Something Else", tostring(v.headOf["Renamed.md"]))
    check("↩️ …by eval, never a rebuild, so his ⌘Z survives it (6.323.0)",
          (W.htmlSets or 0) == htmlBefore
          and (function()
                   for i = #EVALS, evalsBefore + 1, -1 do
                       if EVALS[i]:find("^setIndex%(") then return true end
                   end
                   return false
               end)(), (W.htmlSets or 0) .. " vs " .. htmlBefore)
    local pushes = 0
    for i = evalsBefore + 1, #EVALS do
        if EVALS[i]:find("^setIndex%(") then pushes = pushes + 1 end
    end
    v.setText("# Something Else\n\nmore words\n")
    local pushes2 = 0
    for i = evalsBefore + 1, #EVALS do
        if EVALS[i]:find("^setIndex%(") then pushes2 = pushes2 + 1 end
    end
    check("🔕 …and typing that does NOT change the heading pushes nothing — "
          .. "this runs on every keystroke",
          pushes2 == pushes, pushes .. " → " .. pushes2)
    v.hide()

    local ran = (pass + fail) - before
    check("§6.328.0 ran all of its checks (" .. ran .. " of 16)", ran >= 16, ran)
end


out("\n6.335.0 — 🗑 THE BIN IS A BUTTON, NOT A CONSOLE COMMAND\n")
-- =======================================================================
-- LL: "I need a trash bin at the top with the other buttons that lets me
-- see notes I deleted." 6.321.0 built the bin and every note has been
-- recoverable since — through two Console commands. The data was never
-- the gap and this time neither was the instrument: it was the DOOR.
do
    local before = pass + fail

    -- ---- PURE: the rows the page draws ------------------------------------
    local rows = {
        { file = "Deep  2026-10-04 152233.md", name = "Notes-Deep",
          at = os.time({ year = 2026, month = 10, day = 4, hour = 15, min = 22, sec = 33 }),
          rel = "Notes/Deep.md", known = true, kind = "delete" },
        { file = "Loose  2026-10-04 152200.md", name = "Loose",
          at = os.time({ year = 2026, month = 10, day = 4, hour = 15, min = 22, sec = 0 }),
          rel = nil, known = false, kind = "delete" },
    }
    local pr = v.trashPageRows(rows, os.time())
    check("🗑 every row carries its TRASH FILE NAME — the only thing a "
          .. "restore is ever asked for (6.272.0: a row number forgets a "
          .. "different note the moment the list renumbers)",
          #pr == 2 and pr[1].f == "Deep  2026-10-04 152233.md"
          and pr[2].f == "Loose  2026-10-04 152200.md",
          pr[1] and tostring(pr[1].f))
    check("📎 a note that lived in a folder says it goes back there",
          pr[1].w == "Notes/Deep.md" and pr[1].root == false, tostring(pr[1].w))
    check("🔎 …and one with no index row says it goes back to the ROOT, "
          .. "rather than looking the same (6.196.1 — he is deciding "
          .. "from this list)",
          pr[2].w == "Loose.md" and pr[2].root == true, tostring(pr[2].w))
    check("🕒 the clock is rendered, not raw",
          pr[1].t:find("15:22", 1, true) ~= nil, pr[1].t)

    -- 🚨 6.282.0 — AN INSTRUMENT THAT CAN RAISE IS WORSE THAN ONE THAT
    -- LIES. os.date refuses a float outright, and the bin is the one
    -- list he opens when something has already gone wrong.
    local odd = v.trashPageRows({
        { file = "F  2026-10-04 152233.md", name = "F", at = 1759600000.5, known = false },
        { file = "G  2026-10-04 152233.md", name = "G", at = nil,          known = false },
    }, os.time())
    check("🕒 a fractional clock does not throw, and a missing one reads "
          .. "as 'time not recorded' rather than 1970",
          #odd == 2 and odd[1].t ~= "time not recorded"
          and odd[2].t == "time not recorded", odd[2] and odd[2].t)

    -- ---- the button, the mode and the payload -----------------------------
    FILES[VAULT .. "/Keep.md"]   = "# Keep\n\nstays\n"
    FILES[VAULT .. "/Bin Me.md"] = "# Bin Me\n\ngoing\n"
    v.setNotes({ "Keep.md", "Bin Me.md" })
    local okD, whyD = v.deleteNote("Bin Me.md")
    check("🗑 (fixture) the note really went to the bin", okD == true, tostring(whyD))
    v.show()
    local W = WEBVIEWS[#WEBVIEWS]
    local hp = W.htmlSet
    check("🗑 the bin has a button in the header, beside the others",
          hp:find('id="tbtn"', 1, true) ~= nil
          and hp:find("setMode(MODE==='trash'?'notes':'trash')", 1, true) ~= nil, nil)
    check("…and the page can draw it: the payload, the drawer and the "
          .. "placeholder all exist",
          hp:find("var TRASH = {rows:[", 1, true) ~= nil
          and hp:find("function drawTrashRows", 1, true) ~= nil
          and hp:find("trash: 'filter the bin", 1, true) ~= nil, nil)
    check("🚨 and the row's restore message is NOT named text/sel/rel — "
          .. "say() stamps those onto every message (6.203.0), so a value "
          .. "sent under one is silently replaced with the OPEN note's",
          hp:find("a:'untrash', bin: un", 1, true) ~= nil, nil)

    local evalsBefore = #EVALS
    v.setMode("trash")
    check("🗑 ⇪3's left column has a fourth face, and asking for it READS "
          .. "the folder", v.mode == "trash" and #v.trashRows >= 1,
          v.mode .. " / " .. #v.trashRows)
    check("…and it pushes them into the page it is already showing",
          (function()
              for i = #EVALS, evalsBefore + 1, -1 do
                  if EVALS[i]:find('^setRows%("trash"') then return true end
              end
              return false
          end)(), EVALS[#EVALS])
    local binned
    for _, r in ipairs(v.trashRows) do if r.n == "Bin Me" then binned = r end end
    check("🗑 the note he deleted is in it, by name",
          binned ~= nil and binned.f:find("^Bin Me  ") ~= nil,
          binned and binned.f or "not listed")

    -- ---- clicking a row puts it back --------------------------------------
    check("↩️ a click restores by FILE NAME and the note is on disk again",
          (function()
              v.handleMessage({ a = "untrash", bin = binned.f })
              return FILES[VAULT .. "/Bin Me.md"] ~= nil
          end)(), nil)
    check("↩️ …and the bin is not still showing it",
          (function()
              for _, r in ipairs(v.trashRows) do if r.f == binned.f then return false end end
              return true
          end)(), #v.trashRows)
    check("🔢 …counted apart, so the report can be asked",
          (v.untrashes or 0) == 1, tostring(v.untrashes))

    -- 🚨 A MESSAGE WITH NO FILE NAME MUST NOT GUESS. The obvious build
    -- falls through to "the first row", which restores something he did
    -- not click — in the one list whose job is getting the right note
    -- back.
    -- 🚨 AND THE FIRST VERSION OF THIS CHECK COULD NOT FAIL (6.273.0).
    -- It asserted only that nothing was restored — which is true with
    -- the guard DELETED, because _G.vaultRestore finds no row called ""
    -- and refuses by itself. The guard's whole job is the SENTENCE, and
    -- a refusal he cannot act on is a defect even when the refusal is
    -- right (6.320.0). So it asserts the words.
    local n0, a0 = #v.trashRows, #ALERTS
    v.handleMessage({ a = "untrash", bin = "" })
    check("🔒 an empty row name restores NOTHING…",
          #v.trashRows == n0 and (v.untrashes or 0) == 1, #v.trashRows)
    check("…and says so in words he can act on, naming the ROW as the "
          .. "thing that was wrong — not \"nothing in the bin called\"\"\"",
          #ALERTS > a0 and ALERTS[#ALERTS]:find("no file name", 1, true) ~= nil,
          ALERTS[#ALERTS])

    -- 🔕 and the bin never destroys anything: the only door that removes
    -- a file is still the purge (6.321.0), and nothing in the page can
    -- reach it. A purge-forever control one pixel from a restore
    -- control, in the list that exists to prevent loss, is the wrong
    -- button to add.
    -- 🚨 AND THE FIRST VERSION OF THIS CHECK WAS SATISFIED BY ITS OWN
    -- EXPLANATION. It grepped the page for "vaultPurgeTrash" and found
    -- the JS COMMENT above drawTrashRows saying that the purge is the
    -- only door that destroys a file — the sentry matched the sentence
    -- that states the rule it enforces (6.280.0 / 6.262.0, in a page
    -- rather than a module). It reads the MESSAGES the page can send
    -- now, which is what the rule is actually about, and asserts the
    -- comment still exists so it cannot be satisfied by deleting it.
    check("🔒 nothing the PAGE can send destroys a file in the bin",
          (function()
              local sent, bad = {}, nil
              for m in hp:gmatch("a:%s*'([%w_]+)'") do sent[m] = true end
              for _, m in ipairs({ "purge", "erase", "rm", "trashpurge", "destroy" }) do
                  if sent[m] then bad = m end
              end
              if bad then return false, "the page can send a:'" .. bad .. "'" end
              if not sent["untrash"] then return false, "the page cannot restore at all" end
              return true
          end)())
    check("…and the page SAYS why, so the rule cannot be deleted quietly",
          hp:find("only door that destroys a file", 1, true) ~= nil, nil)

    -- 🔎 a bin that could not be READ is not an empty bin (6.196.1)
    local realList = v.trashList
    v.trashList = function() return nil, "the .trash folder could not be read" end
    v.listTrash()
    check("🔎 a bin that cannot be read says so, and does NOT read as empty",
          v.trashErr ~= nil and #v.trashRows == 0
          and EVALS[#EVALS]:find("could not be read", 1, true) ~= nil,
          tostring(v.trashErr))
    v.trashList = realList
    v.listTrash()
    check("…and it clears the moment the folder answers again",
          v.trashErr == nil, tostring(v.trashErr))

    v.setMode("notes")
    v.hide()

    local ran = (pass + fail) - before
    check("§6.335.0 ran all of its checks (" .. ran .. " of 18)", ran >= 18, ran)
end

out("\n6.340.0 — 🔎 A FIRST OPEN IS NOT AN EMPTY VAULT\n")
-- =======================================================================
-- LL: "When I first load Hamsidian, it's blank. Then I escape, open
-- again, and the notes are there." v.render() runs BEFORE v.scan("open"),
-- and the rows only reached the page at finish() — the end of find →
-- links → tags → front matter. So the window sat blank for the whole
-- chain and said "no notes yet — ⌘N" while it did. 6.196.1 for the
-- fourth time, in the tool that holds his writing.
do
    local before = pass + fail

    -- ---- the page is TOLD which of the two states it is in ---------------
    -- 🚨 THE STRIP, NOT THE PAGE: "reading your notes…" is also a string
    -- in drawRows' own source, so a check that greps the whole document
    -- passes with the strip untouched. This reads the one span.
    local function hintOf(h) return h:match('id="hint">([^<]*)') or "" end
    -- earlier sections leave a scan in flight; v.scanning outranks both
    -- states here and would mask the one under test
    -- …and §6.304.0 deliberately leaves a refused scan recorded, which
    -- outranks both states in the strip for the same honest reason
    v.scanning, v.scanErr = false, nil
    v.setNotes({})
    v.lastScan = nil
    local h0 = v.buildHtml()
    check("🔎 an index nobody has read reaches the page as SCANNED = false",
          h0:find("var SCANNED = false", 1, true) ~= nil)
    check("…and the hint strip says reading, not '0 notes'",
          hintOf(h0):find("reading your notes", 1, true) ~= nil
          and hintOf(h0):find("0 notes", 1, true) == nil, hintOf(h0))

    v.setNotes({ "Alpha.md", "Beta.md" })
    v.lastScan = 1700000000
    local h1 = v.buildHtml()
    check("…and a read index reaches it as SCANNED = true, with the count",
          h1:find("var SCANNED = true", 1, true) ~= nil
          and hintOf(h1):find("2 notes", 1, true) ~= nil, hintOf(h1))

    -- ---- THE ROWS GO IN WHEN THE FIND ANSWERS ----------------------------
    -- The names are known after ONE task and the page waited for four.
    -- This is the check that bites: it asserts the push has happened
    -- BEFORE any grep callback is delivered.
    v.openNote("Alpha")
    v.open()
    local W = WEBVIEWS[#WEBVIEWS]
    local mark = #EVALS
    v.rowRefresh = 0
    v.scan("firstopen")
    local ft = lastTask("find")
    ft.cb(0, "/Users/ll/OneDrive/Vault/Alpha.md\n/Users/ll/OneDrive/Vault/Beta.md\n", "")

    local pushedEarly = false
    for i = #EVALS, mark + 1, -1 do
        if EVALS[i]:find("^setIndex%(") then pushedEarly = true break end
    end
    check("🔎 the rows are in the page the moment the FIND answers — "
          .. "not three greps later",
          pushedEarly and v.rowRefresh >= 1, v.rowRefresh .. " refresh(es)")
    check("…and the push carried the notes the find named",
          EVALS[#EVALS]:find("Alpha", 1, true) ~= nil, EVALS[#EVALS]:sub(1, 60))

    -- drain the rest of the chain so the module is left idle
    for _ = 1, 5 do
        local t = lastTask("grep")
        if t and not t.done then t.cb(1, "", "") else break end
    end

    -- ---- 🪟 THE PAGE SAYS WHEN IT EXISTS, AND LUA ANSWERS -----------------
    -- view:html() returns BEFORE WebKit has parsed the document (6.238.0),
    -- so a find that answers inside that window pushes into a page with no
    -- setIndex in it and is dropped in silence. The `ready` handshake is
    -- the belt for exactly that.
    local mark2 = #EVALS
    msg({ a = "ready" })
    local answered = false
    for i = #EVALS, mark2 + 1, -1 do
        if EVALS[i]:find("^setIndex%(") then answered = true break end
    end
    check("🪟 the page saying 'ready' is answered with the index — a push "
          .. "into a page WebKit had not parsed is not lost",
          answered, tostring(#EVALS - mark2) .. " eval(s)")

    -- …and it says NOTHING when there is nothing to say: a ready on a Mac
    -- where no scan has ever completed and no note is known must not push
    -- an empty index and end the reading state for a list still loading.
    local keptNotes, keptScan = v.notes, v.lastScan
    v.notes, v.lastScan = {}, nil
    local mark3 = #EVALS
    msg({ a = "ready" })
    local saidNothing = true
    for i = #EVALS, mark3 + 1, -1 do
        if EVALS[i]:find("^setIndex%(") then saidNothing = false break end
    end
    check("…and a ready with nothing known pushes NO index, so the page "
          .. "keeps saying it is reading",
          saidNothing, tostring(#EVALS - mark3) .. " eval(s)")
    v.notes, v.lastScan = keptNotes, keptScan

    v.hide()

    local ran = (pass + fail) - before
    check("§6.340.0 ran all of its checks (" .. ran .. " of 7)", ran >= 7, ran)
end

out(string.format("\n%d passed, %d failed\n", pass, fail))
os.exit(fail == 0 and 0 or 1)
