-- =====================================================================
-- test_ocr_tag.lua — 🏷 which files does the clipboard point at? 6.98.0
-- =====================================================================
--     lua5.4 test_ocr_tag.lua [/path/to/hammerspoon]
--
-- LL hit this in the Console:
--     🏷 OCR tag: clipboard has file URL(s) but no image files matched
--        ↳ first candidate: no file extension found — raw value:
--          "/.file/id=6571367.18736568/"
-- and asked: "Isn't this non-breaking? If not, do we even need to show
-- that line or only show when it errors?"
--
-- Two things were wrong with the old behaviour, and this suite pins the
-- fixes to the REAL init.lua source (lifted the way test_hyper_key and
-- test_select_mode do, so init.lua and this suite cannot drift):
--
--   T1  "/.file/id=…" is a macOS FILE-REFERENCE path — a file named by
--       id, not by name. It has no extension, so a REAL IMAGE copied
--       that way was skipped. Now it is resolved through the filesystem
--       (realpath) first and judged by its real name — the image OCRs.
--   T2  ERRORS ONLY. Copying non-image files is normal and prints
--       NOTHING now. A line appears only for a genuine anomaly (a
--       supported image that isn't readable, an unresolvable reference
--       path), and it carries the ⚠️ mark so core/console.lua files it
--       under NONBREAKING.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail, failures = 0, 0, {}
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else
        fail = fail + 1
        failures[#failures + 1] = label .. (extra and ("  [" .. tostring(extra) .. "]") or "")
        io.write("   ❌ " .. failures[#failures] .. "\n")
    end
end
local function out(s) io.write(s) end

-- ---- a Mac in tables --------------------------------------------------
local printed = {}
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    printed[#printed + 1] = table.concat(p, " ")
end
local function saidAnything() return #printed > 0 end
local function said(needle)
    for _, l in ipairs(printed) do if l:find(needle, 1, true) then return true end end
end

local CLIPBOARD_ITEMS = {}     -- what readAllData answers
local DISK       = {}          -- path -> "file" (hs.fs.attributes mode)
local REALPATHS  = {}          -- what pathToAbsolute answers
local RESOLVED_ARGS = {}       -- every arg pathToAbsolute was given
local URLPATHS   = {}          -- what pathFromURL answers (6.155.0), keyed by URL
local URL_ARGS   = {}          -- every URL pathFromURL was given

hs = {
    pasteboard = {
        readAllData = function() return CLIPBOARD_ITEMS end,
        readURL     = function() return nil end,
        readString  = function() return nil end,
    },
    fs = {
        attributes = function(path, field)
            if DISK[path] then
                if field == "mode" then return DISK[path] end
                return { mode = DISK[path] }
            end
            return nil
        end,
        pathToAbsolute = function(path)
            table.insert(RESOLVED_ARGS, path)
            return REALPATHS[path]
        end,
        pathFromURL = function(url)
            table.insert(URL_ARGS, url)
            return URLPATHS[url]
        end,
    },
}

-- ---- load the REAL module ---------------------------------------------
-- 6.105.0: this used to cut the block out of init.lua by string search
-- and compile it with stripToQwerty injected. The engine is a module now,
-- so it loads the way Hammerspoon loads it and the real function is
-- called by name — no marker strings, nothing a reformat can break.
-- The rest of the module needs stubs it does not get here (hs.chooser,
-- hs.task); every one of those calls is inside a pcall in the module, on
-- purpose, so setup() completes and the pasteboard reader is reachable.
hs.chooser = { new = function()
    local c = {}
    setmetatable(c, { __index = function() return function(self) return self end end })
    return c
end }
_G.choosers = {}

-- 6.187.0 — the OCR log is quote-aware CSV now, and the module parses it
-- through core's splitter. A stub core without these is a stub that lies
-- about what every module is really handed.
local function csvQuote(value)
    local s = tostring(value or "")
    s = s:gsub('[\r\n]+', ' '):gsub('"', '""')
    return '"' .. s .. '"'
end
local function splitCSVLine(line)
    local out, i, n = {}, 1, #line
    while i <= n + 1 do
        if line:sub(i, i) == '"' then
            local j, buf = i + 1, {}
            while j <= n do
                local c = line:sub(j, j)
                if c == '"' then
                    if line:sub(j + 1, j + 1) == '"' then buf[#buf + 1] = '"'; j = j + 2
                    else break end
                else buf[#buf + 1] = c; j = j + 1 end
            end
            out[#out + 1] = table.concat(buf)
            i = j + 2
        else
            local j = line:find(",", i, true) or (n + 1)
            out[#out + 1] = line:sub(i, j - 1)
            i = j + 1
        end
    end
    return out
end
local CORE = {
    logsDir = "/logs", csvQuote = csvQuote, splitCSVLine = splitCSVLine,
    hostTag = "Test",
    adoptLegacyFile  = function() end,
    warnWriteFailed  = function() end,
    showPopup        = function() end,
    hyperAddShortcut = function() end,
    provide          = function() end,
}

local OCRM = dofile(HS .. "/modules/ocr_engine.lua")
check("the OCR engine module loads", type(OCRM) == "table"
      and type(OCRM.setup) == "function")
local okSetup, setupErr = pcall(OCRM.setup, CORE)
check("...and its setup() completes without a real hs", okSetup, setupErr)
local clipboardImageFilePaths = _G.ocrEngine and _G.ocrEngine.clipboardFiles
check("...and exposes the clipboard reader",
      type(clipboardImageFilePaths) == "function")
printed = {}   -- setup() may print; the checks below count lines

local function reset()
    printed, CLIPBOARD_ITEMS, RESOLVED_ARGS = {}, {}, {}
    DISK, REALPATHS, URLPATHS, URL_ARGS = {}, {}, {}, {}
end

-- =====================================================================
out("\n=== T1. File-reference paths (/.file/id=…) resolve to the real file ===\n")

reset()
DISK["/Users/lee/IMG_0001.heic"] = "file"
REALPATHS["/.file/id=6571367.18736568"] = "/Users/lee/IMG_0001.heic"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=6571367.18736568/" } }
local paths = clipboardImageFilePaths()
check("LL's exact case: the id-named image IS found now",
      #paths == 1 and paths[1] == "/Users/lee/IMG_0001.heic",
      paths[1] or "none")
check("the trailing slash is stripped before resolving",
      RESOLVED_ARGS[1] == "/.file/id=6571367.18736568", RESOLVED_ARGS[1])
check("...and a successful resolve prints nothing", not saidAnything(),
      printed[1])

reset()
DISK["/Users/lee/shot.png"] = "file"
REALPATHS["/.file/id=1.2"] = "/Users/lee/shot.png"
CLIPBOARD_ITEMS = {
    { ["public.file-url"] = "file:///Users/lee/shot.png" },
    { ["public.file-url"] = "file:///.file/id=1.2/" },
}
paths = clipboardImageFilePaths()
check("the same file arriving by name AND by reference is ONE path, not two",
      #paths == 1 and paths[1] == "/Users/lee/shot.png", #paths)

reset()
REALPATHS["/.file/id=9.9"] = "/Users/lee/report.docx"
DISK["/Users/lee/report.docx"] = "file"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=9.9/" } }
paths = clipboardImageFilePaths()
check("a reference that resolves to a NON-image is a normal miss",
      #paths == 0)
check("...and normal misses print nothing", not saidAnything(), printed[1])

out("\n=== T2. Errors only: normal misses are silent, anomalies say so ===\n")

reset()
DISK["/Users/lee/notes.docx"] = "file"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///Users/lee/notes.docx" } }
paths = clipboardImageFilePaths()
check("⌘C on an ordinary non-image file prints NOTHING",
      #paths == 0 and not saidAnything(), printed[1])

reset()
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=404.404/" } }
paths = clipboardImageFilePaths()
check("an UNRESOLVABLE reference path is a real anomaly — one line",
      #paths == 0 and #printed == 1, #printed)
check("...the line carries the ⚠️ mark (Console files it NONBREAKING)",
      printed[1] and printed[1]:find("⚠️", 1, true) == 1, printed[1])
check("...and says the path would not resolve",
      said("would not resolve"))

out("\n=== T3. 6.155.0 — a second route, and a copied FOLDER is not an anomaly ===\n")
-- LL's Console, right after unpacking a release and ⌘C-ing the folder:
--   ⚠️ OCR tag: clipboard file URL(s) matched no usable image — a
--   file-reference path macOS would not resolve — raw value:
--   "/.file/id=6571367.22263352/"

reset()
DISK["/Users/lee/photo.png"] = "file"
URLPATHS["file:///.file/id=5.5/"] = "/Users/lee/photo.png"   -- realpath: nothing
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=5.5/" } }
paths = clipboardImageFilePaths()
check("realpath empty, CoreFoundation answers: the image IS found",
      #paths == 1 and paths[1] == "/Users/lee/photo.png", paths[1] or "none")
check("...asked with the reference as a file URL, slash restored",
      URL_ARGS[1] == "file:///.file/id=5.5/", URL_ARGS[1])
check("...realpath was still asked FIRST", RESOLVED_ARGS[1] == "/.file/id=5.5")
check("...and nothing is printed", not saidAnything(), printed[1])

reset()
DISK["/Users/lee/IMG_0001.heic"] = "file"
REALPATHS["/.file/id=6.6"] = "/Users/lee/IMG_0001.heic"
URLPATHS["file:///.file/id=6.6/"] = "/Users/lee/other.png"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=6.6/" } }
paths = clipboardImageFilePaths()
check("when realpath answers, the second route is not consulted",
      #paths == 1 and paths[1] == "/Users/lee/IMG_0001.heic" and #URL_ARGS == 0,
      #URL_ARGS)

reset()
URLPATHS["file:///.file/id=7.7/"] = "/.file/id=7.7"   -- an answer that is no answer
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=7.7/" } }
paths = clipboardImageFilePaths()
check("a second route that hands the reference back unresolved counts as no answer",
      #paths == 0 and #printed == 1 and said("would not resolve"), printed[1])

reset()
DISK["/.file/id=6571367.22263352"] = "directory"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=6571367.22263352/" } }
paths = clipboardImageFilePaths()
check("LL's exact line: a copied FOLDER by reference is a normal miss — silent",
      #paths == 0 and not saidAnything(), printed[1])

reset()
DISK["/.file/id=8.8"] = "file"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=8.8/" } }
paths = clipboardImageFilePaths()
check("a reference the filesystem CAN stat but nobody can name still speaks, "
      .. "and says what it is", #printed == 1 and said("calls it a file"), printed[1])

reset()
hs.fs.pathFromURL = nil
REALPATHS = {}
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///.file/id=9.9/" } }
paths = clipboardImageFilePaths()
check("a Hammerspoon build without pathFromURL degrades to the old line, no throw",
      #paths == 0 and #printed == 1 and said("would not resolve"), printed[1])
hs.fs.pathFromURL = function(url) table.insert(URL_ARGS, url) return URLPATHS[url] end

reset()
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///Users/lee/ghost.png" } }
paths = clipboardImageFilePaths()   -- .png but nothing at that path
check("a supported image that is NOT readable is also worth one line",
      #paths == 0 and #printed == 1, #printed)
check("...and names the problem", said("not a readable local file"))

reset()
DISK["/Users/lee/two words.png"] = "file"
CLIPBOARD_ITEMS = { { ["public.file-url"] = "file:///Users/lee/two%20words.png" } }
paths = clipboardImageFilePaths()
check("percent-encoded names still decode (unchanged 6.11.x behaviour)",
      #paths == 1 and paths[1] == "/Users/lee/two words.png", paths[1])

out("\n=== T3. The old chatty lines are really gone from the engine ===\n")

-- comments stripped, so a remembering comment can't fake a match
local msrc = io.open(HS .. "/modules/ocr_engine.lua", "r")
local OCR_SRC = msrc and msrc:read("*a") or "" ; if msrc then msrc:close() end
local CODE = ("\n" .. OCR_SRC):gsub("\n%s*%-%-[^\n]*", "\n")
check("the engine source was found", #OCR_SRC > 2000, #OCR_SRC)
check("the 'clipboard has file URL(s) but no image files matched' line is gone",
      CODE:find("no image files matched", 1, true) == nil)
check("the '↳ first candidate' companion line is gone",
      CODE:find("first candidate:", 1, true) == nil)
check("resolution goes through the filesystem (pathToAbsolute is wired in)",
      CODE:find("pathToAbsolute", 1, true) ~= nil)
check("failure paths still print (the errors-only rule keeps its errors)",
      CODE:find("⚠️ OCR tag:", 1, true) ~= nil)

-- =====================================================================
out("\n=== T4. ✍️ 6.115.0 — the entry editor is a WINDOW ===\n")
-- =====================================================================
-- LL: "Edit OCR is too small — give me a window like notepad", and
-- separately "it doesn't come to the front for an immediately editable
-- window, I have to click on it".
--
-- It was hs.dialog.textPrompt: a fixed-size NSAlert wrapped around a
-- ONE-LINE NSTextField. It cannot be resized, cannot scroll, and Return
-- presses the default button rather than inserting a newline — while the
-- thing being edited is OCR output, which is multi-line by nature.
--
-- 🚨 THE FALLBACK IS TESTED AS HARD AS THE WINDOW. This has to work on
-- the managed work Mac, where hs.webview is the piece most likely to be
-- absent, and a rewrite that turned ⇪⇧O into a dead key there would be a
-- worse outcome than the small box ever was.
do
    local DIR = (os.getenv("TMPDIR") or "/tmp"):gsub("/$", "")
                .. "/hs-ocred-" .. tostring(os.time()) .. "-" .. tostring(math.random(9999))
    os.execute("mkdir -p '" .. DIR .. "'")
    local CSVF = DIR .. "/image_text-Test.csv"
    local function putCsv(body)
        local h = io.open(CSVF, "w") ; if h then h:write(body); h:close() end
    end
    local function getCsv()
        local h = io.open(CSVF, "r") ; if not h then return nil end
        local s = h:read("*a"); h:close(); return s
    end

    -- Two entries, the second deliberately multi-line and quote-bearing —
    -- the exact content the one-line field could not show.
    local PROV2 = {}
    putCsv('2026-08-18 09:00:00,"short one"\n'
           .. '2026-08-19 11:17:32,"All Snippets\\nsecond line\\nthird ""quoted"" line"\n')

    -- ---- a Mac WITH a webview ----------------------------------------
    local VIEWS, ALERTS2, PROMPTED = {}, {}, {}
    -- the fake window manager: which hs.window each view answers with,
    -- which one macOS currently calls KEY, and every :focus() asked for
    local WINDOW_FOR, FOCUSED, FOCUS_CALLS = setmetatable({}, { __mode = "k" }), nil, {}
    local nextWinId = 0
    local function mkWindow(becomesKey)
        nextWinId = nextWinId + 1
        local w = { wid = nextWinId }
        function w:id() return self.wid end
        -- A window macOS REFUSES to make key still answers :focus() —
        -- that is the shape of LL's bug, so the stub can play it.
        function w:focus()
            FOCUS_CALLS[#FOCUS_CALLS + 1] = self.wid
            if becomesKey ~= false then FOCUSED = self end
            return true
        end
        return w
    end
    local function mkView(rect)
        local v = { shown = false, front = false, textEntry = nil, html = nil,
                    deleted = false,
                    -- The stub keeps the rect it was CONSTRUCTED with. A
                    -- stub that returned a made-up frame would report the
                    -- box as correctly sized no matter what the module
                    -- asked for, which is the one thing being checked.
                    rect = rect or { x = 0, y = 0, w = 0, h = 0 } }
        function v:windowTitle() return self end
        function v:allowTextEntry(b) self.textEntry = b; return self end
        function v:level() return self end
        function v:behaviorAsLabels() return self end
        function v:html(h) self.html = h; return self end
        function v:show() self.shown = true; return self end
        function v:bringToFront() self.front = true; return self end
        function v:frame(f) if f then self.rect = f end return self.rect end
        function v:delete() self.deleted = true; return self end
        -- 🎯 6.225.0 — THE REAL WEBVIEW ANSWERS THESE, so the stub does
        -- too (6.193.0's rule, and it bit here: the stub had no
        -- hs.timer.doAfter either, which is how the caret chase could
        -- never have been proven right OR wrong).
        v.js = {}
        function v:evaluateJavaScript(code) self.js[#self.js + 1] = code; return self end
        function v:hswindow() return WINDOW_FOR[self] end
        VIEWS[#VIEWS + 1] = v
        return v
    end
    hs.webview = {
        new = function(rect) return mkView(rect) end,
        usercontent = { new = function()
            local u = {} ; function u:setCallback(fn) self.cb = fn; return self end
            return u
        end },
    }
    hs.drawing = { windowLevels = { floating = 25 } }
    hs.screen  = { mainScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1800, h = 1000 } end }
    end }
    -- a timer that FIRES when the suite says so, never on its own
    local PENDING = {}
    hs.timer   = { doEvery = function() return { stop = function() end } end,
                   doAfter = function(secs, fn)
                       local t = { secs = secs, fn = fn, stopped = false }
                       function t:stop() self.stopped = true; return self end
                       PENDING[#PENDING + 1] = t
                       return t
                   end }
    local function runTimers(times)
        for _ = 1, (times or 1) do
            local due = PENDING[#PENDING]
            if not due or due.stopped then return end
            PENDING[#PENDING] = nil
            due.fn()
        end
    end
    hs.window  = { focusedWindow = function() return FOCUSED end }
    hs.alert   = { show = function(m) ALERTS2[#ALERTS2 + 1] = tostring(m) end }
    hs.dialog  = { textPrompt = function(title, msg, deflt)
        PROMPTED[#PROMPTED + 1] = { title = title, msg = msg, deflt = deflt }
        return "Save", "typed into the small box"
    end }
    _G.movablePanels, _G.choosers = {}, {}

    local M2 = dofile(HS .. "/modules/ocr_engine.lua")
    M2.setup({
        logsDir = DIR, hostTag = "Test", csvQuote = csvQuote, splitCSVLine = splitCSVLine,
        adoptLegacyFile  = function() end,
        warnWriteFailed  = function() end,
        showPopup        = function() end,
        hyperAddShortcut = function() end,
        provide          = function(n, f) PROV2[n] = f end,
    })
    local E = _G.ocrEngine
    -- 6.172.1 — ocr.record: the one door into the log for OCR done elsewhere (⇪4)
    check("ocr.record is published", type(PROV2["ocr.record"]) == "function")
    check("ocr.record appends a row ⇪O will read, stripped to plain text, and refuses an empty one",
          PROV2["ocr.record"]("Fr\xE2\x80\x99om a screenshot\nline two") == true
          and PROV2["ocr.record"]("   ") == false
          and (getCsv() or ""):find(',"From a screenshot\\nline two"\n$') ~= nil, getCsv())
    -- 🖼 6.187.0 — the THIRD column: the image the words were read from
    check("ocr.record takes the IMAGE too, and quotes it (a screenshot name may hold a comma)",
          PROV2["ocr.record"]("words here", "/shots/a, b.png") == true
          and (getCsv() or ""):find(',"words here","/shots/a, b.png"\n$') ~= nil, getCsv())
    check("…and a caller with no image still writes the two-column row it always did",
          PROV2["ocr.record"]("no image for this one") == true
          and (getCsv() or ""):find(',"no image for this one"\n$') ~= nil, getCsv())
    check("a path that is not absolute is refused rather than written as a bad link",
          PROV2["ocr.record"]("relative", "shots/a.png") == true
          and (getCsv() or ""):find(',"relative"\n$') ~= nil, getCsv())
    check("v.parseRow reads both shapes, old and new, and never glues the path onto the text",
          (function()
              local ts, t1, p1 = E.parseRow('2026-01-01 00:00:00,"just words"')
              local _,  t2, p2 = E.parseRow('2026-01-01 00:00:00,"just words","/a/b.png"')
              local _,  t3, p3 = E.parseRow('2026-01-01 00:00:00,"a ""quote"", a comma","/a/b,c.png"')
              local _,  t4     = E.parseRow('2026-01-01 00:00:00,"one\\ntwo"')
              return ts == "2026-01-01 00:00:00"
                     and t1 == "just words" and p1 == nil
                     and t2 == "just words" and p2 == "/a/b.png"
                     and t3 == 'a "quote", a comma' and p3 == "/a/b,c.png"
                     and t4 == "one\ntwo"
          end)())
    check("the editor API is exposed", type(E.openEditor) == "function"
          and type(E.applyEdit) == "function"
          and type(E.editorHtml) == "function")

    E.edit()                     -- loads the snapshot from the CSV
    check("⇪⇧O reads both entries out of the CSV", (function()
        local okOpen = E.openEditor(2)
        return okOpen and #VIEWS == 1
    end)(), #VIEWS)

    local v = VIEWS[1]
    check("🎯 the box takes keystrokes — allowTextEntry(true) is what makes "
          .. "an hs.webview able to become the key window at all",
          v and v.textEntry == true)
    check("🎯 ...and it comes to the FRONT on open. This is the 'I have to "
          .. "click on it' report, and it is one call",
          v and v.front == true and v.shown == true)
    check("the window is a real size, not an alert", (function()
        return v and v.rect.w >= 600 and v.rect.h >= 400
    end)(), v and (v.rect.w .. "x" .. v.rect.h))

    local html = v and v.html or ""
    check("🚨 it is a multi-line TEXTAREA — the whole complaint was a "
          .. "one-line field", html:find("<textarea", 1, true) ~= nil)
    check("...with real height, not one row", (function()
        local rows = tonumber(html:match('rows="(%d+)"') or "0")
        return rows >= 8
    end)(), html:match('rows="(%d+)"'))
    check("...and it is FOCUSED by the page itself, caret at the end",
          html:find("t.focus()", 1, true) ~= nil
          and html:find("setSelectionRange", 1, true) ~= nil)
    check("the entry's text is in the box", html:find("All Snippets", 1, true) ~= nil)
    check("🚨 newlines survive into the box — the old control could not "
          .. "even accept a Return, so multi-line OCR was untouchable",
          html:find("second line", 1, true) ~= nil
          and html:find("third", 1, true) ~= nil)
    check("🚨 the text is HTML-ESCAPED — OCR output is arbitrary text off "
          .. "someone's screen, and a stray < would eat the rest of the box",
          html:find("&quot;quoted&quot;", 1, true) ~= nil)
    check("⌘⏎ saves and Esc cancels", html:find("metaKey", 1, true) ~= nil
          and html:find("Escape", 1, true) ~= nil)
    check("there is a Delete button — 'save it empty to delete' is a fine "
          .. "rule and a terrible thing to have to discover",
          html:find("a:'delete'", 1, true) ~= nil)
    check("the header is a drag handle, like every other window here",
          html:find("'drag'", 1, true) ~= nil
          and html:find("hdr", 1, true) ~= nil)
    check("the page talks back on the ocrEdit channel, not another "
          .. "window's", html:find("messageHandlers.ocrEdit", 1, true) ~= nil)

    -- Saving through the real message handler, not by calling applyEdit.
    E.handleEditorMessage({ a = "save", text = "edited text" })
    check("⌘⏎ writes the edit to the CSV",
          (getCsv() or ""):find("edited text", 1, true) ~= nil, getCsv())
    check("...and closes the window", v.deleted == true)
    check("...and the OTHER entry is untouched",
          (getCsv() or ""):find("short one", 1, true) ~= nil)

    -- 🖼 6.187.0 — THE ONE THAT MATTERS. ⇪⇧O rewrites the WHOLE file from a
    -- snapshot, so a snapshot or a writer that knows only two columns strips
    -- the image off EVERY row the first time LL fixes a typo in one of them —
    -- and the write ledger lists this file as rewritten-whole, so the loss
    -- would not even be reported.
    putCsv('2026-08-18 09:00:00,"keep me","/shots/keep.png"\n'
           .. '2026-08-19 09:00:00,"fix me","/shots/fix.png"\n')
    E.edit()
    E.openEditor(1)
    E.handleEditorMessage({ a = "save", text = "fixed" })
    check("editing ONE entry does not strip the image off the OTHERS",
          (getCsv() or ""):find('"fix me","/shots/fix.png"', 1, true) ~= nil, getCsv())
    check("…and the edited entry keeps ITS OWN image too",
          (getCsv() or ""):find('"fixed","/shots/keep.png"', 1, true) ~= nil, getCsv())
    check("…and a two-column row round-trips as two columns, not as an empty third",
          (function()
              putCsv('2026-08-18 09:00:00,"old row, no image"\n'
                     .. '2026-08-19 09:00:00,"edit me"\n')
              E.edit(); E.openEditor(1)
              E.handleEditorMessage({ a = "save", text = "edited" })
              return (getCsv() or ""):find('"edit me"\n', 1, true) ~= nil
                     and (getCsv() or ""):find('"edit me",', 1, true) == nil
          end)(), getCsv())

    -- put the log back the way the next block expects to find it
    putCsv('2026-08-18 09:00:00,"short one"\n'
           .. '2026-08-19 09:00:00,"edited text"\n')

    -- Deleting through the button.
    E.edit()
    E.openEditor(1)
    E.handleEditorMessage({ a = "delete" })
    check("the Delete button removes that entry",
          (getCsv() or ""):find("short one", 1, true) == nil, getCsv())
    check("...and leaves the rest of the log alone",
          (getCsv() or ""):find("edited text", 1, true) ~= nil)

    -- Emptying the box still deletes — the documented rule, kept.
    E.edit()
    E.openEditor(1)
    E.handleEditorMessage({ a = "save", text = "   \n  " })
    check("a box emptied to whitespace still deletes the entry",
          (getCsv() or "") == "" or (getCsv() or ""):find("edited text", 1, true) == nil,
          getCsv())

    -- 🚨 The stale-index bug the non-modal window makes reachable.
    putCsv('2026-08-18 09:00:00,"first"\n2026-08-19 09:00:00,"second"\n')
    E.edit()
    E.openEditor(2)
    local staleView = VIEWS[#VIEWS]
    E.edit()          -- ⇪⇧O again: re-reads the CSV into a NEW snapshot
    check("🚨 pressing ⇪⇧O again CLOSES the open editor. It holds an index "
          .. "into the previous snapshot, and saving it after a reload "
          .. "would overwrite whatever entry now sits at that position",
          staleView.deleted == true)
    E.handleEditorMessage({ a = "save", text = "should go nowhere" })
    check("...so a save from the abandoned box writes nothing",
          (getCsv() or ""):find("should go nowhere", 1, true) == nil, getCsv())

    check("the editor is listed for ⇪⇧W, like every other panel", (function()
        for _, p in ipairs(_G.movablePanels or {}) do
            if (p.name or ""):find("OCR") then return true end
        end
        return false
    end)())

    -- ---- ✍️ 6.213.5: the window is a SERVICE with hooks ---------------
    -- LL's ⇪⇧V report was 6.115.0's two complaints again, in the module
    -- that had kept the prompt. The window answers to hooks now, so any
    -- caller can use it; ocr.openEditor is its first caller.
    check("ocr.openTextEditor exists and is published as editor.open", (function()
        local src = io.open(HS .. "/modules/ocr_engine.lua"):read("a")
        return type(E.openTextEditor) == "function"
           and src:find('core.provide("editor.open",', 1, true) ~= nil
    end)())
    local GOT = {}
    local n0 = #VIEWS
    local okG, whyG = E.openTextEditor({
        title = "✏️ Edit clipboard entry", text = "from the clipboard",
        placeholder = "The copied text.", deleteLabel = "Delete it",
        onSave = function(t) GOT.saved = t end,
        onDelete = function() GOT.deleted = true end,
        onCancel = function() GOT.cancelled = true end,
    })
    local gv = VIEWS[#VIEWS]
    check("a generic open draws the SAME window: front, key, textarea, the caller's words",
          okG == true and #VIEWS == n0 + 1 and gv.front == true and gv.textEntry == true
          and (gv.html or ""):find("<textarea", 1, true) ~= nil
          and (gv.html or ""):find("Edit clipboard entry", 1, true) ~= nil
          and (gv.html or ""):find("from the clipboard", 1, true) ~= nil
          and (gv.html or ""):find('placeholder="The copied text."', 1, true) ~= nil
          and (gv.html or ""):find(">Delete it</button>", 1, true) ~= nil, tostring(whyG))
    E.handleEditorMessage({ a = "save", text = "edited on the way" })
    check("🚨 ⌘⏎ runs the caller's onSave with the text, closes the box, touches no OCR entry",
          GOT.saved == "edited on the way" and gv.deleted == true
          and (getCsv() or ""):find("edited on the way", 1, true) == nil, tostring(GOT.saved))
    E.openTextEditor({ text = "x", onDelete = function() GOT.deleted = true end })
    E.handleEditorMessage({ a = "delete" })
    check("Delete runs the caller's onDelete", GOT.deleted == true)
    E.openTextEditor({ text = "x", onSave = function() GOT.savedAfterCancel = true end,
                       onCancel = function() GOT.cancelled = true end })
    local cv = VIEWS[#VIEWS]
    E.handleEditorMessage({ a = "cancel" })
    E.handleEditorMessage({ a = "save", text = "late" })
    check("Esc runs onCancel, closes the box, and a save after it goes NOWHERE",
          GOT.cancelled == true and cv.deleted == true and GOT.savedAfterCancel == nil)
    check("a hook that THROWS never leaves the box open", (function()
        E.openTextEditor({ text = "x", onSave = function() error("boom") end })
        local bv = VIEWS[#VIEWS]
        E.handleEditorMessage({ a = "save", text = "t" })
        return bv.deleted == true and E.editorView == nil
    end)())

    -- ---- 🎯 6.225.0: THE CARET ----------------------------------------
    -- LL: the edit window "opens front but the caret is not in the box".
    -- bringToFront RAISES a window; it does not make it KEY, and a DOM
    -- focus() inside a window macOS has not made key leaves no caret.
    do
        local mine = 0
        local function ck(label, cond, extra)
            mine = mine + 1; check(label, cond, extra)
        end

        -- 1. the ordinary Mac: the window takes key on the first try
        FOCUS_CALLS, FOCUSED, PENDING = {}, nil, {}
        E.openTextEditor({ text = "hello" })
        local v = VIEWS[#VIEWS]
        WINDOW_FOR[v] = mkWindow(true)
        ck("the box comes up front, and the caret is NOT claimed yet — a "
           .. "page focus() inside a window that is not key is the bug",
           v.front == true and #FOCUS_CALLS == 0
           and E.editorFocusState:find("asking for the caret") ~= nil,
           E.editorFocusState)
        runTimers(1)
        ck("🚨 a turn later LUA focuses the WINDOW — the step the page "
           .. "cannot take for itself",
           #FOCUS_CALLS == 1 and FOCUS_CALLS[1] == WINDOW_FOR[v]:id(),
           #FOCUS_CALLS)
        ck("…and asks the page for the caret again, at the END of the text",
           #v.js == 1 and v.js[1]:find("setSelectionRange", 1, true) ~= nil,
           #v.js)
        ck("…and STOPS once the window is key — no timer left running",
           E.editorFocusState:find("caret placed on try 1") ~= nil
           and #PENDING == 0, E.editorFocusState)
        E.closeEditor()

        -- 2. a window macOS will not make key: bounded, and it SAYS so
        FOCUS_CALLS, FOCUSED, PENDING = {}, nil, {}
        E.openTextEditor({ text = "stubborn" })
        local v2 = VIEWS[#VIEWS]
        WINDOW_FOR[v2] = mkWindow(false)
        runTimers(E.editorFocusTries + 2)
        ck("🚨 a window that never becomes key is tried editorFocusTries "
           .. "times and then GIVES UP — never a timer that lives on",
           #FOCUS_CALLS == E.editorFocusTries and #PENDING == 0,
           #FOCUS_CALLS .. " tries · " .. #PENDING .. " pending")
        ck("…and the state says so in words, not in silence",
           E.editorFocusState:find("gave up after", 1, true) ~= nil,
           E.editorFocusState)
        E.closeEditor()

        -- 3. no hswindow at all — the caret is still asked for
        FOCUS_CALLS, FOCUSED, PENDING = {}, nil, {}
        E.openTextEditor({ text = "no window object" })
        local v3 = VIEWS[#VIEWS]
        WINDOW_FOR[v3] = nil
        runTimers(1)
        ck("🚨 with no hswindow the page is asked ONCE and the chase stops "
           .. "— retrying cannot make a window key that does not exist, "
           .. "and the state names the degrade instead of claiming success",
           #v3.js == 1 and #PENDING == 0
           and E.editorFocusState:find("no hswindow", 1, true) ~= nil,
           E.editorFocusState .. " · pending " .. #PENDING)
        E.closeEditor()

        -- 4. the chase never outlives the window it was chasing
        FOCUS_CALLS, FOCUSED, PENDING = {}, nil, {}
        E.openTextEditor({ text = "closed at once" })
        WINDOW_FOR[VIEWS[#VIEWS]] = mkWindow(false)
        local armed = PENDING[#PENDING]
        E.closeEditor()
        ck("🚨 closing the box STOPS the caret chase — a timer chasing a "
           .. "window that is gone is the 6.196.1 shape",
           armed ~= nil and armed.stopped == true)
        runTimers(1)
        ck("…and even if it fired, it touches nothing and says why",
           #FOCUS_CALLS == 0, #FOCUS_CALLS)

        -- 5. the page still does its own half at load
        FOCUS_CALLS, FOCUSED, PENDING = {}, nil, {}
        E.openTextEditor({ text = "page half" })
        ck("the PAGE still focuses on load — Lua's turn is a second ask, "
           .. "never a replacement",
           (VIEWS[#VIEWS].html or ""):find("t.focus()", 1, true) ~= nil)
        E.closeEditor()

        -- 6. the report says which of the three states this Mac is in
        printed = {}
        E.openTextEditor({ text = "for the report" })
        WINDOW_FOR[VIEWS[#VIEWS]] = mkWindow(true)
        runTimers(1)
        printed = {}
        _G.ocrReport()
        ck("_G.ocrReport() carries the caret's state, in ONE print",
           #printed == 1 and (printed[1] or ""):find("edit box", 1, true) ~= nil
           and (printed[1] or ""):find("caret placed", 1, true) ~= nil,
           printed[1])
        E.closeEditor()

        check("the 6.225.0 caret section ran every one of its checks",
              mine == 11, mine)
    end

    -- ---- a Mac WITHOUT a webview (the managed work Mac) --------------
    hs.webview = nil
    _G.movablePanels, _G.choosers = {}, {}
    putCsv('2026-08-19 11:17:32,"needs the fallback"\n')
    local M3 = dofile(HS .. "/modules/ocr_engine.lua")
    M3.setup({
        logsDir = DIR, hostTag = "Test", csvQuote = csvQuote, splitCSVLine = splitCSVLine,
        adoptLegacyFile  = function() end,
        warnWriteFailed  = function() end,
        showPopup        = function() end,
        hyperAddShortcut = function() end,
        provide          = function() end,
    })
    local E2 = _G.ocrEngine
    PROMPTED = {}
    E2.edit()
    local okFall = E2.openEditor(1)
    check("🚨 no hs.webview falls back to the small prompt rather than "
          .. "doing nothing — a worse box still edits the entry, a dead "
          .. "key does not", okFall == true and #PROMPTED == 1)
    check("...pre-filled with the entry, so the fallback is the same edit",
          PROMPTED[1] and PROMPTED[1].deflt == "needs the fallback",
          PROMPTED[1] and PROMPTED[1].deflt)
    check("...and it actually saves what the prompt returned",
          (getCsv() or ""):find("typed into the small box", 1, true) ~= nil, getCsv())
    local okNo, whyNo = E2.openTextEditor({ text = "x" })
    check("🚨 6.213.5: the SERVICE refuses honestly with no webview — false and why — and"
          .. " never opens a prompt for another module's text",
          okNo == false and tostring(whyNo):find("webview", 1, true) ~= nil
          and #PROMPTED == 1, tostring(whyNo))

    os.execute("rm -rf '" .. DIR .. "'")
end

out("\n=== T5. The one-line prompt is no longer the primary editor ===\n")
check("🚨 the chooser opens the WINDOW, not a prompt — a leftover "
      .. "textPrompt call on the Enter path would keep the old box",
      CODE:find("ocr.openEditor(choice.idx)", 1, true) ~= nil)
check("...and hs.dialog.textPrompt is INVOKED exactly once, in the "
      .. "no-webview fallback", (function()
    -- Counted as calls, not as mentions: the fallback's own failure
    -- message names the function in a string, and a check that counted
    -- occurrences would have to be loosened every time the module
    -- explains itself — which is how a real second call slips back in.
    local _, direct = CODE:gsub("hs%.dialog%.textPrompt%s*%(", "")
    local _, viaPcall = CODE:gsub("pcall%(hs%.dialog%.textPrompt", "")
    return direct == 0 and viaPcall == 1
end)())
check("the editor html is built by the module, not borrowed from another "
      .. "window's channel", CODE:find("messageHandlers.ocrEdit", 1, true) ~= nil)


-- =====================================================================
out("\n=== T6. 🔁 6.170.1 — a 0×0 clipboard image must NEVER reach the Shortcut ===\n")
-- =====================================================================
-- LL, with a screenshot: an "HS OCR · Zero-dimensioned image (0.0 x 0.0)"
-- macOS notification "popping up in an infinite loop". The Shortcuts app
-- posts that when it is handed an empty image, and ocr.image handed it
-- one on EVERY pasteboard tick while an app kept an undecodable image
-- flavor on the clipboard. Guards, in order: busy → held → empty →
-- repeat; a failure holds too; one ⚠️ line per streak.
do
    -- a fresh setup(): T4 loaded the module again, so _G.ocrReport and
    -- the table below must come from the SAME setup
    local M2 = dofile(HS .. "/modules/ocr_engine.lua")
    assert(pcall(M2.setup, CORE))
    local ocr = M2.config
    ocr.autoImage = true                  -- 6.170.2: off by default; T6 tests the guards

    local CLOCK = 1000
    local TASKS = {}
    hs.timer = { secondsSinceEpoch = function() return CLOCK end,
                 doEvery = function() return { stop = function() end } end }
    hs.task  = { new = function(bin, cb, args)
        local t = { bin = bin, cb = cb, args = args }
        function t:start() TASKS[#TASKS + 1] = self ; return true end
        return t
    end }
    local FILEBYTES = 1234
    local realAttr = hs.fs.attributes
    hs.fs.attributes = function(path, field)
        if path == "/tmp/hs_auto_ocr.png" and field == "size" then return FILEBYTES end
        return realAttr(path, field)
    end
    local realRemove = os.remove
    os.remove = function() return true end
    local function img(w, h, saves)
        return { size = function() return { w = w, h = h } end,
                 saveToFile = function() return saves ~= false end }
    end
    _G.ocrShortcutAvailable = true
    printed = {}

    -- the loop itself: ten pasteboard ticks with a 0×0 image
    local words = {}
    for _ = 1, 10 do words[#words + 1] = ocr.image(img(0, 0)) end
    check("🚨 a 0×0 image is never sent to the Shortcut (that IS the notification)",
          #TASKS == 0, #TASKS)
    check("...the first tick says 'empty'", words[1] == "empty", words[1])
    check("...the next nine are 'held' — the quiet lasts ocr.failGrace",
          words[2] == "held" and words[10] == "held", words[2] .. "/" .. words[10])
    check("...and the streak prints ONE ⚠️ line, not ten", #printed == 1
          and said("0×0 image") and said("⚠️"), #printed)
    check("...which names the report", said("_G.ocrReport"))
    CLOCK = CLOCK + ocr.failGrace + 1
    check("after the grace a real image runs", ocr.image(img(800, 600)) == "ran"
          and #TASKS == 1 and TASKS[1].args[4] == "/tmp/hs_auto_ocr.png", #TASKS)
    check("...while it runs a second image is 'busy' — one process at a time",
          ocr.image(img(800, 600)) == "busy" and #TASKS == 1)
    check("...and the task is HELD in ocr.imageTask", ocr.imageTask == TASKS[1])
    TASKS[1].cb(0, "hello world", "")
    check("a clean exit frees the slot and files the words", ocr.imageTask == nil
          and ocr.imageStats.ran == 1)
    printed = {}
    check("the SAME image again within repeatGrace is 'repeat', not sent",
          ocr.image(img(800, 600)) == "repeat" and #TASKS == 1)
    FILEBYTES = 4321
    check("...a different image (other bytes) is sent",
          ocr.image(img(800, 600)) == "ran" and #TASKS == 2)
    TASKS[2].cb(1, "", "Error: Zero-dimensioned image (0.0 x 0.0)")
    check("a failed Shortcut run holds too, with the Shortcut's first line",
          ocr.imageStats.failed == 1 and ocr.image(img(640, 480)) == "held"
          and said("Zero-dimensioned") and said("exit 1"), printed[1])
    check("...one ⚠️ line for that streak", #printed == 1, #printed)
    CLOCK = CLOCK + ocr.failGrace + 1
    check("...and it runs again after the grace", ocr.image(img(640, 480)) == "ran")
    check("an image whose size cannot be read counts as empty",
          (function() ocr.imageTask = nil; CLOCK = CLOCK + 100
                      return ocr.image({ size = function() error("no") end,
                                         saveToFile = function() return true end }) end)()
          == "empty")
    printed = {}
    local st = _G.ocrReport()
    check("_G.ocrReport() prints the counters", type(st) == "table" and #printed == 1
          and said("empty 2") and said("failed 1") and said("6.170.2"), printed[1])
    check("the poll in init.lua still routes images through ocr.image (the only caller)",
          (function()
              local h = io.open(HS .. "/init.lua", "r"); local src = h:read("*a"); h:close()
              return src:find('_G.service.call("ocr.image", img)', 1, true) ~= nil
          end)())

    hs.fs.attributes, os.remove = realAttr, realRemove

    out("\n=== T7. 🛑 6.170.2 — raw clipboard image OCR is OFF unless a profile turns it on ===\n")
    local M3 = dofile(HS .. "/modules/ocr_engine.lua"); M3.setup(CORE); local o3 = M3.config
    check("ocr.autoImage defaults to false", o3.autoImage == false)
    TASKS = {}; printed = {}
    check("with it off, ocr.image returns \"off\", starts no task and prints nothing",
          o3.image(img(800, 600)) == "off" and #TASKS == 0 and #printed == 0 and o3.imageStats.off == 1)
    check("_G.ocrReport() says OFF and names the settings knob",
          (function() _G.ocrReport(); return said("OFF") and said("ocr_engine = { autoImage = true }") end)(), printed[1])
    o3.autoImage = true; CLOCK = CLOCK + 100
    check("a profile override (settings = { ocr_engine = { autoImage = true } }) turns it back on",
          o3.image(img(800, 600)) == "ran" and #TASKS == 1)
    local h = io.open(HS .. "/init.lua", "r"); local src = h:read("*a"); h:close()
    local body = src:match("local function clipboardPoll%(%).-\nend\n_G%.clipboardTimer") or ""
    check("init.lua's poll asks typesAvailable() before readImage()",
          (function() local a = body:find("hs.pasteboard.typesAvailable(", 1, true); local b = body:find("hs.pasteboard.readImage(", 1, true)
                      return a and b and a < b end)())
    check("...and carries the thrash breaker (ticks in a row → rest, one ⚠️ line, a report)",
          body:find("_G.clipboardThrashTicks", 1, true) ~= nil
          and body:find("_G.clipboardThrashRest", 1, true) ~= nil
          and body:find("ticks in a row", 1, true) ~= nil
          and src:find("function _G.clipboardPollReport()", 1, true) ~= nil
          and body:find("thrashRun = 0", 1, true) ~= nil)
    check("...the counter is advanced BEFORE the breaker returns, so nothing is filed twice",
          (function() local a = body:find("lastChangeCount = currentChangeCount", 1, true)
                      local b = body:find("nowT < thrashUntil", 1, true); return a and b and a < b end)())
end

do
    out("\n=== T8. 6.170.3 — the poll asks ocr.imageWanted before it decodes anything ===\n")
    local M4 = dofile(HS .. "/modules/ocr_engine.lua"); M4.setup(CORE); local o4 = M4.config
    check("imageWanted is false while autoImage is off", o4.imageWanted() == false)
    o4.autoImage = true
    check("…true once a profile turns image OCR on", o4.imageWanted() == true)
    o4.imageTask = {}
    check("…false while a Shortcut run is in flight (busy)", o4.imageWanted() == false)
    o4.imageTask = nil; o4.imageHoldUntil = os.time() + 1e6
    check("…false while resting after a failure / empty image", o4.imageWanted() == false)
    o4.imageHoldUntil = 0
    check("…and true again after the rest", o4.imageWanted() == true)
    local h = io.open(HS .. "/init.lua", "r"); local src = h:read("*a"); h:close()
    local body = src:match("local function clipboardPoll%(%).-\nend\n_G%.clipboardTimer") or ""
    local a = body:find('_G.service.call("ocr.imageWanted")', 1, true)
    local b = body:find("hs.pasteboard.readImage(", 1, true)
    check("init.lua's poll consults ocr.imageWanted BEFORE readImage()", a and b and a < b)
    check("…and readImage() is gated on that answer", body:find("wanted and hs.pasteboard.readImage(", 1, true) ~= nil)
    local sh = io.open(HS .. "/modules/screenshots.lua", "r"); local ss = sh:read("*a"); sh:close()
    check("screenshots.lua no longer pushes a decoded shot through writeObjects in finish()",
          (ss:match("function shots%.finish%(.-\n    end\n") or ""):find("writeObjects", 1, true) == nil)
    check("…the osascript copy is an hs.task, never hs.execute / hs.osascript",
          ss:find('hs.task.new("/usr/bin/osascript"', 1, true) ~= nil
          and ss:find("hs.osascript", 1, true) == nil and ss:find("hs.execute(", 1, true) == nil)
    check("…an interactive capture (-i) and the area selector both call shots.expectHyperRelease()",
          select(2, ss:gsub("shots%.expectHyperRelease%(%)", "")) >= 2
          and ss:find('_G.hyperExpectRelease, 1.5, "the screenshot tool"', 1, true) ~= nil)
end

-- =====================================================================
out("\n-- ⇪O opens the ⇪space panel (6.190.0) --\n")
-- =====================================================================
-- LL: "make the histories match unified search." ⇪space already renders
-- this exact log as its @ocr source. ⇪⇧O stays a chooser — it EDITS
-- entries, and the panel is a reader.
do
    local E = _G.ocrEngine
    local asked, calls = {}, 0
    _G.service = { has = function(n) return n == "unified.show" end,
                   -- ⚠️ RETURNS TRUE — what uni.show really returns when
                   -- it opens. This stub returned NOTHING until 6.193.0
                   -- and the suite was green over the exact shape that
                   -- made the key dead on LL's Mac.
                   call = function(_, arg) calls = calls + 1
                                           asked[#asked + 1] = arg
                                           return true end }
    check("⇪O asks the panel first", E.openInPanel() == true and calls == 1)
    check("...prefilled on this log's own source", asked[1] == "@ocr ", asked[1])

    -- 🚨 THE DEGRADE, asked at PRESS time and never cached: unified_search
    -- can fail to load, and a cached answer would strand ⇪O all session.
    _G.service = { has = function() return false end, call = function() end }
    check("🚨 with the panel unavailable it returns FALSE so ⇪O falls back "
          .. "to the chooser", E.openInPanel() == false)
    check("...and says why", tostring(E.panelWhy or ""):find("not loaded", 1, true) ~= nil,
          E.panelWhy)

    -- 🚨 6.193.0, THE ONE THAT BIT: nothing returned at all (uni.show
    -- returns nil when unified search is off). The old guard tested
    -- `== false` and let this through as success, so ⇪O opened neither.
    _G.service = { has = function() return true end, call = function() end }
    check("🚨 a provider that returns NOTHING falls back too — the key must "
          .. "never do nothing", E.openInPanel() == false)

    _G.service = { has = function() return true end, call = function() return false end }
    check("a panel that REFUSES to open also falls back", E.openInPanel() == false)

    _G.service = { has = function() return true end, call = function() error("boom") end }
    local ok, res = pcall(E.openInPanel)
    check("🚨 a panel that THROWS does not take ⇪O down with it",
          ok and res == false, res)

    check("the rollback flag exists and is on by default", E.panel == true)
    _G.service = nil
end

-- =====================================================================
out("\n=== T8. 🔤 6.226.0 — the junk filter: singles out, everything else kept ===\n")
-- =====================================================================
-- LL, with a page of his own OCR log: "just remove single characters;
-- anything two or more characters together is retained." And the bound
-- he set himself: if a method can introduce errors, singles only. So
-- this is TIER 1 alone — no dictionary vote, no digit/letter splitting,
-- nothing that can turn a real word into a different one.
do
    local mine = 0
    local function ck(label, cond, extra) mine = mine + 1; check(label, cond, extra) end

    local DIR8 = (os.getenv("TMPDIR") or "/tmp"):gsub("/$", "")
                 .. "/hs-junk-" .. tostring(os.time()) .. "-" .. tostring(math.random(9999))
    os.execute("mkdir -p '" .. DIR8 .. "'")
    local CSV8 = DIR8 .. "/image_text-Test.csv"
    local function put8(body) local h = io.open(CSV8, "w"); if h then h:write(body); h:close() end end
    local function get8() local h = io.open(CSV8, "r"); if not h then return nil end
        local t = h:read("*a"); h:close(); return t end

    hs.webview = nil
    _G.movablePanels, _G.choosers = {}, {}
    local PROV8 = {}
    local M8 = dofile(HS .. "/modules/ocr_engine.lua")
    M8.setup({
        logsDir = DIR8, hostTag = "Test", csvQuote = csvQuote, splitCSVLine = splitCSVLine,
        adoptLegacyFile = function() end, warnWriteFailed = function() end,
        showPopup = function() end, hyperAddShortcut = function() end,
        provide = function(n, f) PROV8[n] = f end,
    })
    local E8 = _G.ocrEngine

    -- ---- the PURE rule -------------------------------------------------
    ck("a one-character token goes", E8.isJunkToken("l") and E8.isJunkToken("x"))
    ck("🚨 …but a DIGIT stays — a lone 7 is a page number, and his rule "
       .. "names characters, not noise",
       E8.isJunkToken("7") == false)
    ck("…and so do I and a, which are real English words",
       E8.isJunkToken("I") == false and E8.isJunkToken("a") == false)
    ck("a punctuation-only token goes AT ANY LENGTH — |, ---, ..., •••",
       E8.isJunkToken("|") and E8.isJunkToken("---")
       and E8.isJunkToken("...") and E8.isJunkToken("•••"))
    ck("🚨 two characters or more is KEPT EXACTLY, misspelt or not — lUE, "
       .. "ido and dic are his TIER 2 and this release does not touch them",
       E8.isJunkToken("lUE") == false and E8.isJunkToken("ido") == false
       and E8.isJunkToken("dic") == false and E8.isJunkToken("of") == false)
    ck("🚨 one CHARACTER, not one byte: é is TWO BYTES and one character, "
       .. "so it is a single and goes",
       E8.isJunkToken("\xC3\xA9") == true)
    ck("…and a two-character accented word survives — été, día, señor",
       E8.isJunkToken("\xC3\xA9t") == false
       and E8.isJunkToken("d\xC3\xADa") == false)
    ck("…an em dash and an ellipsis are punctuation even though they are "
       .. "not ASCII — U+2000–U+2FFF and U+0080–U+00BF are removed before "
       .. "the question is asked",
       E8.isJunkToken("\xE2\x80\x94") == true      -- —
       and E8.isJunkToken("\xE2\x80\xA6") == true  -- …
       and E8.isJunkToken("\xC2\xB7") == true)      -- ·
    ck("🚨 A NON-LATIN WORD IS A WORD, not punctuation: Lua's %w is ASCII "
       .. "only, so without the high-byte clause this filter would delete "
       .. "every word of every Cyrillic, Greek or CJK reading",
       E8.isJunkToken("\xD0\xB4\xD0\xB0") == false
       and E8.isJunkToken("\xE6\x97\xA5\xE6\x9C\xAC") == false)

    -- ---- whole readings -------------------------------------------------
    local cleaned, dropped = E8.cleanText("All l Snippets | of\nthe x list")
    ck("🚨 NEWLINES SURVIVE — a 40-line reading must not become one "
       .. "paragraph (tokens split on SPACES only)",
       cleaned == "All Snippets of\nthe list", cleaned:gsub("\n", "⏎"))
    ck("…and the dropped tokens are counted", dropped == 3, dropped)
    ck("a line left with nothing is dropped whole, and the lines around it "
       .. "close up",
       (E8.cleanText("real words\n| x |\nmore words")) == "real words\nmore words",
       (E8.cleanText("real words\n| x |\nmore words")):gsub("\n", "⏎"))
    ck("a reading that is ALL junk comes back empty",
       (E8.cleanText("| x - •")) == "")
    ck("a clean reading is returned untouched, with nothing dropped",
       (E8.cleanText("two or more words here")) == "two or more words here"
       and select(2, E8.cleanText("two or more words here")) == 0)

    -- ---- the ONE door ----------------------------------------------------
    put8("")
    ck("ocr.record files the CLEANED text, not what OCR read",
       PROV8["ocr.record"]("Hello l there | world") == true
       and (get8() or ""):find(',"Hello there world"\n$') ~= nil, get8())
    ck("🚨 a reading that is nothing but junk is NOT written at all, and "
       .. "the call says false rather than pretending it filed something",
       PROV8["ocr.record"]("| x - •") == false
       and select(2, (get8() or ""):gsub("\n", "")) == 1, get8())
    ck("…and it is COUNTED — a silent drop is a reading he could never "
       .. "account for",
       E8.junkStats.emptied == 1 and E8.junkStats.tokens >= 2,
       E8.junkStats.emptied .. "/" .. E8.junkStats.tokens)
    E8.junkFilter = false
    ck("the off switch really is off — the row lands as OCR read it",
       PROV8["ocr.record"]("raw l row") == true
       and (get8() or ""):find(',"raw l row"\n$') ~= nil, get8())
    E8.junkFilter = true

    -- ---- the one-shot clean ----------------------------------------------
    put8('2026-09-01 09:00:00,"Good l line","/shots/a.png"\n'
         .. '2026-09-01 09:01:00,"| x •"\n'
         .. '2026-09-01 09:02:00,"already clean"\n')
    printed = {}
    local dry = _G.ocrCleanHistory()
    ck("🚨 the clean is a DRY RUN unless told otherwise — it says what it "
       .. "would do and changes NOTHING (this is his text)",
       dry.rows == 2 and dry.emptied == 1
       and (get8() or ""):find("Good l line", 1, true) ~= nil, get8())
    ck("…and it says so out loud, in one print",
       #printed == 1 and (printed[1] or ""):find("nothing was changed", 1, true) ~= nil,
       printed[1])
    printed = {}
    _G.ocrCleanHistory(true)
    local after = get8() or ""
    ck("the real run rewrites the log: the junk token is gone",
       after:find('"Good line"', 1, true) ~= nil
       and after:find("Good l line", 1, true) == nil, after)
    ck("🚨 …and the IMAGE PATH rides through the rewriter — a two-column "
       .. "rewriter would strip it off every row it touched (6.187.0)",
       after:find('"/shots/a.png"', 1, true) ~= nil, after)
    ck("…the all-junk row is removed, the clean row untouched",
       after:find("already clean", 1, true) ~= nil
       and after:find("09:01:00", 1, true) == nil, after)
    ck("…and the run says what it did", #printed == 1
       and (printed[1] or ""):find("rewritten", 1, true) ~= nil, printed[1])

    printed = {}
    _G.ocrReport()
    ck("_G.ocrReport() carries the junk line and the clean command, still "
       .. "in ONE print", #printed == 1
       and (printed[1] or ""):find("junk", 1, true) ~= nil
       and (printed[1] or ""):find("ocrCleanHistory", 1, true) ~= nil, printed[1])

    os.execute("rm -rf '" .. DIR8 .. "'")
    check("T8 ran every one of its checks", mine == 25, mine)
end

out(("\n── test_ocr_tag: %d passed, %d failed\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
