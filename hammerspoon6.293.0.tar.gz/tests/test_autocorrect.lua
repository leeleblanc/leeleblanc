-- Run from anywhere:  lua5.4 <this file> [path to ~/.hammerspoon]
local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

-- =====================================================================
-- Harness for AUTOCORRECT. Drives the REAL event tap with real key
-- events and reads back what it typed.
--
-- 🚨 WHY THIS SUITE EXISTS, WRITTEN IN 6.69.0 AND OVERDUE.
-- Autocorrect has run on LL's Mac since 6.10.0 against an ~11,000-row
-- dictionary and had NO behavioural test of any kind — the other suites
-- only ever checked that the module loaded and deferred its CSV. The
-- TWo-caps rule in particular is one line of Lua pattern:
--
--     word:match("^%u%u%l")
--
-- and LL's own description of what it must do is precise enough to test
-- directly: "USa" is turned into "Usa", and only if it is three capitals
-- is it left alone — "USA". Three capitals cause nothing to change. Two
-- capitals cause a change from SAt to Sat.
--
-- That got a suite the moment a SECOND event tap started sharing the
-- keyboard with it. Two taps on one keystroke stream is exactly the
-- arrangement where a rule this quiet breaks without anyone noticing.
-- =====================================================================

local TMP = os.tmpname()
os.remove(TMP)
os.execute("mkdir -p '" .. TMP .. "'")

local KEYSTROKES, DELETES, log = {}, 0, {}
local TAP, FRONTAPP = nil, "TextEdit"
local SECURE = false
local ALERTS, TIMERS = {}, {}
local BOUND = {}

hs = {
  eventtap = {
    -- 🚨 6.200.0 — every real Mac answers this; the dictionary check asks
    -- before it rewrites a word, and treats "cannot answer" as locked.
    isSecureInputEnabled = function() return SECURE end,
    event = { types = { keyDown = 10, leftMouseDown = 1, rightMouseDown = 3 } },
    new = function(types, fn)
      TAP = { types = types, fn = fn, on = false }
      function TAP:start() self.on = true end
      function TAP:stop() self.on = false end
      function TAP:isEnabled() return self.on end
      return TAP
    end,
    keyStroke = function(mods, key)
      if key == "delete" then DELETES = DELETES + 1 end
    end,
    keyStrokes = function(s) table.insert(KEYSTROKES, s) end,
  },
  timer = {
    secondsSinceEpoch = function() return 1000.4231 end,
    doAfter = function(d, fn)
      local t = { delay = d, fn = fn, running = true }
      function t:stop() self.running = false end
      table.insert(TIMERS, t); return t
    end,
    doEvery = function(d, fn)
      local t = { delay = d, fn = fn, running = true }
      function t:stop() self.running = false end
      return t
    end,
  },
  application = {
    frontmostApplication = function()
      return { name = function() return FRONTAPP end }
    end,
  },
  hotkey = { bind = function(mods, key, fn)
    BOUND[table.concat(mods or {}, "+") .. "+" .. tostring(key)] = fn
  end },
  alert = { show = function(m) table.insert(ALERTS, m) end },
  accessibilityState = function() return true end,
  configdir = TMP,
}

print = function(...)
  local p = {}
  for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
  table.insert(log, table.concat(p, " "))
end

-- The REAL shared injection guard, lifted out of core/coexist.lua rather
-- than reimplemented — the point of the guard is that both taps agree,
-- and a private copy here would agree with itself.
local INJECT_PEAK = 0
do
  local f = io.open(HS .. "/core/coexist.lua", "r")
  local src = f and f:read("*a") or ""; if f then f:close() end
  local block = src:match("(_G%.injectDepth = 0.-\n    return ok, err\nend)")
  assert(block, "could not find the injection guard in core/coexist.lua")
  local sb = { hs = hs, pcall = pcall, math = math, type = type,
               print = function() end }
  sb._G = sb
  load(block, "guard", "t", sb)()
  _G.typingInjection = function() return sb.typingInjection() end
  _G.withInjection = function(fn)
    local r = { sb.withInjection(fn) }
    if sb.injectDepth + 1 > INJECT_PEAK then INJECT_PEAK = sb.injectDepth + 1 end
    return table.unpack(r)
  end
end

_G.diag = { say = function() end, warn = function() end, err = function() end }

local core = {
  logsDir = TMP,
  adoptLegacyFile = function() end,
  popupKeys = { mods = { "ctrl", "alt", "cmd" } },
  warnWriteFailed = function() end,
  splitCSVLine = function(line)
    local out = {}
    for seg in (line .. ","):gmatch("([^,]*),") do out[#out + 1] = seg end
    return out
  end,
}

local mod = dofile(HS .. "/modules/autocorrect.lua")
mod.setup(core)
if mod.warm then mod.warm(core) end     -- reads the seeded CSV

local out = io.write
local pass, fail = 0, 0
local function check(name, cond, detail)
  if cond then pass = pass + 1; out("  ✅ ", name, "\n")
  else fail = fail + 1; out("  ❌ ", name, " — ", tostring(detail or ""), "\n") end
end

-- Type a string through the real tap. Returns the text it typed back, or
-- nil if it left the word alone.
local function press(code)
  TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
           getFlags = function() return {} end,
           getKeyCode = function() return code end,
           getCharacters = function() return "" end })
end
local function keyIn(ch)
  TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
           getFlags = function() return {} end,
           getKeyCode = function() return 0 end,
           getCharacters = function() return ch end })
end
local function runShortTimers()
  for _, t in ipairs(TIMERS) do
    if t.running and (t.delay or 0) < 0.1 then t.fn() end
  end
end
-- 🚨 6.218.0 — THIS HARNESS PLAYS macOS. hs.eventtap.keyStrokes POSTS
-- its keys: they reach the tap AFTER the call returns, looking exactly
-- like typing. So after the injection timer runs, every delete and
-- every retyped character is delivered BACK INTO THE TAP, the way LL's
-- Mac delivered them on 6.216.0 — a stub that swallowed them could not
-- see the doesnt ⇄ doesn storm (6.193.0's rule, fourth costume). The
-- guard's own 0.3 s hold timer is never run here: the count must let go.
-- `hold` = true skips the delivery, for §9's dropped-key row.
local function deliver(nDel, text)
  for _ = 1, nDel do press(51) end
  for ch in text:gmatch(".") do keyIn(ch) end
end
local function typeWord(s, hold)
  KEYSTROKES, DELETES, TIMERS = {}, 0, {}
  for ch in s:gmatch(".") do keyIn(ch) end
  -- The fix is injected on a short timer, the same as the expander's.
  runShortTimers()
  if not hold and KEYSTROKES[1] then
    local nDel, text = DELETES, KEYSTROKES[1]
    TIMERS = {}
    deliver(nDel, text)
    runShortTimers()     -- a second injection, if the retype was read back
  end
  return KEYSTROKES[1]
end

-- =====================================================================
out("\n=== 1. The TWo-caps rule, exactly as LL describes it ===\n")
-- "if the first two letters are capitals like this USa it is turned into
--  Usa, and only if it is three capitals is it left alone USA. Three
--  capitals cause nothing to change. Two capitals cause a change from
--  SAt to Sat."
check("USa → Usa", typeWord("USa ") == "Usa ", typeWord("USa "))
check("SAt → Sat", typeWord("SAt ") == "Sat ", typeWord("SAt "))
check("THe → The", typeWord("THe ") == "The ")
check("MAn → Man", typeWord("MAn ") == "Man ")

out("\n  1b. 🚨 THREE CAPITALS CHANGE NOTHING\n")
check("USA is left alone", typeWord("USA ") == nil, typeWord("USA "))
check("OCLC is left alone", typeWord("OCLC ") == nil, typeWord("OCLC "))
check("SAC is left alone", typeWord("SAC ") == nil, typeWord("SAC "))
check("🚨 AND A THREE-CAP WORD WITH A LOWERCASE TAIL IS NOT AN ACRONYM. "
   .. "USAf reads as a typo of USAF, and the rule only ever looks at the "
   .. "first three characters — so it stays out of it",
  typeWord("USAf ") == nil, typeWord("USAf "))

out("\n  1c. the rule needs a THIRD letter before it can decide\n")
check("a two-letter all-caps word is untouched — there is no third "
   .. "character to tell an acronym from a typo", typeWord("US ") == nil,
   typeWord("US "))
check("...and so is a single capital", typeWord("A ") == nil)
check("🚨 TV's KEEPS ITS APOSTROPHE. The rule needs a third LETTER, and "
   .. "the apostrophe ends the word before one arrives — otherwise every "
   .. "acronym possessive would be corrected",
  typeWord("TV's ") == nil, typeWord("TV's "))
check("lowercase words are not the rule's business", typeWord("the ") == nil)
-- ⚠️ ONE GUARD IN autocorrectFor IS NOT REACHABLE FROM HERE, and saying so
-- is better than pretending otherwise: the rule also requires
-- word:match("^%a+$"), but the tap only ever puts LETTERS in the buffer
-- (a digit clears it, see §3), so that condition is always true by the
-- time it is read. Removing it changes nothing observable. It is correct
-- defensive code guarding an invariant enforced one layer up — worth
-- keeping, and not something this suite can prove.
check("...nor is a normally capitalised one", typeWord("The ") == nil)

out("\n  1d. exceptions are honoured\n")
-- Seeded into autocorrect.csv by the module itself on first boot.
check("IDs is a real plural, not a typo", typeWord("IDs ") == nil, typeWord("IDs "))
check("TVs likewise", typeWord("TVs ") == nil)
check("MHz likewise", typeWord("MHz ") == nil)
check("🚨 BUT ITs IS NOT ON THE LIST, on purpose — it is a typo of Its far "
   .. "more often than a plural of IT", typeWord("ITs ") == "Its ",
   typeWord("ITs "))

-- =====================================================================
out("\n=== 2. The dictionary, and your capitalisation ===\n")
check("mna → man", typeWord("mna ") == "man ", typeWord("mna "))
check("Mna → Man (leading capital preserved)", typeWord("Mna ") == "Man ",
  typeWord("Mna "))
check("MNA → MAN (all caps preserved)", typeWord("MNA ") == "MAN ",
  typeWord("MNA "))
check("teh → the", typeWord("teh ") == "the ")
check("a word that is not in the dictionary is left alone",
  typeWord("hello ") == nil)
check("the boundary character is retyped after the fix, so the space you "
   .. "pressed still arrives", (typeWord("teh ") or ""):sub(-1) == " ")
check("...and the wrong word is deleted first, one backspace per letter",
  (function() typeWord("teh "); return DELETES == 3 end)(), DELETES)

out("\n  2b. which boundary characters end a word\n")
for _, b in ipairs({ ".", ",", ";", ":", "!", "?", ")", "-", "/", "'" }) do
  check("'" .. b .. "' ends a word", typeWord("teh" .. b) == "the" .. b,
        typeWord("teh" .. b))
end

-- =====================================================================
out("\n=== 3. What abandons the word ===\n")
check("an arrow key abandons it — the cursor moved and we cannot know "
   .. "where the word now is", (function()
    KEYSTROKES, DELETES, TIMERS = {}, 0, {}
    for ch in ("teh"):gmatch(".") do
      TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
               getFlags = function() return {} end,
               getKeyCode = function() return 0 end,
               getCharacters = function() return ch end })
    end
    press(123)                      -- left arrow
    return typeWord(" ") == nil
  end)())
check("a ⌘ chord abandons it", (function()
    KEYSTROKES, TIMERS = {}, {}
    for ch in ("teh"):gmatch(".") do
      TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
               getFlags = function() return {} end,
               getKeyCode = function() return 0 end,
               getCharacters = function() return ch end })
    end
    TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
             getFlags = function() return { cmd = true } end,
             getKeyCode = function() return 9 end,
             getCharacters = function() return "v" end })
    return typeWord(" ") == nil
  end)())
check("digits abandon it — a token with a number in it is not a word",
  typeWord("teh1 ") == nil, typeWord("teh1 "))
check("an excluded app is never corrected", (function()
    FRONTAPP = "Terminal"
    local r = typeWord("teh ")
    FRONTAPP = "TextEdit"
    return r == nil
  end)())
check("...and the very next app is", typeWord("teh ") == "the ")
check("the off switch stops it dead", (function()
    _G.autocorrectEnabled = false
    local r = typeWord("teh ")
    _G.autocorrectEnabled = true
    return r == nil
  end)())

-- =====================================================================
out("\n=== 4. 6.69.0 — sharing the keyboard with the text expander ===\n")
check("🚨 AUTOCORRECT'S OWN TYPING GOES THROUGH THE SHARED GUARD, so the "
   .. "expander's tap stands down while a correction is retyped — "
   .. "otherwise a spelling fix ending in a trigger fires a snippet",
  (function()
    INJECT_PEAK = 0
    typeWord("teh ")
    return INJECT_PEAK > 0
  end)(), INJECT_PEAK)
check("...and the guard is released again", _G.typingInjection() == false)

check("🚨 AND AUTOCORRECT IGNORES KEYSTROKES THE EXPANDER IS TYPING. "
   .. "Without this, expanding `hte` into \"the\" fed a word nobody typed "
   .. "into an 11,000-row dictionary", (function()
    KEYSTROKES, TIMERS = {}, {}
    _G.withInjection(function()
      for ch in ("teh "):gmatch(".") do
        TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
                 getFlags = function() return {} end,
                 getKeyCode = function() return 0 end,
                 getCharacters = function() return ch end })
      end
    end)
    for _, t in ipairs(TIMERS) do if t.running then t.fn() end end
    return #KEYSTROKES == 0
  end)(), KEYSTROKES[1])

check("_G.autocorrectResetBuffer exists for the expander to call",
  type(_G.autocorrectResetBuffer) == "function")
check("🚨 AND IT REALLY EMPTIES THE WORD. The expander CONSUMES a "
   .. "trigger's last character, so this module is left holding the front "
   .. "of a word that is no longer on screen — 'ht' from 'hte', which "
   .. "would go on to join whatever you type next",
  (function()
    KEYSTROKES, TIMERS = {}, {}
    for ch in ("te"):gmatch(".") do        -- "teh" minus the eaten "h"
      TAP.fn({ getType = function() return hs.eventtap.event.types.keyDown end,
               getFlags = function() return {} end,
               getKeyCode = function() return 0 end,
               getCharacters = function() return ch end })
    end
    _G.autocorrectResetBuffer()
    -- If the buffer had survived, "te" + "h" would make "teh" and fix.
    return typeWord("h ") == nil
  end)())
check("...and the text expander actually calls it", (function()
    local f = io.open(HS .. "/modules/text_expander.lua")
    local s = f:read("*a"); f:close()
    s = s:gsub("%-%-[^\n]*", "")       -- comments discuss it freely
    return s:find("_G.autocorrectResetBuffer", 1, true) ~= nil
  end)())

-- =====================================================================
out("\n=== 5. The tap itself ===\n")
check("the tap was started", TAP.on == true)
check("it is held in a global so the GC cannot collect it",
  _G.autocorrectTap == TAP)
check("a watchdog exists to revive it when macOS switches it off",
  _G.autocorrectWatchdog ~= nil)
check("the dictionary is deferred to warm(), off the boot path",
  type(mod.warm) == "function")
check("...and it really loaded", (_G.autocorrectStatus or ""):find("fixes") ~= nil,
  _G.autocorrectStatus)

-- =====================================================================
out("\n=== 6. 🚨 WHAT ⇪Z LEARNS IS VISIBLE AND REVERSIBLE (6.199.0) ===\n")
-- =====================================================================
-- LL: "I fixed HOw by deleting the entry and you can see that it is still
-- HOw" — and his grep of 11,000 lines: `11052:allow,HOw,`. One ⇪Z press,
-- long forgotten, switching the TWo-caps rule off for that word on BOTH
-- Macs. Permanent is the design. Invisible was the bug, and there was no
-- report in this module at all, which is why a text editor was the only
-- way to find it.
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  local CSV = TMP .. "/autocorrect.csv"
  local function readCsv()
    local f = io.open(CSV, "r") ; local t = f and f:read("*a") or "" 
    if f then f:close() end ; return t
  end
  local function lineCount(t)
    local n = 0 ; for _ in t:gmatch("([^\r\n]+)") do n = n + 1 end ; return n
  end
  local function append(row)
    local f = io.open(CSV, "a") ; f:write(row .. "\n") ; f:close()
    mod.warm(core)
  end

  -- ---- LL's row, exactly ---------------------------------------------
  ck("before it is learned, HOw is corrected", typeWord("HOw ") == "How ")
  append("allow,HOw,")
  ck("🚨 one `allow,HOw,` row is the whole bug — HOw is left alone now",
     typeWord("HOw ") == nil, tostring(typeWord("HOw ")))

  local rep = _G.autocorrectReport()
  ck("🚨 the report NAMES it as something ⇪Z learned — this module had no"
     .. " report at all, which is why grep was the only way to find it",
     rep:find("HOw", 1, true) ~= nil and rep:find("⇪Z learned", 1, true) ~= nil,
     rep:match("⇪Z learned[^\n]*"))
  ck("…and hands over the exact way to undo it",
     rep:find('_G.autocorrectForget("HOw")', 1, true) ~= nil)
  ck("…while an exception this config SHIPS is not called something he"
     .. " taught it", (function()
        local block = rep:match("⇪Z learned.*") or ""
        return block:find("IDs", 1, true) == nil
     end)(), rep:match("⇪Z learned[^\n]*"))

  -- ---- and the way back ----------------------------------------------
  -- The rule matches case-sensitively, so HOw and How are two different
  -- exceptions and forgetting one must not take the other with it.
  append("allow,How,")
  local before = lineCount(readCsv())
  local okF, whyF = _G.autocorrectForget("HOw")
  ck("_G.autocorrectForget removes it and says so", okF == true, whyF)
  ck("…the rule corrects HOw again, without a reload",
     typeWord("HOw ") == "How ", tostring(typeWord("HOw ")))
  local after = readCsv()
  ck("🚨 …and it took exactly ONE row out of the file — a whole-file"
     .. " rewrite that loses rows is 11,000 lines of LL's own work",
     lineCount(after) == before - 1, before .. " -> " .. lineCount(after))
  ck("…every other row is still there",
     after:find("allow,IDs,", 1, true) and after:find("fix,teh,the", 1, true)
     and after:find("type,wrong,right", 1, true))
  ck("🚨 …including the word that differs only in CASE — HOw and How are"
     .. " two exceptions, and one is not the other",
     after:find("allow,How,", 1, true) ~= nil)
  ck("…and it survives a reload", (function()
     mod.warm(core) ; return typeWord("HOw ") == "How "
  end)())

  local okG, whyG = _G.autocorrectForget("HOw")
  ck("forgetting a word that is not an exception refuses and says which",
     okG == false and whyG:find("not an exception", 1, true) ~= nil, whyG)
  ck("…and forgetting nothing at all refuses too", (function()
     local o, w = _G.autocorrectForget("")
     return o == false and w:find("give it a word", 1, true) ~= nil
  end)())
  _G.autocorrectForget("How")     -- the case-sensitivity fixture, cleared
  ck("a Mac that has learned nothing says exactly that, and differently",
     _G.autocorrectReport():find("nothing on this Mac", 1, true) ~= nil)

  -- ---- ⇪Z itself: no duplicate row, and it names the way back --------
  local zKey = BOUND["ctrl+alt+cmd+Z"]
  ck("⇪Z is bound", type(zKey) == "function")
  typeWord("GHq ")                      -- a rule fix, so acLast.wasRule
  ALERTS = {}
  zKey()
  ck("⇪Z learns the word", _G.autocorrectReport():find("GHq", 1, true) ~= nil)
  ck("🚨 …and the alert names the way back, so it is never only in a CSV",
     (ALERTS[#ALERTS] or ""):find('_G.autocorrectForget("GHq")', 1, true) ~= nil,
     ALERTS[#ALERTS])
  _G.autocorrectForget("GHq")

  -- 📌 A DUPLICATE ROW IS UNREACHABLE IN ONE SESSION and reachable
  -- across two: once a word is allowed the rule stops firing, so ⇪Z has
  -- nothing to undo — but the OTHER Mac, which has not reloaded since the
  -- row synced, still corrects it and appends a second. So the defence is
  -- not the in-memory guard (which cannot see that): it is that the
  -- loader counts DISTINCT words and forget removes EVERY matching row.
  -- No in-memory guard is written for this, because no test could fail
  -- against it: the mutation that removed one survived, so the guard did.
  append("allow,ZZq,") ; append("allow,ZZq,")
  local dupBefore = lineCount(readCsv())
  ck("a word learned twice on two Macs is still ONE exception",
     (_G.autocorrectReport():gsub("[^\n]*ZZq[^\n]*", "x", 1)
      :find("ZZq", 1, true)) == nil)
  local okD = _G.autocorrectForget("ZZq")
  ck("…and forgetting it removes BOTH rows, not one of them",
     okD == true and lineCount(readCsv()) == dupBefore - 2,
     dupBefore .. " -> " .. lineCount(readCsv()))

  -- ---- a `fix` row whose two sides are the same word -----------------
  -- Obeyed, it MANGLES: the dictionary lowercases both sides and then
  -- re-applies sentence case, so IDs comes back Ids. It also costs the
  -- TWo-caps rule its turn, because a dictionary hit returns first.
  append("fix,IDs,IDs")
  ck("🚨 a dead `fix` row is SKIPPED — obeyed it turns IDs into Ids",
     typeWord("IDs ") == nil, tostring(typeWord("IDs ")))
  -- 🚨 AND THE SIDES ONLY HAVE TO MATCH ONCE LOWERED. The dictionary
  -- stores both sides lowercased, so `fix,TVs,tvs` is the same dead row
  -- written differently — and obeyed it hands back Tvs.
  append("fix,TVs,tvs")
  ck("🚨 …and a row whose sides differ only in CASE is dead too",
     typeWord("TVs ") == nil, tostring(typeWord("TVs ")))
  local rep2 = _G.autocorrectReport()
  ck("…and the report names it WITH ITS LINE NUMBER, so it can be found"
     .. " in an 11,000-line file", (function()
        local n = select(2, readCsv():gsub("[^\r\n]+", ""))
        return rep2:find("dead rows", 1, true)
           and rep2:find("fix,IDs,IDs", 1, true)
           and rep2:match("line%s+(%d+)%s+fix,IDs,IDs") ~= nil
     end)(), rep2:match("[^\n]*fix,IDs,IDs[^\n]*"))
  ck("…and it is not counted as a dictionary row it obeys", (function()
        return rep2:match("dictionary%s*:%s*(%d+)") ==
               rep:match("dictionary%s*:%s*(%d+)")
     end)(), rep2:match("dictionary[^\n]*"))
  ck("…and the CSV itself is NOT edited — his file, his call",
     readCsv():find("fix,IDs,IDs", 1, true) ~= nil)

  check("§6 ran every one of its checks", mine == 24, mine)
end

-- =====================================================================
out("\n=== 7. 📖 THE REAL DICTIONARY CHECK (6.200.0) ===\n")
-- =====================================================================
-- LL: "The actual word is somethgni, somethingg, somethinng, somethng,
-- somtething" — five spellings of one word, listed to make the point that
-- he should not have to keep adding custom rows. The risk is not missing
-- a typo; it is CORRECTING SOMETHING THAT WAS RIGHT, because a word list
-- holds no names, no jargon and no identifiers. So most of this section
-- is about what it must leave alone.
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  local WORDS = TMP .. "/words"
  local function seedWords(list)
    local f = io.open(WORDS, "w")
    for _, w in ipairs(list) do f:write(w .. "\n") end
    f:close()
    mod.config.wordsFile = WORDS
    mod.warm(core)
  end
  seedWords({ "something", "porter", "potter", "house", "houses", "backed",
              "collect", "the", "man", "and", "that", "their", "receive",
              "separate", "iphone" })

  -- ---- LL's five, by name --------------------------------------------
  for _, typo in ipairs({ "somethingg", "somethinng", "somethng", "somtething",
                          "somethgni" }) do
    ck("🚨 " .. typo .. " → something, with no row written for it",
       typeWord(typo .. " ") == "something ", tostring(typeWord(typo .. " ")))
  end
  ck("…and the word spelled correctly is left alone",
     typeWord("something ") == nil, tostring(typeWord("something ")))
  -- 🚨 TWO EDITS CAN REACH THE SAME WORD: inserting the l before or
  -- after the l already in "colect" both give "collect". Counted twice
  -- that reads as two candidates — a guess — and nothing is corrected.
  ck("🚨 one word reached two ways is still ONE candidate",
     typeWord("colect ") == "collect ", tostring(typeWord("colect ")))

  -- ---- what it must NOT touch ----------------------------------------
  ck("🚨 two real words a single edit away is a GUESS — poter does nothing"
     .. " while both porter and potter exist",
     typeWord("poter ") == nil, tostring(typeWord("poter ")))
  -- potter removed. house/houses and backed stay: a REAL word with
  -- exactly one real neighbour is the only fixture that can prove
  -- "it is already a word" and the length floor actually BITE, and
  -- "backed" is the only one that can prove the deletion rule does.
  seedWords({ "something", "porter", "house", "houses", "backed", "iphone" })
  ck("…and the moment only ONE is left, it corrects",
     typeWord("poter ") == "porter ", tostring(typeWord("poter ")))

  ck("a leading capital is restored onto the fix",
     typeWord("Somethingg ") == "Something ", tostring(typeWord("Somethingg ")))
  ck("🚨 ALL CAPS is never touched — that is an acronym",
     typeWord("SOMETHINGG ") == nil, tostring(typeWord("SOMETHINGG ")))
  ck("🚨 mixed case is never touched — that is CamelCase or a product name",
     typeWord("iPhonee ") == nil, tostring(typeWord("iPhonee ")))
  ck("🚨 a word that IS in the list is never touched, even when exactly"
     .. " one real word sits a single edit away — house must not become houses",
     typeWord("house ") == nil, tostring(typeWord("house ")))
  ck("🚨 a word under the length floor is never touched, even when exactly"
     .. " one real word is one edit away (hous → house)",
     typeWord("hous ") == nil, tostring(typeWord("hous ")))
  ck("two neighbours the wrong way round is its own edit — hosue → house",
     typeWord("hosue ") == "house ", tostring(typeWord("hosue ")))
  -- 🚨 THE MEASURED ONE. Against the real 73,000-word list, deleting
  -- ANY letter turned rsync into sync, backend into backed and frontend
  -- into fronted. A deleted letter must be one that REPEATS within the
  -- next two positions — already coming, so plainly typed twice or early.
  ck("🚨 a word is not shortened into another word — backend must never"
     .. " become backed, however alone that leaves it in the word list",
     typeWord("backend ") == nil, tostring(typeWord("backend ")))
  ck("a word nothing in the list is near is left exactly as typed",
     typeWord("qwertyuio ") == nil, tostring(typeWord("qwertyuio ")))

  -- ---- it is asked LAST ----------------------------------------------
  ck("the CSV dictionary still answers first", typeWord("teh ") == "the ",
     tostring(typeWord("teh ")))
  ck("the TWo-caps rule still answers before it",
     typeWord("USa ") == "Usa ", tostring(typeWord("USa ")))

  -- ---- ⇪Z governs it too ---------------------------------------------
  -- The learned exception is checked by the word-list rule as well, so
  -- 6.199.0's report and _G.autocorrectForget already govern this
  -- feature — there is no second thing to learn or unlearn.
  local f = io.open(TMP .. "/autocorrect.csv", "a")
  f:write("allow,somethingg,\n") ; f:close() ; mod.warm(core)
  ck("🚨 a word ⇪Z was told to leave alone is not spell-corrected either",
     typeWord("somethingg ") == nil, tostring(typeWord("somethingg ")))
  ck("…and it shows up in the SAME learned list, with the same way back",
     _G.autocorrectReport():find('_G.autocorrectForget("somethingg")', 1, true) ~= nil)
  _G.autocorrectForget("somethingg")
  ck("…and forgetting it brings the correction straight back",
     typeWord("somethingg ") == "something ", tostring(typeWord("somethingg ")))

  -- ---- where it stands down ------------------------------------------
  FRONTAPP = "Code"
  ck("🚨 it does not speak in a code editor — identifiers look exactly"
     .. " like misspellings to a word list",
     typeWord("somethingg ") == nil, tostring(typeWord("somethingg ")))
  FRONTAPP = "Terminal"
  ck("…nor in a terminal", typeWord("somethingg ") == nil)
  FRONTAPP = "TextEdit"
  SECURE = true
  ck("🚨 …nor into a password field", typeWord("somethingg ") == nil,
     tostring(typeWord("somethingg ")))
  SECURE = false
  ck("…and it comes back afterwards", typeWord("somethingg ") == "something ")

  -- 🚨 IT FAILS CLOSED. A Mac that cannot answer whether the keyboard is
  -- locked is treated as locked — the opposite choice would run the one
  -- feature that rewrites text in the one place it must never speak.
  local realSec = hs.eventtap.isSecureInputEnabled
  hs.eventtap.isSecureInputEnabled = nil
  ck("🚨 a Mac that cannot answer about secure input is treated as locked",
     typeWord("somethingg ") == nil, tostring(typeWord("somethingg ")))
  hs.eventtap.isSecureInputEnabled = realSec

  -- ---- 🚨 IT MUST NOT BLOCK THE THREAD THAT READS THE KEYBOARD ----
  -- The real list is ~235,000 lines. Folding that into a table in one go
  -- is a visible hitch on the main thread, so it goes in acSpell.slice
  -- words per turn of the event loop. A fixture smaller than one slice
  -- proves the slicing EXISTS, never that it BITES (6.187.0's rule), so
  -- this one is deliberately bigger than the slice it is given.
  TIMERS = {}
  mod.config.slice = 2
  seedWords({ "aaa", "bbb", "ccc", "ddd", "eee", "something" })
  ck("🚨 a list bigger than one slice does not finish inline — it hands"
     .. " the thread back and comes round again",
     #TIMERS > 0 and _G.autocorrectReport():find("reading the word list", 1, true) ~= nil,
     #TIMERS .. " timers · " .. tostring(_G.autocorrectReport():match("word list[^\n]*")))
  -- typeWord() empties TIMERS (it watches for the inject timer), so the
  -- half-built list's next slice is put back by hand here. On a real Mac
  -- the timer holds its own reference in _G.acSpellTimer.
  local held = TIMERS
  local midAnswer = typeWord("somethingg ")
  TIMERS = held
  ck("…and it is not answering yet, rather than answering wrongly",
     midAnswer == nil, tostring(midAnswer))
  local rounds = 0
  while rounds < 20 do
    rounds = rounds + 1
    local pending = TIMERS ; TIMERS = {}
    if #pending == 0 then break end
    for _, t in ipairs(pending) do if t.running then t.fn() end end
  end
  ck("…and when the last slice lands it is ready and answers",
     _G.autocorrectReport():find("ready", 1, true) ~= nil
     and typeWord("somethingg ") == "something ",
     tostring(_G.autocorrectReport():match("word list[^\n]*")))
  mod.config.slice = 20000

  -- ---- and when there is no word list at all -------------------------
  mod.config.wordsFile = TMP .. "/no-such-file"
  mod.warm(core)
  ck("no word list: it says so and changes nothing",
     typeWord("somethingg ") == nil, tostring(typeWord("somethingg ")))
  ck("…and the CSV dictionary still works, untouched by any of it",
     typeWord("teh ") == "the ", tostring(typeWord("teh ")))
  local repOff = _G.autocorrectReport()
  ck("…and the report NAMES the missing file rather than going quiet",
     repOff:find("no word list at", 1, true) ~= nil,
     repOff:match("word list[^\n]*"))

  -- ---- the report ----------------------------------------------------
  seedWords({ "something", "porter", "house" })
  typeWord("somethingg ")
  local rep = _G.autocorrectReport()
  ck("the report says the list is ready, and how many words",
     rep:find("ready", 1, true) and rep:match("word list[^\n]*3 words") ~= nil,
     rep:match("word list[^\n]*"))
  ck("…counts what it changed and shows the last few, so an app that"
     .. " misfires is named from EVIDENCE rather than guessed at",
     rep:find("somethingg → something", 1, true) ~= nil,
     rep:match("spelling[^\n]*"))
  ck("…and lists where it deliberately does not speak",
     rep:find("not asked in", 1, true) and rep:find("Terminal", 1, true)
     and rep:find("password field", 1, true))

  -- ---- the rule itself, with no Mac near it --------------------------
  local function known(w)
    return ({ something = true, porter = true, house = true })[w] == true
  end
  ck("the rule is pure and reachable, so every shape above is provable"
     .. " without typing anything",
     _G.acSpellCorrection("somethgni", known, 4) == "something"
     and _G.acSpellCorrection("something", known, 4) == nil
     and _G.acSpellCorrection("hous", known, 4) == "house"
     and _G.acSpellCorrection("hou", known, 4) == nil)

  check("§7 ran every one of its checks", mine == 37, mine)
end

-- =====================================================================
out("\n=== 8. 🚨 AN INFLECTION OF A WORD IS A WORD (6.205.0) ===\n")
-- =====================================================================
-- LL, on 6.203.0 in Chrome: "starets which should be starts", "allows is
-- changing to gallows", and "convinced" rewritten mid-sentence. macOS's
-- word list is a list of BASE words — it has start, allow and convince,
-- and not starts, allows or convinced — so every regular inflection read
-- as "not a word", and the one real word an insertion away was an
-- obscure entry. The fixture below is that list in miniature.
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  local WORDS = TMP .. "/words"
  local function seedWords(list)
    local f = io.open(WORDS, "w")
    for _, w in ipairs(list) do f:write(w .. "\n") end
    f:close()
    mod.config.wordsFile = WORDS
    mod.warm(core)
  end
  seedWords({ "start", "starets", "allow", "gallows", "convince", "run",
              "stop", "happy", "quick", "kind", "wish", "try", "make",
              "tall", "nice", "big", "something", "house" })

  -- ---- LL's three, by name -------------------------------------------
  ck("🚨 starts is left alone — start is a word, so starts is one too"
     .. " (it became starets)", typeWord("starts ") == nil,
     tostring(typeWord("starts ")))
  ck("🚨 allows is left alone (it became gallows)",
     typeWord("allows ") == nil, tostring(typeWord("allows ")))
  ck("🚨 convinced is left alone — the e-dropping past tense",
     typeWord("convinced ") == nil, tostring(typeWord("convinced ")))
  ck("Starts with a capital is left alone too",
     typeWord("Starts ") == nil, tostring(typeWord("Starts ")))

  -- ---- every regular ending, one word each ---------------------------
  for _, w in ipairs({ "running", "stopped", "happier", "happiest", "happily",
                       "happiness", "quickly", "kindness", "wishes", "tries",
                       "tried", "making", "taller", "tallest", "nicer",
                       "nicest", "bigger", "houses" }) do
    ck(w .. " is an inflection of a listed word and is left alone",
       typeWord(w .. " ") == nil, tostring(typeWord(w .. " ")))
  end

  -- ---- and the rule still corrects a real typo ------------------------
  ck("🚨 statrs → starts: an inflection is a real ANSWER as well, not only"
     .. " a word to leave alone — starts is not listed, start is",
     typeWord("statrs ") == "starts ", tostring(typeWord("statrs ")))
  ck("somethingg → something still works", typeWord("somethingg ") == "something ",
     tostring(typeWord("somethingg ")))
  ck("a stem must keep two letters — 'as' is not read as a plural of 'a'",
     (function()
        local known = function(w) return w == "a" end
        for _, s in ipairs(_G.acSpellStems("as")) do if known(s) then return false end end
        return true
     end)())

  -- ---- the pure rule, with no Mac near it ----------------------------
  local known = function(w)
    return ({ start = true, starets = true, allow = true, gallows = true })[w] == true
  end
  ck("_G.acSpellStems names start for starts", (function()
     for _, s in ipairs(_G.acSpellStems("starts")) do if s == "start" then return true end end
     return false
  end)(), table.concat(_G.acSpellStems("starts"), " "))
  ck("🚨 …and the pure rule refuses to touch starts while it would still"
     .. " turn a word with NO known stem into starets",
     _G.acSpellCorrection("starts", known, 4) == nil
     -- stare is NOT in this fixture, so stares is not a word here; starets
     -- (listed, an insertion away) beats startes (start+es, only a word by
     -- its ending) — 6.213.4's tier rule. On the real list stare is listed
     -- and stares is never touched.
     and _G.acSpellCorrection("stares", known, 4) == "starets"
     and _G.acSpellCorrection("starts", function(w) return w == "starets" end, 4) == "starets",
     tostring(_G.acSpellCorrection("starts", known, 4)))
  ck("allows: allow is a stem; gallows is not a correction of it",
     _G.acSpellCorrection("allows", known, 4) == nil)

  -- ---- ✏️ the door for a fix row ---------------------------------------
  local CSV = TMP .. "/autocorrect.csv"
  local function readCsv()
    local f = io.open(CSV, "r") ; local t = f and f:read("*a") or ""
    if f then f:close() end ; return t
  end
  ck("before the row, intsead is left alone", typeWord("intsead ") == nil,
     tostring(typeWord("intsead ")))
  local okA, whyA = _G.autocorrectAdd("intsead", "instead")
  ck("_G.autocorrectAdd writes the row and says so", okA == true
     and whyA:find("intsead → instead", 1, true) ~= nil, whyA)
  ck("…and it corrects at once, with no reload",
     typeWord("intsead ") == "instead ", tostring(typeWord("intsead ")))
  ck("…the row is in the file as fix,intsead,instead",
     readCsv():find("\nfix,intsead,instead\n", 1, true) ~= nil)
  ck("…and it survives a reload", (function()
     mod.warm(core) ; return typeWord("intsead ") == "instead "
  end)())
  ck("…with the capitalisation rules of any other row (Intsead → Instead)",
     typeWord("Intsead ") == "Instead ", tostring(typeWord("Intsead ")))
  ck("the report counts it as a dictionary row",
     tonumber(_G.autocorrectReport():match("dictionary%s*:%s*(%d+)")) >= 11)
  local n0 = select(2, readCsv():gsub("\n", ""))
  local okD, whyD = _G.autocorrectAdd("IDs", "ids")
  ck("🚨 a dead row is REFUSED, not written — obeyed it would turn IDs into Ids",
     okD == false and whyD:find("same word", 1, true) ~= nil
     and select(2, readCsv():gsub("\n", "")) == n0, whyD)
  local okC, whyC = _G.autocorrectAdd("a,b", "ab")
  ck("…and so is a comma, which would corrupt the file",
     okC == false and select(2, readCsv():gsub("\n", "")) == n0, whyC)
  local okE, whyE = _G.autocorrectAdd("", "x")
  ck("…and an empty side", okE == false and whyE:find("two words", 1, true) ~= nil, whyE)
  ck("the cheat sheet tells LL the door exists", (function()
     for _, e in ipairs(mod.cheatsheet.entries) do
       if e[2]:find("_G.autocorrectAdd", 1, true) then return true end
     end
     return false
  end)())

  check("§8 ran every one of its checks", mine == 39, mine)
end

-- =====================================================================
out("\n=== 8b. 🚨 AN INFLECTED ANSWER MUST CARRY THE TYPED ENDING (6.213.2) ===\n")
-- =====================================================================
-- 6.205.0 was proven against the fixture above, and the fixture shared
-- its blind spot. Measured against the REAL /usr/share/dict/words:
-- plugin → pluging (plug+ing), backend → backened (backen+ed), signin →
-- signing (sign+ing) — right words, rewritten, the class 6.205.0 was
-- shipped to end. And LL's own report: statrs stayed statrs, because
-- the real list has stater AND stator, so starts was one of THREE
-- answers. The fixture below holds exactly the real list's words that
-- bit. Two mutations fail rows here: dropping the ending gate turns
-- plugin into pluging; comparing endings strictly instead of by family
-- loses wishess → wishes. 6.213.4 adds three more: the by-ending tier
-- unordered (statrs silent), the listed tier ordered (adress → daress,
-- sceen → scene), the tiers collapsed (allways silent).
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  local WORDS = TMP .. "/words"
  local function seedWords(list)
    local f = io.open(WORDS, "w")
    for _, w in ipairs(list) do f:write(w .. "\n") end
    f:close()
    mod.config.wordsFile = WORDS
    mod.warm(core)
  end
  seedWords({ "plug", "backen", "sign", "wish", "start", "stater", "stator",
              "something", "convince",
              -- 6.213.4's real-list words: address AND adpress are listed,
              -- dares too (so daress is dares+s); scene and screen; always
              -- and hallway (hallways is hallway+s); weird and wired
              "address", "adpress", "dares", "scene", "screen", "always",
              "hallway", "weird", "wired" })

  ck("🚨 plugin is left alone — pluging (plug+ing) is no answer for a word"
     .. " typed with no ending", typeWord("plugin ") == nil, tostring(typeWord("plugin ")))
  ck("🚨 backend is left alone (it became backened — backen is listed)",
     typeWord("backend ") == nil, tostring(typeWord("backend ")))
  ck("🚨 signin is left alone (it became signing)",
     typeWord("signin ") == nil, tostring(typeWord("signin ")))
  ck("wishess → wishes: es and s are ONE ending family (the list has wish,"
     .. " not wishes; wishs itself is wish+s and is left alone)",
     typeWord("wishess ") == "wishes " and typeWord("wishs ") == nil,
     tostring(typeWord("wishess ")) .. " / " .. tostring(typeWord("wishs ")))
  ck("sttarts → starts: a doubled letter in the stem, the ending kept",
     typeWord("sttarts ") == "starts ", tostring(typeWord("sttarts ")))
  ck("somethingg → something: a word the list holds outright is never gated",
     typeWord("somethingg ") == "something ", tostring(typeWord("somethingg ")))
  ck("🚨 6.213.4 — statrs → starts WITH stater and stator listed: no listed"
     .. " word is near, so the by-ending tier runs in kind order and the"
     .. " swap answers before the missing letter (LL: \"statrs is still"
     .. " not corrected\")", typeWord("statrs ") == "starts ", tostring(typeWord("statrs ")))
  ck("🚨 …but adress stays: address and adpress are BOTH listed, two"
     .. " answers, and the swap's daress (dares+s) never outvotes them",
     typeWord("adress ") == nil, tostring(typeWord("adress ")))
  ck("🚨 …and sceen stays: scene (a swap) and screen (a letter missing) are"
     .. " both listed — the kind order never decides between listed words",
     typeWord("sceen ") == nil, tostring(typeWord("sceen ")))
  ck("allways → always: a listed word beats hallways, a word only by its"
     .. " ending, whatever the kind of edit",
     typeWord("allways ") == "always ", tostring(typeWord("allways ")))
  ck("wierd stays: weird and wired are two listed swaps",
     typeWord("wierd ") == nil, tostring(typeWord("wierd ")))
  ck("…and the measured cost, named: a typo INSIDE the ending (convincd)"
     .. " is left alone now — silence is the safe side",
     typeWord("convincd ") == nil, tostring(typeWord("convincd ")))

  -- ---- the pure helper, with no Mac near it ---------------------------
  local E = _G.acSpellEnding
  ck("_G.acSpellEnding: wishes, tries, starts are all the s family",
     E("wishes") == "s" and E("tries") == "s" and E("starts") == "s")
  ck("…allowed/tried → ed · running → ing · taller/happier → er ·"
     .. " tallest/happiest → est · quickly/happily → ly · kindness/happiness → ness",
     E("allowed") == "ed" and E("tried") == "ed" and E("running") == "ing"
     and E("taller") == "er" and E("happier") == "er" and E("tallest") == "est"
     and E("happiest") == "est" and E("quickly") == "ly" and E("happily") == "ly"
     and E("kindness") == "ness" and E("happiness") == "ness")
  ck("…and a word with no ending answers \"\" — plugin, backend, signin,"
     .. " and a bare suffix is not an ending of itself (s, ing)",
     E("plugin") == "" and E("backend") == "" and E("signin") == ""
     and E("s") == "" and E("ing") == "")
  local known = function(w) return ({ plug = true, start = true })[w] == true end
  ck("the pure rule: plugin stays under a known() that lists plug…",
     _G.acSpellCorrection("plugin", known, 5) == nil,
     tostring(_G.acSpellCorrection("plugin", known, 5)))
  ck("…while startss → starts, the typed s family carried by the answer",
     _G.acSpellCorrection("startss", known, 5) == "starts",
     tostring(_G.acSpellCorrection("startss", known, 5)))

  check("§8b ran every one of its checks", mine == 17, mine)
end


-- =====================================================================
out("\n=== 9. 6.218.0 — THE RETYPE IS NOT READ BACK (LL's doesnt ⇄ doesn storm) ===\n")
-- The harness delivers every injection back into the tap (see typeWord).
-- On 6.216.0 LL's Mac did the same: fix,doesnt,doesn't retyped an
-- apostrophe, the spelling rule read "doesn" → "doesnt", and the two
-- corrected each other for ever (24 rows of "doesn → doesnt" in his
-- report; every stray "t" a Vimium new tab).
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  FRONTAPP = "TextEdit"
  local WORDS = TMP .. "/words"
  do
    local f = io.open(WORDS, "w")
    for _, w in ipairs({ "does", "doesnt", "the", "something" }) do f:write(w .. "\n") end
    f:close()
    mod.config.wordsFile = WORDS
    mod.warm(core)
  end
  local okA = _G.autocorrectAdd("doesnt", "doesn't")
  ck("fixture: the row LL has (line 3235 of his CSV) and a word list that"
     .. " holds doesnt, as Webster's Second does", okA == true, tostring(okA))
  -- 🚨 THE LOOP, PROVEN WITHOUT THE SPELLING RULE. Until 6.219.0 this
  -- section used LL's own trap (doesn' → doesnt', the spelling rule
  -- answering on the apostrophe); 6.219.0 closed that half, so the
  -- guard — which is what stops a retype being READ BACK AT ALL — is
  -- proven here with two dictionary rows that answer each other. Take
  -- the drain out and this ping-pongs for ever, exactly as LL's Mac did.
  local okB = _G.autocorrectAdd("aaaa", "bbbb")
  local okC = _G.autocorrectAdd("bbbb", "aaaa")
  ck("fixture: two rows that answer each other — the loop in one line",
     okB == true and okC == true, tostring(okB) .. " " .. tostring(okC))
  local ping = typeWord("aaaa ")
  ck("🚨 THE RETYPE IS NOT READ BACK: aaaa␣ → bbbb␣ and it STOPS THERE",
     ping == "bbbb " and #KEYSTROKES == 1,
     tostring(ping) .. " · " .. #KEYSTROKES)

  -- ---- the storm, and its end ------------------------------------------
  local typed = typeWord("doesnt ")
  ck("doesnt␣ → doesn't␣ (the dictionary row)", typed == "doesn't ", tostring(typed))
  ck("🚨 THE RETYPE IS NOT READ BACK: one injection, not two — the storm"
     .. " cannot start", #KEYSTROKES == 1, #KEYSTROKES .. " · " .. tostring(KEYSTROKES[2]))
  ck("…and the count released the guard on the last key: the hold timer is"
     .. " stopped and let go", _G.acInjectHold == nil
     and (function() local n = 0 for _, t in ipairs(TIMERS) do if t.running then n = n + 1 end end return n end)() == 0,
     tostring(_G.acInjectHold))
  -- 🚨 MUTATION ROW: a guard released by TIME alone would still be up
  -- here. LL's very next key must be examined, not skipped.
  ck("🚨 LL's next word, typed at once, is still corrected (the guard is"
     .. " DOWN — released by the count, not a clock)",
     typeWord("teh ") == "the ", tostring(typeWord("teh ")))

  -- ---- the belt: a key macOS never delivered ---------------------------
  typed = typeWord("teh ", true)          -- posted, nothing delivered yet
  ck("teh␣ → the␣, and the hold timer is armed in _G.acInjectHold at 0.3 s"
     .. " (settings = { autocorrect = { injectHold = … } })",
     typed == "the " and _G.acInjectHold ~= nil and _G.acInjectHold.delay == 0.3
     and mod.config.injectHold == 0.3, tostring(_G.acInjectHold and _G.acInjectHold.delay))
  local hold = _G.acInjectHold
  deliver(3, "the")                       -- one key short: the space never arrives
  log = {}
  _G.autocorrectReport()
  local rep = table.concat(log, "\n")
  ck("one key short, the guard is still UP and the report says so",
     _G.acInjectHold == hold and rep:find("UP NOW, 1 key(s) still to drain", 1, true) ~= nil,
     rep:match("retype guard[^\n]*"))
  hold.fn()                               -- the hold timer fires
  ck("…the hold timer releases it (let go, counted): teh␣ corrects again",
     _G.acInjectHold == nil and typeWord("teh ") == "the ", tostring(_G.acInjectHold))

  -- ---- ⇪Z's restore was the same shape ---------------------------------
  typed = typeWord("teh ")
  ck("teh␣ → the␣, then ⇪Z…", typed == "the ")
  KEYSTROKES, DELETES, TIMERS = {}, 0, {}
  BOUND["ctrl+alt+cmd+Z"]()
  ck("…restores teh␣ (4 deletes, the word retyped)",
     KEYSTROKES[1] == "teh " and DELETES == 4, tostring(KEYSTROKES[1]) .. " " .. DELETES)
  deliver(4, "teh ")
  runShortTimers()
  ck("🚨 THE RESTORED WORD IS NOT CORRECTED AGAIN as it comes back through"
     .. " the tap (it was, before 6.218.0)", #KEYSTROKES == 1, #KEYSTROKES)

  -- ---- the report names it ---------------------------------------------
  log = {}
  _G.autocorrectReport()
  rep = table.concat(log, "\n")
  ck("the report's \"retype guard\" line counts retypes and both releases",
     rep:find("retype guard : %d+ retype%(s%) · released by count %d+ · by timer 1") ~= nil,
     rep:match("retype guard[^\n]*"))
  ck("…and it never reads UP NOW once the keys have drained",
     not rep:find("UP NOW", 1, true))

  -- ---- against the source: one door, one release -----------------------
  local f = io.open(HS .. "/modules/autocorrect.lua", "r")
  local src = f:read("*a"); f:close()
  local _, clears = src:gsub("acInjecting = false", "")
  ck("🔒 the guard is cleared in ONE place (acInjectRelease) — never on the"
     .. " line after keyStrokes again", clears == 2, clears)   -- the declaration + the release
  local _, strokes = src:gsub("hs%.eventtap%.keyStrokes%(", "")
  ck("🔒 and there is ONE keyStrokes call — acType — so ⇪Z and the fix"
     .. " share the drain", strokes == 1, strokes)

  check("§9 ran every one of its checks", mine == 17, mine)
end


-- =====================================================================
out("\n=== 10. 6.219.0 — AN APOSTROPHE INSIDE A WORD IS NOT A WORD ENDING ===\n")
-- LL, on 6.218.0: "Doesnt't kinda works as you can see." The storm was
-- gone; this was left. An apostrophe is a boundary character, so typing
-- "Doesn't" hands "Doesn" to the rules, and Webster's Second HOLDS the
-- apostrophe-less contractions — measured against the real list (web2,
-- 234,454 words): doesn → doesnt, wouldn → wouldnt, mightn → mightnt,
-- oughtn → oughtnt. The word list is not asked when the boundary is an
-- apostrophe. The dictionary rows and the TWo-caps rule still are.
do
  local mine = 0
  local function ck(label, cond, extra)
    mine = mine + 1 ; check(label, cond, extra)
  end
  FRONTAPP = "TextEdit"
  local WORDS = TMP .. "/words10"
  do
    local f = io.open(WORDS, "w")
    -- the four Webster's Second entries that bit, plus ordinary words
    for _, w in ipairs({ "does", "doesnt", "would", "wouldnt", "might",
                         "mightnt", "the", "something" }) do f:write(w .. "\n") end
    f:close()
    mod.config.wordsFile = WORDS
    mod.warm(core)
  end
  ck("fixture: the word list holds doesnt and wouldnt, as Webster's"
     .. " Second does", _G.autocorrectReport() ~= nil)

  -- ---- LL's complaint, gone --------------------------------------------
  ck("🚨 Doesn't typed BY HAND is left alone (it became Doesnt't)",
     typeWord("Doesn'") == nil, tostring(typeWord("Doesn'")))
  ck("…and lower case doesn't too", typeWord("doesn'") == nil,
     tostring(typeWord("doesn'")))
  ck("…wouldn't as well (wouldn → wouldnt on the real list)",
     typeWord("wouldn'") == nil, tostring(typeWord("wouldn'")))
  ck("…and mightn't", typeWord("mightn'") == nil, tostring(typeWord("mightn'")))

  -- 🚨 MUTATION ROW: switching the word list off for EVERY boundary would
  -- pass every row above. A space must still spell-check.
  ck("🚨 the word list is switched off for the apostrophe ONLY: doesn␣ is"
     .. " still corrected (a space is a word ending)",
     typeWord("doesn ") == "doesnt ", tostring(typeWord("doesn ")))

  -- ---- what an apostrophe still gets ------------------------------------
  local okA = _G.autocorrectAdd("teh", "the")
  ck("fixture: a dictionary row", okA == true or okA == false)
  ck("🚨 the DICTIONARY still answers on an apostrophe: teh' → the'",
     typeWord("teh'") == "the'", tostring(typeWord("teh'")))
  ck("🚨 and TWo-caps still does: THe' → The'",
     typeWord("THe'") == "The'", tostring(typeWord("THe'")))
  ck("LL's own row is untouched: doesnt␣ → doesn't␣",
     typeWord("doesnt ") == "doesn't ", tostring(typeWord("doesnt ")))

  -- ---- the report names it ----------------------------------------------
  log = {}
  _G.autocorrectReport()
  local rep = table.concat(log, "\n")
  ck("the report counts the pieces a ' handed to the dictionary alone",
     rep:find("apostrophe   : %d+ piece%(s%) before a ' — dictionary"
              .. " and TWo%-caps only, never the word list") ~= nil,
     rep:match("apostrophe[^\n]*"))

  -- ---- against the source: one door -------------------------------------
  local f = io.open(HS .. "/modules/autocorrect.lua", "r")
  local src = f:read("*a"); f:close()
  local _, asks = src:gsub("acSpellHereOK", "")
  ck("🔒 there is ONE place that asks whether the word list may speak"
     .. " (the definition and a single call) — never a second door",
     asks == 2, asks)
  local _, quotes = src:gsub('ch == "\'"', "")
  ck("🔒 and ONE apostrophe test in the tap", quotes == 1, quotes)

  check("§10 ran every one of its checks", mine == 13, mine)
end

-- =====================================================================
out("\n=== 11. 6.243.0 — ⇪Z learns the correction HE just made ===\n")
-- =====================================================================
-- LL: "I wanted a quick way to use the last correction I makee and then I
-- type make to fix it, is either added by you catching it, or me adding it
-- via shortcut key." His answer to the one open decision was ARM, not
-- write: the pair is noticed silently and ⇪Z is what writes it down.
--
-- 🚨 THE TRAP THIS SECTION EXISTS FOR. This module corrects by deleting and
-- retyping, and 6.218.0's rule is that those keys come BACK through this
-- tap looking exactly like typing — so the config's own corrections are
-- indistinguishable from LL correcting himself unless the injection guard
-- separates them. The harness above DELIVERS the posted keys back into the
-- tap, which is the only way that can be proven at all.
--
-- 🚨 THE SECTION WRAPS ITSELF AND COUNTS ITS OWN CHECKS (6.186.0).
local before243 = pass + fail
local ok243, err243 = pcall(function()
  local CSV = TMP .. "/autocorrect.csv"
  local function readCsv()
    local f = io.open(CSV, "r") ; local t = f and f:read("*a") or ""
    if f then f:close() end ; return t
  end
  local ac = mod.config
  ac.selfLearn, ac.selfSecs, ac.selfMinLen = true, 30, 3
  local zKey = BOUND["ctrl+alt+cmd+Z"] or BOUND["cmd+alt+ctrl+Z"]
  for k, fn in pairs(BOUND) do if k:find("Z$") then zKey = fn end end

  -- 🚨 ⇪Z POSTS KEYS TOO, AND THEY MUST COME BACK. The undo branch
  -- retypes through the same guarded door as a correction (6.218.0), so a
  -- harness that presses ⇪Z and does not deliver those keys leaves the
  -- guard UP and every later keystroke in this section is swallowed —
  -- which is a test measuring its own stub, not the feature.
  local function pressZ()
    KEYSTROKES, DELETES = {}, 0
    zKey()
    if KEYSTROKES[1] then deliver(DELETES, KEYSTROKES[1]) end
  end

  -- Backspace over a word and retype a near-twin of it.
  local function selfCorrect(typed, back, retyped, boundary)
    KEYSTROKES, DELETES, TIMERS = {}, 0, {}
    for ch in typed:gmatch(".") do keyIn(ch) end
    for _ = 1, back do press(51) end
    for ch in retyped:gmatch(".") do keyIn(ch) end
    keyIn(boundary or " ")
    runShortTimers()
  end

  -- 🚨 DRAIN ANY UNDO LEFT PENDING BY AN EARLIER SECTION FIRST. ⇪Z
  -- undoes OUR correction when there is one, and that branch is unchanged
  -- and takes precedence — so a suite that starts here with acLast set is
  -- testing the wrong branch and would have reported this feature broken.
  pressZ() ; pressZ()
  -- …and one boundary on an empty buffer, which clears any half-typed
  -- word an earlier section left behind in the detector.
  keyIn(" ")

  -- ---- the pair rules, through the tap --------------------------------
  ALERTS = {}
  selfCorrect("makee", 5, "make")          -- his own example, verbatim
  local before = readCsv()
  pressZ()
  local after = readCsv()
  check("🔤 his own sentence: makee → backspace → make → ⇪Z writes the row",
        after:find("fix,makee,make", 1, true) ~= nil, after:sub(-120))
  check("🚨 ...and NOTHING was written before he pressed it — armed, not"
        .. " written, which was his call",
        before:find("fix,makee,make", 1, true) == nil, before:sub(-120))
  check("...the row is TAGGED, so the report can find it again",
        after:match("fix,makee,make,[^\n]+") ~= nil,
        after:match("fix,makee,make[^\n]*"))
  check("...and it is live at once, without a reload",
        typeWord("makee ") == "make ", typeWord("makee "))

  -- ---- one edit apart, and not one edit apart -------------------------
  local function armed()
    log = {} ; _G.autocorrectReport()
    return (table.concat(log, "\n")):match("↳ NOW: ⇪Z writes ([^\n]*)")
  end
  selfCorrect("teh", 3, "the")
  check("🔤 a transposition arms — teh → the is THE typo and is three letters",
        (armed() or ""):find("teh → the", 1, true) ~= nil, armed())
  selfCorrect("adress", 6, "address")
  check("...an inserted letter arms", (armed() or ""):find("adress → address", 1, true) ~= nil,
        armed())
  selfCorrect("recieve", 7, "receive")
  check("...and a swap in the middle of a long word arms",
        (armed() or ""):find("recieve → receive", 1, true) ~= nil, armed())

  -- 🚨 THE ROW THE SIMILARITY TEST EXISTS FOR. Typing a word, changing your
  -- mind and typing a DIFFERENT word is an ordinary edit, and a dictionary
  -- that learned it would rewrite that word for ever, on both Macs.
  selfCorrect("cat", 3, "dog")
  check("🚨 cat → dog is a REWRITE, not a typo, and is never offered",
        armed() == nil, armed())
  selfCorrect("hello", 5, "goodbye")
  check("...nor is anything else more than one edit apart", armed() == nil, armed())
  selfCorrect("ab", 2, "ac")
  check("🔎 ...and two letters is under the floor: too many real words are"
        .. " one edit from each other down there", armed() == nil, armed())
  -- 🚨 AND THIS ONE IS ASSERTED ON ITS REASON, NOT ON THE REFUSAL.
  -- "The" and "the" are ZERO edits apart once lowered, so the edit rule
  -- turns them away all by itself and a check that only asked "was it
  -- refused" passed with this branch deleted. The branch earns its place by
  -- saying the TRUE thing — that row would be dead (6.199.0) — instead of
  -- "more than one edit apart", which would be a lie about zero.
  local function lastWhy()
    log = {} ; _G.autocorrectReport()
    return (table.concat(log, "\n")):match("Last retype: ([^\n]*)")
  end
  selfCorrect("The", 3, "the")
  check("🚨 a capitalisation-only pair is refused, and the reason given is"
        .. " the DEAD ROW (6.199.0) rather than an edit count",
        armed() == nil and (lastWhy() or ""):find("would be dead", 1, true) ~= nil,
        lastWhy())

  -- ---- 🚨 THE TRAP: our own retype must never teach us ------------------
  -- typeWord delivers the posted deletes and characters back into the tap,
  -- exactly as macOS does. Without the injection guard those look identical
  -- to LL fixing a typo, and the module would learn its own corrections.
  local taughtBefore = readCsv()
  check("the config still corrects USa → Usa", typeWord("USa ") == "Usa ")
  check("🚨 ...and it did NOT learn its own retype: no row, and nothing armed"
        .. " for ⇪Z to write (6.218.0 — a retype comes back through the tap)",
        armed() == nil and readCsv() == taughtBefore, armed())
  pressZ() -- there IS an undo pending here; it must take the undo branch
  check("...and ⇪Z there undoes OUR correction, as it always did",
        (ALERTS[#ALERTS] or ""):find("USa", 1, true) ~= nil, ALERTS[#ALERTS])

  -- ---- the window, and the three refusals -----------------------------
  selfCorrect("freind", 6, "friend")
  -- A minute passes. The clock is moved rather than the setting, so this
  -- measures the AGE of the pair and not a knob set to a silly value.
  ALERTS = {}
  local staleBefore = readCsv()
  local realTime = os.time
  os.time = function() return realTime() + 60 end
  pressZ()
  os.time = realTime
  check("⏱ a pair older than selfSecs is NOT written",
        readCsv() == staleBefore, readCsv():sub(-80))
  check("...and the refusal says so, rather than doing nothing",
        (ALERTS[#ALERTS] or ""):find("retype it and press", 1, true) ~= nil,
        ALERTS[#ALERTS])

  ALERTS = {}
  selfCorrect("cat", 3, "dog")   -- refused, so lastWhy is set and pair is nil
  pressZ()
  check("🔎 nothing offered NAMES the last retype and why it was not — a key"
        .. " that does nothing is a key he stops trusting",
        (ALERTS[#ALERTS] or ""):find("was not offered", 1, true) ~= nil,
        ALERTS[#ALERTS])

  ac.selfLearn = false
  ALERTS = {} ; KEYSTROKES, DELETES, TIMERS = {}, 0, {}
  selfCorrect("makee", 5, "make")
  local offBefore = readCsv()
  pressZ()
  check("🔌 switched off, nothing is armed and nothing is written",
        readCsv() == offBefore
        and (ALERTS[#ALERTS] or ""):find("switched off", 1, true) ~= nil,
        ALERTS[#ALERTS])
  ac.selfLearn = true

  -- ---- a click and a caret move end the word --------------------------
  KEYSTROKES, DELETES, TIMERS = {}, 0, {}
  for ch in ("makee"):gmatch(".") do keyIn(ch) end
  press(51)
  TAP.fn({ getType = function() return hs.eventtap.event.types.leftMouseDown end,
           getFlags = function() return {} end,
           getKeyCode = function() return 0 end,
           getCharacters = function() return "" end })
  for ch in ("make "):gmatch(".") do keyIn(ch) end
  runShortTimers()
  check("🖱 a click between the backspace and the retype ends the pair — the"
        .. " caret is somewhere else and those are two different words",
        armed() == nil, armed())

  -- ---- the way back ---------------------------------------------------
  log = {}
  _G.autocorrectReport()
  local rep = table.concat(log, "\n")
  check("📋 the report NAMES what ⇪Z taught, with the line and the one-liner"
        .. " that removes it (6.199.0's rule, in the other column)",
        rep:find("⇪Z taught", 1, true) ~= nil
        and rep:find("_G.autocorrectForgetFix(\"makee\")", 1, true) ~= nil,
        rep:match("⇪Z taught[^\n]*\n[^\n]*"))
  local okF, whyF = _G.autocorrectForgetFix("makee")
  check("↩️ and that one-liner really removes the row",
        okF == true and readCsv():find("fix,makee,make", 1, true) == nil, whyF)
  check("...and the word is corrected no longer, without a reload",
        typeWord("makee ") == nil, typeWord("makee "))
  check("...a word that is not a fix row is refused, never a silent rewrite",
        select(1, _G.autocorrectForgetFix("nosuchword")) == false)
  check("...and so is an empty ask", select(1, _G.autocorrectForgetFix("")) == false)

  -- 🚨 IT REMOVES EVERY MATCHING ROW, tagged or not. The other Mac appends a
  -- duplicate before it has reloaded, and a hand-written row for the same
  -- word would otherwise go on correcting after a command that said it
  -- would stop.
  local f = io.open(CSV, "a")
  f:write("fix,dupe,duplicate\nfix,dupe,duplicate,⇪Z\n") ; f:close()
  mod.warm(core)
  local okD = _G.autocorrectForgetFix("dupe")
  check("🚨 every matching row goes — the hand-written one and the taught"
        .. " duplicate alike", okD == true
        and readCsv():find("fix,dupe", 1, true) == nil, readCsv():sub(-160))

  -- ---- 🔎 an older row and an older build ------------------------------
  -- The loader has always read columns 1..3 and ignored the rest, so a
  -- tagged row loads in an older build and an untagged row loads here.
  local f2 = io.open(CSV, "a")
  f2:write("fix,plainrow,plainfix\n") ; f2:close()
  mod.warm(core)
  check("🔎 a row with no fourth column still corrects, and is NOT listed as"
        .. " something a keypress taught", typeWord("plainrow ") == "plainfix ",
        typeWord("plainrow "))
  log = {} ; _G.autocorrectReport()
  check("...and the taught list only ever holds the tagged ones",
        (table.concat(log, "\n")):find("plainrow", 1, true) == nil)
end)
if not ok243 then
  check("🚨 the 6.243.0 section ran to the end without throwing", false,
        tostring(err243))
end
check("🚨 ...and it asserted every check it was written to make",
      (pass + fail) - before243 >= 26, (pass + fail) - before243)

-- ---- against the source ------------------------------------------------
do
  local f = io.open(HS .. "/modules/autocorrect.lua", "r")
  local src = f:read("*a") ; f:close()
  -- 🚨 THE DETECTOR MUST SIT BEHIND THE INJECTION GUARD. That guard returns
  -- early for every key this module posted, and it is the ONLY honest way
  -- to tell our own retype from his. If the detector ever moves above it,
  -- the module starts learning its own corrections — and the functional
  -- check above would still pass on the day the guard itself broke.
  local guardAt  = src:find("if acInjecting then", 1, true)
  local detectAt = src:find("if acSelf.before == nil and #acBuffer > 0 then", 1, true)
  local armAt    = src:find("acSelf.pair = { wrong = wasBefore", 1, true)
  check("🔒 the self-correction detector sits BELOW the injection guard, so"
        .. " this module can never learn from its own retype",
        guardAt and detectAt and armAt and guardAt < detectAt and guardAt < armAt,
        tostring(guardAt) .. " / " .. tostring(detectAt) .. " / " .. tostring(armAt))
  local _, writes = src:gsub("autocorrectAdd%(p%.wrong", "")
  check("🔒 ...and there is exactly ONE place a learned pair is written",
        writes == 1, writes)
end

out(("\n%d passed, %d failed\n\n"):format(pass, fail))
os.execute("rm -rf '" .. TMP .. "'")
os.exit(fail == 0 and 0 or 1)
