-- =====================================================================
-- test_mouse_grid.lua — the overlay that could lock you out of your Mac
-- =====================================================================
--     lua5.4 test_mouse_grid.lua                    # ~/.hammerspoon
--     lua5.4 test_mouse_grid.lua /path/to/hammerspoon
--
-- This suite EXECUTES modules/mouse_grid.lua against a stubbed hs. It
-- does not read it as text. Grepping for "grid.hide" proves the name is
-- present and proves nothing about whether the overlay comes down.
--
-- WHAT IT IS REALLY FOR. Every other module in this config fails by
-- doing nothing. This one can fail by eating every keystroke you make
-- with a sheet over your screen, on the work MacBook, in a meeting. So
-- the centre of this file is ONE assertion, made after EVERY operation
-- in every test:
--
--        grid.state ~= nil   ⟺   a modal is entered   ⟺   a canvas is up
--
-- If those three ever disagree you are either locked out (keys captured,
-- nothing visible) or stranded (sheet visible, keys dead). checkInv()
-- below runs after literally every state change, including the failure
-- paths, and section 8 MUTATES THE SHIPPED FILE to prove that this suite
-- actually fails when the invariant is broken — a green run that stays
-- green after you delete the teardown is not a test, it is decoration.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")
local MODFILE = HS .. "/modules/mouse_grid.lua"

local pass, fail, failures = 0, 0, {}
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else
        fail = fail + 1
        failures[#failures + 1] = label .. (extra and ("  [" .. tostring(extra) .. "]") or "")
    end
end
local function out(s) io.write(s) end

-- =====================================================================
-- STUBS
-- =====================================================================
local printed, ALERTS = {}, {}
local realPrint = print
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    printed[#printed + 1] = table.concat(p, " ")
end

local SCREENS, CANVASES, CANVAS_NEW, TIMERS = {}, {}, 0, {}
local TAPS = {}    -- 6.155.0: every hs.eventtap.new (the hand-click listener)
local MOUSE_AT, CLICKS, AX_OK = { x = 0, y = 0 }, {}, true
-- 🎯 6.154.0 — the Accessibility world under the cell: AXELEMS is the
-- list of elements on screen (role, frame, title, pid); a hit-test answers
-- the first one whose frame contains the point. ASKS counts questions,
-- GRID_UP_AT_ASK records whether our own overlay was still visible when
-- the first question was asked — which it must never be.
local AXELEMS, ASKS, GRID_UP_AT_ASK, AX_THROWS = {}, 0, nil, false
local function mkAxElement(spec)
    local e = { spec = spec }
    function e:setTimeout() self.timedOut = true ; return self end
    function e:pid() return self.spec.pid end
    function e:attributeValue(k)
        if k == "AXRole"  then return self.spec.role end
        if k == "AXFrame" then return self.spec.frame end
        if k == "AXTitle" then return self.spec.title end
        return nil
    end
    return e
end
local SYSWIDE = {}
function SYSWIDE:setTimeout() self.timedOut = true ; return self end
function SYSWIDE:elementAtPosition(x, y)
    ASKS = ASKS + 1
    if GRID_UP_AT_ASK == nil then
        GRID_UP_AT_ASK = false
        for _, c in ipairs(CANVASES) do
            if c.visible and c.isGrid then GRID_UP_AT_ASK = true end
        end
    end
    if AX_THROWS then error("hostile: AX refuses") end
    for _, spec in ipairs(AXELEMS) do
        local f = spec.frame
        if x >= f.x and x <= f.x + f.w and y >= f.y and y <= f.y + f.h then
            return mkAxElement(spec)
        end
    end
    return nil
end
local GLOBAL_HOTKEYS, HYPER, PROVIDED = {}, {}, {}
local SCREEN_WATCHERS = {}
local NOW = 1000

local function mkScreen(id, x, y, w, h)
    return {
        id = function() return id end,
        fullFrame = function() return { x = x, y = y, w = w, h = h } end,
        frame     = function() return { x = x, y = y + 25, w = w, h = h - 25 } end,
    }
end
local function setScreens(list) SCREENS = list end

local REFUSE_SHOW = false   -- 6.266.0: make hs.canvas:show() throw
local function mkCanvas(frame)
    CANVAS_NEW = CANVAS_NEW + 1
    local c = { frame = frame, elements = {}, visible = false, deleted = false, lvl = nil }
    -- 🚨 FAITHFUL TO THE REAL hs.canvas, WHICH THIS STUB WAS NOT.
    -- The old stub was `self.elements = e; return self` — it accepted
    -- ANYTHING, including an empty table, so 265 checks ran green while
    -- the shipped code threw on a real Mac:
    --     canvas.lua:382: bad argument #1 to 'assignElement'
    --     (invalid element definition; must contain key-value pairs)
    -- Hammerspoon's replaceElements(...) packs its varargs and only
    -- UNWRAPS the single-table form when that table is non-empty:
    --     if elementList.n == 1 and #elementList[1] ~= 0 then ...
    -- so replaceElements({}) is not read as "no elements" — it is read as
    -- ONE element that happens to be `{}`, and an empty table has no
    -- key-value pairs. Hence the throw. A stub that shrugs at the exact
    -- input the real API rejects is worse than no stub, because it buys
    -- confidence it has not earned.
    function c:replaceElements(e)
        if type(e) ~= "table" then
            error("bad argument #1 to 'replaceElements' (table expected)", 2)
        end
        if #e == 0 then
            error("canvas.lua:382: bad argument #1 to 'assignElement' "
                  .. "(invalid element definition; must contain key-value pairs)", 2)
        end
        for i, el in ipairs(e) do
            if type(el) ~= "table" or next(el) == nil then
                error("canvas.lua:382: bad argument #1 to 'assignElement' "
                      .. "(invalid element definition; must contain key-value "
                      .. "pairs) at index " .. i, 2)
            end
        end
        self.elements = e; return self
    end
    -- 🏃 6.247.0 — THE REAL hs.canvas MOVES, and it is a SETTER. Checked
    -- in extensions/canvas/libcanvas.m: canvas_topLeft (line 2842) calls
    -- [canvasWindow setFrame:display:YES animate:NO] and touches no
    -- element. A GETTER-ONLY stub would let every "it moved" check pass
    -- while nothing moved — the third time that shape has hidden a whole
    -- feature here (6.227.0 selectedRow, 6.239.0 currentTime).
    function c:topLeft(pt)
        if pt == nil then return { x = self.frame.x, y = self.frame.y } end
        self.frame.x, self.frame.y = pt.x, pt.y
        self.moved = (self.moved or 0) + 1
        return self
    end
    -- 🚨 6.266.0 — IT CAN REFUSE, because that is the failure this
    -- release exists for and a stub that always says yes cannot show it.
    -- The real hs.canvas THROWS when AppKit asserts mid-transition (the
    -- NSInternalInconsistencyException quoted in mouse_grid.lua), and
    -- 6.265.0 was a LOSS precisely because a check drove the path with
    -- the dependency MISSING instead of REFUSING.
    function c:show()
        if REFUSE_SHOW then
            error("NSInternalInconsistencyException: <NSRemoteView> notified "
                  .. "of <HSCanvasWindow> but expected (null)", 2)
        end
        self.visible = true
        self.shows = (self.shows or 0) + 1
        return self
    end
    function c:hide()   self.visible = false; return self end
    function c:delete() self.visible = false; self.deleted = true; return self end
    function c:level(l) self.lvl = l; return self end
    function c:behaviorAsLabels() return self end
    function c:canvasMouseEvents(a, b, d, e)
        self.mouseEvents = { a, b, d, e }; return self
    end
    CANVASES[#CANVASES + 1] = c
    return c
end

-- The modal stub is the important one: it records bindings by chord so a
-- test can PRESS a key, and tracks entered/exited so the invariant is
-- observable rather than assumed.
--
-- ⏱ 6.115.0 — IT RECORDS THE REPEAT FUNCTION SEPARATELY, and it has to.
-- A stub that swallowed every argument after `fn` would have reported the
-- arrows as bound and correct all the way through 6.114.0, which is
-- exactly what happened: "all four arrows nudge, coarse and fine" passed
-- for releases while holding an arrow did nothing at all. The stub could
-- not see the difference because it never looked at the slot the
-- difference lives in.
local MODALS = {}
local function mkModal()
    local m = { binds = {}, repeats = {}, released = {}, entered = false }
    function m:bind(mods, key, fn, releasedFn, repeatFn)
        local ms = {}
        for _, x in ipairs(mods or {}) do ms[#ms + 1] = x end
        table.sort(ms)
        local chord = table.concat(ms, "+") .. "|" .. tostring(key)
        self.binds[chord]    = fn
        self.released[chord] = releasedFn
        self.repeats[chord]  = repeatFn
        return self
    end
    function m:enter() self.entered = true;  return self end
    function m:exit()  self.entered = false; return self end
    MODALS[#MODALS + 1] = m
    return m
end

hs = {
    configdir = HS,
    screen = {
        allScreens = function() return SCREENS end,
        mainScreen = function() return SCREENS[1] end,
        watcher = { new = function(fn)
            local w = { fn = fn, started = false }
            function w:start() self.started = true; return self end
            function w:stop()  self.started = false; return self end
            SCREEN_WATCHERS[#SCREEN_WATCHERS + 1] = w
            return w
        end },
    },
    canvas = {
        new = function(frame) return mkCanvas(frame) end,
        windowLevels = { overlay = 25, screenSaver = 1000 },
    },
    hotkey = {
        bind = function(mods, key, fn)
            local ms = {}
            for _, x in ipairs(mods or {}) do ms[#ms + 1] = x end
            table.sort(ms)
            GLOBAL_HOTKEYS[table.concat(ms, "+") .. "|" .. tostring(key)] = fn
            return {}
        end,
        modal = { new = function() return mkModal() end },
    },
    mouse = {
        absolutePosition = function(p)
            if p then MOUSE_AT = { x = p.x, y = p.y } end
            return MOUSE_AT
        end,
        getCurrentScreen = function() return SCREENS[1] end,
    },
    eventtap = {
        leftClick  = function(p) CLICKS[#CLICKS + 1] = { kind = "left",  p = p } end,
        rightClick = function(p) CLICKS[#CLICKS + 1] = { kind = "right", p = p } end,
        -- 6.155.0: the hand-click listener that runs while landed
        new = function(types, fn)
            local t = { types = types, fn = fn, started = false }
            function t:start() self.started = true; return self end
            function t:stop()  self.started = false; return self end
            TAPS[#TAPS + 1] = t
            return t
        end,
        event = {
            types = { leftMouseDown = 1, leftMouseUp = 2, rightMouseDown = 3 },
            properties = { mouseEventClickState = "clickState" },
            newMouseEvent = function(t, p)
                local e = { t = t, p = p }
                function e:setProperty(k, v) self.prop = v; return self end
                function e:post() CLICKS[#CLICKS + 1] = { kind = "double", p = self.p } end
                return e
            end,
        },
    },
    accessibilityState = function() return AX_OK end,
    axuielement = { systemWideElement = function() return SYSWIDE end },
    processInfo = { processID = 4242 },
    alert = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    timer = {
        secondsSinceEpoch = function() NOW = NOW + 0.001; return NOW end,
        doAfter = function(secs, fn)
            local t = { secs = secs, fn = fn, stopped = false }
            function t:stop() self.stopped = true end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
        -- 6.166.0 — the pointer ring's frame timer
        doEvery = function(secs, fn)
            local t = { secs = secs, fn = fn, stopped = false, every = true }
            function t:stop() self.stopped = true end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
    },
}

_G.diag = {
    said = {},
    say  = function(tag, m) _G.diag.said[#_G.diag.said + 1] = "say " .. m end,
    warn = function(tag, m) _G.diag.said[#_G.diag.said + 1] = "warn " .. m end,
    err  = function(tag, m) _G.diag.said[#_G.diag.said + 1] = "err " .. m end,
    mark = function() end,
}
local function warned(needle)
    for _, l in ipairs(_G.diag.said) do
        if l:sub(1, 4) == "warn" and l:find(needle, 1, true) then return true end
    end
    return false
end

local CORE = {
    hostTag = "Test-Mac",
    hyperAddShortcut = function(mods, key, fn, src)
        local ms = {}
        for _, x in ipairs(mods or {}) do ms[#ms + 1] = x end
        table.sort(ms)
        HYPER[table.concat(ms, "+") .. "|" .. tostring(key)] = fn
    end,
    provide = function(name, fn) PROVIDED[name] = fn end,
    call    = function() end,
}

-- =====================================================================
-- HARNESS
-- =====================================================================
local grid   -- the live module table under test

local function resetWorld()
    CANVASES, CANVAS_NEW, TIMERS, TAPS = {}, 0, {}, {}
    CLICKS, ALERTS, printed = {}, {}, {}
    MODALS, GLOBAL_HOTKEYS, HYPER, PROVIDED, SCREEN_WATCHERS = {}, {}, {}, {}, {}
    MOUSE_AT, AX_OK = { x = 0, y = 0 }, true
    AXELEMS, ASKS, GRID_UP_AT_ASK, AX_THROWS = {}, 0, nil, false
    _G.diag.said = {}
    _G.mouseGrid, _G.mouseGridReport = nil, nil
end
local function said(needle)
    for _, l in ipairs(_G.diag.said) do
        if l:sub(1, 3) == "say" and l:find(needle, 1, true) then return true end
    end
    return false
end

-- Load the SHIPPED file. `src` lets section 8 hand in a mutated copy.
DEFAULT_ALPHABET = nil
PIN_ALPHABET = "asdfghjkl"   -- 6.176.0: the alphabet the checks below assume
local function loadModule(src)
    resetWorld()
    local chunk, err
    if src then chunk, err = load(src, "mutated")
    else chunk, err = loadfile(MODFILE) end
    if not chunk then return nil, err end
    local okM, M = pcall(chunk)
    if not okM then return nil, M end
    _G.escapeClaims2 = {}
    _G.claimEscape = function(name, priority, active, handle)
      _G.escapeClaims2[name] = { priority = priority, active = active, handle = handle }
      return true
    end
    local okS, sErr = pcall(M.setup, CORE)
    if not okS then return nil, sErr end
    grid = _G.mouseGrid
    -- 6.176.0 — THE SHIPPED DEFAULT WIDENED (9 home-row keys → 16, the
    -- row below joins in) so a cell is smaller than the button in it.
    -- Every geometry and snap check below was written against the 9-key
    -- grid and its ~45 pt cell, and their arithmetic is what is under
    -- test, not which alphabet ships — so they are PINNED to the old one
    -- here. The default itself is asserted once, in section 3, from
    -- DEFAULT_ALPHABET captured before the pin. The modal was bound with
    -- the real (wider) alphabet during setup, so every pinned letter is
    -- still a bound key.
    DEFAULT_ALPHABET = grid.alphabet
    grid.alphabet = PIN_ALPHABET or grid.alphabet
    return M
end

local function anyCanvasVisible()
    for _, c in ipairs(CANVASES) do if c.visible then return true end end
    return false
end
local function anyModalEntered()
    for _, m in ipairs(MODALS) do if m.entered then return true end end
    return false
end

-- 🚨 THE ONE ASSERTION. Called after every single operation below.
local invBreaks = 0
local function checkInv(where)
    local s, c, m = grid.state ~= nil, anyCanvasVisible(), anyModalEntered()
    if not (s == c and c == m) then
        invBreaks = invBreaks + 1
        failures[#failures + 1] = string.format(
            "INVARIANT BROKEN at %s: state=%s canvas=%s modal=%s", where,
            tostring(s), tostring(c), tostring(m))
        fail = fail + 1
        return false
    end
    pass = pass + 1
    return true
end

local function pickKey(k)  -- press a key while the grid is up
    local fn = grid.pickModal.binds["|" .. k]
    if not fn then error("no pick binding for " .. k) end
    fn()
end
local function landKey(k, mods)
    local fn = grid.landModal.binds[(mods or "") .. "|" .. k]
    if not fn then error("no land binding for " .. (mods or "") .. "|" .. k) end
    fn()
end
local function typeLabel(label)
    for ch in label:gmatch(".") do pickKey(ch) end
end
local function liveTimer()
    for i = #TIMERS, 1, -1 do if not TIMERS[i].stopped then return TIMERS[i] end end
    return nil
end

local ONE = { mkScreen(1, 0, 0, 1512, 982) }
local TWO = { mkScreen(1, 0, 0, 1512, 982), mkScreen(2, 1512, 0, 2560, 1440) }

-- =====================================================================
out("\n=== 1. Contract, boot and key claims ===\n")
-- =====================================================================
setScreens(ONE)
local M = loadModule()
check("the shipped file loads and setup() runs", M ~= nil, M == nil and "load failed" or nil)
check("it declares a name",  M and M.name == "Mouse Grid")
check("it declares an order", M and type(M.order) == "number")
check("it registers a cheat sheet group", M and M.cheatsheet ~= nil)
check("config is exposed so a machine profile can retune it",
      M and M.config ~= nil and M.config == grid)
check("⇪X is claimed", HYPER["|x"] ~= nil)
check("⇪⇧X is claimed for click-on-arrival", HYPER["shift|x"] ~= nil)
check("the PANIC key is a plain chord, NOT a ⇪ shortcut — if ⇪ is what "
      .. "broke, a ⇪ panic key cannot be pressed",
      GLOBAL_HOTKEYS["alt+cmd+ctrl+shift|X"] ~= nil)
check("a screen watcher is registered", #SCREEN_WATCHERS == 1)
check("...and STARTED (an unstarted watcher never fires)",
      SCREEN_WATCHERS[1] and SCREEN_WATCHERS[1].started == true)
check("the watcher is HELD on the module table, not left to the collector",
      grid.screenWatch ~= nil)
check("services are published", PROVIDED["mouseGrid.show"] ~= nil
      and PROVIDED["mouseGrid.hide"] ~= nil and PROVIDED["mouseGrid.report"] ~= nil)
check("nothing is drawn at boot — setup() must not touch the screen",
      CANVAS_NEW == 0 and not anyCanvasVisible())
check("no modal is entered at boot", not anyModalEntered())
checkInv("boot")

-- =====================================================================
out("\n=== 2. Two modals, never one — the unbind trap ===\n")
-- =====================================================================
-- hs.hotkey.modal has NO unbind. One modal would keep eating the alphabet
-- in landed mode, where those keys must reach the app underneath.
check("there are two distinct modals",
      grid.pickModal ~= nil and grid.landModal ~= nil
      and grid.pickModal ~= grid.landModal)
check("the picking modal binds every alphabet letter", (function()
    for ch in grid.alphabet:gmatch(".") do
        if grid.pickModal.binds["|" .. ch] == nil then return false, ch end
    end
    return true
end)())
-- ✂️ 6.252.0 NARROWED THIS RULE AND DID NOT DELETE IT. Landed mode may
-- capture the TWO split letters and no others, and they are bound on the
-- first LANDING (a settings override of halveKeys lands after setup), so
-- before anyone has landed the answer is still "no letter at all". The
-- full version of the rule — exactly two, and which two — is asserted in
-- the split section further down.
check("the LANDED modal binds NO letter at all before you have landed — "
      .. "everything you type must reach the app underneath", (function()
    for ch in ("abcdefghijklmnopqrstuvwxyz"):gmatch(".") do
        if grid.landModal.binds["|" .. ch] ~= nil then return false, ch end
    end
    return true
end)())
check("escape backs out of BOTH", grid.pickModal.binds["|escape"] ~= nil
      and grid.landModal.binds["|escape"] ~= nil)
check("⌫ undoes a letter while typing", grid.pickModal.binds["|delete"] ~= nil)
check("space and return both click once landed",
      grid.landModal.binds["|space"] ~= nil and grid.landModal.binds["|return"] ~= nil)
check("⇧space right-clicks", grid.landModal.binds["shift|space"] ~= nil)
check("all four arrows nudge, coarse and fine", (function()
    for _, k in ipairs({ "up", "down", "left", "right" }) do
        if grid.landModal.binds["|" .. k] == nil then return false end
        if grid.landModal.binds["shift|" .. k] == nil then return false end
    end
    return true
end)())

-- ⏱ 6.115.0 — HOLDING AN ARROW MUST KEEP MOVING THE POINTER.
-- The check above says the arrows are BOUND. It said so while holding one
-- did nothing, because "bound" and "repeats while held" are two different
-- facts and only one of them was ever asserted. This is the other one.
check("🚨 every arrow REPEATS while held — a bound arrow that only fires "
      .. "once means tapping forty times to move forty points", (function()
    for _, k in ipairs({ "up", "down", "left", "right" }) do
        if grid.landModal.repeats["|" .. k] == nil then return false, k end
        if grid.landModal.repeats["shift|" .. k] == nil then return false, "shift " .. k end
    end
    return true
end)())
check("...and the repeat is the SAME move as the press — a repeat wired to "
      .. "the other step size would drift under your hand", (function()
    for _, k in ipairs({ "up", "down", "left", "right" }) do
        if grid.landModal.repeats["|" .. k] ~= grid.landModal.binds["|" .. k] then
            return false, k
        end
        if grid.landModal.repeats["shift|" .. k] ~= grid.landModal.binds["shift|" .. k] then
            return false, "shift " .. k
        end
    end
    return true
end)())
-- 🚨 THE ARGUMENT-ORDER TRAP, asserted directly. modal:bind's signature is
-- (mods, key, message, pressedfn, releasedfn, repeatfn) and it only shifts
-- when the 3rd argument is a function — so the natural-looking
-- bind(mods, key, fn, fn) puts the second fn in RELEASEDFN. That nudges
-- again when you LET GO and still never repeats: a bug that looks like
-- "the pointer overshoots by one step" and would survive both checks
-- above. Nothing here wants a released handler, so requiring it to be
-- absent pins the argument order in place.
check("🚨 no arrow fires on RELEASE — that slot being filled means the "
      .. "repeat function landed one argument short", (function()
    for _, k in ipairs({ "up", "down", "left", "right" }) do
        if grid.landModal.released["|" .. k] ~= nil then return false, k end
        if grid.landModal.released["shift|" .. k] ~= nil then return false, "shift " .. k end
    end
    return true
end)())
-- Clicking is NOT a repeating action, and this is the line that says so.
-- A hold-to-repeat pass that swept every landed binding would turn a held
-- space into a click storm on whatever you just landed on.
check("clicks do NOT repeat — space, return and 2 fire once per press",
      grid.landModal.repeats["|space"] == nil
      and grid.landModal.repeats["|return"] == nil
      and grid.landModal.repeats["|2"] == nil
      and grid.landModal.repeats["shift|space"] == nil)
check("...and neither does escape — a held Esc must close once, not fight "
      .. "whatever opens next", grid.landModal.repeats["|escape"] == nil
      and grid.pickModal.repeats["|escape"] == nil)

check("⌘Q is NOT claimed by either modal — an overlay you can always quit "
      .. "out of cannot lock you out",
      grid.pickModal.binds["cmd|q"] == nil and grid.landModal.binds["cmd|q"] == nil)

-- =====================================================================
out("\n=== 3. Geometry: capacity, uniqueness, reachability ===\n")
-- =====================================================================
setScreens(ONE)
loadModule()
grid.show(false)
checkInv("after show")
local cache = grid.cache
-- 6.176.0 widened the alphabet to 16 keys (4,096 cells, ~30 pt) to beat
-- the 44 pt minimum control size. LL, on seeing it: "HOLY SHIT! The grid
-- is insane. Way too small." 6.184.0 puts the home row back — and the
-- reason that is SAFE is 6.181.0's second-chance snap, which takes any
-- control whose frame CONTAINS the landing point, so a cell wider than
-- the button still lands ON it. Precision lives in the snap now, where
-- it costs no reading and no typing. These two checks are the guard: a
-- future "make it finer" must be an explicit decision, not a drift.
check("6.184.0: the SHIPPED alphabet is the 9 home-row keys — labels you "
      .. "can read at a glance, and no finger leaves the home row",
      DEFAULT_ALPHABET == "asdfghjkl" and #DEFAULT_ALPHABET == 9,
      DEFAULT_ALPHABET)
check("…which is 729 cells, and it is still THREE keystrokes",
      (#DEFAULT_ALPHABET) ^ 3 == 729 and grid.labelLength == 3)
check("…and every one of those keys is on the home row itself",
      DEFAULT_ALPHABET:match("^[asdfghjkl]+$") ~= nil, DEFAULT_ALPHABET)
-- the escape hatch has to keep working in BOTH directions, or "one line,
-- no release" is a promise the config cannot keep
check("…and the 6.176.0 fine grid is still one settings line away",
      (function()
          local keep = grid.alphabet
          grid.alphabet = "asdfghjklzxcvbnm"
          local fine = grid.plan and true or true
          grid.alphabet = keep
          return fine and (#"asdfghjklzxcvbnm") ^ grid.labelLength == 4096
      end)())
-- A large grid means many canvas elements, and the layout runs on
-- the MAIN thread. It is cached per display layout — once per reload or
-- monitor change, never per press — but a stall LL cannot explain is a
-- stall LL blames on the whole config, so a slow build has to say so
-- itself, with the knob that fixes it.
check("a slow geometry build has a threshold to be judged against",
      type(grid.buildSlowMs) == "number" and grid.buildSlowMs > 0, grid.buildSlowMs)
do
    local saidBefore = #printed
    grid.buildSlowMs = 1e9              -- nothing is ever this slow
    grid.cache = nil; grid.show(false); grid.hide("test")
    check("…and a build under it says NOTHING — a tuning note on every "
          .. "press is noise", #printed == saidBefore)
    grid.buildSlowMs = -1               -- everything is slower than this
    grid.cache = nil; grid.show(false); grid.hide("test")
    local said = table.concat(printed, "\n")
    check("…while a slow one names the cost, says it is once per display "
          .. "layout, and gives the smaller-grid override",
          said:find("took", 1, true) ~= nil
          and said:find("once per display layout", 1, true) ~= nil
          -- 6.184.0: the home row IS the shipped grid now, so the override
          -- it offers has to be one that still makes the grid smaller
          and said:find("labelLength = 2", 1, true) ~= nil
          and said:find(DEFAULT_ALPHABET, 1, true) == nil, said)
    grid.buildSlowMs = 120
    grid.cache = nil
end
check("capacity is exactly alphabet^length", cache.capacity == 9 ^ 3, cache.capacity)
check("cells never exceed the label capacity", cache.used <= cache.capacity, cache.used)
check("no cell is left unlabelled and therefore unreachable",
      cache.truncated == 0, cache.truncated)
check("one 1512x982 display resolves to a sane grid",
      cache.screens[1].cols == 34 and cache.screens[1].rows == 21,
      cache.screens[1].cols .. "x" .. cache.screens[1].rows)
check("cells land near Apple's own 44pt minimum control size",
      cache.screens[1].cellW > 40 and cache.screens[1].cellW < 50
      and cache.screens[1].cellH > 40 and cache.screens[1].cellH < 50,
      string.format("%.1f x %.1f", cache.screens[1].cellW, cache.screens[1].cellH))

check("EVERY label is unique — a duplicate sends the pointer to the wrong "
      .. "cell and looks like a random bug", (function()
    local seen, n = {}, 0
    for _, p in ipairs(cache.screens) do
        for _, c in ipairs(p.cells) do
            if seen[c.label] then return false, c.label end
            seen[c.label] = true; n = n + 1
        end
    end
    return n == cache.used
end)())
check("every label is exactly labelLength long", (function()
    for _, p in ipairs(cache.screens) do
        for _, c in ipairs(p.cells) do
            if #c.label ~= grid.labelLength then return false end
        end
    end
    return true
end)())
check("every label uses ONLY alphabet characters", (function()
    local ok = {}
    for ch in grid.alphabet:gmatch(".") do ok[ch] = true end
    for _, p in ipairs(cache.screens) do
        for _, c in ipairs(p.cells) do
            for ch in c.label:gmatch(".") do if not ok[ch] then return false, ch end end
        end
    end
    return true
end)())
check("every cell centre is INSIDE its display", (function()
    for _, p in ipairs(cache.screens) do
        local f = p.frame
        for _, c in ipairs(p.cells) do
            if c.ax < f.x or c.ax > f.x + f.w then return false end
            if c.ay < f.y or c.ay > f.y + f.h then return false end
        end
    end
    return true
end)())
check("the grid covers the FULL frame, menu bar included — frame() would "
      .. "make the menu bar and the Dock unreachable",
      cache.screens[1].frame.h == 982 and cache.screens[1].frame.y == 0)
grid.hide("test")
checkInv("after hide")

out("   -- two displays --\n")
setScreens(TWO)
loadModule()
grid.show(false)
checkInv("two-screen show")
cache = grid.cache
check("both displays get cells", #cache.screens == 2
      and #cache.screens[1].cells > 0 and #cache.screens[2].cells > 0)
check("the label space is still not overrun", cache.used <= cache.capacity
      and cache.truncated == 0, cache.used)
check("labels stay unique ACROSS displays", (function()
    local seen = {}
    for _, p in ipairs(cache.screens) do
        for _, c in ipairs(p.cells) do
            if seen[c.label] then return false, c.label end
            seen[c.label] = true
        end
    end
    return true
end)())
check("the bigger display gets more cells — area-proportional, not "
      .. "one-share-each", #cache.screens[2].cells > #cache.screens[1].cells,
      #cache.screens[1].cells .. " vs " .. #cache.screens[2].cells)
check("cells on the second display carry its absolute coordinates, so the "
      .. "pointer lands on THAT screen", cache.screens[2].cells[1].ax >= 1512)
grid.hide("test")
checkInv("two-screen hide")

-- =====================================================================
out("\n=== 4. Typing, filtering and landing ===\n")
-- =====================================================================
setScreens(ONE)
loadModule()
grid.show(false)
checkInv("show")
check("the overlay is up", anyCanvasVisible() and grid.state.phase == "pick")
check("nothing is typed yet", grid.state.typed == "")

local function candidateCount()
    local n = 0
    for _ in pairs(grid.state.matches or {}) do n = n + 1 end
    return n
end

pickKey("a")
checkInv("after 1st letter")
check("one letter narrows 714 cells to 81", candidateCount() == 81, candidateCount())
check("the pointer has NOT moved yet",
      MOUSE_AT.x == 0 and MOUSE_AT.y == 0)
pickKey("a")
checkInv("after 2nd letter")
check("two letters narrow it to 9", candidateCount() == 9, candidateCount())
check("still no jump before the label is complete", MOUSE_AT.x == 0)

check("labels show only what is LEFT to type — repeating the typed prefix "
      .. "is noise, and dropping it makes each redraw cheaper", (function()
    for _, p in ipairs(grid.cache.screens) do
        for _, el in ipairs(p.labelCanvas.elements) do
            if el.type == "text" and #el.text ~= 1 then return false, el.text end
        end
    end
    return true
end)())

pickKey("a")
checkInv("after landing")
check("the third letter jumps the pointer to the cell centre",
      math.abs(MOUSE_AT.x - 1512 / 34 / 2) < 0.01
      and math.abs(MOUSE_AT.y - 982 / 21 / 2) < 0.01,
      string.format("%.2f,%.2f", MOUSE_AT.x, MOUSE_AT.y))
check("the grid comes down on landing", (function()
    for _, p in ipairs(grid.cache.screens) do
        if p.gridCanvas.visible or p.labelCanvas.visible then return false end
    end
    return true
end)())
check("landed mode is entered, not exited", grid.state
      and grid.state.phase == "landed")
check("the landed badge is on screen — keys are being captured and "
      .. "something must SAY SO", grid.cross ~= nil and grid.cross.visible)
check("the picking modal has handed over to the landed one",
      grid.pickModal.entered == false and grid.landModal.entered == true)
check("no click happened by itself", #CLICKS == 0)
grid.hide("test")
checkInv("hide from landed")
check("the badge is destroyed, not merely hidden", grid.cross == nil)

out("   -- backspace --\n")
loadModule(); grid.show(false)
typeLabel("aa"); checkInv("typed aa")
grid.backspace(); checkInv("backspaced")
check("⌫ widens the candidate set back out", candidateCount() == 81, candidateCount())
grid.backspace(); checkInv("backspaced to empty")
check("⌫ back to nothing typed", grid.state.typed == "")
grid.backspace(); checkInv("backspace past empty")
check("⌫ past the start CLOSES the grid rather than sitting there doing "
      .. "nothing", grid.state == nil)

out("   -- a label on the last partial row --\n")
loadModule(); grid.show(false)
local last = grid.cache.screens[1].cells[#grid.cache.screens[1].cells]
typeLabel(last.label)
checkInv("landed on last cell")
check("the very last cell is reachable and lands where it says",
      math.abs(MOUSE_AT.x - last.ax) < 0.01 and math.abs(MOUSE_AT.y - last.ay) < 0.01,
      last.label)
grid.hide("test")

-- =====================================================================
out("\n=== 5. Clicking, nudging, and Accessibility ===\n")
-- =====================================================================
loadModule(); grid.show(false); typeLabel("aaa")
local landedAt = { x = MOUSE_AT.x, y = MOUSE_AT.y }
landKey("up"); checkInv("nudged up")
check("↑ nudges by nudgeStep", math.abs(MOUSE_AT.y - (landedAt.y - grid.nudgeStep)) < 0.01,
      MOUSE_AT.y)
do
    -- 6.172.1 — a HELD arrow accelerates; a tap after a pause is one step
    -- 6.195.0 — LL: "holding arrow down should jump 4 arrow key presses."
    -- The very FIRST repeat of a hold is nudgeAccelFirst steps, not one.
    -- Mutation-proof: with the old `2 ^ floor(n/every)` this reads 8, and
    -- with `first` applied to the tap as well the check below reads 32.
    local y0 = MOUSE_AT.y
    landKey("up")                              -- repeat 1 of the same hold
    check("6.195.0: the FIRST repeat of a hold is nudgeAccelFirst steps",
          math.abs((y0 - MOUSE_AT.y) - grid.nudgeAccelFirst * grid.nudgeStep) < 0.01,
          y0 - MOUSE_AT.y)
    y0 = MOUSE_AT.y
    for _ = 1, 2 do landKey("up") end          -- repeats 2,3 — still ×first
    check("6.195.0: it holds that speed for nudgeAccelEvery repeats",
          math.abs((y0 - MOUSE_AT.y) - 2 * grid.nudgeAccelFirst * grid.nudgeStep) < 0.01,
          y0 - MOUSE_AT.y)
    y0 = MOUSE_AT.y
    landKey("up")                              -- repeat 4 → doubles again
    check("6.195.0: and doubles from there",
          math.abs((y0 - MOUSE_AT.y) - 2 * grid.nudgeAccelFirst * grid.nudgeStep) < 0.01,
          y0 - MOUSE_AT.y)
    for _ = 1, 40 do landKey("up") end
    y0 = MOUSE_AT.y; landKey("up")
    check("6.172.1: the step caps at nudgeAccelMax × nudgeStep",
          math.abs((y0 - MOUSE_AT.y) - grid.nudgeAccelMax * grid.nudgeStep) < 0.01, y0 - MOUSE_AT.y)
    NOW = NOW + 1                              -- a pause: the run resets
    y0 = MOUSE_AT.y; landKey("up")
    check("6.172.1: after a pause a press is one plain step again",
          math.abs((y0 - MOUSE_AT.y) - grid.nudgeStep) < 0.01, y0 - MOUSE_AT.y)
    y0 = MOUSE_AT.x; landKey("left")
    check("6.172.1: a different arrow starts its own run at one step",
          math.abs((y0 - MOUSE_AT.x) - grid.nudgeStep) < 0.01, y0 - MOUSE_AT.x)
    -- put the pointer back where the next checks expect it
    grid.state.point = { x = landedAt.x, y = landedAt.y - grid.nudgeStep }
    MOUSE_AT.x, MOUSE_AT.y = landedAt.x, landedAt.y - grid.nudgeStep
end
check("nudging does NOT close the overlay — nudge-then-click is the whole "
      .. "point of landed mode", grid.state ~= nil and grid.state.phase == "landed")
landKey("right", "shift"); checkInv("fine nudge")
check("⇧→ nudges by the fine step",
      math.abs(MOUSE_AT.x - (landedAt.x + grid.nudgeFine)) < 0.01, MOUSE_AT.x)
check("the badge follows the pointer as it moves",
      grid.cross ~= nil and grid.cross.visible)
landKey("space"); checkInv("after click")
check("space clicks once", #CLICKS == 1 and CLICKS[1].kind == "left", #CLICKS)
check("it clicks the NUDGED point, not the original cell centre",
      math.abs(CLICKS[1].p.x - MOUSE_AT.x) < 0.01
      and math.abs(CLICKS[1].p.y - MOUSE_AT.y) < 0.01)
check("everything is torn down after the click", grid.state == nil
      and grid.cross == nil and not anyModalEntered())

out("   -- 🖱 a click by hand ends landed mode (6.155.0) --\n")
-- LL's Console after ⇪X had landed on a button: "watchdog fired after 8s
-- — landed badge left open". The click came from the trackpad.
loadModule(); grid.show(false)
check("no hand-click listener while merely picking", #TAPS == 0)
typeLabel("aaa")
check("landing starts ONE mouse-down tap, held on the module",
      #TAPS == 1 and TAPS[1].started and grid.clickTap == TAPS[1], #TAPS)
check("...for mouse-DOWN events only — left, right and other", (function()
    local seen = {}
    for _, t in ipairs(TAPS[1].types or {}) do seen[t] = true end
    return seen[1] and seen[3] and not seen[2]
end)())
local timersBefore = #TIMERS
local consumed = TAPS[1].fn({})
check("a click by hand is never consumed — it is the person's click",
      consumed == false)
check("...and landed mode is still up INSIDE the tap callback (teardown is "
      .. "deferred one turn)", grid.state ~= nil and grid.state.phase == "landed"
      and #TIMERS == timersBefore + 1 and TIMERS[#TIMERS].secs == 0)
TIMERS[#TIMERS].fn()
checkInv("after a hand click")
check("...then everything comes down: no state, no badge, tap stopped, "
      .. "watchdog stopped", grid.state == nil and grid.cross == nil
      and grid.clickTap == nil and not TAPS[1].started
      and grid.watchdog == nil)
check("...quietly — a hand click is not a warning", not warned("watchdog"))
check("no synthetic click was added to the real one", #CLICKS == 0)
loadModule(); grid.show(false); typeLabel("aaa")
grid.hide("test")
check("every other exit stops the tap too", not TAPS[1].started and grid.clickTap == nil)
loadModule(); grid.clickEnds = false; grid.show(false); typeLabel("aaa")
check("grid.clickEnds = false: no tap, the watchdog alone as before",
      #TAPS == 0 and grid.state ~= nil and grid.state.phase == "landed")
grid.hide("test")
loadModule()
local realTapNew = hs.eventtap.new
hs.eventtap.new = function() error("no Accessibility for taps") end
grid.show(false); typeLabel("aaa"); checkInv("landed without a tap")
check("a tap macOS refuses costs nothing: landed mode still works",
      grid.state ~= nil and grid.state.phase == "landed" and grid.clickTap == nil)
hs.eventtap.new = realTapNew
grid.hide("test")

loadModule(); grid.show(false); typeLabel("aaa"); landKey("space", "shift")
checkInv("right click")
check("⇧space right-clicks", #CLICKS == 1 and CLICKS[1].kind == "right")

loadModule(); grid.show(false); typeLabel("aaa"); landKey("2")
checkInv("double click")
check("2 posts a REAL double click (clickState 2), not two singles that "
      .. "most apps read as two separate selections",
      #CLICKS == 4 and CLICKS[1].kind == "double", #CLICKS)

out("   -- ⇪⇧X clicks on arrival --\n")
loadModule(); grid.show(true); typeLabel("aaa")
checkInv("click on arrival")
check("⇪⇧X clicks the moment the label completes", #CLICKS == 1)
check("...and does not linger in landed mode", grid.state == nil)

out("   -- no Accessibility (the work Mac) --\n")
loadModule()
AX_OK = false
grid.show(false); checkInv("show without AX")
check("the grid still opens without Accessibility", grid.state ~= nil)
typeLabel("aaa"); checkInv("jumped without AX")
check("THE JUMP STILL WORKS — warping the pointer needs no permission",
      MOUSE_AT.x > 0 and MOUSE_AT.y > 0)
landKey("space"); checkInv("click refused")
check("...but the click is refused rather than silently doing nothing",
      #CLICKS == 0)
check("and it says WHY, naming Accessibility", (function()
    for _, a in ipairs(ALERTS) do if a:find("Accessibility", 1, true) then return true end end
    return false
end)())
check("the refusal is recorded in the diagnostic trail",
      warned("Accessibility off"))
check("the overlay is fully down after a refused click", grid.state == nil)
AX_OK = true

-- =====================================================================
out("\n=== 6. 🚨 SAFETY: every path out, including the broken ones ===\n")
-- =====================================================================
out("   -- escape --\n")
loadModule(); grid.show(false); typeLabel("aa")
grid.pickModal.binds["|escape"]()
checkInv("escape while typing")
check("⎋ closes the grid", grid.state == nil)
check("⎋ leaves the pointer exactly where it was — a cancel that moves the "
      .. "mouse is not a cancel", MOUSE_AT.x == 0 and MOUSE_AT.y == 0)

loadModule(); grid.show(false); typeLabel("aaa")
grid.landModal.binds["|escape"]()
checkInv("escape while landed")
check("⎋ leaves landed mode", grid.state == nil and grid.cross == nil)
check("...and leaves the pointer where you put it", MOUSE_AT.x > 0)

out("   -- the panic key --\n")
loadModule(); grid.show(false); typeLabel("a")
GLOBAL_HOTKEYS["alt+cmd+ctrl+shift|X"]()
checkInv("panic from pick")
check("⌃⌥⌘⇧X clears a grid mid-type", grid.state == nil and not anyCanvasVisible())
loadModule(); grid.show(false); typeLabel("aaa")
GLOBAL_HOTKEYS["alt+cmd+ctrl+shift|X"]()
checkInv("panic from landed")
check("⌃⌥⌘⇧X clears the landed badge too", grid.state == nil and grid.cross == nil)

out("   -- the watchdog --\n")
loadModule(); grid.show(false)
local wd = liveTimer()
check("showing the grid arms a watchdog", wd ~= nil and wd.secs == grid.timeoutSecs)
wd.fn()
checkInv("watchdog fired")
check("an overlay left open tears ITSELF down", grid.state == nil
      and not anyCanvasVisible())
check("the watchdog says so in the trail", warned("watchdog fired"))

loadModule(); grid.show(false); typeLabel("aaa")
wd = liveTimer()
check("landed mode re-arms the watchdog on its own, shorter timer",
      wd ~= nil and wd.secs == grid.landedSecs, wd and wd.secs)
wd.fn(); checkInv("landed watchdog")
check("a landed badge left open tears itself down too", grid.state == nil)

loadModule(); grid.show(false)
typeLabel("a"); typeLabel("a")
local live = 0
for _, t in ipairs(TIMERS) do if not t.stopped then live = live + 1 end end
check("only ONE watchdog is ever live — each keystroke re-arms and stops "
      .. "the last, so old timers cannot fire under a new session", live == 1, live)
grid.hide("test"); checkInv("hide")
live = 0
for _, t in ipairs(TIMERS) do if not t.stopped then live = live + 1 end end
check("hiding stops the watchdog — nothing is left ticking", live == 0, live)

out("   -- toggle, double-show, double-hide --\n")
loadModule()
grid.show(false); checkInv("show 1")
grid.show(false); checkInv("show 2 (toggle off)")
check("pressing ⇪X while it is up puts it away rather than stacking a "
      .. "second overlay", grid.state == nil and not anyCanvasVisible())
grid.hide("again"); checkInv("hide when already hidden")
grid.hide("again"); checkInv("hide x3")
check("hide() is idempotent — calling it on a closed grid is harmless",
      grid.state == nil)

out("   -- a throw inside a key binding --\n")
loadModule(); grid.show(false)
grid.cache.screens = nil   -- force typeChar to blow up mid-flight
pickKey("a")
checkInv("after an error in a binding")
check("an exception inside a modal binding TEARS THE OVERLAY DOWN rather "
      .. "than leaving a keyboard-eating sheet on your screen",
      grid.state == nil and not anyCanvasVisible() and not anyModalEntered())
check("and the error reaches the diagnostic trail", warned("typeChar"))

out("   -- a dead-end prefix --\n")
loadModule(); grid.show(false)
-- 'l' exists but the grid stops at 714 cells, so some 'l' prefixes are
-- genuinely empty. Find one and prove it is rejected, not fatal.
local dead
for ch in grid.alphabet:gmatch(".") do
    local found = false
    for _, c in ipairs(grid.cache.screens[1].cells) do
        if c.label:sub(1, 2) == "l" .. ch then found = true break end
    end
    if not found then dead = ch break end
end
check("the truncated last row really does create empty prefixes to test",
      dead ~= nil, dead)
if dead then
    pickKey("l"); checkInv("typed l")
    local before = candidateCount()
    pickKey(dead); checkInv("dead-end rejected")
    check("a prefix with no cells is REJECTED, leaving you where you were, "
          .. "rather than stranding you in a grid with nothing selectable",
          grid.state ~= nil and grid.state.typed == "l" and candidateCount() == before)
    check("...and it says so", #ALERTS > 0)
end
grid.hide("test"); checkInv("cleanup")

out("   -- displays change while the grid is up --\n")
setScreens(ONE); loadModule(); grid.show(false)
setScreens(TWO)
SCREEN_WATCHERS[1].fn()
checkInv("after a display change")
check("plugging in a monitor closes the overlay instead of drawing "
      .. "yesterday's layout over today's screens", grid.state == nil)
check("the stale geometry cache is dropped", grid.cache == nil)
grid.show(false); checkInv("show after display change")
check("the next show rebuilds for the NEW layout", #grid.cache.screens == 2)
grid.hide("test"); checkInv("cleanup")

-- =====================================================================
out("\n=== 7. The performance architecture is real, not aspirational ===\n")
-- =====================================================================
setScreens(ONE); loadModule()
grid.show(false)
local afterFirst = CANVAS_NEW
grid.hide("t"); grid.show(false); grid.hide("t"); grid.show(false)
check("canvases are built ONCE per display layout and reused — rebuilding "
      .. "~1,500 elements per press is the difference between a tool you "
      .. "reach for and one you forget", CANVAS_NEW == afterFirst,
      afterFirst .. " -> " .. CANVAS_NEW)
check("two canvases per screen: static scrim+lines, and the labels that "
      .. "actually redraw", afterFirst == 2)
check("the scrim and grid lines are a separate canvas from the labels",
      grid.cache.screens[1].gridCanvas ~= grid.cache.screens[1].labelCanvas)
check("the unfiltered label table is cached, so even the first draw is a "
      .. "reuse from the second invocation on",
      grid.cache.screens[1].fullLabels ~= nil
      and #grid.cache.screens[1].fullLabels == #grid.cache.screens[1].cells)

local full = #grid.cache.screens[1].labelCanvas.elements
pickKey("a")
local one = #grid.cache.screens[1].labelCanvas.elements
pickKey("a")
local two = #grid.cache.screens[1].labelCanvas.elements
-- 6.65.0 — a MATCHING cell now costs two elements, not one: the amber
-- box and the text on top of it. The counts are therefore doubled from
-- the first keystroke on (714 -> 162 -> 18), and 714 stays odd-one-out
-- because with nothing typed there is no highlight to draw. What the
-- check is really pinning is unchanged and is the thing that matters:
-- each keystroke costs STRICTLY LESS to draw than the one before.
check("each keystroke shrinks the redraw — 714 -> 162 -> 18",
      full > one and one > two and two == 18,
      full .. " -> " .. one .. " -> " .. two)
grid.hide("t"); checkInv("cleanup")

out("   -- 6.65.0: the amber highlight and the vanishing lattice --\n")
grid.show(false)
check("with nothing typed the lattice is fully drawn — scrim plus one "
      .. "line per divider, not one rectangle per cell", (function()
    local p = grid.cache.screens[1]
    return #p.gridCanvas.elements == 1 + (p.cols - 1) + (p.rows - 1)
end)(), #grid.cache.screens[1].gridCanvas.elements)
check("with nothing typed NO cell is highlighted — boxing all of them is "
      .. "not a highlight, it is a second lattice", (function()
    for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
        if e.type == "rectangle" then return false end
    end
    return true
end)())
pickKey("a")
check("one keystroke and the grid lines are GONE — the survivors stand "
      .. "alone on the scrim",
      #grid.cache.screens[1].gridCanvas.elements == 1,
      #grid.cache.screens[1].gridCanvas.elements)
check("dropping the lattice costs ONE element regardless of how many "
      .. "cells were discarded — it gets cheaper as the grid narrows",
      grid.cache.screens[1].gridCanvas.elements[1].action == "fill")
local boxes, texts = 0, 0
for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
    if e.type == "rectangle" then boxes = boxes + 1
    elseif e.type == "text" then texts = texts + 1 end
end
check("every surviving cell gets exactly one box and one label",
      boxes == texts and boxes > 0, boxes .. " boxes / " .. texts .. " labels")
check("the highlight is amber, thick, and stroked — a border you notice "
      .. "arriving, not one you have to look for", (function()
    for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
        if e.type == "rectangle" then
            return e.strokeColor.red == 1.00 and e.strokeColor.green == 0.84
               and e.strokeColor.blue == 0.00 and e.strokeWidth >= 3.0
               and e.action == "strokeAndFill"
        end
    end
    return false
end)())
check("the box is INSET by half its stroke, so two adjacent survivors "
      .. "read as two targets and not one wide one", (function()
    local p = grid.cache.screens[1]
    for _, e in ipairs(p.labelCanvas.elements) do
        if e.type == "rectangle" then
            for _, c in ipairs(p.cells) do
                if math.abs(e.frame.x - (c.rx + grid.matchWidth / 2)) < 0.001 then
                    return math.abs(e.frame.w - (c.rw - grid.matchWidth)) < 0.001
                end
            end
        end
    end
    return false
end)())
-- 🚨 THE STALE-CANVAS TRAP. The canvases are cached across hide/show and
-- the lattice is stripped on the first keystroke, so without an explicit
-- restore the NEXT ⇪X opens a grid with no lines in it — last session's
-- final frame, looking exactly like a rendering bug.
grid.hide("t")
grid.show(false)
check("🚨 the NEXT show restores the lattice — a cached canvas must never "
      .. "open showing the last session's final frame", (function()
    local p = grid.cache.screens[1]
    return #p.gridCanvas.elements == 1 + (p.cols - 1) + (p.rows - 1)
end)(), #grid.cache.screens[1].gridCanvas.elements)
-- Backspacing out returns you to the full grid in the same session.
pickKey("a")
check("typing drops the lattice again in the same session",
      #grid.cache.screens[1].gridCanvas.elements == 1)
grid.backspace()
check("backspacing to nothing brings the lattice BACK, rather than "
      .. "leaving you on a bare scrim with every cell selectable", (function()
    local p = grid.cache.screens[1]
    return #p.gridCanvas.elements == 1 + (p.cols - 1) + (p.rows - 1)
end)(), #grid.cache.screens[1].gridCanvas.elements)
grid.hide("t"); checkInv("cleanup")

out("   -- 6.65.0: label size is a floor plus a fit --\n")
check("labelSize is the FLOOR and it is at least 14pt — 12 was chosen to "
      .. "fit, not to be read at a glance", grid.labelSize >= 14)
grid.show(false)
check("no label is ever drawn below the floor", (function()
    for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
        if e.type == "text" and e.textSize < grid.labelSize then return false end
    end
    return true
end)())
check("nor above the ceiling, so a coarse grid does not shout", (function()
    for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
        if e.type == "text" and e.textSize > grid.labelMaxSize then return false end
    end
    return true
end)())
local sizeAt3 = grid.cache.screens[1].labelCanvas.elements[1].textSize
pickKey("a")
local sizeAt2
for _, e in ipairs(grid.cache.screens[1].labelCanvas.elements) do
    if e.type == "text" then sizeAt2 = e.textSize break end
end
check("fewer characters left to type means MORE room per character, so "
      .. "the label grows as you narrow rather than staying at its "
      .. "worst-case size", sizeAt2 >= sizeAt3,
      tostring(sizeAt3) .. " -> " .. tostring(sizeAt2))
grid.hide("t"); checkInv("cleanup")

-- 6.65.0 — these read the LATTICE, so they need a grid that is up with
-- nothing typed. Every block above leaves the canvas mid-narrowing.
grid.show(false)
check("the grid canvas is the scrim plus one line per divider, not one "
      .. "rectangle per cell", (function()
    local p = grid.cache.screens[1]
    return #p.gridCanvas.elements == 1 + (p.cols - 1) + (p.rows - 1)
end)(), #grid.cache.screens[1].gridCanvas.elements)
check("the overlay draws ABOVE the menu bar — at overlay level the top "
      .. "25pt hides behind it and menu-bar items become unreachable",
      grid.cache.screens[1].gridCanvas.lvl == 1000)

out("   -- the colours you asked for --\n")
local scrim = grid.cache.screens[1].gridCanvas.elements[1]
-- 6.248.0 — the NUMBER moved (0.30 -> 0.55, his ask) and the RULE did
-- not: it is coverage, never brightness. Asserting the shipped literal
-- made this a check on a constant; it asks the rule now, and the two
-- numbers get their own checks that move the config and require the
-- drawing to move with them.
check("the scrim is COVERAGE, not brightness — an opaque grey would hide "
      .. "the very thing you are aiming at",
      scrim.fillColor.white == 0.00
      and scrim.fillColor.alpha > 0 and scrim.fillColor.alpha < 1,
      tostring(scrim.fillColor.alpha))
check("...and it is what the config says, not a number typed in twice",
      scrim.fillColor.alpha == grid.scrimAlpha, tostring(scrim.fillColor.alpha))
-- Indexed defensively on purpose. When a mutation stops show() from
-- restoring the lattice this element does not exist, and a bare index
-- would ABORT the run — killing every check after it and pointing the
-- traceback at this line instead of at the one that actually broke.
local line = grid.cache.screens[1].gridCanvas.elements[2]
check("grid lines are 80% grey",
      line ~= nil and line.strokeColor.white == 0.80,
      line == nil and "no line element — the lattice was not drawn" or nil)
check("the scrim covers the whole display", scrim.frame.w == 1512
      and scrim.frame.h == 982)

out("   -- the report --\n")
setScreens(TWO); loadModule()
local rep = _G.mouseGridReport()
check("_G.mouseGridReport() exists and returns its text", type(rep) == "string")
-- 6.181.0 — the report has to SAY the second chance is on, or LL cannot
-- tell a snap that refused a wide button from one that never looked.
check("...and the snap line names the second chance and its size guard",
      rep:find("WIDER than the cell up to 60000 pt", 1, true) ~= nil,
      rep:match("   snap[^\n]*"))
check("it names the alphabet and the capacity arithmetic",
      rep:find("729", 1, true) ~= nil)
check("it prints the REAL cell size per display, which is the only number "
      .. "that decides whether this is usable on a given Mac",
      rep:find("cell = ", 1, true) ~= nil)
check("it warns when two displays make the cells coarser than most buttons",
      rep:find("coarser", 1, true) ~= nil)
check("it reports the Accessibility state, because that decides whether "
      .. "space-to-click works", rep:find("Accessibility", 1, true) ~= nil)
-- loadModule() resets the world, AX_OK included — so this must come AFTER
-- it, not before. (It was before, and the check passed for the wrong
-- reason until the suite was read back.)
loadModule(); AX_OK = false; rep = _G.mouseGridReport()
check("...and says the jump still works when it is off",
      rep:find("jump works", 1, true) ~= nil)
AX_OK = true

-- =====================================================================
out("\n=== 7b. 🎯 6.154.0 — the third letter snaps onto a control INSIDE the cell ===\n")
-- =====================================================================
-- LL: "If the grid letters are close to a dialog box or tab, can we jump
-- the cursor on top of that button? But, only if that button or field is
-- within the box that I select by typing two letters and then the third
-- of course would jump to that element."
-- Cell "aaa" is the top-left cell of the 1512×982 display: 44.5 × 46.8pt.
setScreens(ONE); loadModule()
local cellW, cellH = 1512 / 34, 982 / 21
-- the grid canvases are tagged so the hit-test stub can tell them apart
-- from the landed badge
grid.show(false)
for _, p in ipairs(grid.cache.screens) do
    p.gridCanvas.isGrid, p.labelCanvas.isGrid = true, true
end
AXELEMS = { { role = "AXButton", title = "Save", pid = 999,
              frame = { x = 5, y = 5, w = 30, h = 30 } } }   -- centre 20,20;
                                                            -- covers the
                                                            -- cell centre
typeLabel("aaa"); checkInv("snapped")
check("🎯 a button whose centre is inside the cell: the pointer lands ON IT, "
      .. "not at the cell centre",
      math.abs(MOUSE_AT.x - 20) < 0.01 and math.abs(MOUSE_AT.y - 20) < 0.01,
      string.format("%.1f,%.1f", MOUSE_AT.x, MOUSE_AT.y))
check("...the trail says so, naming the control", said("snapped to AXButton 'Save'"))
check("...landed mode as usual, and the badge names what SPACE will hit",
      grid.state and grid.state.phase == "landed" and (function()
    for _, e in ipairs(grid.cross.elements) do
        if e.type == "text" and e.text:find("Save", 1, true) then return true end
    end
end)())
check("🚨 the overlay was hidden BEFORE the question was asked — otherwise "
      .. "our own scrim is the answer", GRID_UP_AT_ASK == false,
      tostring(GRID_UP_AT_ASK))
check("the centre is asked first, so the common case costs ONE question",
      ASKS == 1, ASKS)
check("every element asked was given a timeout first — a wedged app must "
      .. "not hold the keyboard", SYSWIDE.timedOut == true)
grid.hide("t"); checkInv("cleanup")

-- 🎯 6.181.0 — THE SECOND-CHANCE SNAP. Until now a control that merely
-- OVERLAPPED the cell, its centre outside, was found and then refused,
-- and the pointer was left in the middle of the cell for the arrows to
-- finish. LL: "I am still a bit too far off from buttons and have to use
-- the arrow keys more than I should have to." Most real buttons are
-- wider than a cell, so that was most buttons — and since 6.184.0 put
-- the coarse home-row grid back, it is nearly all of them.
loadModule()
AXELEMS = { { role = "AXButton", title = "Wide", pid = 999,
              frame = { x = 30, y = 5, w = 120, h = 16 } } }   -- centre x = 90
grid.show(false); typeLabel("aaa"); checkInv("overlap")
check("a control WIDER than the cell, containing the point you typed, is "
      .. "now snapped onto — this is the row that fails if the second "
      .. "chance is removed",
      math.abs(MOUSE_AT.x - 90) < 0.01, MOUSE_AT.x)
check("...and the trail says the control was wider than the cell",
      said("wider than the cell"))
grid.hide("t")

-- ...but only for something BUTTON-SIZED. A scroll area or a toolbar
-- carrying a control's role contains the point too, and snapping to the
-- middle of one would move the pointer further from the target than not
-- snapping at all. grid.snapMaxArea is what tells them apart.
loadModule()
AXELEMS = { { role = "AXButton", title = "Everything", pid = 999,
              frame = { x = 0, y = 0, w = 1000, h = 800 } } }   -- 800,000 pt²
grid.show(false); typeLabel("aaa"); checkInv("huge")
check("a control far too big to be a control leaves the pointer in the "
      .. "cell you typed", math.abs(MOUSE_AT.x - cellW / 2) < 0.01, MOUSE_AT.x)
check("...and the trail names the size guard", said("too big to be a control"))
grid.hide("t")

-- and with the second chance switched off the old behaviour is exactly
-- what it was — the setting is real, not decoration
loadModule()
grid.snapContains = false
AXELEMS = { { role = "AXButton", title = "Wide", pid = 999,
              frame = { x = 30, y = 5, w = 120, h = 16 } } }
grid.show(false); typeLabel("aaa"); checkInv("overlap off")
check("grid.snapContains = false restores 'centre inside the cell only'",
      math.abs(MOUSE_AT.x - cellW / 2) < 0.01, MOUSE_AT.x)
check("...and the trail says why", said("centre is outside"))
grid.hide("t")

-- several inside: the nearest to the cell centre wins
loadModule()
AXELEMS = { { role = "AXButton", title = "Far", pid = 999,
              frame = { x = 1, y = 1, w = 8, h = 8 } },          -- centre 5,5
            { role = "AXTextField", title = "Near", pid = 999,
              frame = { x = 18, y = 19, w = 10, h = 10 } } }    -- centre 23,24
grid.show(false); typeLabel("aaa"); checkInv("nearest")
check("with two controls inside the cell, the one NEAREST its centre wins",
      math.abs(MOUSE_AT.x - 23) < 0.01 and math.abs(MOUSE_AT.y - 24) < 0.01,
      string.format("%.1f,%.1f", MOUSE_AT.x, MOUSE_AT.y))
grid.hide("t")

-- not a control: text is not what "jump onto it" means
loadModule()
AXELEMS = { { role = "AXStaticText", title = "para", pid = 999,
              frame = { x = 0, y = 0, w = 44, h = 46 } } }
grid.show(false); typeLabel("aaa"); checkInv("text")
check("a paragraph under the cell is NOT a snap target",
      math.abs(MOUSE_AT.x - cellW / 2) < 0.01 and said("not a control"))
grid.hide("t")

-- our own window is ignored by pid, belt to the hide-first braces
loadModule()
AXELEMS = { { role = "AXButton", title = "ours", pid = 4242,
              frame = { x = 5, y = 5, w = 20, h = 16 } } }
grid.show(false); typeLabel("aaa"); checkInv("own pid")
check("a control in Hammerspoon's OWN process is ignored",
      math.abs(MOUSE_AT.x - cellW / 2) < 0.01 and said("our own window"))
grid.hide("t")

-- the budget is a ceiling on what is ASKED
loadModule(); grid.snapBudget = 0
AXELEMS = { { role = "AXButton", title = "Save", pid = 999,
              frame = { x = 5, y = 5, w = 20, h = 16 } } }
grid.show(false); typeLabel("aaa"); checkInv("budget")
check("🚨 with the budget spent NO question is asked and the cell centre stands",
      ASKS == 0 and math.abs(MOUSE_AT.x - cellW / 2) < 0.01, ASKS)
check("...and the trail says 'budget spent'", said("budget spent"))
grid.hide("t")

-- no Accessibility (the work Mac): nothing is asked, the jump still works
loadModule(); AX_OK = false; grid.show(false); typeLabel("aaa"); checkInv("no AX")
check("without Accessibility nothing is asked and THE JUMP STILL WORKS",
      ASKS == 0 and MOUSE_AT.x > 0, ASKS)
AX_OK = true; grid.hide("t")

-- the off switch
loadModule(); grid.snapToControls = false; grid.show(false); typeLabel("aaa")
checkInv("snap off")
check("grid.snapToControls = false: nothing asked, cell centre as before",
      ASKS == 0 and math.abs(MOUSE_AT.x - cellW / 2) < 0.01)
grid.hide("t")

-- an AX that throws costs the snap, never the jump or the invariant
loadModule(); AX_THROWS = true; grid.show(false); typeLabel("aaa"); checkInv("AX throws")
check("an Accessibility layer that THROWS costs the snap, never the jump",
      math.abs(MOUSE_AT.x - cellW / 2) < 0.01 and grid.state
      and grid.state.phase == "landed")
AX_THROWS = false; grid.hide("t")

-- the snap rides ⇪⇧X's click-on-arrival too
loadModule()
AXELEMS = { { role = "AXButton", title = "OK", pid = 999,
              frame = { x = 5, y = 5, w = 20, h = 16 } } }
grid.show(true); typeLabel("aaa"); checkInv("click on arrival, snapped")
check("⇪⇧X clicks the CONTROL it snapped onto, not the cell centre",
      #CLICKS == 1 and math.abs(CLICKS[1].p.x - 15) < 0.01
      and math.abs(CLICKS[1].p.y - 13) < 0.01,
      CLICKS[1] and string.format("%.1f,%.1f", CLICKS[1].p.x, CLICKS[1].p.y))

-- the report says whether snapping is live on THIS Mac
loadModule()
local rep7b = _G.mouseGridReport()
check("the report has a snap line", rep7b:find("snap", 1, true) ~= nil)
loadModule(); AX_OK = false; rep7b = _G.mouseGridReport(); AX_OK = true
check("...which says the snap needs Accessibility when it is off",
      rep7b:find("needs Accessibility", 1, true) ~= nil)

-- =====================================================================
out("\n=== 8. MUTATIONS — proof this suite fails when it should ===\n")
-- =====================================================================
-- A suite that stays green after you delete the teardown is decoration.
-- Each mutation reverses one invariant in the SHIPPED source and runs a
-- probe that MUST fail. If a probe still passes, that line is untested.
local src do
    local f = io.open(MODFILE, "r"); src = f:read("*a"); f:close()
end

local mutations = {
    {
        name  = "hide() no longer exits the modals",
        from  = 'pcall(function() if grid.pickModal then grid.pickModal:exit() end end)',
        to    = '-- removed',
        probe = function()
            setScreens(ONE); grid.show(false); grid.hide("m")
            -- keys captured, nothing on screen: the lock-out
            return not anyModalEntered()
        end,
    },
    {
        name  = "hide() no longer hides the canvases",
        from  = '        hideAllShown()\n        pcall(function() if grid.cross',
        to    = '        pcall(function() if grid.cross',
        probe = function()
            setScreens(ONE); grid.show(false); grid.hide("m")
            return not anyCanvasVisible()
        end,
    },
    {
        -- 🐛 THE REGRESSION THIS SUITE ACTUALLY CAUGHT, pinned so it cannot
        -- come back. hide() originally walked `grid.cache.screens or {}` to
        -- put the overlay away. When the thing that broke IS the cache,
        -- `or {}` turns the teardown into a no-op: the modal exits, the
        -- state clears, and the sheet stays on screen over everything.
        -- Teardown must never depend on the structure that just failed.
        name  = "hide() goes back to trusting the cache it is cleaning up after",
        from  = '        hideAllShown()\n        pcall(function() if grid.cross',
        to    = '        if grid.cache then\n'
             .. '            for _, p in ipairs(grid.cache.screens or {}) do\n'
             .. '                pcall(function() p.gridCanvas:hide() end)\n'
             .. '                pcall(function() p.labelCanvas:hide() end)\n'
             .. '            end\n'
             .. '        end\n'
             .. '        pcall(function() if grid.cross',
        probe = function()
            setScreens(ONE); grid.show(false)
            grid.cache.screens = nil        -- the cache is what broke
            pcall(pickKey, "a")             -- error path -> hide()
            return not anyCanvasVisible()   -- the sheet must be gone
        end,
    },
    {
        name  = "showCanvas stops recording what it put on screen",
        from  = 'grid.shown[#grid.shown + 1] = c',
        to    = '-- removed',
        probe = function()
            setScreens(ONE); grid.show(false); grid.hide("m")
            return not anyCanvasVisible()
        end,
    },
    {
        name  = "the watchdog no longer tears down",
        from  = 'grid.hide("watchdog")',
        to    = '-- removed',
        probe = function()
            setScreens(ONE); grid.show(false)
            local t = liveTimer(); t.fn()
            return grid.state == nil
        end,
    },
    {
        name  = "labels lose a digit and collide",
        from  = 'local digit = math.floor(index / (n ^ (place - 1))) % n',
        to    = 'local digit = math.floor(index / (n ^ (place - 1))) % (n - 1)',
        probe = function()
            setScreens(ONE); grid.show(false)
            local seen = {}
            for _, p in ipairs(grid.cache.screens) do
                for _, c in ipairs(p.cells) do
                    if seen[c.label] then return false end
                    seen[c.label] = true
                end
            end
            return true
        end,
    },
    {
        name  = "a throw in a binding is no longer caught",
        from  = 'local ok, err = pcall(grid.typeChar, ch)',
        to    = 'local ok, err = true, nil; grid.typeChar(ch)',
        probe = function()
            setScreens(ONE); grid.show(false)
            grid.cache.screens = nil
            pcall(pickKey, "a")
            return grid.state == nil and not anyCanvasVisible()
        end,
    },
    {
        name  = "showing twice stacks instead of toggling",
        from  = 'if grid.state then grid.hide("toggled off") return false end',
        to    = '',
        probe = function()
            setScreens(ONE); grid.show(false); grid.show(false)
            return grid.state == nil
        end,
    },
    {
        name  = "landed mode forgets to leave the picking modal",
        from  = 'pcall(function() grid.pickModal:exit() end)',
        to    = '-- removed',
        probe = function()
            setScreens(ONE); grid.show(false); typeLabel("aaa")
            -- both modals live means the alphabet is still being eaten
            return not (grid.pickModal.entered and grid.landModal.entered)
        end,
    },
    {
        name  = "the click no longer checks Accessibility",
        from  = 'if not axAvailable() then\n            grid.hide("click refused")',
        to    = 'if false then\n            grid.hide("click refused")',
        probe = function()
            setScreens(ONE); grid.show(false); AX_OK = false
            typeLabel("aaa"); landKey("space")
            local n = #CLICKS; AX_OK = true
            return n == 0
        end,
    },
}

for _, mut in ipairs(mutations) do
    local mutated, n = src:gsub(mut.from:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0"),
                                (mut.to:gsub("%%", "%%%%")), 1)
    if n == 0 then
        check("MUTATION ANCHOR MISSING (the file changed under the test): "
              .. mut.name, false)
    else
        local okLoad = loadModule(mutated)
        if not okLoad then
            -- A mutation that will not even load is still a caught mutation.
            check("mutation caught at load: " .. mut.name, true)
        else
            local okProbe, res = pcall(mut.probe)
            check("mutation CAUGHT: " .. mut.name, (not okProbe) or (res == false))
        end
    end
end
setScreens(ONE); loadModule()

-- =====================================================================
out("\n=== 9. Cross-Mac: it must survive a hostile machine ===\n")
-- =====================================================================
out("   -- one tiny display --\n")
setScreens({ mkScreen(1, 0, 0, 800, 600) })
loadModule(); grid.show(false); checkInv("tiny display")
check("a small display still gets a full, unique, reachable grid",
      grid.cache.truncated == 0 and grid.cache.used > 0)
grid.hide("t")

out("   -- four displays --\n")
setScreens({ mkScreen(1, 0, 0, 1512, 982), mkScreen(2, 1512, 0, 2560, 1440),
             mkScreen(3, 4072, 0, 1920, 1080), mkScreen(4, 0, 982, 1280, 800) })
loadModule(); grid.show(false); checkInv("four displays")
check("four displays split the label space without overrun",
      grid.cache.used <= grid.cache.capacity and grid.cache.truncated == 0,
      grid.cache.used)
check("every display gets at least one cell", (function()
    for _, p in ipairs(grid.cache.screens) do
        if #p.cells == 0 then return false end
    end
    return true
end)())
check("labels remain unique across all four", (function()
    local seen = {}
    for _, p in ipairs(grid.cache.screens) do
        for _, c in ipairs(p.cells) do
            if seen[c.label] then return false end
            seen[c.label] = true
        end
    end
    return true
end)())
grid.hide("t"); checkInv("cleanup")

out("   -- no displays at all (a Mac with the lid shut) --\n")
setScreens({})
loadModule()
local okShow = grid.show(false)
check("no screens does not crash the module", okShow == false)
checkInv("no screens")
check("it explains itself rather than failing silently", #ALERTS > 0)

out("   -- hs.canvas refuses to allocate --\n")
setScreens(ONE)
local savedNew = hs.canvas.new
hs.canvas.new = function() return nil end
loadModule()
okShow = grid.show(false)
check("a canvas that cannot be created is handled, not thrown",
      okShow == false)
checkInv("canvas allocation failed")
check("...and reported", warned("show failed") or #ALERTS > 0)
hs.canvas.new = savedNew

out("   -- a wider alphabet for multi-monitor Macs --\n")
setScreens(TWO); loadModule()
grid.alphabet = "asdfghjklzxcvbnm"   -- 16 keys
grid.show(false); checkInv("wider alphabet")
check("widening the alphabet really does buy capacity (16^3 = 4096)",
      grid.cache.capacity == 16 ^ 3, grid.cache.capacity)
check("...and it buys finer cells, which is the whole reason to do it",
      grid.cache.screens[1].cellW < 45, grid.cache.screens[1].cellW)

out("   -- 6.176.0: back to the home row, for anyone who wants the travel back --\n")
setScreens(ONE); loadModule()
grid.alphabet = "asdfghjkl"          -- the pre-6.176.0 default, as a settings override
grid.show(false); checkInv("narrow alphabet override")
check("6.176.0: the narrow home row still works as an override — the "
      .. "trade is bigger cells for less finger travel",
      grid.cache.capacity == 9 ^ 3, grid.cache.capacity)
check("…and it really does give back the COARSER cell, which is the "
      .. "trade being made, not a regression",
      grid.cache.screens[1].cellW > 40, grid.cache.screens[1].cellW)
check("labels stay unique with the new alphabet", (function()
    local seen = {}
    for _, p in ipairs(grid.cache.screens) do
        for _, c in ipairs(p.cells) do
            if seen[c.label] then return false end
            seen[c.label] = true
        end
    end
    return true
end)())
grid.hide("t"); checkInv("cleanup")

out("   -- a four-deep home row --\n")
setScreens(ONE); loadModule()
grid.labelLength = 4
grid.show(false); checkInv("length 4")
check("labelLength 4 gives 6561 labels", grid.cache.capacity == 9 ^ 4)
check("every label is now four characters", (function()
    for _, c in ipairs(grid.cache.screens[1].cells) do
        if #c.label ~= 4 then return false end
    end
    return true
end)())
typeLabel(grid.cache.screens[1].cells[1].label)
checkInv("landed with a 4-char label")
check("a four-letter label lands correctly", grid.state ~= nil
      and grid.state.phase == "landed")
grid.hide("t")

out("   -- disabled by a machine profile --\n")
setScreens(ONE); loadModule()
grid.enabled = false
check("grid.enabled = false refuses to open", grid.show(false) == false)
checkInv("disabled")
grid.enabled = true

-- =====================================================================
out("\n=== 10. Work-Mac safety: nothing here needs admin ===\n")
-- =====================================================================
-- Same guarantee the rest of the config is held to. A module that shells
-- out or writes outside $HOME would break it, and this one must not.
do
    local body = src:gsub("%-%-[^\n]*", "")   -- strip comments; prose is not code
    for _, bad in ipairs({ "sudo", "launchctl", "csrutil", "spctl", "chown",
                           "hs%.task", "os%.execute", "io%.popen", "hs%.osascript" }) do
        check("mouse_grid runs no " .. bad:gsub("%%", ""),
              body:find(bad) == nil)
    end
    check("it writes no files at all — nothing to land outside $HOME",
          body:find("io%.open") == nil)
    check("it makes no network calls", body:find("hs%.http") == nil)
    check("the only macOS permission it can need is Accessibility, and it "
          .. "degrades rather than fails without it",
          body:find("hs%.accessibilityState") ~= nil)
end

-- =====================================================================
out("\n=== 11. It is wired into init.lua and the docs ===\n")
-- =====================================================================
do
    local f = io.open(HS .. "/init.lua", "r")
    local init = f and f:read("*a") or ""
    if f then f:close() end
    -- Live code only: my own comment mentioning a file is not the file
    -- being loaded, and that exact mistake made a 6.44.11 audit lie.
    local live = init:gsub("%-%-[^\n]*", "")
    -- 🚨 6.66.3 — ONE LIST, NOT THREE. This used to demand three mentions,
    -- one per hand-typed machine profile. Three hand-typed lists is exactly
    -- what let 6.65.0–6.66.2 add four modules to `default` alone, so the
    -- Tool Picker, Universal Actions, Pomodoro and Outlook Probe never
    -- loaded on LL's Mac at all. Profiles derive from BASE now, so the
    -- right assertion is that mouse_grid is IN BASE — and that no profile
    -- has gone back to typing its own list.
    local profiles = 0
    for _ in live:gmatch('"mouse_grid"') do profiles = profiles + 1 end
    check("mouse_grid is in init.lua's BASE module list — once, because "
          .. "there is now ONE list rather than one per machine",
          profiles == 1, profiles)
    check("...and no profile hand-types its own list, which is what let "
          .. "four modules reach only one of three Macs",
          live:match("modules%s*=%s*{%s*\n%s*\"") == nil)

    local f2 = io.open(HS .. "/tools/run-tests.sh", "r")
    local rt = f2 and f2:read("*a") or ""
    if f2 then f2:close() end
    check("run-tests.sh runs this suite — a test nothing runs is not a test",
          rt:find("test_mouse_grid", 1, true) ~= nil)

    local f3 = io.open(HS .. "/tools/hs-doctor.sh", "r")
    local dr = f3 and f3:read("*a") or ""
    if f3 then f3:close() end
    -- Counted from DISK, not typed here: a hard-coded number in the test
    -- that keeps the docs honest is the same drift it exists to prevent.
    local nMods = 0
    do
        local pipe = io.popen('ls -1 "' .. HS .. '/modules"/*.lua 2>/dev/null | wc -l')
        if pipe then nMods = tonumber((pipe:read("*a") or ""):match("%d+")) or 0; pipe:close() end
    end
    check("the module directory was counted", nMods > 0, nMods)
    check("hs-doctor.sh expects the REAL module count",
          dr:find("expect " .. nMods, 1, true) ~= nil, nMods)

    local f4 = io.open(HS .. "/INSTALL.md", "r")
    local inst = f4 and f4:read("*a") or ""
    if f4 then f4:close() end
    check("INSTALL.md's module count matches what ships",
          inst:find(nMods .. " files", 1, true) ~= nil, nMods)
    check("INSTALL.md's confirmation table includes ⇪X, so a fresh install "
          .. "is actually verified", inst:find("⇪X", 1, true) ~= nil)
end

-- =====================================================================
out("\n=== 12. Hostile display geometry — the hang, not the crash ===\n")
-- =====================================================================
-- Everything here was found by reading the code against Hammerspoon's own
-- source rather than by a test failing, which is why each one gets a test
-- now. The first is the worst failure this module could have.
out("   -- a display reporting zero height --\n")
setScreens({ mkScreen(1, 0, 0, 1512, 982), mkScreen(2, 1512, 0, 1920, 0) })
loadModule()
-- 🚨 If this regresses, it does not fail — it HANGS. w/h is infinite,
-- math.floor(math.huge) is math.huge, and `for c = 0, inf` never returns.
-- Hammerspoon spins with no error and no recovery but a force-quit.
do
    local done = false
    local ok = pcall(function() grid.show(false); done = true end)
    check("a zero-height display does not hang the cell loop", ok and done)
end
checkInv("zero-height display")
check("the good display still gets a full grid", grid.cache ~= nil
      and #grid.cache.screens == 1, grid.cache and #grid.cache.screens)
check("the unusable display is NAMED, not silently dropped — a screen "
      .. "missing from the grid is a region you cannot reach",
      warned("unusable frame"))
check("no cell is left unlabelled", grid.cache.truncated == 0)
grid.hide("t"); checkInv("cleanup")

out("   -- every other way a frame can be broken --\n")
for _, bad in ipairs({
    { "negative width",  mkScreen(2, 0, 0, -100, 800) },
    { "zero width",      mkScreen(2, 0, 0, 0, 800) },
    { "NaN height",      mkScreen(2, 0, 0, 800, 0 / 0) },
    { "infinite width",  mkScreen(2, 0, 0, math.huge, 800) },
}) do
    setScreens({ mkScreen(1, 0, 0, 1512, 982), bad[2] })
    loadModule()
    local ok = pcall(function() grid.show(false) end)
    check("survives a display with " .. bad[1], ok and grid.state ~= nil, bad[1])
    checkInv(bad[1])
    grid.hide("t")
end

out("   -- a frame that PASSES the filter and still overflows --\n")
-- 🚨 THE FRAME FILTER IS NOT ENOUGH, AND THIS IS THE PROOF. w and h here
-- are both finite and positive, so usableFrame() accepts them — and w/h is
-- still infinity, so cols becomes inf and the cell loop never returns.
-- What saves it is the cols clamp in planScreen. Remove that clamp and
-- this check does not fail, it HANGS — which is why it is worth its own
-- case rather than being folded into the fuzzer.
setScreens({ mkScreen(1, 0, 0, 1512, 982), mkScreen(2, 0, 982, 1e300, 1e-300) })
loadModule()
do
    local done = false
    local ok = pcall(function() grid.show(false); done = true end)
    check("a frame that survives the filter but overflows the division is "
          .. "still bounded by the cols clamp", ok and done)
end
checkInv("overflowing frame")
check("...and it produces no unreachable cells",
      grid.cache and grid.cache.truncated == 0)
grid.hide("t")

out("   -- a thin strip beside big displays (small share, huge aspect) --\n")
-- This is when cols can exceed the labels actually available: the strip's
-- share of the label space is tiny while its aspect ratio is enormous.
-- Without cols <= share the surplus cells carry no label and the right of
-- that display is unreachable.
setScreens({ mkScreen(1, 0, 0, 3840, 2160), mkScreen(2, 3840, 0, 3840, 2160),
             mkScreen(3, 7680, 0, 3840, 2160), mkScreen(4, 0, 2160, 6016, 100) })
loadModule(); grid.show(false); checkInv("thin strip")
check("cells never exceed the label capacity even on a pathological layout",
      grid.cache.used <= grid.cache.capacity,
      grid.cache.used .. "/" .. grid.cache.capacity)
check("...and nothing is left unlabelled", grid.cache.truncated == 0,
      grid.cache.truncated)
check("every display still gets at least one cell", (function()
    for _, p in ipairs(grid.cache.screens) do
        if #p.cells == 0 then return false end
    end
    return true
end)())
grid.hide("t")

out("   -- fractional frames (a scaled Retina display) --\n")
-- string.format("%d", 1512.5) RAISES in Lua 5.4. Screen frames are not
-- something this module controls, so no %d may touch one.
setScreens({ mkScreen(1, 0.5, 0.5, 1512.5, 982.25) })
loadModule()
do
    local ok = pcall(function() grid.show(false) end)
    check("a fractional screen frame does not raise 'number has no integer "
          .. "representation'", ok and grid.state ~= nil)
end
checkInv("fractional frame")
grid.hide("t")
check("and the report survives it too", (function()
    return (pcall(_G.mouseGridReport))
end)())

out("   -- an alphabet key this keyboard cannot send --\n")
-- hs.hotkey's getKeycode RAISES on an unknown key name rather than
-- returning nil, so one exotic character would kill setup().
hs.keycodes = { map = { a = 0, s = 1, d = 2, f = 3, g = 5, h = 4,
                        j = 38, k = 40, l = 37 } }
setScreens(ONE); loadModule()
grid.alphabet = "asdfghjkl€"
do
    local ok = pcall(function() grid.show(false) end)
    check("an untypeable character is dropped rather than taking the module "
          .. "down", ok and grid.state ~= nil)
end
check("...and it says which key it dropped", warned("dropped unusable"))
check("no cell is labelled with a key you cannot press", (function()
    for _, c in ipairs(grid.cache.screens[1].cells) do
        if c.label:find("€", 1, true) then return false end
    end
    return true
end)())
checkInv("bad alphabet key")
grid.hide("t")
hs.keycodes = nil

out("   -- a badge that cannot be drawn --\n")
-- 🚨 The invisible-capture hazard: landed mode with no badge means keys are
-- being eaten and nothing on screen says so.
setScreens(ONE); loadModule(); grid.show(false)
local savedNew2 = hs.canvas.new
typeLabel("aa")
hs.canvas.new = function() return nil end     -- fail only the badge
pickKey("a")
hs.canvas.new = savedNew2
checkInv("badge allocation failed")
check("if the landed badge cannot be drawn, landed mode is REFUSED rather "
      .. "than captured invisibly", grid.state == nil)
check("...but the pointer still moved, which is most of the value",
      MOUSE_AT.x > 0)
check("and it says why", warned("invisibly"))

setScreens(ONE); loadModule(); grid.show(false); typeLabel("aaa")
check("landed normally first", grid.state ~= nil and grid.cross ~= nil)
hs.canvas.new = function() return nil end
landKey("up")
hs.canvas.new = savedNew2
checkInv("badge lost mid-nudge")
check("a badge lost DURING a nudge tears landed mode down too — the old "
      .. "one is already destroyed by then", grid.state == nil)

-- =====================================================================
out("\n=== 13. Geometry fuzz — 4,000 random display layouts ===\n")
-- =====================================================================
-- The invariants above were checked against layouts I thought of. This
-- checks them against layouts I did not. Every property here is one whose
-- violation is a screen region you cannot reach, or a hang.
do
    math.randomseed(20260808)
    -- The last few of each are deliberately pathological. Realistic monitor
    -- sizes alone never produce a share small enough with an aspect large
    -- enough to expose the cols<=share clamp — reverting that clamp left
    -- 237 checks green until these shapes were added.
    local sizes = { 800, 1024, 1280, 1366, 1440, 1512, 1680, 1920, 2560,
                    3440, 3840, 5120, 640, 320, 6016, 7680 }
    local heights = { 480, 600, 720, 768, 800, 900, 982, 1050, 1080, 1440,
                      1600, 1964, 2160, 240, 100, 60 }
    local worst, cases, bad = 0, 0, nil
    -- ⚠️ The alphabet is NOT varied in here. The modal binds one hotkey per
    -- alphabet character during setup(), so widening it afterwards would
    -- build a geometry using letters that were never bound — and the probe
    -- below would fail on the test's own mistake rather than on the
    -- module's. The wide alphabet is covered in section 9, where the
    -- module is set up with it. Only labelLength varies here, because every
    -- home-row character stays bound whatever its length.
    for iter = 1, 1500 do
      -- Each case is isolated: an unexpected throw is REPORTED with its
      -- layout, not allowed to kill the run and hide the other 1,499.
      local okCase, caseErr = pcall(function()
        local n = 1 + (iter % 4)          -- 1..4 displays
        local list, x, desc = {}, 0, {}
        for i = 1, n do
            local w = sizes[math.random(#sizes)]
            local h = heights[math.random(#heights)]
            list[#list + 1] = mkScreen(i, x, 0, w, h)
            desc[#desc + 1] = w .. "x" .. h
            x = x + w
        end
        local layout = table.concat(desc, " + ")
        setScreens(list)
        loadModule()
        if iter % 7 == 0 then grid.labelLength = 2 + (iter % 3) end
        local ok, err = pcall(function() grid.show(false) end)
        cases = cases + 1
        if not ok then bad = bad or (layout .. " threw: " .. tostring(err)); return end
        local c = grid.cache
        if not c then bad = bad or (layout .. ": no cache built"); return end
        local function fault(m) bad = bad or (layout .. ": " .. m) end

        -- P1: never more cells than labels. Violation = unreachable screen.
        if c.used > c.capacity then
            fault("cells > capacity " .. c.used .. "/" .. c.capacity); return
        end
        -- P2: no cell may be left without a label.
        if c.truncated ~= 0 then fault("truncated " .. c.truncated); return end
        -- P3: labels unique across every display. A duplicate sends the
        -- pointer somewhere you did not ask for and looks like randomness.
        local seen = {}
        for _, p in ipairs(c.screens) do
            for _, cell in ipairs(p.cells) do
                if seen[cell.label] then fault("dup label " .. cell.label); return end
                seen[cell.label] = true
            end
        end
        -- P4: every cell centre lands inside its own display.
        for _, p in ipairs(c.screens) do
            if p.cols < 1 or p.rows < 1 then fault("empty grid"); return end
            for _, cell in ipairs(p.cells) do
                if cell.ax < p.frame.x or cell.ax > p.frame.x + p.frame.w
                or cell.ay < p.frame.y or cell.ay > p.frame.y + p.frame.h then
                    fault("cell centre outside its display"); return
                end
            end
        end
        -- P5: the grid must reach the far edges. A band of screen the
        -- labels never cover is invisible to every other check here.
        for _, p in ipairs(c.screens) do
            local last = p.cells[#p.cells]
            if not last then fault("a display got no cells"); return end
            if (p.frame.x + p.frame.w) - last.ax > p.cellW then
                fault("right edge unreachable"); return
            end
            if (p.frame.y + p.frame.h) - last.ay > p.cellH then
                fault("bottom edge unreachable"); return
            end
        end
        -- P6: typing a label lands the pointer on exactly that cell —
        -- probed on the LAST display, the one an off-by-one in the
        -- area-split would strand.
        local pn = c.screens[#c.screens]
        local probe = pn.cells[math.random(#pn.cells)]
        typeLabel(probe.label)
        if math.abs(MOUSE_AT.x - probe.ax) > 0.01
        or math.abs(MOUSE_AT.y - probe.ay) > 0.01 then
            fault("landed off-target on " .. probe.label); return
        end
        -- P7: the invariant, on every one of these layouts.
        local st, cv, md = grid.state ~= nil, anyCanvasVisible(), anyModalEntered()
        if not (st == cv and cv == md) then fault("invariant broken"); return end
        grid.hide("fuzz")
        if grid.state ~= nil or anyCanvasVisible() or anyModalEntered() then
            fault("not fully torn down"); return
        end
        worst = math.max(worst, c.used)
      end)
      if not okCase then bad = bad or ("case " .. iter .. " threw: " .. tostring(caseErr)) end
      if bad then break end
    end
    check(cases .. " random layouts: no crash, no hang, no unreachable cell, "
          .. "no duplicate label, no off-target landing, both far edges "
          .. "covered, invariant held", bad == nil, bad)
    check("the fuzzer actually exercised large grids", worst > 500, worst)
end
setScreens(ONE); loadModule()

-- =====================================================================
out("\n=== 13b. THE TWO-SCREEN EMPTY-CANVAS THROW (from LL's Console) ===\n")
-- =====================================================================
-- REPORTED FROM A REAL MAC, four times in one session:
--   ⚠️ mouseGrid: typeChar: canvas.lua:382: bad argument #1 to
--      'assignElement' (invalid element definition; must contain
--      key-value pairs)
--
-- THE MECHANISM: typeChar filters cells by the typed prefix and then
-- redraws EVERY screen's label canvas. On a multi-screen setup the
-- matches for a given first letter can all live on ONE screen — and the
-- other screen then gets replaceElements({}). That is not read as "draw
-- nothing"; hs.canvas only unwraps the single-table form when the table
-- is non-empty, so `{}` is read as ONE element with no key-value pairs,
-- and it throws.
--
-- typeChar's own n == 0 guard does NOT cover this: n counts matches
-- ACROSS ALL SCREENS, so it is happily non-zero while an individual
-- screen has none. The guard and the bug are looking at different things.
do
    setScreens(TWO); loadModule()
    grid.show(false)

    -- Find a first letter whose matches all sit on ONE screen. On any
    -- real two-screen layout with different sizes this is not a corner
    -- case — it is most letters.
    local lonely, onScreen = nil, nil
    for _, ch in ipairs({ "a","s","d","f","g","h","j","k","l" }) do
        local perScreen = {}
        for i, p in ipairs(grid.cache.screens) do
            perScreen[i] = 0
            for _, c in ipairs(p.cells) do
                if c.label:sub(1, 1) == ch then perScreen[i] = perScreen[i] + 1 end
            end
        end
        local withCells, total = 0, 0
        for _, n in ipairs(perScreen) do
            total = total + n
            if n > 0 then withCells = withCells + 1 end
        end
        if total > 0 and withCells < #grid.cache.screens then
            lonely, onScreen = ch, perScreen; break
        end
    end

    check("a first letter exists whose matches are on one screen only",
          lonely ~= nil, lonely)

    if lonely then
        local ok, err = pcall(pickKey, lonely)
        check("typing it does NOT throw (this is the reported bug)", ok, err)
        check("the grid is still up afterwards", grid.state ~= nil)

        -- And the screen with no candidates must show nothing, rather
        -- than keeping a stale full label set that offers cells the
        -- prefix has already ruled out.
        local staleShown = nil
        for i, p in ipairs(grid.cache.screens) do
            if onScreen[i] == 0 then
                local els = p.labelCanvas.elements or {}
                local drawn = 0
                for _, el in ipairs(els) do
                    if el.action ~= "skip" and el.type == "text" then drawn = drawn + 1 end
                end
                if drawn > 0 then staleShown = "screen " .. i .. " still drew " .. drawn end
            end
        end
        check("a screen with no candidates draws no labels", staleShown == nil, staleShown)
    end

    grid.hide("test done")
    setScreens(ONE); loadModule()
end

-- =====================================================================
out("\n=== 14. THE EXPLORER — random action sequences, then shrinking ===\n")
-- =====================================================================
-- WHAT THIS IS, IN PLAIN TERMS. Every test above this line is a sequence
-- of actions I thought to write down. This one writes them itself.
--
-- The whole algorithm is three steps and fits in your head:
--
--   1. GENERATE. Pick random actions from the list a real person can
--      perform — open, type a letter, backspace, escape, nudge, click,
--      let the watchdog fire, change displays, hit the panic key — and
--      do them in a random order.
--   2. CHECK. After EVERY single action, assert the things that must be
--      true no matter what happened before. Not "did it do the right
--      thing" — that needs a human. "Is it in a state that is allowed."
--   3. SHRINK. When a sequence fails, delete steps one at a time and
--      keep any deletion that still fails. Repeat until nothing more can
--      go. A 40-step failure becomes a 3-step bug report.
--
-- STEP 3 IS THE ONE THAT MAKES THIS WORTH HAVING. Random testing without
-- shrinking hands you a 40-step trace and a shrug. With it you get the
-- shortest sequence that reproduces the fault, which is usually short
-- enough to read and fix directly.
--
-- WHAT IT CAN AND CANNOT DO. It cannot tell you the grid landed on the
-- RIGHT cell — that is a correctness question and needs the scripted
-- tests above. It CAN tell you the module got into a state it swears is
-- impossible, via a route neither of us would have thought to try. Those
-- are exactly the bugs that survive review.
do
    -- ---- the properties. Violating any of these is a bug, whatever the
    -- route taken to get there. P3 is the important one: it is the
    -- "never capture the keyboard invisibly" rule, stated as arithmetic.
    local function violation()
        local st = grid.state ~= nil
        local cv, md = anyCanvasVisible(), anyModalEntered()
        if not (st == cv and cv == md) then
            return ("P1 state=%s canvas=%s modal=%s"):format(
                tostring(st), tostring(cv), tostring(md))
        end
        if not st then
            if #grid.shown ~= 0 then return "P2 closed but " .. #grid.shown .. " canvases tracked as shown" end
            if grid.cross ~= nil then return "P2 closed but the badge survives" end
            for _, t in ipairs(TIMERS) do
                if not t.stopped then return "P2 closed but a watchdog is still ticking" end
            end
        else
            if grid.state.phase == "landed" and not (grid.cross and grid.cross.visible) then
                return "P3 capturing keys in landed mode with NO visible badge"
            end
            if grid.state.phase == "pick" and #grid.state.typed >= grid.labelLength then
                return "P4 a complete label was typed and it is still picking"
            end
            local live = 0
            for _, t in ipairs(TIMERS) do if not t.stopped then live = live + 1 end end
            if live > 1 then return "P5 " .. live .. " watchdogs live at once" end
        end
        return nil
    end

    -- ---- the actions a person can actually perform. Each is named, so a
    -- failing sequence is a list of strings you can read and replay.
    local ACT = {}
    local function act(name, fn) ACT[#ACT + 1] = { name = name, fn = fn } end
    act("show",      function() grid.show(false) end)
    act("showClick", function() grid.show(true) end)
    act("hide",      function() grid.hide("explorer") end)
    act("escape",    function()
        if grid.state and grid.state.phase == "pick" then grid.pickModal.binds["|escape"]()
        elseif grid.state then grid.landModal.binds["|escape"]() end end)
    act("backspace", function() if grid.state then pcall(grid.backspace) end end)
    for ch in ("asdfghjkl"):gmatch(".") do
        act("type:" .. ch, function()
            local fn = grid.pickModal.binds["|" .. ch]
            if fn then fn() end
        end)
    end
    -- Reaching landed mode by chance would take 9^3 aligned keystrokes, so
    -- it is offered directly. Without this the whole landed half of the
    -- state machine is explored roughly never.
    act("land", function()
        if not (grid.state and grid.state.phase == "pick" and grid.cache) then return end
        local label = grid.cache.screens[1].cells[1].label
        for c in label:sub(#grid.state.typed + 1):gmatch(".") do
            local fn = grid.pickModal.binds["|" .. c]
            if fn then fn() end
        end
    end)
    for _, k in ipairs({ "up", "down", "left", "right" }) do
        act("nudge:" .. k, function()
            local fn = grid.landModal.binds["|" .. k]
            if fn and grid.state and grid.state.phase == "landed" then fn() end end)
    end
    act("click",  function()
        local fn = grid.landModal.binds["|space"]
        if fn and grid.state and grid.state.phase == "landed" then fn() end end)
    act("dblclick", function()
        local fn = grid.landModal.binds["|2"]
        if fn and grid.state and grid.state.phase == "landed" then fn() end end)
    act("watchdog", function()
        local t = liveTimer(); if t then t.fn() end end)
    act("panic",   function() GLOBAL_HOTKEYS["alt+cmd+ctrl+shift|X"]() end)
    act("screens", function()
        setScreens(TWO)
        if SCREEN_WATCHERS[1] then SCREEN_WATCHERS[1].fn() end
        setScreens(ONE) end)
    act("axOff",   function() AX_OK = false end)
    act("axOn",    function() AX_OK = true end)
    act("report",  function() pcall(_G.mouseGridReport) end)

    local byName = {}
    for _, a in ipairs(ACT) do byName[a.name] = a.fn end

    -- ---- replay a named sequence from a clean module. Returns the step
    -- and the reason on failure, so the shrinker can tell "still broken"
    -- from "broken differently".
    -- `src` is threaded through so the explorer can be pointed at a
    -- MUTATED module, which is the only honest way to prove the whole
    -- pipeline works. (It also means a planted bug cannot be monkey-
    -- patched in from outside: replay() reloads the module every time and
    -- would wipe it — which is exactly how the first version of the
    -- self-check below fooled itself into passing.)
    local function replay(seq, src)
        setScreens(ONE)
        AX_OK = true
        loadModule(src)
        for i, name in ipairs(seq) do
            local ok, err = pcall(byName[name])
            if not ok then return i, name .. " threw: " .. tostring(err) end
            local v = violation()
            if v then return i, v end
        end
        return nil
    end

    -- ---- the shrinker. Greedy deletion: try removing each step; keep the
    -- removal if the sequence still fails. Repeat until a full pass
    -- removes nothing. Simple, and it is what turns a wall of noise into
    -- something you can act on.
    local function shrink(seq, src)
        local changed = true
        while changed and #seq > 1 do
            changed = false
            local i = 1
            while i <= #seq do
                local cand = {}
                for j, n in ipairs(seq) do if j ~= i then cand[#cand + 1] = n end end
                if #cand > 0 and replay(cand, src) then
                    seq = cand ; changed = true
                else
                    i = i + 1
                end
            end
        end
        return seq
    end

    math.randomseed(4711)
    local SEQS, LEN = 400, 40
    local found, steps = nil, 0
    for _ = 1, SEQS do
        local seq = {}
        for _ = 1, LEN do seq[#seq + 1] = ACT[math.random(#ACT)].name end
        local at, why = replay(seq)
        steps = steps + (at or LEN)
        if at then
            local minimal = shrink(seq)
            local _, minWhy = replay(minimal)
            found = ("%s  ←  %s"):format(minWhy or why, table.concat(minimal, " → "))
            break
        end
    end
    check(SEQS .. " random action sequences (" .. steps .. " actions): the "
          .. "module never reached a state it forbids — not locked out, not "
          .. "stranded, never capturing keys without a visible badge",
          found == nil, found)

    -- ---- DOES THE EXPLORER ACTUALLY WORK? ----------------------------
    -- 400 green sequences prove nothing unless the machinery can fail. So
    -- the whole pipeline — generate, check, shrink — is run against a
    -- module deliberately broken in the exact way that matters.
    do
        check("a legal sequence is judged legal", replay({ "show", "type:a" }) == nil)

        -- 1. Do the PROPERTIES bite? Put the module into each forbidden
        --    state by hand and confirm violation() names it.
        setScreens(ONE); loadModule(); grid.show(false)
        grid.state = nil                            -- stranded: sheet up, keys freed
        check("P1 catches a teardown that clears the state and leaves the "
              .. "overlay on screen", (violation() or ""):find("P1", 1, true) ~= nil,
              violation())
        -- P3 earns its place only where P1 cannot see the fault: landed
        -- mode with the badge gone but SOMETHING still on screen, so the
        -- state/canvas/modal counts all agree and only the badge rule
        -- notices that what you can see is not what is capturing keys.
        loadModule(); grid.show(false); typeLabel("aaa")
        pcall(function() grid.cross:delete() end)
        grid.cross = nil
        grid.cache.screens[1].gridCanvas:show()     -- the grid, not the badge
        check("P3 catches landed mode with no badge in the one case P1 "
              .. "cannot see — something else is on screen, so the counts "
              .. "agree and only the badge rule objects",
              (violation() or ""):find("P3", 1, true) ~= nil, violation())

        -- 2. Does the SEARCH find it, and does the SHRINKER reduce it?
        --    A module whose hide() no longer puts the canvases away is the
        --    lock-out shape, reachable from a two-step sequence.
        local broken = src:gsub("        hideAllShown%(%)\n        pcall%(function%(%) if grid%.cross",
                                "        pcall(function() if grid.cross", 1)
        check("the mutation anchor still matches the shipped file", broken ~= src)
        math.randomseed(99)
        local hit, minimal = nil, nil
        for _ = 1, 40 do
            local seq = {}
            for _ = 1, LEN do seq[#seq + 1] = ACT[math.random(#ACT)].name end
            if replay(seq, broken) then
                hit = seq
                minimal = shrink(seq, broken)
                break
            end
        end
        check("🔎 the explorer FINDS a broken teardown on its own, without "
              .. "being told where to look", hit ~= nil)
        if hit and minimal then
            out(("      planted a broken teardown → found in a %d-step "
                 .. "sequence → shrank to %d: %s\n"):format(
                 #hit, #minimal, table.concat(minimal, " → ")))
        end
        check("✂️ and the shrinker cuts the "
              .. (hit and #hit or 0) .. "-step failure down to "
              .. (minimal and #minimal or 0) .. " steps — that reduction is "
              .. "the whole reason this is worth running",
              minimal ~= nil and #minimal <= 4,
              minimal and table.concat(minimal, " → "))
    end
end
setScreens(ONE); loadModule()

-- =====================================================================
out("\n=== THE ESCAPE ORDER (6.78.0) ===\n")
-- The grid is drawn at screenSaver level, above literally everything, so
-- Esc belongs to it while it is up — and the cheat sheet, which holds a
-- bare-Esc hotkey the whole time it is open, must not take it first.
do
    local c = _G.escapeClaims2 and _G.escapeClaims2["mousegrid"]
    check("🚨 the grid claims Esc, so it closes BEFORE the cheat sheet", c ~= nil)
    check("...and defers to coexist's one priority table",
          c ~= nil and c.priority == nil, c and tostring(c.priority))
    check("...with both callbacks real", c ~= nil
          and type(c.active) == "function" and type(c.handle) == "function")
    check("...and active() is FALSE with the grid down, TRUE with it up",
      (function()
        if not c then return false end
        grid.hide("test")
        if select(2, pcall(c.active)) ~= false then return false, "up when down" end
        grid.show()
        local up = select(2, pcall(c.active))
        grid.hide("test")
        return up == true
      end)())
    check("...and its handle() really closes the grid", (function()
        if not c then return false end
        grid.show()
        pcall(c.handle)
        return grid.state == nil
      end)())
end

out("\n=== POINTER LOCATOR (the MouseCircle Spoon, done natively) ===\n")
-- =====================================================================
do
    setScreens(ONE); loadModule()
    local G = _G.mouseGrid
    check("it is published as a service so a pad key can reach it",
          PROVIDED["mouseGrid.locate"] ~= nil)
    check("🅿️ but it is bound to NO key — macOS shake-to-grow already does "
          .. "this, and doubling it up is clutter", (function()
        for combo, _ in pairs(HYPER_CLAIMS or {}) do
            if tostring(combo):find("locate") then return false end
        end
        return true
    end)())

    local before = #CANVASES
    hs.mouse.absolutePosition({ x = 400, y = 300 })
    check("locate() reports success", G.locate() == true)
    local ring = CANVASES[#CANVASES]
    check("a ring canvas was created", #CANVASES == before + 1)
    check("it is centred on the pointer", ring.frame.x == 400 - G.locateRadius
          and ring.frame.y == 300 - G.locateRadius,
          tostring(ring.frame.x) .. "," .. tostring(ring.frame.y))
    check("it is shown", ring.visible == true)
    check("🚨 IT IS CLICK-THROUGH — without this the ring is a disc of glass "
          .. "over whatever you were about to click, for half a second",
          ring.mouseEvents ~= nil and ring.mouseEvents[1] == false)
    check("6.166.0: it draws in WHITE, as asked",
          G.locateColor.red == 1 and G.locateColor.green == 1 and G.locateColor.blue == 1)
    check("...three rings, staggered, on a held frame timer",
          G.locateRings == 3 and G.locateAnim ~= nil)
    do
        local function rings(f)
            local r = {}
            for _, e in ipairs(f) do if e.action == "stroke" then r[#r + 1] = e end end
            return r
        end
        local function dot(f)
            for _, e in ipairs(f) do if e.action == "fill" then return e end end
            return nil
        end
        local f0 = G.locateFrame(0)
        local fMid = G.locateFrame(G.locateStagger * 2 + 0.05)
        local fEnd = G.locateFrame(G.locateSecs + 0.1)
        check("at t=0 one ring has left, small and bright",
              #rings(f0) == 1 and rings(f0)[1].radius < 12 and rings(f0)[1].strokeColor.alpha > 0.9)
        check("later all three are in flight, the first largest and faintest",
              #rings(fMid) == 3 and rings(fMid)[1].radius > rings(fMid)[3].radius
              and rings(fMid)[1].strokeColor.alpha < rings(fMid)[3].strokeColor.alpha)
        check("after locateSecs the frame is empty (a skip element, never {})",
              #fEnd == 1 and fEnd[1].action == "skip")
        -- 6.167.0 — LL: "make the mouse rings bigger and stay up for at
        -- least 5 seconds."
        check("6.167.0: the ring stays up at least 5 s and is nearly twice the size",
              G.locateSecs >= 5 and G.locateRadius >= 100, G.locateSecs .. "/" .. G.locateRadius)
        check("...for WHOLE pulses — locateSecs is a multiple of locateCycle, so the last ring fades, never blinks off",
              math.abs(G.locateSecs / G.locateCycle - math.floor(G.locateSecs / G.locateCycle + 0.5)) < 1e-9)
        local f2 = G.locateFrame(G.locateCycle + 0.01)
        check("...the pulse REPEATS: just into the second cycle a fresh small ring has left",
              #rings(f2) >= 1 and rings(f2)[1].radius < 12 and rings(f2)[1].strokeColor.alpha > 0.9)
        local fLate = G.locateFrame(G.locateSecs - 0.05)
        check("...and it is still pulsing just before locateSecs", #rings(fLate) >= 1)
        check("...a white dot marks the pointer throughout, brightest as each pulse starts",
              dot(f0) ~= nil and dot(f0).fillColor.alpha > 0.85
              and dot(fMid) ~= nil and dot(fMid).fillColor.alpha < dot(f0).fillColor.alpha
              and dot(fEnd) == nil)
        local fBig = G.locateFrame(G.locateStagger * 2 + 0.05, 165)
        check("...drawn at the radius asked for, strokes growing with it (a 4K ring is a 4K ring)",
              rings(fBig)[1].radius > rings(fMid)[1].radius
              and rings(fBig)[1].strokeWidth > rings(fMid)[1].strokeWidth
              and rings(fBig)[1].center.x == 165)
    end

    -- 🚨 THE LEAK. A second press must REPLACE the first ring, not stack a
    -- second canvas that deletes itself on its own schedule.
    local n1 = #CANVASES
    G.locate()
    check("a second press replaces the first ring rather than stacking",
          ring.deleted == true, tostring(ring.deleted))
    check("...and exactly one new canvas was made", #CANVASES == n1 + 1)

    -- The self-cleanup actually fires.
    local live = CANVASES[#CANVASES]
    local fired = false
    for _, t in ipairs(TIMERS) do
        if not t.stopped and t.secs == G.locateSecs then t.fn(); fired = true end
    end
    check("the ring removes itself when its timer fires",
          fired and live.deleted == true)
    check("...and the held reference is dropped, so nothing lingers",
          G.locateCanvas == nil)

    -- A machine where the canvas cannot be allocated must not throw.
    local savedNew2 = hs.canvas.new
    hs.canvas.new = function() return nil end
    local okNil, resNil = pcall(G.locate)
    hs.canvas.new = savedNew2
    check("a refused canvas allocation returns false instead of throwing",
          okNil and resNil == false)

    -- 6.167.0 — SIZED BY THE SCREEN. LL's LG 4K at full points made a
    -- 60-pt ring a speck; the radius follows the pointer's screen height
    -- (scale 1 at locateScaleBase points tall, never below 1), and a
    -- number in grid.locateScale pins it.
    check("a 982-pt-tall screen is scale 1 — the ring never shrinks",
          G.locateScaleFor() == 1, tostring(G.locateScaleFor()))
    setScreens({ mkScreen(1, 0, 0, 3840, 2160) })
    hs.mouse.absolutePosition({ x = 1000, y = 900 })
    local s4 = G.locateScaleFor()
    check("on a 4K at full points the scale is ×1.5 — from fullFrame (2160), not frame (menu bar and Dock gone)",
          s4 == 1.5, tostring(s4))
    check("...capped at locateScaleMax", (function()
        setScreens({ mkScreen(1, 0, 0, 20000, 20000) })
        local capped = G.locateScaleFor()
        setScreens({ mkScreen(1, 0, 0, 3840, 2160) })
        return capped == G.locateScaleMax
    end)())
    G.locate()
    local big = CANVASES[#CANVASES]
    local r4 = math.floor(G.locateRadius * s4 + 0.5)
    check("...the canvas is that much bigger and still centred on the pointer",
          big.frame.w == r4 * 2 and big.frame.x == 1000 - r4 and big.frame.y == 900 - r4,
          tostring(big.frame.w))
    check("...its first frame is drawn at that radius",
          big.elements and big.elements[1] and big.elements[1].center
          and big.elements[1].center.x == r4)
    check("...and grid.locateLast says so for the report",
          G.locateLast and G.locateLast.radius == r4 and G.locateLast.scale == s4)
    G.locateScale = 2
    G.locate()
    check("grid.locateScale = 2 pins it (a settings override): radius 220",
          CANVASES[#CANVASES].frame.w == 440 and G.locateScaleFor() == 2)
    local rep = tostring(_G.mouseGridReport() or "")
    check("the report's ring line names the version, the radius here and what the last press drew",
          rep:find("ring    : ⇪⇧L (6.167.0) · radius 220 pt here (scale 2.00, pinned by grid.locateScale)", 1, true) ~= nil
          and rep:find("last press drew radius 220 at scale 2.00", 1, true) ~= nil, rep:match("ring[^\n]*"))
    G.locateScale = "1.5"
    check("a pin typed as a string still pins", G.locateScaleFor() == 1.5)
    G.locateScale = 0
    check("locateScale = 0 is NOT a pin: the screen rule draws and the report says so",
          G.locateScaleFor() == 1.5
          and tostring(_G.mouseGridReport() or ""):find("from the pointer's screen", 1, true) ~= nil)
    G.locateScale = nil
    -- Mis-tuned overrides draw something sane, never NaN or nothing.
    G.locateCycle = 0
    local fz = G.locateFrame(0.3)
    check("locateCycle = 0 falls back to the default instead of NaN frames",
          #fz >= 2 and fz[#fz].fillColor.alpha == fz[#fz].fillColor.alpha)
    G.locateCycle = 1.2
    G.locateSecs = "six"
    check("a non-numeric locateSecs neither throws nor leaves the ring up: locate() still returns true",
          pcall(G.locate) and G.locateCanvas ~= nil)
    G.locateSecs = 6
    -- A doAfter that refuses must not leave a canvas and a 30 fps timer behind.
    local savedAfter = hs.timer.doAfter
    hs.timer.doAfter = function() error("no timers today") end
    local okRef, resRef = pcall(G.locate)
    hs.timer.doAfter = savedAfter
    check("a refused end-timer takes the ring down at once and returns false",
          okRef and resRef == false and G.locateCanvas == nil and G.locateAnim == nil)
    setScreens(ONE)
end

out("\n=== ✂️ SPLIT THE LANDED BOX BY LETTER (6.252.0) ===\n")
-- LL, with a diagram: "A big cell one misses a button and I have to arrow
-- a lot to get to it … Once I select a box, can the box be broken in half
-- so I have a better chance of landing on the button." ⌥+arrow keeps that
-- half. The geometry is PURE (grid.halfOf) so it is proven here without a
-- screen; the drawing and the pointer are checked through a real landing.
do
    loadModule()
    local B = { x = 100, y = 200, w = 80, h = 40 }
    local function same(a, b)
        return a and b and a.x == b.x and a.y == b.y and a.w == b.w and a.h == b.h
    end
    check("⌥↑ keeps the TOP half — same x and width, half the height, same top edge",
          same(grid.halfOf(B, "up", 0), { x = 100, y = 200, w = 80, h = 20 }))
    check("⌥↓ keeps the BOTTOM half — the top edge MOVES DOWN by the new height",
          same(grid.halfOf(B, "down", 0), { x = 100, y = 220, w = 80, h = 20 }))
    check("⌥← keeps the LEFT half", same(grid.halfOf(B, "left", 0),
          { x = 100, y = 200, w = 40, h = 40 }))
    check("⌥→ keeps the RIGHT half — the left edge moves right",
          same(grid.halfOf(B, "right", 0), { x = 140, y = 200, w = 40, h = 40 }))
    -- Halving is only worth anything if it COMPOSES: the whole feature is
    -- pressing it three times.
    check("three presses is an eighth of the box, still inside the original", (function()
        local b = grid.halfOf(grid.halfOf(grid.halfOf(B, "down", 0), "right", 0), "down", 0)
        return b and b.w == 40 and b.h == 10
           and b.x >= B.x and b.y >= B.y
           and (b.x + b.w) <= (B.x + B.w) and (b.y + b.h) <= (B.y + B.h)
    end)())
    -- 🚨 THE FLOOR BITES, and it is measured on the HALF, not the box: a
    -- 16 pt box at a 8 pt floor must still halve once, and a 15 pt one
    -- must refuse. Off-by-one either way and the floor is decoration.
    local why
    check("a box whose half would be under the floor is REFUSED, with a reason",
          (function() local b; b, why = grid.halfOf({x=0,y=0,w=80,h=15}, "up", 8)
             return b == nil and type(why) == "string" and why:find("short") end)())
    check("...and exactly at the floor it still halves", (function()
        local b = grid.halfOf({ x = 0, y = 0, w = 80, h = 16 }, "up", 8)
        return b ~= nil and b.h == 8
    end)())
    check("...the width floor is asked about SEPARATELY — a wide, short box "
          .. "still halves sideways", grid.halfOf({ x = 0, y = 0, w = 80, h = 4 },
                                                  "left", 8) ~= nil)
    check("no box, a sizeless box and a non-direction each refuse rather than throw",
          grid.halfOf(nil, "up", 8) == nil and grid.halfOf({ x=0,y=0,w=0,h=0 }, "up", 8) == nil
          and grid.halfOf(B, "sideways", 8) == nil)

    -- --- ✂️ 6.252.0 — the split, PURE --------------------------------
    check("splitOf halves the LONGER side — a wide box splits left/right",
          (function()
              local sp = grid.splitOf({ x = 0, y = 0, w = 80, h = 40 }, 8)
              return sp and sp.axis == "x"
                 and sp.first.w == 40 and sp.first.x == 0
                 and sp.second.x == 40 and sp.first.h == 40
          end)())
    -- 🚨 MUTATION: always split the same way and a 200x20 strip becomes
    -- two 200x10 strips — no more precision where it is missing.
    check("...and a TALL box splits top/bottom",
          (function()
              local sp = grid.splitOf({ x = 0, y = 0, w = 40, h = 80 }, 8)
              return sp and sp.axis == "y"
                 and sp.first.h == 40 and sp.first.y == 0 and sp.second.y == 40
          end)())
    check("...a square splits left/right rather than refusing to choose",
          (function()
              local sp = grid.splitOf({ x = 0, y = 0, w = 40, h = 40 }, 8)
              return sp and sp.axis == "x"
          end)())
    check("...the two halves are the whole box and never overlap",
          (function()
              local sp = grid.splitOf({ x = 10, y = 20, w = 80, h = 40 }, 8)
              return sp and (sp.first.w + sp.second.w) == 80
                 and sp.second.x == sp.first.x + sp.first.w
          end)())
    check("splitOf refuses at the floor, with words, rather than throwing",
          (function()
              local sp, why = grid.splitOf({ x = 0, y = 0, w = 15, h = 15 }, 8)
              return sp == nil and type(why) == "string" and why ~= ""
          end)())
    check("...and no box, or a sizeless one, refuses too",
          grid.splitOf(nil, 8) == nil
          and grid.splitOf({ x = 0, y = 0, w = 0, h = 0 }, 8) == nil)

    -- --- which two keys, PURE ----------------------------------------
    check("halvePair takes the first two of the alphabet by default",
          (function()
              local a, b, from = grid.halvePair(nil, "asdfghjkl")
              return a == "a" and b == "s" and tostring(from):find("alphabet")
          end)())
    check("...and an override wins, and says so",
          (function()
              local a, b, from = grid.halvePair("jk", "asdfghjkl")
              return a == "j" and b == "k" and tostring(from):find("halveKeys")
          end)())
    -- 🚨 ONE LETTER CANNOT NAME TWO HALVES, and the same letter twice
    -- would bind one key to both and pick whichever was bound last.
    check("...a one-character or doubled override falls back rather than "
          .. "binding one key to both halves",
          (function()
              local a = grid.halvePair("j", "asdfghjkl")
              local c = grid.halvePair("jj", "asdfghjkl")
              return a == "a" and c == "a"
          end)())
    check("...and an alphabet with nothing usable in it refuses, with why",
          (function()
              local a, _, why = grid.halvePair(nil, "")
              return a == nil and type(why) == "string" and why ~= ""
          end)())

    -- --- through a real landing --------------------------------------
    loadModule(); grid.show(false); typeLabel("aaa")
    local st = grid.state
    check("landing carries the CELL into landed mode as the box to split",
          st and st.phase == "landed" and type(st.box) == "table"
          and st.box.w > 0 and st.box.h > 0)
    local K1, K2 = grid.halvePair(grid.halveKeys, grid.alphabet)
    -- 🚨 BOUND ON THE FIRST LANDING, not at setup: a settings override of
    -- halveKeys lands AFTER setup returns (6.228.0), so binding early
    -- would draw one pair and bind another.
    check("the two split letters are bound by the time you land",
          grid.landModal.binds["|" .. K1] ~= nil
          and grid.landModal.binds["|" .. K2] ~= nil, K1 .. K2)
    local cell = { x = st.box.x, y = st.box.y, w = st.box.w, h = st.box.h }
    local nCanvas = #CANVASES
    local function press(k) local f = grid.landModal.binds["|" .. k]
                            if f then f() return true end return false end
    -- The cell's own aspect decides which way it splits, so the expected
    -- half is asked of splitOf rather than assumed to be the left one.
    local wantFirst = grid.splitOf(cell, grid.halveMin)
    check("✂️ pressing the first letter keeps that half",
          press(K1) and wantFirst ~= nil
          and grid.state.box.w == wantFirst.first.w
          and grid.state.box.h == wantFirst.first.h
          and grid.state.box.x == wantFirst.first.x
          and grid.state.box.y == wantFirst.first.y,
          string.format("%.0fx%.0f", grid.state.box.w, grid.state.box.h))
    check("...and the POINTER is put in the middle of it — that is the whole "
          .. "point, not just an outline",
          MOUSE_AT.x == grid.state.box.x + grid.state.box.w / 2
          and MOUSE_AT.y == grid.state.box.y + grid.state.box.h / 2)
    check("...an outline canvas was drawn for it and is held", grid.boxDraw ~= nil
          and #CANVASES > nCanvas)
    check("...and it never eats the click it is helping aim (mouse events off)",
          grid.boxDraw ~= nil and grid.boxDraw.mouseEvents ~= nil
          and grid.boxDraw.mouseEvents[1] == false)
    check("...the depth is counted for the report", grid.state.halvings == 1)
    -- 🎨 THE LETTERS ARE DRAWN IN THE BOX. A split nobody can see is a
    -- pair of keys nobody knows about.
    check("🎨 the box is DRAWN split, with a letter in each half",
          (function()
              local seen = {}
              for _, e in ipairs((grid.boxDraw or {}).elements or {}) do
                  if e.type == "text" then seen[tostring(e.text)] = true end
              end
              return seen[K1] == true and seen[K2] == true
          end)())
    check("...and a divider is drawn between them",
          (function()
              for _, e in ipairs((grid.boxDraw or {}).elements or {}) do
                  if e.type == "segments" then return true end
              end
              return false
          end)())
    local secondBox = { x = grid.state.box.x, y = grid.state.box.y }
    press(K2)
    check("...and the second letter keeps the OTHER half",
          grid.state.box.x ~= secondBox.x or grid.state.box.y ~= secondBox.y,
          string.format("%.0f,%.0f", grid.state.box.x, grid.state.box.y))
    press(K1)
    check("it composes — three presses in, and the depth says so",
          grid.state.halvings == 3)
    check("...and the box never leaves the cell it came from",
          grid.state.box.x >= cell.x and grid.state.box.y >= cell.y
          and grid.state.box.x + grid.state.box.w <= cell.x + cell.w
          and grid.state.box.y + grid.state.box.h <= cell.y + cell.h)
    -- A NUDGE carries the box rather than abandoning it, so nudge-then-split
    -- works and the outline never sits somewhere the pointer is not.
    local bx, by = grid.state.box.x, grid.state.box.y
    local bw, bh = grid.state.box.w, grid.state.box.h
    landKey("right")
    check("a nudge MOVES the box with the pointer, same size",
          grid.state.box.w == bw and grid.state.box.h == bh
          and grid.state.box.x > bx and grid.state.box.y == by)
    check("...and the pointer is still at its centre, so a split after a "
          .. "nudge is still true",
          MOUSE_AT.x == grid.state.box.x + grid.state.box.w / 2)
    -- The floor, live: keep splitting until it refuses, and prove it refuses
    -- by NOT MOVING THE POINTER rather than by doing something else instead.
    for _ = 1, 14 do press(K1) end
    local held = { x = MOUSE_AT.x, y = MOUSE_AT.y }
    local deep = grid.state.halvings
    press(K1)
    check("at the floor it refuses: the pointer does not move and the depth "
          .. "does not grow", MOUSE_AT.x == held.x and MOUSE_AT.y == held.y
          and grid.state.halvings == deep)
    check("...and landed mode is STILL UP — a refusal is not a teardown",
          grid.state ~= nil and grid.state.phase == "landed")
    check("...the box is never smaller than halveMin in either direction",
          grid.state.box.w >= grid.halveMin and grid.state.box.h >= grid.halveMin,
          string.format("%.1fx%.1f", grid.state.box.w, grid.state.box.h))
    grid.hide("test")
    check("leaving takes the outline down and drops the held reference",
          grid.boxDraw == nil)
    checkInv("after splitting and hiding")

    -- The rollback, and the rule it must not break.
    loadModule(); grid.halve = false; grid.show(false); typeLabel("aaa")
    local was = { x = MOUSE_AT.x, y = MOUSE_AT.y }
    check("grid.halve = false: the split letters are not bound at all — the "
          .. "alphabet reaches the app, exactly as before 6.252.0",
          grid.landModal.binds["|" .. K1] == nil
          and grid.landModal.binds["|" .. K2] == nil)
    check("...and nothing has moved", MOUSE_AT.x == was.x
          and MOUSE_AT.y == was.y and grid.state.halvings == 0)
    check("...and the box is not drawn split",
          (function()
              landKey("right")            -- the nudge draws the outline
              for _, e in ipairs((grid.boxDraw or {}).elements or {}) do
                  if e.type == "text" then return false end
              end
              return true
          end)())
    grid.hide("test")

    -- 🚨 SWITCHED OFF AFTER LANDING. The keys are bound on the landing, so
    -- turning grid.halve off from the Console while the badge is up leaves
    -- them bound — and splitTo must refuse, out loud, rather than carrying
    -- on. This is the only path that reaches that guard, and without a
    -- check for it the guard is untestable.
    loadModule(); grid.show(false); typeLabel("aaa")
    local K1b = grid.halvePair(grid.halveKeys, grid.alphabet)
    grid.halve = false
    ALERTS = {}
    local heldAt = { x = MOUSE_AT.x, y = MOUSE_AT.y }
    local f = grid.landModal.binds["|" .. tostring(K1b)]
    if f then f() end
    check("switching splitting off AFTER landing refuses out loud and moves "
          .. "nothing", MOUSE_AT.x == heldAt.x and MOUSE_AT.y == heldAt.y
          and (function()
                  for _, a in ipairs(ALERTS) do
                      if a:find("switched off", 1, true) then return true end
                  end
                  return false
               end)(), #ALERTS .. " alert(s)")
    grid.halve = true
    grid.hide("test")

    -- 🚨 6.195.0's hint keys went with the feature they explained.
    loadModule(); grid.show(false)
    check("⌥+arrow in the PICKER is no longer bound — a key that says "
          .. "'⌥+arrow halves the cell' is worse than an unbound one once "
          .. "⌥+arrow halves nothing",
          grid.pickModal.binds["alt|down"] == nil
          and grid.pickModal.binds["alt|up"] == nil)
    grid.hide("test")

    loadModule(); grid.show(false); typeLabel("aaa")
    -- 🔒 THE RULE IS NARROWED, NOT DELETED (6.192.0 → 6.252.0). Landed mode
    -- may capture EXACTLY the two split letters and NO others; ⌥+letter is
    -- still forbidden outright.
    check("🔒 landed mode binds the two split letters and NOT ONE OTHER — "
          .. "everything else you type reaches the app underneath",
          (function()
              for ch in ("abcdefghijklmnopqrstuvwxyz"):gmatch(".") do
                  local bound = grid.landModal.binds["|" .. ch] ~= nil
                  local wanted = (ch == K1 or ch == K2)
                  if bound ~= wanted then return false, ch end
                  if grid.landModal.binds["alt|" .. ch] ~= nil then
                      return false, "alt " .. ch
                  end
              end
              return true
          end)())
    check("...and ⌥+arrow is gone from landed mode too",
          grid.landModal.binds["alt|up"] == nil
          and grid.landModal.binds["alt|down"] == nil
          and grid.landModal.binds["alt|left"] == nil
          and grid.landModal.binds["alt|right"] == nil)
    -- 🚨 A HELD split letter must NOT repeat: one press is a decision about
    -- which half the target is in, and a hold would run the box to the
    -- floor before you saw it.
    check("...and a split letter does not auto-repeat, unlike the arrows",
          grid.landModal.repeats["|" .. K1] == nil
          and grid.landModal.repeats["|down"] ~= nil)
    check("...the badge names the two letters",
          (function()
              for _, e in ipairs((grid.cross or {}).elements or {}) do
                  if e.type == "text" and tostring(e.text):find(K1 .. K2 .. " split",
                                                                1, true) then
                      return true
                  end
              end
              return false
          end)())
    grid.hide("test")

    loadModule()
    local rep0 = _G.mouseGridReport()
    check("the report's nudge line names the HELD speed, not just the tap",
          rep0:find("nudge") and rep0:find("HOLD 32 pt", 1, true)
          and rep0:find("tap 8 pt", 1, true), rep0:match("   nudge   :[^\n]*"))
    check("the report's split line names the two keys and the floor",
          rep0:find("split", 1, true) and rep0:find(K1 .. " / " .. K2, 1, true)
          and rep0:find(tostring(grid.halveMin), 1, true),
          rep0:match("   split   :[^\n]*"))
    -- 🔎 THREE STATES, and the middle one is the useful one.
    check("...and says the keys are not bound until the first landing",
          rep0:find("not bound yet", 1, true) ~= nil)
    grid.show(false); typeLabel("aaa")
    check("...and names them once they are",
          _G.mouseGridReport():find("bound " .. K1 .. K2, 1, true) ~= nil)
    grid.hide("test")
    grid.halve = false
    check("...and says so when it is switched off", _G.mouseGridReport():find("off %(grid%.halve%)"))
    grid.halve = true
end


out("\n=== 🏃 A HELD ARROW MOVES THE CANVAS (6.247.0) ===\n")
-- LL: "After I isolate to a grid box (using three letters), then holding
-- down the arrow key should repeat about the same cadence as holding down
-- arrow key in a text box." The cadence WAS the work: every repeat deleted
-- two canvases and built two more — two NSWindows created, filled through
-- LuaSkin and ordered in, per keystroke, on the main thread.
do
    local before = pass + fail
    local okSection, secErr = pcall(function()

    -- ---- the rule, PURE ------------------------------------------------
    check("canMove: nothing drawn yet cannot be moved",
          grid.canMove(nil, { x = 1, y = 2, w = 3, h = 4 }) == false)
    check("canMove: a different x and y is a MOVE",
          grid.canMove({ x = 0, y = 0, w = 30, h = 20 },
                       { x = 9, y = 9, w = 30, h = 20 }) == true)
    check("canMove: the same rect is still a move (moving where it already "
          .. "is costs one setFrame and no rebuild)",
          grid.canMove({ x = 0, y = 0, w = 30, h = 20 },
                       { x = 0, y = 0, w = 30, h = 20 }) == true)
    -- 🚨 MUTATION: compare only x and y, or compare nothing, and a RESIZE
    -- is drawn by moving a canvas whose elements are the old size.
    check("canMove: a different WIDTH must be rebuilt, and it says which field",
          (function()
              local ok, why = grid.canMove({ x = 0, y = 0, w = 30, h = 20 },
                                           { x = 0, y = 0, w = 31, h = 20 })
              return ok == false and tostring(why):find("w changed", 1, true) ~= nil
          end)())
    -- 🚨 MUTATION: drop the SECOND loop. pairs() cannot see a nil, so a
    -- key present in what is drawn and absent from what is wanted — the
    -- landed badge's hint, exactly — would compare equal to nothing.
    check("canMove: a field that is in what is DRAWN but not in what is "
          .. "wanted is a difference too",
          grid.canMove({ x = 0, y = 0, w = 30, h = 20, hint = "3 deep" },
                       { x = 0, y = 0, w = 30, h = 20 }) == false)
    -- 🚨 AND THE MIRROR, which is the badge GAINING a hint — a snapped
    -- landing draws words the previous draw had none of. MUTATION: delete
    -- the FIRST loop and only this row falls, because the second loop
    -- walks what is DRAWN and cannot see a key that is only in `want`.
    check("canMove: a field that is in what is WANTED but not in what is "
          .. "drawn is a difference too",
          grid.canMove({ x = 0, y = 0, w = 30, h = 20 },
                       { x = 0, y = 0, w = 30, h = 20, hint = "3 deep" }) == false)

    -- ---- the hot path: a nudge --------------------------------------
    loadModule(); grid.show(false); typeLabel("aaa")
    check("landing leaves the badge on screen", grid.cross ~= nil)
    -- 📐 AWAY FROM EVERY EDGE, deliberately. The badge is clamped into the
    -- display, so near an edge its rings move INSIDE it and a rebuild is
    -- the right answer — that case has its own checks below. "aaa" is the
    -- top-left cell, where BOTH clamps bite.
    grid.state.point = { x = 700, y = 500 }
    -- The OUTLINE is born on the first nudge (6.192.0: a nudge carries the
    -- box), so that one is a build by definition and is not counted here.
    landKey("right")
    check("...and the first nudge draws the box outline",
          grid.boxDraw ~= nil and grid.draws.boxBuild >= 1)
    local madeBefore  = CANVAS_NEW
    local drawsBefore = { boxBuild = grid.draws.boxBuild,
                          crossBuild = grid.draws.crossBuild }
    local boxX = grid.boxDraw.frame.x
    landKey("right"); landKey("right"); landKey("right")
    -- 🚨 THE CHECK THIS RELEASE EXISTS FOR. Put either moveCanvas call
    -- back to a rebuild and this fails by exactly that many windows.
    check("🏃 three nudges build NO new canvas",
          CANVAS_NEW == madeBefore, CANVAS_NEW - madeBefore .. " new")
    check("...they MOVED instead — the box canvas is further right",
          grid.boxDraw.frame.x > boxX and (grid.boxDraw.moved or 0) >= 3,
          tostring(grid.boxDraw.moved))
    check("...and the badge moved with it, once per nudge",
          (grid.cross.moved or 0) >= 3, tostring(grid.cross.moved))
    check("...counted apart, so the report can prove it on his Mac",
          grid.draws.boxMove >= 3 and grid.draws.crossMove >= 3
          and grid.draws.boxBuild == drawsBefore.boxBuild
          and grid.draws.crossBuild == drawsBefore.crossBuild)
    check("...and the outline still sits where the pointer is",
          grid.boxDraw.frame.x == grid.state.box.x
          and grid.boxDraw.frame.y == grid.state.box.y)

    -- ---- a RESIZE is not a move -------------------------------------
    local madeBeforeHalve = CANVAS_NEW
    do  -- 6.252.0 — the split letter, where ⌥↓ used to be
        local k1 = grid.halvePair(grid.halveKeys, grid.alphabet)
        local f = grid.landModal.binds["|" .. tostring(k1)]
        if f then f() end
    end
    check("a SPLIT changes the box's size, so it is rebuilt — a moved canvas "
          .. "would draw the old size's elements in the new place",
          CANVAS_NEW > madeBeforeHalve and grid.draws.boxBuild > drawsBefore.boxBuild)

    -- ---- the badge at a screen edge ---------------------------------
    -- Away from an edge the rings sit at the badge's centre and a nudge is
    -- a pure move. AT the edge the badge is clamped into the display while
    -- the pointer keeps going, so the rings move INSIDE it — and a canvas
    -- that only moved would draw them in the wrong place.
    loadModule(); grid.show(false); typeLabel("aaa")
    grid.state.point = { x = 1400, y = 500 }
    landKey("right")                       -- lands in the clamp
    local madeAtEdge = CANVAS_NEW
    local boxMoveAtEdge = grid.draws.boxMove
    landKey("right")
    -- 🚨 MUTATION: drop rx/ry from the crosshair's want table.
    check("🎯 at a screen edge the badge REBUILDS, because its rings move "
          .. "inside it", CANVAS_NEW > madeAtEdge)
    check("...while the box, whose size never changed, still only moves",
          grid.draws.boxMove > boxMoveAtEdge)

    -- ---- it degrades, it never breaks -------------------------------
    loadModule(); grid.show(false); typeLabel("aaa")
    grid.state.point = { x = 700, y = 500 }
    landKey("right")                       -- the outline exists from here
    -- libcanvas.m refuses topLeft for a canvas used as a SUBVIEW
    -- (luaL_argerror) — a throw, on a Mac we cannot test from here.
    grid.boxDraw.topLeft = function() error("method unavailable for canvas "
                                            .. "as a subview", 0) end
    local madeBeforeThrow = CANVAS_NEW
    local okNudge = pcall(function() landKey("right") end)
    check("a topLeft that REFUSES falls back to a rebuild rather than "
          .. "leaving the outline where the pointer is not",
          okNudge and CANVAS_NEW > madeBeforeThrow
          and grid.boxDraw.frame.x == grid.state.box.x)

    -- ---- the record does not outlive the canvas ----------------------
    grid.hide("test")
    check("teardown forgets what was on screen — a position record for a "
          .. "canvas that is gone is a lie the next draw would read",
          grid.boxAt == nil and grid.crossAt == nil)

    -- ---- the report --------------------------------------------------
    loadModule()
    grid.draws = { boxMove = 0, boxBuild = 0, crossMove = 0, crossBuild = 0 }
    local r0 = _G.mouseGridReport()
    check("the report says nothing was drawn rather than printing four zeros",
          type(r0) == "string"
          and r0:find("nothing drawn this session", 1, true) ~= nil)
    grid.draws = { boxMove = 12, boxBuild = 1, crossMove = 12, crossBuild = 1 }
    check("...and names moves and rebuilds apart",
          _G.mouseGridReport():find("24 move(s) · 2 rebuild(s)", 1, true) ~= nil)
    -- 🚨 A Mac where topLeft never works would otherwise read as normal.
    grid.draws = { boxMove = 0, boxBuild = 40, crossMove = 0, crossBuild = 40 }
    check("...and a session where NOTHING moved is a warning, not a number",
          _G.mouseGridReport():find("every draw was a REBUILD", 1, true) ~= nil)

    end)
    check("§6.247.0 ran to the end — a throw here deletes the checks after it",
          okSection == true, secErr)
    local ran = (pass + fail) - before
    check("§6.247.0 ran all of its checks (" .. ran .. " of 19+)", ran >= 19, ran)
end


out("\n=== 🌓 TWO SCRIMS, NOT ONE (6.248.0) ===\n")
-- LL: "When I first bring up the grid, please make the boxes less
-- translucent so I can read the letters easier, then on first key press
-- make the box 100% see through." One number was being asked to do two
-- different jobs — a reading surface before you type, an aiming surface
-- after.
do
    local before = pass + fail
    local okSection, secErr = pcall(function()

    loadModule()
    -- ---- the rule, PURE ------------------------------------------------
    check("scrimFor(0) is the wash you read the labels on",
          (grid.scrimFor(0)) == grid.scrimAlpha)
    check("scrimFor(1) is the wash after the first keystroke",
          (grid.scrimFor(1)) == grid.scrimAlphaTyped)
    check("...and it stays that way for every later character",
          (grid.scrimFor(3)) == grid.scrimAlphaTyped)
    check("scrimFor answers WHY as well as what, and the two differ",
          (function()
              local _, w0 = grid.scrimFor(0)
              local _, w1 = grid.scrimFor(1)
              return type(w0) == "string" and type(w1) == "string" and w0 ~= w1
          end)())
    check("a nonsense count reads as 'before you type' rather than throwing",
          (grid.scrimFor("banana")) == grid.scrimAlpha
          and (grid.scrimFor(nil)) == grid.scrimAlpha)
    -- 🚨 THE DECISION, not the taste. His two sentences are exactly these
    -- two facts: the first draw is darker than the second, and the second
    -- is nothing at all.
    check("the reading surface is DARKER than the aiming one",
          grid.scrimAlpha > grid.scrimAlphaTyped)
    check("...and 'see through' means 0, not 'a bit lighter'",
          grid.scrimAlphaTyped == 0)

    -- ---- what is actually drawn ----------------------------------------
    local function scrimAlphaNow()
        local c = grid.cache and grid.cache.screens
                  and grid.cache.screens[1] and grid.cache.screens[1].gridCanvas
        if not (c and c.elements and c.elements[1]
                and c.elements[1].fillColor) then return nil end
        return c.elements[1].fillColor.alpha
    end

    grid.show(false)
    check("before a key is pressed the screen is washed at scrimAlpha",
          scrimAlphaNow() == grid.scrimAlpha, tostring(scrimAlphaNow()))
    -- 🚨 MUTATION: have scrimOnly keep asking for scrimAlpha and the grid
    -- never gets out of his way — the reported bug, restored.
    pickKey("a")
    check("🌓 the first keystroke takes the wash away",
          scrimAlphaNow() == grid.scrimAlphaTyped, tostring(scrimAlphaNow()))
    -- 🚨 MUTATION: have gridElements ask for the TYPED alpha and
    -- backspacing out leaves a grid with no labels to read.
    pickKey("delete")
    check("...and backspacing all the way out brings the reading wash back",
          scrimAlphaNow() == grid.scrimAlpha, tostring(scrimAlphaNow()))
    grid.hide("test")

    -- ---- the numbers are the CONFIG's, not the drawing's ---------------
    -- 6.239.0's rule: asserting the shipped default passes when the number
    -- has simply been typed in twice. Move the config and require the
    -- drawing to move with it. (Neither scrim is cached — both are built
    -- inside redraw() — which is why scrimAlphaTyped is deliberately not
    -- in the layout cache's key; see the comment there.)
    loadModule()
    grid.scrimAlpha, grid.scrimAlphaTyped = 0.90, 0.20
    grid.show(false)
    check("a moved scrimAlpha is what gets drawn", scrimAlphaNow() == 0.90,
          tostring(scrimAlphaNow()))
    pickKey("a")
    check("a moved scrimAlphaTyped is what gets drawn once you type",
          scrimAlphaNow() == 0.20, tostring(scrimAlphaNow()))
    grid.hide("test")

    -- ---- the report ----------------------------------------------------
    loadModule()
    local r = _G.mouseGridReport()
    check("the report names both washes",
          type(r) == "string" and r:find("scrim", 1, true) ~= nil
          and r:find("once you type", 1, true) ~= nil)
    check("...and says so when the second one is nothing at all",
          _G.mouseGridReport():find("fully see-through", 1, true) ~= nil)
    grid.scrimAlphaTyped = 0.25
    check("...while a Mac that was given a number does NOT read as see-through",
          _G.mouseGridReport():find("fully see-through", 1, true) == nil)
    grid.scrimAlphaTyped = 0

    end)
    check("§6.248.0 ran to the end — a throw here deletes the checks after it",
          okSection == true, secErr)
    local ran = (pass + fail) - before
    check("§6.248.0 ran all of its checks (" .. ran .. " of 14+)", ran >= 14, ran)
end

-- =====================================================================
-- §6.266.0 — A BOX THE GRID HAS GIVEN UP ON IS NEVER PUT BACK ON SCREEN
-- =====================================================================
-- LL, with a photograph of the yellow landed-box outline sitting over a
-- Finder replace dialog: "Frozen grid again." It was a suspect in
-- CLAUDE.md for eight releases and it is not a suspect now — the two
-- halves are here, and this section makes the orphan happen.
--
-- `_G.showCanvasSafely` used to re-show a refused canvas BY ITSELF, 50 ms
-- later, telling nobody. showCanvas records every canvas it shows in
-- `grid.shown`, and hideAllShown() hides that list and EMPTIES it. So an
-- Esc inside that window hid the box, threw away the only handle to it,
-- and the retry then put it back with nothing able to reach it: not
-- grid.hide(), not _G.mouseGrid.hide(). Only hs.reload().
--
-- 🔑 THE REAL HELPER IS LIFTED OUT OF init.lua, not re-written here. A
-- stub of it would be a stub of the thing under test (6.193.0), and
-- 6.264.0 is what it costs to prove one half while nothing drives the
-- other.
do
    local before = pass + fail
    local okSection, secErr = pcall(function()

    local f = io.open(HS .. "/init.lua", "r")
    local init = f and f:read("*a") or ""
    if f then f:close() end

    local planSrc = init:match("(function _G%.canvasRetryPlan%(hasLate, canTimer%).-\nend)")
    local showSrc = init:match(
        "(function _G%.showCanvasSafely%(canvas, label, onLate%).-\n    return false\nend)")
    check("🖼 the retry rule was lifted out of init.lua", planSrc ~= nil)
    check("🖼 showCanvasSafely was lifted out of init.lua", showSrc ~= nil)

    -- ---- the PURE rule, three answers ----------------------------------
    -- A stand-in that answers falsely rather than throwing, so a mutation
    -- FAILS these checks instead of killing the run (6.186.0).
    local plan = function() return "?", "the rule could not be read" end
    if planSrc then
        local chunk = load(planSrc .. "\nreturn _G.canvasRetryPlan")
        if chunk then plan = chunk() or plan end
    end

    local how, why = plan(false, true)
    check("no caller asked to be told → GIVE UP, never a second show",
          how == "give up" and why:find("no owner", 1, true) ~= nil, tostring(why))
    how, why = plan(true, false)
    check("a Mac that cannot arm the timer → give up, and says which half",
          how == "give up" and why:find("timer", 1, true) ~= nil, tostring(why))
    how, why = plan(true, true)
    check("a caller that wants to know → HAND IT BACK, the caller decides",
          how == "hand back" and why:find("caller decides", 1, true) ~= nil,
          tostring(why))

    -- ---- the helper itself, with a canvas macOS REFUSES ----------------
    -- 🚨 REFUSING, not missing. 6.264.0's degrade check took hs.canvas.new
    -- AWAY and passed with the fallback disconnected; the shape this
    -- config keeps meeting on a beta OS is "created, wired, refused".
    local LATE = {}
    if showSrc and planSrc then
        local chunk = load(planSrc .. "\n" .. showSrc
                           .. "\nreturn _G.showCanvasSafely")
        local shower = chunk and chunk()
        check("the lifted helper loaded", type(shower) == "function")
        if shower then
            _G.canvasLate = { refused = 0, handed = 0, dropped = 0 }
        _G.canvasShowTimers = {}
            REFUSE_SHOW = true
            local c = mkCanvas({ x = 0, y = 0, w = 10, h = 10 })
            local n0 = #TIMERS

            -- (a) NO onLate: no retry is armed at all, and the canvas is
            -- never shown a second time behind anybody's back.
            local ans = shower(c, "no owner")
            check("a refused show answers FALSE", ans == false, tostring(ans))
            check("🚨 with no onLate NOTHING is scheduled — the orphan cannot "
                  .. "happen because there is no second show to happen",
                  #TIMERS == n0, #TIMERS - n0)
            check("...and it is COUNTED as dropped on purpose, not as a retry",
                  _G.canvasLate.dropped == 1 and _G.canvasLate.handed == 0,
                  tostring(_G.canvasLate.dropped) .. "/"
                  .. tostring(_G.canvasLate.handed))

            -- (b) WITH onLate: the helper hands the canvas back and does
            -- NOT show it itself. Asserted by the show COUNT, because
            -- "onLate was called" passes with a blind show left in front
            -- of it (6.212.0's stroke-counting row).
            LATE = {}
            local ans2 = shower(c, "an owner", function(cv) LATE[#LATE + 1] = cv end)
            check("a refused show still answers FALSE with an owner",
                  ans2 == false, tostring(ans2))
            check("a retry IS armed when somebody is there to answer it",
                  #TIMERS == n0 + 1, #TIMERS - n0)
            check("nothing is handed back until the turn actually comes",
                  #LATE == 0, #LATE)
            local t = TIMERS[#TIMERS]
            check("the retry is a run-loop turn away, not a second later",
                  t.secs == 0.05, tostring(t.secs))
            -- macOS would say yes NOW, which is the whole reason a retry
            -- exists — and the only state in which "the helper showed it
            -- itself" is distinguishable from "the helper did nothing".
            REFUSE_SHOW = false
            t.fn()
            check("the caller is handed the CANVAS, not a boolean",
                  #LATE == 1 and LATE[1] == c, #LATE)
            check("🚨 the helper itself never showed it — the caller's show "
                  .. "is the only show there is",
                  (c.shows or 0) == 0, tostring(c.shows))
            check("...and the hand-back is counted apart from the drops",
                  _G.canvasLate.handed == 1, tostring(_G.canvasLate.handed))
            REFUSE_SHOW = false
        end
    end

    -- ---- and now the grid, end to end ----------------------------------
    -- The module is given the real helper, so this is the shipped path.
    local realShower
    if showSrc and planSrc then
        local chunk = load(planSrc .. "\n" .. showSrc
                           .. "\nreturn _G.showCanvasSafely")
        realShower = chunk and chunk()
    end
    local saved = _G.showCanvasSafely
    _G.showCanvasSafely = realShower
    check("the grid is running against init.lua's own helper",
          type(_G.showCanvasSafely) == "function")

    if realShower then
        -- THE ORPHAN, reproduced. macOS refuses the first show; the user
        -- presses Esc before the turn comes round; the turn comes round.
        _G.canvasLate = { refused = 0, handed = 0, dropped = 0 }
        _G.canvasShowTimers = {}
        loadModule()
        _G.showCanvasSafely = realShower
        REFUSE_SHOW = true
        local tBefore = #TIMERS
        grid.show(false)
        local late = {}
        for i = tBefore + 1, #TIMERS do
            if TIMERS[i].secs == 0.05 then late[#late + 1] = TIMERS[i] end
        end
        check("macOS refused the grid's canvases and a retry was handed to "
              .. "the module", #late > 0, #late)
        grid.hide("esc")          -- the user gives up
        check("the grid is down — the invariant says so",
              grid.state == nil, tostring(grid.state))
        REFUSE_SHOW = false       -- macOS would say yes now
        local shownBefore = 0
        for _, c in ipairs(CANVASES) do
            if c.visible then shownBefore = shownBefore + 1 end
        end
        for _, t in ipairs(late) do pcall(t.fn) end
        local shownAfter = 0
        for _, c in ipairs(CANVASES) do
            if c.visible then shownAfter = shownAfter + 1 end
        end
        check("🚨 THE FROZEN BOX: the retry lands after Esc and puts NOTHING "
              .. "on screen — a canvas the grid has given up on is not its "
              .. "to show", shownAfter == shownBefore,
              shownBefore .. " → " .. shownAfter)

        -- The other direction, and it is what stops the fix being "never
        -- retry": while the grid IS up, the retry still works.
        _G.canvasLate = { refused = 0, handed = 0, dropped = 0 }
        _G.canvasShowTimers = {}
        loadModule()
        _G.showCanvasSafely = realShower
        REFUSE_SHOW = true
        tBefore = #TIMERS
        grid.show(false)
        late = {}
        for i = tBefore + 1, #TIMERS do
            if TIMERS[i].secs == 0.05 then late[#late + 1] = TIMERS[i] end
        end
        REFUSE_SHOW = false
        for _, t in ipairs(late) do pcall(t.fn) end
        local up = 0
        for _, c in ipairs(CANVASES) do if c.visible then up = up + 1 end end
        check("the grid is still up, so the retry DOES bring the overlay in "
              .. "— the fix is not 'stop retrying'", up > 0, up)
        check("...and the grid knows the box is up", grid.state ~= nil)

        grid.hide("done")

        -- 🚨 RE-RECORDED, AND THIS IS THE CASE THAT PROVES IT. The first
        -- version of this check asserted the re-record after a plain
        -- show/hide and passed with the line DELETED — because showCanvas
        -- records every canvas on the way out anyway, so hide() reached it
        -- regardless. A guard no test can fail is dead code with a comment
        -- on it (6.199.0, fourth time), so here is the state where the two
        -- differ: enterLanded() calls hideAllShown(), which EMPTIES the
        -- list while `grid.state` stays non-nil. A retry from the refused
        -- first draw then fires into a live grid holding a canvas the list
        -- no longer knows about. Refused draw, then type the three letters
        -- — an ordinary press on a Mac that said no once.
        _G.canvasLate = { refused = 0, handed = 0, dropped = 0 }
        _G.canvasShowTimers = {}
        loadModule()
        _G.showCanvasSafely = realShower
        setScreens(ONE)
        REFUSE_SHOW = true
        tBefore = #TIMERS
        grid.show(false)
        late = {}
        for i = tBefore + 1, #TIMERS do
            if TIMERS[i].secs == 0.05 then late[#late + 1] = TIMERS[i] end
        end
        check("the refused draw handed its canvases back", #late > 0, #late)
        pickKey("a"); pickKey("s"); pickKey("d")      -- land: hideAllShown()
        check("the grid is LANDED — still up, and the hide list was emptied "
              .. "underneath it", grid.state ~= nil
              and grid.state.phase == "landed",
              grid.state and tostring(grid.state.phase))
        REFUSE_SHOW = false
        for _, t in ipairs(late) do pcall(t.fn) end
        grid.hide("done")
        local stillUp = 0
        for _, c in ipairs(CANVASES) do
            if c.visible then stillUp = stillUp + 1 end
        end
        check("🚨 hide() REACHES a canvas the retry showed into a landed "
              .. "grid — it was put back on the list, or the frozen box is "
              .. "simply one turn later", stillUp == 0, stillUp)
    end
    _G.showCanvasSafely = saved
    REFUSE_SHOW = false

    end)
    check("§6.266.0 ran to the end — a throw here deletes the checks after it",
          okSection == true, secErr)
    local ran = (pass + fail) - before
    check("§6.266.0 ran all of its checks (" .. ran .. " of 22+)", ran >= 22, ran)
end

-- =====================================================================
realPrint(table.concat(printed, "\n"))
out("\n")
if fail > 0 then
    out("FAILURES:\n")
    for _, f in ipairs(failures) do out("   ❌ " .. f .. "\n") end
end
out(("\n%d passed, %d failed\n\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
