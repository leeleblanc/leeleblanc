-- =====================================================================
-- MODULE: CLIPBOARD HISTORY (⇪V) — every copy, searchable · ⇪⇧V to edit
-- =====================================================================
-- ⇪V searches the FULL text of every saved copy, not just the 100
-- characters a row shows. ⇪⇧V opens the same list to edit or delete an
-- entry — and an edited entry is put back on the clipboard, because you
-- edited it in order to paste it.
--
-- ---------------------------------------------------------------------
-- 6.55.0 — WHY THIS IS A MODULE NOW
-- ---------------------------------------------------------------------
-- This lived in init.lua, spread over four separate places: the file
-- path in §0.2, load/save in §2, the dedupe inside the pasteboard
-- watcher in §3, and two choosers in §5. Every one of those lines ran
-- BEFORE the module loader, in the stretch where a single error takes
-- the whole config down rather than costing you one feature. Moving it
-- buys three things: init.lua gets shorter, a fault in clipboard
-- history now costs you clipboard history, and the behaviour finally
-- has somewhere to be tested.
--
-- 🔗 THE ONE THING THAT STAYED BEHIND, and why. The pasteboard watcher
-- in init.lua is SHARED with image OCR — one timer reading one
-- changeCount, deciding between "copied image files", "a raw image" and
-- "text". Splitting that in two would mean two timers polling the same
-- counter and racing over which handled a change first. So the watcher
-- stays, and calls clipboard.add through the service registry. If this
-- module is switched off the watcher simply gets no provider, prints so
-- once, and OCR carries on.
--
-- ---------------------------------------------------------------------
-- 🚨 THE FAILURE THAT MATTERS HERE IS LOSING THE HISTORY
-- ---------------------------------------------------------------------
-- The file is rewritten on EVERY copy, so a bad write is not a one-off:
-- it is a thousand chances a day to destroy the lot. Two guards, both
-- carried over intact because both were earned by real incidents:
--   · AN UNREADABLE FILE IS BACKED UP BEFORE ANYTHING ELSE. It used to
--     fall back to {} silently, and the very next copy overwrote the
--     broken file with that empty list — losing whatever was still
--     recoverable inside it.
--   · AN ENCODE IS VERIFIED BEFORE IT IS COMMITTED. If encode ever
--     produces something that will not read back, the existing file is
--     left ALONE. Writing it was what corrupted the file in the first
--     place, and it was discovered only at the next reload, as
--     "history wiped".

local M = {
    name  = "Clipboard History",
    order = 14.3,
    -- 🗂 6.113.0 — MOVED FROM "text" TO "capture", ON REQUEST. The families
    -- are about what a tool is FOR, not what it operates on, and a store
    -- that catches everything you copy so you can go back for it later is
    -- the same shape as the Capture Pad and Quick Append: it takes
    -- something in and keeps it. "text" is where things that TRANSFORM
    -- text live — Text Expander, Autocorrect, Begone, OCR, URL Cleaner.
    -- ⚠️ NOTHING FOLLOWS IT AUTOMATICALLY. ⇪H (Command History) reads a
    -- shell's history file rather than catching anything, and was already
    -- filed under FIND & OPEN; the hand-written CLIPBOARD & OCR group in
    -- core/cheatsheet.lua is ⇪O/⇪⇧O/⇪⇧C, which is OCR and copy-on-select,
    -- so it stays in "text" too. Say the word if either should move.
    family = "capture",
    cheatsheet = {
        title = "📋 CLIPBOARD HISTORY (⇪V — every copy, searchable)",
        entries = {
            { "⇪V",   "Search clipboard history — matches the FULL text" },
            { "👁 pane","Beside the list: the WHOLE entry of the row the arrows or the" },
            { "",     "mouse are on — grows to the screen edge, then '… N more lines'" },
            { "⇪⇧V",  "Edit or delete an entry · an edit is re-copied" },
            { "☑️ row","Pick several rows, then delete or copy them as ONE" },
            { "keeps","The last 1,000 copies, newest first" },
            { "skips","Anything over ~1 MB, so the file stays quick to write" },
            { "dedupe","Copying something again moves it up, not a second row" },
        },
    },
}

function M.setup(core)
    local clip = {}

    -- ✏️ EDIT HERE ---------------------------------------------------------
    clip.enabled     = true
    clip.key         = "v"          -- ⇪V search · ⇪⇧V edit
    clip.max         = 1000         -- how many copies to keep
    clip.maxItemSize = 1000000      -- ~1 MB; bigger copies are not stored
    clip.rows        = 250          -- rows shown before you narrow the search
    -- 6.190.0 — ⇪V opens the ⇪space panel on @clip instead of the macOS
    -- chooser. THE ROLLBACK IS THIS LINE: a chooser is a macOS control
    -- and the panel is a web view, and if the panel ever gets in LL's way
    -- the old one is still here, still tested, one setting away.
    --     settings = { clipboard_history = { panel = false } }
    clip.panel       = true
    clip.panelTag    = "@clip "   -- what ⇪V types into the panel for you
    clip.panelWhy    = nil        -- why the last press fell back, for the report
    clip.preview     = 100          -- characters shown per row
    -- 👁 6.154.0 — the pane beside the picker (see THE PREVIEW PANE below)
    clip.previewOn   = true         -- false = the list alone, as before
    clip.previewW    = 420          -- points wide; shrinks if the screen is narrow
    clip.previewPoll = 0.08         -- seconds between selection/hover reads —
                                    -- runs ONLY while a picker is on screen
    clip.previewMaxChars = 12000    -- characters laid out per preview
    clip.previewGrace = 0.6         -- 6.155.0: seconds the pane waits for a
                                    -- NUDGED picker to come back (⇪⇧-arrows
                                    -- hide + re-show it) before it gives up
    clip.previewMousePx = 2         -- 6.160.4/6.202.0: points the pointer must
                                    -- MOVE between two polls to earn the
                                    -- "🖱 under the pointer" tag — the ROW is
                                    -- always the chooser's own highlight; a
                                    -- pointer merely resting on the picker
                                    -- never earns the tag
    clip.file        = (core.logsDir or hs.configdir)
                       .. "/clipboard_history-" .. tostring(core.hostTag) .. ".json"
    -- ----------------------------------------------------------------------

    -- 💾 6.154.0 — the file is rewritten WHOLE on every copy, edit and
    -- delete, so it shrinks whenever you delete an entry. Said to the
    -- write ledger, which otherwise reads a smaller file as a truncation.
    _G.rewrittenFiles = _G.rewrittenFiles or {}
    _G.rewrittenFiles[clip.file] = "the clipboard history — rewritten on every copy, edit and delete"

    -- The one-time migration of the pre-6.10 file from ~/.hammerspoon into
    -- the Logs folder came across with the rest of the feature: it belongs
    -- with the code that owns the file, not in the orchestrator.
    if core.adoptLegacyFile then
        pcall(core.adoptLegacyFile, clip.file,
              hs.configdir .. "/clipboard_history.json")
    end

    _G.clipboardCache = _G.clipboardCache or {}
    clip.loaded  = false
    -- 📋 6.224.0 — WHAT WAS STORED AND WHAT WAS REFUSED. 6.202.0 queued
    -- this report and LL's "I'm not sure my copy and history is working.
    -- I don't see items that i just copied" is what it is for: every
    -- refusal in clip.add was silent, and clip.save's write failure told
    -- core and returned false without leaving a trace anyone could read
    -- an hour later.
    clip.stats = { added = 0, sameAsTop = 0, tooBig = 0, notText = 0,
                   heldAtBoot = 0, saved = 0, saveFailed = 0,
                   lastAddAt = nil, lastAddText = nil,
                   lastRefusal = nil, lastRefusalAt = nil,
                   lastSaveFail = nil, lastSaveFailAt = nil }
    local function nowHM() return os.date("%H:%M:%S") end
    local function refused(why)
        local st = clip.stats
        st.lastRefusal, st.lastRefusalAt = why, nowHM()
    end
    clip.preload = {}     -- copies made before the file finished loading

    local function say(m)  if _G.diag then _G.diag.say("clipboard", m)  end end
    local function warn(m) if _G.diag then _G.diag.warn("clipboard", m) end end

    -- Anything that goes wrong here is exactly the kind of thing that used
    -- to be visible only in the Console. 6.54.0 gave us somewhere better.
    local function tellFailure(title, detail, key)
        if _G.notices then
            _G.notices.record("runtime", "clipboard_history", detail)
            _G.notices.tell(title, detail, { key = key, every = 600, seconds = 6 })
        else
            hs.alert.show("⚠️ " .. title .. "\n" .. detail, 6)
        end
        print("🚨 Clipboard history: " .. detail)
    end

    -- ---- disk -------------------------------------------------------------
    function clip.load()
        local f = io.open(clip.file, "r")
        if not f then _G.clipboardCache = {} return true end
        local content = f:read("*a"); f:close()
        local ok, data = pcall(hs.json.decode, content)
        if ok and type(data) == "table" then
            _G.clipboardCache = data
            return true
        end
        -- 🚨 BACK UP BEFORE STARTING FRESH. Falling back to {} silently
        -- meant the next copy overwrote the broken file with an empty
        -- list, destroying whatever was still recoverable in it.
        _G.clipboardCache = {}
        local backupPath = clip.file .. ".corrupt-" .. os.date("%Y%m%d-%H%M%S")
        local bf = io.open(backupPath, "w")
        if bf then bf:write(content); bf:close() end
        tellFailure("Clipboard history was unreadable",
                    "backed up to " .. backupPath .. " and started fresh",
                    "clip:corrupt")
        return false
    end

    function clip.save()
        local okEnc, body = pcall(hs.json.encode, _G.clipboardCache)
        if not okEnc or type(body) ~= "string" then
            tellFailure("Clipboard history NOT saved",
                        "encode failed; the existing file was left untouched",
                        "clip:encode")
            clip.stats.saveFailed = clip.stats.saveFailed + 1
            clip.stats.lastSaveFail, clip.stats.lastSaveFailAt =
                "encode failed", nowHM()
            return false
        end
        -- 🚨 VERIFY BEFORE COMMITTING. Writing an encode that will not read
        -- back is what corrupted the file originally, and it was noticed
        -- only at the next reload, as "history wiped".
        local okDec, decoded = pcall(hs.json.decode, body)
        if not okDec or type(decoded) ~= "table" then
            tellFailure("Clipboard history NOT saved",
                        "the encoded JSON would not read back; file untouched",
                        "clip:roundtrip")
            clip.stats.saveFailed = clip.stats.saveFailed + 1
            clip.stats.lastSaveFail, clip.stats.lastSaveFailAt =
                "the encoded JSON would not read back", nowHM()
            return false
        end
        local f = io.open(clip.file, "w")
        if not f then
            clip.stats.saveFailed = clip.stats.saveFailed + 1
            clip.stats.lastSaveFail, clip.stats.lastSaveFailAt =
                "the file could not be opened for writing", nowHM()
            if core.warnWriteFailed then core.warnWriteFailed("clipboard history") end
            return false
        end
        f:write(body); f:close()
        clip.stats.saved = clip.stats.saved + 1
        return true
    end

    -- ---- adding -----------------------------------------------------------
    -- Called by init.lua's shared pasteboard watcher via the service
    -- registry. Returns true when something was actually stored.
    function clip.add(text)
        if type(text) ~= "string" or text == "" then
            clip.stats.notText = clip.stats.notText + 1
            refused(type(text) ~= "string" and "not text" or "an empty string")
            return false
        end
        if #text > clip.maxItemSize then
            clip.stats.tooBig = clip.stats.tooBig + 1
            refused(string.format("%.1f MB — over the %.1f MB limit",
                                  #text / 1000000, clip.maxItemSize / 1000000))
            print("📋 Clipboard item not saved to history (over 1 MB)")
            return false
        end
        local cache = _G.clipboardCache
        -- Already at the top: nothing to do. This is also what stops the
        -- clipboard-edit path filing a duplicate — the edited entry
        -- carries the arriving text, so the dedupe below lifts it rather
        -- than copying it.
        if cache[1] and cache[1].text == text then
            clip.stats.sameAsTop = clip.stats.sameAsTop + 1
            refused("already the newest item — nothing to file")
            return false
        end
        for i = #cache, 1, -1 do
            if cache[i].text == text then table.remove(cache, i) end
        end
        table.insert(cache, 1, { date = os.date("%b %d %H:%M"), text = text })
        while #cache > clip.max do table.remove(cache) end
        -- 🚨 DO NOT SAVE BEFORE THE FILE HAS BEEN READ. Deferring the
        -- load to warm() opened a two-second window at boot in which a
        -- copy would write a ONE-ITEM file straight over the real
        -- history — and warm() would then dutifully load that back,
        -- having destroyed everything. The copy is held instead and
        -- re-applied on top once the file is in, which is what
        -- clip.preload is for. Found by test_clipboard's P4.
        clip.stats.added = clip.stats.added + 1
        clip.stats.lastAddAt = nowHM()
        clip.stats.lastAddText = text
        if not clip.loaded then
            clip.stats.heldAtBoot = clip.stats.heldAtBoot + 1
            clip.preload[#clip.preload + 1] = text
            return true
        end
        clip.save()
        return true
    end

    -- ---- the pickers -------------------------------------------------------
    clip.chooser, clip.editChooser = nil, nil   -- HELD: else collected
    local editSnapshot = {}

    -- =====================================================================
    -- 👁 THE PREVIEW PANE (6.154.0)
    -- =====================================================================
    -- LL: "Can the full contents of the clipboard item in ⌘V be shown as I
    -- arrow up/down, or put my mouse cursor on an item? The view should
    -- show to the right of the window and be able to scroll or
    -- automatically expand to show that entry."
    --
    -- hs.chooser has no selection-changed callback, so ONE small poll
    -- runs only while a picker is on screen and asks it which row is
    -- highlighted: chooser:selectedRow(). Since 6.202.0 that is the
    -- WHOLE answer — for the arrows AND for the mouse — because the
    -- chooser follows the pointer by itself: HSChooserTableView.m
    -- installs a tracking area and its mouseMoved: selects the row under
    -- the pointer (rowAtPoint → selectRowIndexes → scrollRowToVisible),
    -- and libchooser.m's selectedRow() reads that same table selection.
    -- 6.154.0 believed the opposite ("HSChooser.m has no mouseMoved and
    -- no tracking area — checked, not assumed": checked in the WRONG
    -- FILE) and computed a second, geometric answer from the picker's
    -- box and window_move's 56/44 row constants; the real band is ~89 pt
    -- of query field and ~42 pt a row, so over the top half of every
    -- list the guess named the row BENEATH the highlight — and won the
    -- tie. See 🖱 6.202.0 below. The box (placement record + those
    -- constants; macOS gives a chooser no frame getter) is still
    -- computed, for two things that tolerate a rough number: where the
    -- pane goes, and whether the pointer is over the rows at all.
    -- The pane is an hs.canvas beside the picker — to the RIGHT when it
    -- fits, else the left — sized to the text down to the screen's bottom
    -- edge ("automatically expand"); what will not fit ends in an honest
    -- "… N more lines" footer rather than being clipped mid-word. Text is
    -- pre-wrapped in Menlo, whose advance is known, so the height is
    -- arithmetic rather than a guess. The picker's hideCallback takes the
    -- pane down; the poll closes for good once the picker has been gone
    -- for clip.previewGrace.
    --
    -- 🧲 6.155.0 — THE PANE SURVIVES A MOVE. LL: "I can't move it. Should
    -- I be able to?" You can — ⌘-drag from anywhere on it, or ⇪⇧-arrows
    -- (window_move) — and the first cut of the pane did not survive the
    -- second: a nudge is hide() + show(point), the hideCallback closed
    -- the pane AND stopped the poll, and nothing re-opened it because the
    -- re-show goes through core.showPopup, not this module's openers. The
    -- hideCallback now only SUSPENDS (the canvas goes, the poll stays) and
    -- the poll closes for good only after the picker has been gone for
    -- clip.previewGrace; a picker that is back within it — a nudge takes
    -- one event-loop turn — gets its pane back at the NEW placement on
    -- the next tick. A ⌘-drag never hides the picker at all (show(point)
    -- re-anchors it live) and window_move now moves the placement point
    -- with the hand, so the pane rides along at the poll's cadence.
    --
    -- 🖱 6.160.4 — THE LAST HAND THAT MOVED. LL: "In my Chrome history
    -- list, the entry in the picker will say it's a particular line
    -- while the pop-up to the right will list something different."
    -- 6.154.0's rule — the mouse wins while it is INSIDE the picker —
    -- counted a pointer that was merely resting there, and since 6.160.0
    -- Mouse Follows Focus parks the pointer at the centre of the focused
    -- window: on a big Chrome window that is the centre of the screen,
    -- which is row 9 of the ⇪Y picker that opens around it. So the
    -- highlight sat on row 1, the pane showed row 9, and the arrows moved
    -- the highlight while the pane stayed put. 6.160.4's answer was a
    -- HAND-SWITCH: the poll remembered where the pointer was and what
    -- the keyboard had, the mouse took the pane only when it MOVED
    -- (clip.previewMousePx or more) onto a row, the keyboard took it
    -- back the moment the selection changed, and a still pointer never
    -- overruled the highlight. The header's "🖱 under the pointer" tag
    -- dates from here and STAYS — it now says which hand moved last —
    -- and that was the one time the pane and the highlight were meant
    -- to differ. (6.160.4 also estimated the list's scroll from the
    -- arrows so the geometry could survive a scrolled list, with a wheel
    -- scroll as its stated blind spot — both gone with the geometry,
    -- below.)
    --
    -- 🖱 6.202.0 — THE PANE SHOWS THE HIGHLIGHT, FULL STOP. LL: "when I
    -- am on an entry it actually shows the one entry beneath the current
    -- line I am hovering over." The highlight he was on WAS the row under
    -- the pointer — macOS had already moved it there (HSChooserTableView.m
    -- mouseMoved:) — and the pane's own guess, built on 56/44 where the
    -- chooser is ~89/42, resolved most of every row to the one below and
    -- overruled it. So the guess is gone: previewRow returns
    -- selectedRow() for BOTH hands, and the pointer decides one thing
    -- only — whether the header says "🖱 under the pointer", which it
    -- does once the pointer has MOVED onto the rows (6.160.4's rule,
    -- kept for the label). The pane and the highlight can no longer
    -- disagree, which also ends 6.160.4's ⇪Y symptom for good, and a
    -- wheel scroll is no longer a blind spot: the chooser's rowAtPoint
    -- knows its own scroll offset, so the pane never has to. The band
    -- that names the tag is measured with the CHOOSER's numbers now
    -- (headH/rowH below), so a pointer crossing the query field earns no
    -- tag. Left alone on purpose: init.lua's off-screen clamp carries
    -- window_move's 56/44 (a tolerance), and window_move's own constants
    -- size a grab band padded 24 pt a side, where the error is invisible.
    clip.pv = { canvas = nil, poll = nil, chooser = nil, rowsFn = nil,
                lastKey = nil, gen = 0, hiddenAt = nil,
                -- 6.202.0: HSChooserWindow.xib's own geometry — the table's
                -- scroll view sits 89 pt below the content top, rowHeight
                -- 40 + intercellSpacing 2 = 42 a row (HSChooser.m's
                -- resizeWindow keeps 94 + 42·rows). Their ONLY consumer is
                -- the band that names the hand; the pane's placement reads
                -- box.x/y/w, and the ROW is never computed from them
                rowH = 42, headH = 89,
                -- 6.160.4/6.202.0: which hand the header NAMES (the row is
                -- always the chooser's) and what each hand last did
                hand = "keys", lastMouse = nil, lastSel = nil, lastN = nil,
                lastQuery = nil }
    local pv = clip.pv

    local function now()
        local t
        pcall(function() t = hs.timer.secondsSinceEpoch() end)
        return tonumber(t) or os.time()
    end

    function clip.previewClose()
        if pv.poll   then pcall(function() pv.poll:stop()     end) ; pv.poll = nil end
        if pv.canvas then pcall(function() pv.canvas:delete() end) ; pv.canvas = nil end
        pv.chooser, pv.rowsFn, pv.lastKey, pv.shown, pv.hiddenAt = nil, nil, nil, nil, nil
        pv.hand, pv.lastMouse, pv.lastSel, pv.lastN = "keys", nil, nil, nil
        pv.lastQuery = nil
    end

    -- The picker went away: the pane goes with it NOW (a pane over an
    -- empty spot is wrong for as long as it lasts), the poll stays for
    -- previewGrace in case the picker is only being moved.
    function clip.previewSuspend()
        if pv.canvas then pcall(function() pv.canvas:delete() end) ; pv.canvas = nil end
        pv.lastKey, pv.shown = nil, nil
        if pv.poll then pv.hiddenAt = pv.hiddenAt or now()
        else clip.previewClose() end
    end

    -- The picker's box, computed the way window_move computes its grab
    -- box: top-left from the placement record, width and rows asked of
    -- the chooser (pcall'd — both getters vary across builds). A record
    -- that names a DIFFERENT picker is worse than none (the 6.127.0 bug).
    function clip.previewBox(chooser)
        local placed = _G.lastPopupPlacement
        if not (placed and placed.point) then return nil, "no placement on record" end
        if placed.chooser ~= nil and placed.chooser ~= chooser then
            return nil, "the placement on record belongs to a different picker"
        end
        local sf
        pcall(function() sf = placed.screen and placed.screen:frame() end)
        if type(sf) ~= "table" then sf = { x = 0, y = 0, w = 1440, h = 900 } end
        local w = sf.w * 0.4
        pcall(function()
            local pct = chooser:width()
            if type(pct) == "number" and pct > 0 and pct <= 100 then
                w = sf.w * pct / 100
            end
        end)
        local rows = 10
        pcall(function()
            local r = chooser:rows()
            if type(r) == "number" and r > 0 then rows = r end
        end)
        return { x = placed.point.x, y = placed.point.y, w = w,
                 h = pv.headH + rows * pv.rowH }, sf
    end

    -- Which row to show: the chooser's own highlight, whichever hand put
    -- it there (6.202.0 — the chooser hover-selects, see above). The
    -- second value names the hand for the header: "mouse" once the
    -- pointer has MOVED onto the rows, "keys" the moment an arrow or a
    -- letter takes over, and a pointer merely resting there never earns
    -- the tag (6.160.4). nil = nothing to show.
    function clip.previewRow(chooser, box, n)
        local sel
        pcall(function() sel = chooser:selectedRow() end)
        if not (type(sel) == "number" and sel >= 1 and sel <= n) then sel = nil end
        -- 6.161.0: TYPING is keyboard activity too. A query rebuilds the
        -- list with the highlight back on row 1 — which it usually already
        -- was — so the selection never "changes"; the query text (and, for
        -- a picker that filters for itself, the row count) is read
        -- alongside the selection so a letter hands the tag back.
        local q
        pcall(function() q = chooser:query() end)
        if type(q) ~= "string" then q = nil end
        local typed = (q ~= nil and pv.lastQuery ~= nil and q ~= pv.lastQuery)
                      or (pv.lastN ~= nil and n ~= pv.lastN)
        pv.lastQuery, pv.lastN = q, n
        local m
        pcall(function() m = hs.mouse.absolutePosition() end)
        if not (type(m) == "table" and type(m.x) == "number"
                and type(m.y) == "number") then m = nil end
        local moved = false
        if m then
            local last = pv.lastMouse
            if not last then
                pv.lastMouse = { x = m.x, y = m.y }      -- first look: resting
            elseif math.abs(m.x - last.x) >= clip.previewMousePx
                or math.abs(m.y - last.y) >= clip.previewMousePx then
                moved, pv.lastMouse = true, { x = m.x, y = m.y }
            end
        end
        -- over the rows at all? — the band under the query field (< : the
        -- bottom edge pixel is no row). This decides the LABEL, never the row.
        local overRows = m ~= nil and m.x >= box.x and m.x <= box.x + box.w
                         and m.y >= box.y + pv.headH and m.y < box.y + box.h
        local selChanged = pv.lastSel ~= nil and sel ~= pv.lastSel
        pv.lastSel = sel
        if not overRows then pv.hand = "keys"          -- off the rows: the keyboard's
        elseif moved then pv.hand = "mouse"             -- onto a row: the mouse's
        elseif selChanged or typed then pv.hand = "keys" end  -- an arrow, a letter: the keyboard's
        if sel then return sel, pv.hand end
        return nil
    end

    -- Word-wrapped into lines of at most `cols` monospace characters, so
    -- the pane's height is arithmetic. Leading indentation is kept, tabs
    -- become four spaces, a word longer than a line is cut.
    function clip.previewWrap(text, cols)
        cols = math.max(8, math.floor(cols or 60))
        local out = {}
        text = tostring(text or ""):gsub("\r\n", "\n"):gsub("\r", "\n"):gsub("\t", "    ")
        for raw in (text .. "\n"):gmatch("(.-)\n") do
            local line = raw:match("^%s*") or ""
            for word in raw:gmatch("%S+%s*") do
                while #word > cols do
                    if line ~= "" and line:match("%S") then
                        out[#out + 1] = (line:gsub("%s+$", "")) ; line = ""
                    end
                    out[#out + 1] = word:sub(1, cols)
                    word = word:sub(cols + 1)
                end
                if #line + #word > cols and line:match("%S") then
                    out[#out + 1] = (line:gsub("%s+$", ""))
                    line = word
                else
                    line = line .. word
                end
            end
            out[#out + 1] = (line:gsub("%s+$", ""))
        end
        if #out > 1 and out[#out] == "" then out[#out] = nil end
        return out
    end

    -- Lay the entry out beside the picker. Returns true when a pane is
    -- on screen for it. `how` names the hand (6.160.4): when it is the
    -- mouse, the header says so.
    function clip.previewDraw(entry, box, sf, key, how)
        if pv.canvas and pv.lastKey == key then return true end
        local sty = _G.uiStyle or {}
        local pad, fs = 14, 13
        local charW  = fs * 0.602                 -- Menlo's advance, per em
        local lineH  = math.floor(fs * 1.35 + 0.5)
        local gap, w = 12, clip.previewW
        local x = box.x + box.w + gap
        if x + w > sf.x + sf.w - 8 then
            if box.x - gap - w >= sf.x + 8 then
                x = box.x - gap - w                       -- the left, then
            else
                x = box.x + box.w + gap                   -- narrow screen:
                w = math.max(180, sf.x + sf.w - 8 - x)    -- take what fits
            end
        end
        local y    = box.y
        local maxH = sf.y + sf.h - 12 - y
        local text = tostring(entry.rawText or "")
        local shownText = text:sub(1, clip.previewMaxChars)
        local lines = clip.previewWrap(shownText, (w - pad * 2) / charW)
        local total = #lines
        local headH, footH, hidden = 20, 0, 0
        local bodyMax = math.max(1, math.floor((maxH - pad * 2 - headH) / lineH))
        if total > bodyMax then
            footH = 18
            local fit = math.max(1, math.floor((maxH - pad * 2 - headH - footH) / lineH))
            hidden = total - fit
            local cut = {}
            for i = 1, fit do cut[i] = lines[i] end
            lines = cut
        end
        local h = pad * 2 + headH + #lines * lineH + footH
        local rect = { x = x, y = y, w = w, h = h }
        local chars = #text
        local rawLines = select(2, text:gsub("\n", "")) + 1
        -- 6.156.0 — another picker's rows may bring their own header
        -- (the snippet picker names the trigger and the collection);
        -- 6.157.0 — or just a `when`, or nothing but the text
        local head = entry.head or string.format("%s%d char%s  ·  %d line%s%s",
            entry.when and ("📋 " .. tostring(entry.when) .. "  ·  ") or "",
            chars, chars == 1 and "" or "s",
            rawLines, rawLines == 1 and "" or "s",
            chars > clip.previewMaxChars
                and ("  ·  first " .. clip.previewMaxChars .. " shown") or "")
        if how == "mouse" then head = head .. "  ·  🖱 under the pointer" end
        local els = {
            { type = "rectangle", action = "strokeAndFill",
              fillColor   = sty.bg or { red = 0.09, green = 0.10, blue = 0.13, alpha = 0.92 },
              strokeColor = sty.stroke or { white = 1, alpha = 0.18 }, strokeWidth = 1,
              roundedRectRadii = { xRadius = sty.radius or 12, yRadius = sty.radius or 12 },
              frame = { x = 0.5, y = 0.5, w = w - 1, h = h - 1 } },
            { type = "text", text = head, textSize = 11,
              textColor = sty.fgDim or { white = 1, alpha = 0.55 },
              textLineBreak = "truncateTail",
              frame = { x = pad, y = pad - 2, w = w - pad * 2, h = headH } },
            -- pre-wrapped, so "clip" here only ever trims a line the
            -- width estimate got slightly wrong — never re-wraps
            { type = "text", text = table.concat(lines, "\n"), textSize = fs,
              textFont = "Menlo", textLineBreak = "clip",
              textColor = sty.fg or { white = 1, alpha = 0.97 },
              frame = { x = pad, y = pad + headH, w = w - pad * 2,
                        h = #lines * lineH + 4 } },
        }
        if hidden > 0 then
            els[#els + 1] = {
                type = "text",
                text = string.format("… %d more line%s — ⏎ copies all of it",
                                     hidden, hidden == 1 and "" or "s"),
                textSize = 11, textColor = sty.fgDim or { white = 1, alpha = 0.55 },
                frame = { x = pad, y = h - pad - footH + 2, w = w - pad * 2, h = footH },
            }
        end
        if not pv.canvas then
            local okC, c = pcall(hs.canvas.new, rect)
            if not (okC and c) then return false end
            pv.canvas = c
            pcall(function()
                -- beside the chooser, never under it: the ladder's rung
                -- above macOS's fixed chooser level (core/coexist.lua)
                c:level((_G.panelLevel and _G.panelLevel("clippreview"))
                        or (hs.canvas.windowLevels or {}).popUpMenu
                        or (hs.canvas.windowLevels or {}).overlay)
            end)
            pcall(function() c:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" }) end)
            -- click-through: a pane that swallowed the click you were
            -- about to make on the picker would be worse than none
            pcall(function() c:canvasMouseEvents(false, false, false, false) end)
            pcall(function() c:replaceElements(els) end)
            if _G.showCanvasSafely then _G.showCanvasSafely(c, "clipboard preview")
            else pcall(function() c:show() end) end
        else
            pcall(function() pv.canvas:frame(rect) end)
            pcall(function() pv.canvas:replaceElements(els) end)
        end
        pv.lastKey = key
        return true
    end

    function clip.previewTick()
        local ch = pv.chooser
        if not ch then clip.previewClose() return end
        local vis
        pcall(function() vis = ch:isVisible() end)
        if vis == false then
            -- gone — for good, or for the one turn a nudge takes?
            if pv.canvas then pcall(function() pv.canvas:delete() end) ; pv.canvas = nil end
            pv.lastKey, pv.shown = nil, nil
            pv.hiddenAt = pv.hiddenAt or now()
            if now() - pv.hiddenAt >= clip.previewGrace then clip.previewClose() end
            return
        end
        pv.hiddenAt = nil
        local box, sf = clip.previewBox(ch)
        -- 👁 6.157.0 — TWO WAYS TO KNOW WHAT ROW r IS. A picker that
        -- filters for itself hands over rowsFn (the rows AS SHOWN); any
        -- other picker is asked directly — hs.chooser:selectedRowContents(r)
        -- returns the r-th row of whatever list the chooser is showing,
        -- its own filter included — so the pane needs nothing from the
        -- module beyond a rawText on each row. LL: "I need a preview
        -- window for the relevant pickers like hyper+o. Can we correct
        -- all the picker tools that don't have one?"
        local rows = pv.rowsFn and pv.rowsFn() or nil
        local n = rows and #rows or 100000
        local function rowAt(r)
            if rows then return rows[r] end
            local t
            pcall(function() t = ch:selectedRowContents(r) end)
            if type(t) == "table" and next(t) ~= nil then return t end
            return nil
        end
        local r, how
        if box then r, how = clip.previewRow(ch, box, n) end
        local entry = r and rowAt(r)
        if not (entry and type(entry.rawText) == "string") then
            -- an action row, an empty list, or nowhere to put the pane:
            -- take it down (a fresh one is cheap) and keep polling
            if pv.canvas then pcall(function() pv.canvas:delete() end) ; pv.canvas = nil end
            pv.lastKey, pv.shown = nil, nil
            return
        end
        local key = pv.gen .. ":" .. r .. ":" .. how .. ":" .. #entry.rawText
                    .. ":" .. entry.rawText:sub(1, 48)
        if pv.lastKey ~= key then clip.previewDraw(entry, box, sf, key, how) end
        pv.shown = { row = r, how = how }
    end

    function clip.previewOpen(chooser, rowsFn)
        clip.previewClose()
        if not (clip.previewOn and chooser) then return false end
        pv.chooser, pv.rowsFn = chooser, rowsFn
        local okT, t = pcall(hs.timer.doEvery, clip.previewPoll, function()
            local ok, err = pcall(clip.previewTick)
            if not ok then
                warn("preview pane — " .. tostring(err))
                clip.previewClose()
            end
        end)
        if not (okT and t) then pv.chooser, pv.rowsFn = nil, nil ; return false end
        pv.poll = t                 -- HELD: an unreferenced timer is collected
        pcall(clip.previewTick)     -- the first paint is now, not a poll later
        return true
    end

    -- Every way a picker opens goes through one of these two, so the pane
    -- follows. One placement call PER PICKER, on purpose: test_integration
    -- counts them against the pickers built, and that count is the
    -- contract that keeps every picker draggable (6.127.0).
    local function openMain()
        if core.showPopup then core.showPopup(clip.chooser)
        else clip.chooser:show() end
        clip.previewOpen(clip.chooser, function() return clip.lastChoices end)
    end
    -- 6.190.0 — the ⇪space panel, opened straight onto this store.
    -- Returns TRUE when it opened, so the caller falls through to the old
    -- chooser on FALSE and ⇪V is never a dead key. The service registry
    -- is asked at PRESS time, never cached at setup: unified_search may
    -- fail to load, and a cached answer would send ⇪V nowhere all session.
    function clip.openInPanel()
        if not (_G.service and _G.service.has
                and _G.service.has("unified.show")) then
            clip.panelWhy = "unified search is not loaded"
            warn("⇪V wanted the panel but " .. clip.panelWhy
                 .. " — opening the chooser instead")
            return false
        end
        local ok, opened = pcall(function()
            return _G.service.call("unified.show", clip.panelTag)
        end)
        -- 🚨 6.193.0 — ANY FALSY RETURN IS A REFUSAL. This read
        -- `opened == false`, and uni.show returns NIL (not false) when
        -- unified search is switched off — so the panel never opened,
        -- the chooser never opened either, and the key did NOTHING.
        -- That is the worst outcome of the three and it was the one
        -- shape not covered. `not opened` covers nil, false and a
        -- provider that returns nothing at all.
        if not ok or not opened then
            clip.panelWhy = "the panel refused to open"
            warn("⇪V could not open the panel — opening the chooser instead")
            return false
        end
        clip.panelWhy = nil
        return true
    end

    -- 📐 6.227.0 — PURE: which row a picker should land on after its list
    -- was rebuilt. Clamped into the list, and 0/nil means "the top" the
    -- way a fresh picker starts. A row past the end lands on the LAST row
    -- (a delete shortens the list and the eye expects the neighbour), and
    -- an empty list has no row at all.
    function clip.rowAfterRebuild(want, total)
        total = tonumber(total) or 0
        if total <= 0 then return nil end
        want = tonumber(want) or 0
        if want < 1 then return 1 end
        if want > total then return total end
        return want
    end

    -- Never throws: a chooser that cannot be asked costs the PLACE, not
    -- the picker.
    function clip.restoreRow(chooser, want, total)
        local row = clip.rowAfterRebuild(want, total)
        clip.lastRestoredRow = row
        if not (chooser and row) then return false end
        local ok = pcall(function() chooser:selectedRow(row) end)
        return ok
    end

    -- ⤒⤓ 6.227.0 — HOME AND END. LL: "Home/End keys do not work. All I can
    -- use is the arrows. Home/End work in cheat sheets." They do, because
    -- the cheat sheet is a WEB VIEW and the browser handles them;
    -- hs.chooser is an NSTableView in a search field and Hammerspoon
    -- exposes no key handler for it at all. The one honest route is a
    -- plain hs.hotkey that is ENABLED ONLY while the picker is on screen
    -- and disabled the moment it goes — it can never steal Home or End
    -- from any app, because it is not bound while any app has the
    -- keyboard. `chooser:selectedRow(n)` is what actually moves the
    -- highlight, the same call the place-keeping above makes.
    clip.jumpKeysOn = true
    clip.jumpState  = "never asked"
    function clip.makeJumpKeys(chooser, countFn)
        if not clip.jumpKeysOn then
            clip.jumpState = "off (settings = { clipboard_history = { jumpKeysOn = true } })"
            return nil
        end
        if not (hs.hotkey and hs.hotkey.new) then
            clip.jumpState = "⚠️ no hs.hotkey on this Mac — Home/End cannot be bound"
            return nil
        end
        local function jump(toEnd)
            return function()
                local total = 0
                pcall(function() total = tonumber(countFn()) or 0 end)
                clip.restoreRow(chooser, toEnd and total or 1, total)
                clip.jumpState = ("bound · last jump %s to row %s")
                    :format(toEnd and "End" or "Home",
                            tostring(clip.lastRestoredRow))
            end
        end
        local keys = {}
        for _, row in ipairs({ { "home", false }, { "end", true } }) do
            local ok, hk = pcall(function()
                return hs.hotkey.new({}, row[1], jump(row[2]))
            end)
            if ok and hk then keys[#keys + 1] = hk end
        end
        if #keys == 0 then
            clip.jumpState = "⚠️ Home/End refused to bind"
            return nil
        end
        clip.jumpState = "bound — enabled only while the picker is up"
        return keys
    end

    -- Enabled on show, disabled on hide. Never throws: a Mac that cannot
    -- bind them keeps the arrows.
    function clip.setJumpKeys(keys, on)
        if type(keys) ~= "table" then return false end
        for _, hk in ipairs(keys) do
            pcall(function() if on then hk:enable() else hk:disable() end end)
        end
        return true
    end

    local function openEdit()
        if core.showPopup then core.showPopup(clip.editChooser)
        else clip.editChooser:show() end
        clip.previewOpen(clip.editChooser, function() return clip.lastEditChoices end)
    end

    -- ☑️ 6.97.0 — SELECT MODE, the same pattern the Document Watcher list
    -- proved in 6.40.0: hs.chooser has no shift-click multi-select, so
    -- Enter TAGS rows (✓) and an action row applies to all of them at
    -- once. Tags key on the ENTRY TABLE, not the index — a copy made
    -- while the picker is open shifts every index, but identity holds.
    clip.selectMode = false
    clip.tagged     = {}        -- entry table -> true

    function clip.taggedCount()
        local n = 0
        for _ in pairs(clip.tagged) do n = n + 1 end
        return n
    end

    -- Both bulk actions end select mode: the job the mode existed for is
    -- done, and coming back to a stale pick-list is how mistakes happen.
    function clip.deleteTagged()
        local kept, removed = {}, 0
        for _, item in ipairs(_G.clipboardCache) do
            if clip.tagged[item] then removed = removed + 1
            else kept[#kept + 1] = item end
        end
        if removed > 0 then
            _G.clipboardCache = kept
            clip.save()
        end
        clip.selectMode, clip.tagged = false, {}
        return removed
    end

    function clip.copyTagged()
        local parts = {}
        for _, item in ipairs(_G.clipboardCache) do
            if clip.tagged[item] then parts[#parts + 1] = item.text or "" end
        end
        if #parts > 0 then
            -- One pasteboard write; the shared watcher files the joined
            -- text as a NEW top entry, which is what a copy means here.
            pcall(function() hs.pasteboard.setContents(table.concat(parts, "\n")) end)
        end
        clip.selectMode, clip.tagged = false, {}
        return #parts
    end

    local function oneLine(s) return (s:gsub("%s+", " ")) end

    function clip.render(query)
        local q = (query or ""):lower():match("^%s*(.-)%s*$")
        local choices = {}
        for _, item in ipairs(_G.clipboardCache) do
            if q == "" or (item.text or ""):lower():find(q, 1, true) then
                choices[#choices + 1] = {
                    text    = oneLine(item.text or ""):sub(1, clip.preview),
                    subText = item.date or "",
                    rawText = item.text,
                    when    = item.date or "",
                }
                if #choices >= clip.rows then break end
            end
        end
        if #choices == 0 then
            choices[1] = {
                text = (q == "") and "Clipboard history is empty"
                       or ("No matches for \"" .. q .. "\""),
                subText = "Searches the full text of every saved item",
            }
        end
        clip.lastChoices = choices          -- 👁 what the preview pane indexes
        clip.pv.gen = clip.pv.gen + 1
        clip.chooser:choices(choices)
    end

    -- 🚨 THE SNAPSHOT+INDEX PATTERN IS LOAD-BEARING, and the reason is not
    -- obvious. This originally put the entry TABLE on the choice and
    -- compared it with == in the callback — but hs.chooser round-trips
    -- every choice through its Objective-C bridge, and what comes back is
    -- a FRESHLY REBUILT Lua table, never the object you handed it. Table
    -- identity cannot survive that trip, so the match always failed and
    -- every edit answered "that entry is gone". A NUMBER survives, so the
    -- index is passed and the real object looked up on our side.
    function clip.renderEdit(query)
        local q = (query or ""):lower():match("^%s*(.-)%s*$")
        editSnapshot = {}
        local choices = {}
        if #_G.clipboardCache == 0 then
            -- An empty history gets no action rows — nothing to pick.
        elseif clip.selectMode then
            local n = clip.taggedCount()
            choices[#choices + 1] = {
                text    = (n == 0) and "☑️ Nothing picked yet"
                          or ("🗑 Delete the " .. n .. " I picked"),
                subText = (n == 0)
                          and "Go down the list and press Enter on the rows you want"
                          or "Press Enter HERE to delete them all",
                action  = "deletetagged",
            }
            choices[#choices + 1] = {
                text    = "📋 Copy the picked rows as ONE text",
                subText = (n == 0) and "Pick rows first"
                          or (n .. " row" .. ((n == 1) and "" or "s")
                              .. " joined with line breaks, then copied"),
                action  = "copytagged",
            }
            choices[#choices + 1] = {
                text    = "✖️ Never mind — go back",
                subText = "Forget the picks and return to one-at-a-time editing",
                action  = "selectoff",
            }
        else
            choices[#choices + 1] = {
                text    = "☑️ Select several…",
                subText = "Pick rows with Enter, then delete them or copy them as one",
                action  = "selecton",
            }
        end
        local shown = 0
        for i, item in ipairs(_G.clipboardCache) do
            if q == "" or (item.text or ""):lower():find(q, 1, true) then
                editSnapshot[i] = item
                local hint
                if not clip.selectMode then hint = "Enter to edit or delete"
                elseif clip.tagged[item] then hint = "PICKED — Enter unpicks it"
                else hint = "Enter picks it" end
                choices[#choices + 1] = {
                    text    = (clip.tagged[item] and "✓ " or "")
                              .. oneLine(item.text or ""):sub(1, clip.preview),
                    subText = (item.date or "") .. "  ·  " .. hint,
                    idx     = i,
                    rawText = item.text,        -- 👁 for the preview pane
                    when    = item.date or "",
                }
                shown = shown + 1
                if shown >= clip.rows then break end
            end
        end
        if shown == 0 then
            choices[#choices + 1] = {
                text = (q == "") and "Clipboard history is empty"
                       or ("No matches for \"" .. q .. "\""),
                subText = "",
            }
        end
        clip.lastEditChoices = choices      -- 👁 what the preview pane indexes
        clip.pv.gen = clip.pv.gen + 1
        clip.editChooser:choices(choices)
    end

    function clip.applyEdit(idxFromChoice, text)
        local entry = editSnapshot[idxFromChoice]
        if not entry then return "gone" end
        -- Re-find the entry's CURRENT position: a copy made while the
        -- picker was open shifts every index.
        local idx = nil
        for i, v in ipairs(_G.clipboardCache) do
            if v == entry then idx = i break end
        end
        if not idx then return "gone" end

        if not text or text:match("^%s*$") then
            table.remove(_G.clipboardCache, idx)
            clip.save()
            return "deleted"
        end
        _G.clipboardCache[idx].text = text
        clip.save()
        -- 🚨 THE EDITED TEXT GOES ON THE CLIPBOARD, and the ORDER matters.
        -- Setting the pasteboard wakes the watcher, which would normally
        -- file a second entry. It does not, because clip.add's dedupe
        -- removes any entry matching the arriving text and this one now
        -- carries exactly that text — so it is lifted to the front rather
        -- than copied. The cache must hold the new text BEFORE the
        -- pasteboard does, or the duplicate reappears.
        pcall(function() hs.pasteboard.setContents(text) end)
        return "updated"
    end

    -- ---- wiring ------------------------------------------------------------
    if clip.enabled then
        clip.chooser = hs.chooser.new(function(c)
            if c and c.rawText then
                pcall(function() hs.pasteboard.setContents(c.rawText) end)
                hs.alert.show("📋 Copied")
            end
        end)
        -- ⎋ 6.93.0: filed in _G.choosers so Esc closes ⇪V before the cheat sheet
        _G.choosers = _G.choosers or {}
        _G.choosers.clipboardHistory = clip.chooser
        pcall(function()
            clip.chooser:placeholderText("Search Clipboard History...")
        end)
        -- 👁 the pane goes down with the picker — Esc, a pick, a click away
        -- — and waits out a nudge (6.155.0, see previewSuspend)
        clip.jumpKeys = clip.makeJumpKeys(clip.chooser,
            function() return #(clip.lastChoices or {}) end)
        pcall(function()
            clip.chooser:showCallback(function()
                clip.setJumpKeys(clip.jumpKeys, true)
            end)
        end)
        pcall(function()
            clip.chooser:hideCallback(function()
                clip.setJumpKeys(clip.jumpKeys, false)
                clip.previewSuspend()
            end)
        end)
        clip.chooser:queryChangedCallback(function(query)
            local ok, err = pcall(clip.render, query)
            if not ok then
                warn("render failed: " .. tostring(err))
                clip.chooser:choices({ { text = "⚠️ Display error — see Console",
                                         subText = tostring(err) } })
            end
        end)

        -- 🔖 6.227.0 — THE PICKER KEEPS ITS PLACE. LL, on ⇪⇧V: "while
        -- selections work, I'm returned to the top after a selection
        -- multiple times … It seems that until I get out of the search
        -- box, I can't select items."
        --
        -- Both are this function. Every tag, every select-mode toggle and
        -- every action row came back through it, and it threw away BOTH
        -- halves of where he was: it re-rendered with "" (wiping whatever
        -- he had typed, so the list became the whole history again) and
        -- hs.chooser resets the highlight to row 1 whenever :choices() is
        -- handed a new list. Tag the fourth row of a search and the next
        -- keypress is aimed at the first row of everything — which is
        -- also why nothing looked selected until he pressed an arrow.
        --
        -- Now the QUERY is read back and re-applied, and the ROW is put
        -- back after the new choices are in (clamped to the list, because
        -- a delete makes it shorter — landing on the row that took its
        -- place is what a list should do).
        local function reopenEdit(wantRow)
            local q = ""
            pcall(function() q = clip.editChooser:query() or "" end)
            if wantRow == nil then
                pcall(function() wantRow = clip.editChooser:selectedRow() end)
            end
            clip.renderEdit(q)
            openEdit()
            clip.restoreRow(clip.editChooser, wantRow,
                            #(clip.lastEditChoices or {}))
        end

        clip.editChooser = hs.chooser.new(function(choice)
            if not choice then return end
            if choice.action == "selecton" then
                clip.selectMode, clip.tagged = true, {}
                reopenEdit(); return
            elseif choice.action == "selectoff" then
                clip.selectMode, clip.tagged = false, {}
                reopenEdit(); return
            elseif choice.action == "deletetagged" then
                local n = clip.deleteTagged()
                hs.alert.show((n > 0)
                    and ("🗑 Deleted " .. n .. " clipboard entr"
                         .. ((n == 1) and "y" or "ies"))
                    or "Nothing picked — press Enter on the rows you want first")
                return
            elseif choice.action == "copytagged" then
                local n = clip.copyTagged()
                hs.alert.show((n > 0)
                    and ("📋 Copied " .. n .. " entr" .. ((n == 1) and "y" or "ies")
                         .. " as one")
                    or "Nothing picked — press Enter on the rows you want first")
                return
            end
            if not choice.idx then return end
            if clip.selectMode then
                local entry = editSnapshot[choice.idx]
                if entry then
                    if clip.tagged[entry] then clip.tagged[entry] = nil
                    else clip.tagged[entry] = true end
                end
                reopenEdit(); return
            end
            local idx = choice.idx
            local entryText = (editSnapshot[idx] or {}).text or ""
            local function finish(text)
                local result = clip.applyEdit(idx, text)
                if result == "gone" then
                    hs.alert.show("⚠️ That entry is gone — history changed since "
                                  .. "this picker opened")
                elseif result == "deleted" then
                    hs.alert.show("🗑 Clipboard entry deleted")
                else
                    hs.alert.show("✏️ Clipboard entry updated — and copied")
                end
            end
            -- ✍️ 6.213.5 — THE WINDOW, NOT THE PROMPT. LL: "This window does
            -- not come to the front when I edit the clipboard. Also, the
            -- edit field is very small, can we make this a bigger edit box
            -- or use another type of window?" — hs.dialog.textPrompt is a
            -- fixed one-line NSAlert that opens behind whatever is in front
            -- (6.190.0). The OCR module's editor (6.115.0) is a real window
            -- that takes the caret on open, published as `editor.open`;
            -- asked at PRESS time (6.190.0's rule), and the prompt stays
            -- the degrade for a Mac without it. The hooks call the same
            -- clip.applyEdit the prompt did, so one rule decides both.
            local opened = false
            if _G.service and _G.service.has and _G.service.has("editor.open") then
                opened = _G.service.call("editor.open", {
                    title       = "✏️ Edit clipboard entry",
                    windowTitle = "Edit clipboard entry",
                    sub         = "⌘⏎ saves and copies · Esc cancels · empty the box, or Delete, to delete",
                    placeholder = "The copied text. Empty it to delete this entry.",
                    text        = entryText,
                    onSave      = finish,
                    onDelete    = function() finish("") end,
                }) == true
            end
            if opened then return end
            local b, text = hs.dialog.textPrompt(
                "✏️ Edit clipboard entry",
                "Edit the text below.\nSave with it EMPTY to delete this entry.",
                entryText, "Save", "Cancel")
            if b ~= "Save" then return end
            finish(text)
        end)
        _G.choosers = _G.choosers or {}
        _G.choosers.clipboardEdit = clip.editChooser   -- ⎋ 6.93.0: same rule for ⇪⇧V
        pcall(function()
            clip.editChooser:placeholderText(
                "Search clipboard history to edit or delete — Enter opens a row")
        end)
        -- ⤒⤓ 6.227.0 — Home/End live exactly as long as the picker does
        clip.editJumpKeys = clip.makeJumpKeys(clip.editChooser,
            function() return #(clip.lastEditChoices or {}) end)
        pcall(function()
            clip.editChooser:showCallback(function()
                clip.setJumpKeys(clip.editJumpKeys, true)
            end)
        end)
        pcall(function()
            clip.editChooser:hideCallback(function()
                clip.setJumpKeys(clip.editJumpKeys, false)
                clip.previewSuspend()
            end)
        end)
        clip.editChooser:queryChangedCallback(function(query)
            local ok, err = pcall(clip.renderEdit, query)
            if not ok then
                warn("edit render failed: " .. tostring(err))
                clip.editChooser:choices({ { text = "⚠️ Display error — see Console",
                                             subText = tostring(err) } })
            end
        end)

        -- ⇪V / ⇪⇧V. The old ⌃⌥⌘V and ⌃⌥⌘⇧V chords are what §0.4's
        -- migration map POINTS AT these; binding the hyper keys directly
        -- is the same destination without the indirection.
        -- ⌨️ 6.292.0 — ⌘⌘ OPENS THIS, and it is the same door ⇪V takes.
        -- LL asked for it in 6.198.0, again on 2026-09-13, and again on
        -- 2026-09-26; it had never been built, while the engine for it
        -- had been driving ⌃⌃ on his Mac since 6.116.0. ONE function,
        -- two callers (6.231.0) — a gesture that opened the history a
        -- different way from the key is two features to keep in step.
        clip.openHistory = function()
            if clip.panel and clip.openInPanel() then return end
            clip.render("")
            openMain()
        end

        core.hyperAddShortcut({}, clip.key, function()
            -- 6.190.0 — LL: "make the histories match unified search."
            -- ⇪space ALREADY renders this exact store as its @clip source,
            -- in the panel LL wants. So the history opens THERE rather
            -- than growing a second renderer to keep in step with the
            -- first — one page, one look, one place to fix.
            -- The EDIT side (⇪⇧V) stays a chooser: it deletes rows, and
            -- ⇪space is a reader.
            clip.openHistory()
        end, "clipboard history")

        core.hyperAddShortcut({ "shift" }, clip.key, function()
            -- A fresh ⇪⇧V always starts in one-at-a-time mode: reopening
            -- into week-old ✓ marks is how the wrong rows get deleted.
            clip.selectMode, clip.tagged = false, {}
            clip.renderEdit("")
            openEdit()
        end, "clipboard edit")
    end

    -- 🗂 6.116.0 — listed for the ⌘⌘ editor picker. There is no `view`: a
    -- chooser is not a window this config can bring forward, so ⏎ always
    -- opens a fresh one, which for a picker is the same thing.
    --
    -- 🚨 INSIDE the enabled check. clip.chooser is only built when this
    -- module is enabled, so registering unconditionally would put a row in
    -- the picker whose ⏎ calls a method on nil — a dead row is worse than
    -- an absent one, because you only find out by pressing it.
    if clip.enabled then
        _G.editors = _G.editors or {}
        table.insert(_G.editors, {
            name  = "Clipboard",
            -- 6.132.0 — LL: "Shouldn't this be in the edit picker? ⇪⇧V."
            -- It was: ⇪⇧V is this row's EDIT view. The row simply never
            -- said so, so the picker read as if ⇪V were the only way in.
            -- Same shape as the Screenshots row's "⇪4 / ⇪⇧4", where the
            -- second key is likewise a different view, not a second door
            -- into the same one.
            key   = "⇪V / ⇪⇧V",
            what  = "everything you have copied",
            order = 40,
            unit  = "items",
            show  = function()
                clip.render("")
                openMain()
            end,
            size  = function() return #(_G.clipboardCache or {}) end,
            text  = function()
                local top = (_G.clipboardCache or {})[1]
                return top and top.text or nil
            end,
            -- 💾 6.130.0 — the whole history for the one-file CSV export.
            -- `text` above is the ⌥⏎ answer and is deliberately just the
            -- newest item; this is every item, and the cache is stored
            -- newest-first already, which is the order the export wants.
            csv   = function()
                local out = {}
                for _, it in ipairs(_G.clipboardCache or {}) do
                    if type(it) == "table" and type(it.text) == "string" then
                        out[#out + 1] = { when = it.date, text = it.text }
                    end
                end
                return out
            end,
        })
    end

    -- 📋 6.224.0 — THE REPORT 6.202.0 QUEUED. One string (6.179.1), and it
    -- answers "I don't see items that i just copied" in one read: what is
    -- newest and when it landed, how many are stored, what was REFUSED and
    -- why, whether a save failed, and whether the poll that feeds all of
    -- this is running, resting or being suppressed by a borrowed
    -- clipboard. Never a bare count — a count on its own is what left the
    -- question open for two releases.
    _G.clipboardReport = function()
        local cache = _G.clipboardCache or {}
        local st = clip.stats
        local L = { "📋 CLIPBOARD HISTORY — ⇪V · ⇪⇧V edits" }
        local top = cache[1]
        L[#L + 1] = "   newest   : " .. (top and type(top.text) == "string"
            and (('"%s"'):format(
                    (top.text:gsub("%s+", " ")):sub(1, 60)
                    .. (#top.text > 60 and "…" or ""))
                 .. " · " .. tostring(top.date or "no date"))
            or "nothing stored")
        L[#L + 1] = "   stored   : " .. #cache .. " of " .. clip.max
            .. (clip.loaded and " · file read at boot"
                or " ⚠️ THE FILE HAS NOT BEEN READ YET — copies are being held")
        L[#L + 1] = "   file     : " .. tostring(clip.file)
        L[#L + 1] = "   filed    : " .. st.added .. " copy(ies) this session"
            .. (st.lastAddAt and (" · last at " .. st.lastAddAt) or "")
            .. (st.heldAtBoot > 0 and (" · " .. st.heldAtBoot
                .. " held until the file was read") or "")
        local ref = st.sameAsTop + st.tooBig + st.notText
        L[#L + 1] = "   refused  : " .. (ref == 0 and "none" or
            (ref .. " — " .. st.sameAsTop .. " already newest · "
             .. st.tooBig .. " over 1 MB · " .. st.notText .. " not text"))
        if st.lastRefusal then
            L[#L + 1] = "   ↳ last   : " .. st.lastRefusal
                        .. " at " .. tostring(st.lastRefusalAt)
        end
        L[#L + 1] = "   saves    : " .. st.saved .. " ok · "
            .. st.saveFailed .. " FAILED"
        if st.lastSaveFail then
            L[#L + 1] = "   ↳ ⚠️ last: " .. st.lastSaveFail
                        .. " at " .. tostring(st.lastSaveFailAt)
        end
        -- The poll is init.lua's, shared with the image path. Say what it
        -- has seen, because a copy this module never hears about is the
        -- one failure its own counters cannot show.
        local ps = _G.clipboardPollStats
        if type(ps) == "table" then
            local mins = _G.clipboardPollMins and _G.clipboardPollMins() or 0
            L[#L + 1] = ("   poll     : %d pasteboard change(s) in %.0f min · %d rest(s) on the thrash breaker · %d suppressed by a borrowed clipboard")
                :format(ps.changes or 0, mins, ps.rests or 0, ps.suppressed or 0)
            if (ps.changes or 0) > st.added + ref then
                L[#L + 1] = "   ↳ the poll saw MORE changes than this module"
                    .. " was offered — images and copied files are the"
                    .. " innocent explanation (they go to OCR, not here)"
            end
        else
            L[#L + 1] = "   poll     : ⚠️ init.lua's pasteboard watcher is not"
                        .. " running — nothing can reach the history"
        end
        L[#L + 1] = "   pane     : " .. (clip.previewOpen and "available"
                                         or "not loaded")
        -- ⤒⤓ 6.227.0 — Home/End, and where the picker last put itself back
        L[#L + 1] = "   home/end : " .. tostring(clip.jumpState)
        -- ⌨️ 6.292.0 — THREE STATES (6.196.1), because "⌘⌘ does nothing"
        -- reads the same in all of them and they need different answers.
        if not clip.cmdCmd then
            L[#L + 1] = "   ⌘⌘       : OFF — settings = { clipboard_history "
                        .. "= { cmdCmd = true } }"
        elseif clip.cmdCmdWhy then
            L[#L + 1] = "   ⌘⌘       : ⚠️ WANTED but not running — "
                        .. tostring(clip.cmdCmdWhy)
                        .. " · ⇪V still opens the history"
        else
            local g = _G.doubleTap and _G.doubleTap.byName
                      and _G.doubleTap.byName.clipboardHistory
            L[#L + 1] = "   ⌘⌘       : watching · " .. ((g and g.fires) or 0)
                        .. " open(s) this session  ·  _G.doubleTapReport()"
        end
        L[#L + 1] = "   place    : " .. (clip.lastRestoredRow
            and ("the picker last landed on row " .. clip.lastRestoredRow
                 .. " after a rebuild")
            or "the list has not been rebuilt under a selection this session")
        print(table.concat(L, "\n"))
        return clip.stats
    end

    core.provide("clipboard.add",   function(t) return clip.add(t)   end)
    core.provide("clipboard.save",  function()  return clip.save()   end)
    core.provide("clipboard.count", function()  return #_G.clipboardCache end)
    -- 👁 6.156.0 — THE PANE IS A SERVICE. Any picker whose rows carry a
    -- rawText (and, optionally, a head line) can have the same pane beside
    -- it: hand over the chooser and a function returning the rows AS SHOWN
    -- (the caller must do its own filtering, so row indexes match). One
    -- pane at a time — the second opener closes the first.
    core.provide("preview.open",    function(ch, rowsFn) return clip.previewOpen(ch, rowsFn) end)
    core.provide("preview.suspend", function() clip.previewSuspend() return true end)
    core.provide("preview.close",   function() clip.previewClose()   return true end)

    -- ⏱ THE FILE IS READ IN warm(), NOT setup(). It can be a megabyte and
    -- it is on the boot path otherwise. Copies made in the ~2 seconds
    -- before it lands are kept in clip.preload and re-applied on top
    -- afterwards, so nothing copied during boot is lost to the load.
    M.warm = function()
        clip.load()
        for i = #clip.preload, 1, -1 do
            local t = clip.preload[i]
            local cache = _G.clipboardCache
            for j = #cache, 1, -1 do
                if cache[j].text == t then table.remove(cache, j) end
            end
            table.insert(cache, 1, { date = os.date("%b %d %H:%M"), text = t })
        end
        while #_G.clipboardCache > clip.max do table.remove(_G.clipboardCache) end
        if #clip.preload > 0 then clip.save() end
        clip.preload, clip.loaded = {}, true
        say(#_G.clipboardCache .. " items loaded")
    end

    -- ⌨️ 6.292.0 — the ⌘⌘ gesture. `cmdCmdSide` is "either" because no
    -- Apple keyboard has only one ⌘ and a side setting that cannot be
    -- honoured is a gesture that quietly stops working (6.124.0).
    clip.cmdCmd     = true      -- settings = { clipboard_history = { cmdCmd = false } }
    clip.cmdCmdSide = "either"  -- or "left" / "right"

    _G.clipboardHistory = clip
    M.clip   = clip
    M.config = clip
end

-- ⌨️ 6.292.0 — ⌘⌘ IS REGISTERED IN warm(), NEVER IN setup(). init.lua
-- applies a profile's `settings` AFTER setup returns, so a gesture
-- registered in setup could be switched off and never unregistered —
-- 6.228.0's shape, which this project has now met in five modules.
function M.warm(core)
    local clip = M.clip
    if not clip or not clip.cmdCmd then return end
    local dt = _G.doubleTap
    if not dt then
        -- IT DEGRADES, IT NEVER BREAKS: ⇪V is untouched and still opens
        -- the history. Said once, in the report, not as an alert on a
        -- Mac where nothing the user asked for has failed.
        clip.cmdCmdWhy = "core/double_tap.lua did not load"
        return
    end
    local g, why = dt.register("clipboardHistory", {
        mod = "cmd", side = clip.cmdCmdSide, action = clip.openHistory,
        label = "clipboard history (⇪V)",
    })
    if not g then
        clip.cmdCmdWhy = tostring(why)
        if core and core.degrade then
            pcall(core.degrade, "Clipboard ⌘⌘", tostring(why))
        end
        return
    end
    local ok, startWhy = dt.start()
    clip.cmdCmdWhy = ok and nil or tostring(startWhy)
    if not ok and core and core.degrade then
        pcall(core.degrade, "Clipboard ⌘⌘", tostring(startWhy))
    end
end

return M
