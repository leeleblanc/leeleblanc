-- =====================================================================
-- MODULE: TASK FORM (⇪T) — Asana task entry where every field keeps its label
-- =====================================================================
-- The old ⇪T picker was one Spotlight-style line with a placeholder:
--     Title | Description | Assignee | /path/to/attachment
-- and the placeholder vanishes on the first keystroke — that is how the
-- native search field works, there is no API to keep it visible. LL:
-- "The minute I start typing the prompt words go away. That's a lot to
-- remember." Correct, and unfixable inside hs.chooser.
--
-- So creating a task is now a small FORM instead — four fields, each
-- with its label permanently on screen:
--
--     Title:        [                    ]
--     Description:  [                    ]
--     Assignee:     [                    ]
--     Attachment:   [                    ]  (📸 newest screenshot)
--
--   ⏎      send the task, from any field
--   ⇥ / ⇧⇥ next / previous field
--   ⌥⏎     newline inside the Description box (⏎ there still SENDS —
--          one key means one thing everywhere)
--   ⌘L     fill Attachment with the newest screenshot (same as the 📸
--          button; asks the Screenshots module, ⇪4's folder)
--   Esc    close — the draft is KEPT and comes back on the next ⇪T,
--          same guarantee the old picker made in 6.10.1
--
-- The pipe picker did a second job too: SEARCHING past tasks. A form
-- cannot search, so that job moved whole to ⇪⇧S ("S for Search") — the
-- same chooser as before, now used only for looking things up.
-- (⇪⇧T was the plan, but the Text Expander has held it since 6.68.0.)
--
-- ---------------------------------------------------------------------
-- 📐 6.220.0 — IT FITS ON THE SCREEN
-- ---------------------------------------------------------------------
-- LL, with a screenshot: "Can you put the contents of this window
-- hyper+t, so that the items do not run down one long list and we can
-- see the blue create task button?" His Asana project publishes a dozen
-- custom fields; each one added a 44-pt row and the only clamp was the
-- screen, so the window was taller than his display and the Create
-- button sat below its bottom edge, unreachable.
--
-- Three changes, one shape: the page is a header / SCROLLER / footer
-- sandwich, the Create button lives in the footer (outside the
-- scroller, so nothing can push it off), and the project fields are laid
-- two to a row with each label ABOVE its control — an Asana field name
-- ("| 🎯 ACD Strategic Principle |:") wrapped over four lines in a
-- 104-pt right-hand gutter. `form.sizeFor` is PURE and decides the
-- three numbers; `form.maxHeight` is the ceiling the screen never had.
--
-- ---------------------------------------------------------------------
-- WHAT THIS MODULE DELIBERATELY DOES NOT OWN
-- ---------------------------------------------------------------------
-- Submission. Validating the title, resolving "sarah" to an Asana GID,
-- posting, history, the attachment upload — all of that stayed in
-- init.lua §4 where it always lived, published as _G.asanaSubmitTask.
-- This module is ONLY the front end: it collects four strings and hands
-- them over. Both entry paths (this form, and the pipe chooser on ⇪⇧S)
-- go through the exact same submit code, so they cannot drift apart.
--
-- The ⇪T key itself is also bound in init.lua (it is a migrated combo,
-- ⌃⌥⌘T → ⇪T, routed through the hyperKeyMap) — init calls
-- _G.taskFormShow when this module loaded, and falls back to the pipe
-- chooser when it did not. A missing module must cost the form, not
-- task creation.
--
-- The webview recipe (allowTextEntry, fullScreenAuxiliary, the say()
-- rule that every message carries every field) is the Capture Pad's,
-- copied deliberately — see that module's 6.44.x history for why each
-- line is there.
-- =====================================================================

local M = {
    name  = "Task Form",
    order = 24,
    family = "capture",
    cheatsheet = {
        title = "✅ TASK FORM (⇪T — labeled Asana task entry)",
        entries = {
            { "⇪T",   "Open the form: Title · Description · Assignee · Attachment" },
            { "dates", "Start/End date & time — all optional (a start needs an end)" },
            { "fields","The PROJECT'S dropdowns — Priority, Progress… fetched live" },
            { "chips", "A multi-pick field (SAC Values) is CHECKBOXES — tick any" },
            { "drag",  "The title bar moves the window (⌘-drag anywhere works too)" },
            { "⏎",    "send the task (from any field)" },
            { "⇥",    "next field · ⇧⇥ previous" },
            { "⌥⏎",   "newline inside the Description box" },
            { "📸",   "button (or ⌘L): newest screenshot into Attachment" },
            { "esc",  "close — the draft is kept for next time" },
            { "past",  "search PAST tasks from ⇪space (@asana) — the old pipe picker has no key since 6.161.0" },
        },
    },
}

function M.setup(core)
    local form = {}

    -- ✏️ EDIT HERE ---------------------------------------------------------
    form.enabled     = true
    form.width       = 560      -- no project fields: one column, as before
    form.wideWidth   = 820      -- 6.220.0 — two columns of project fields
    form.height      = 480
    -- 6.223.0 — LL, on 6.220.0: "There are options here so the canvas
    -- needs to be bigger so I don't have to scroll." 6.220.0's ceiling
    -- was 760 and his form wanted ~1,090: the button was safe but the
    -- fields still scrolled. The ceiling is the SCREEN now — tall enough
    -- that the form is drawn whole wherever there is room for it, and
    -- still a number rather than "as tall as the display" (the footer
    -- and the scroller stay exactly as they are, for the Mac or the
    -- project where there is not room).
    form.maxHeight   = 1400     -- the window NEVER grows past this
    form.screenGap   = 80       -- …nor within this much of the screen
    form.fieldH      = 62       -- a project field: its label ABOVE its control
    form.focusOnOpen = true
    form.nonActivating = true  -- 6.153.0 — take the keyboard the moment the
                               -- form opens, without a click and without
                               -- pulling Hammerspoon's other windows forward
    -- ----------------------------------------------------------------------

    -- The draft survives Esc, a stray click, and reopening — cleared only
    -- when a task is actually sent. In-memory, like the old _G.taskDraft:
    -- a config reload starts fresh. 6.152.0 adds the schedule fields and
    -- `custom` (field gid → chosen value) for the project dropdowns.
    local function freshDraft()
        return { title = "", desc = "", assignee = "", attach = "",
                 startDate = "", startTime = "", dueDate = "", dueTime = "",
                 custom = {} }
    end
    form.draft = freshDraft()

    local function say(m)  if _G.diag then _G.diag.say("taskForm", m)  end end
    local function warn(m) if _G.diag then _G.diag.warn("taskForm", m) end end

    local function escapeHtml(s)
        return (tostring(s or "")
            :gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
            :gsub('"', "&quot;"))
    end

    -- ---- the page --------------------------------------------------------
    function form.buildHtml()
        -- Assignee autocomplete: a native <datalist> fed from the same
        -- team roster the pipe picker's inline suggestions used (§3.5's
        -- cache). Typing filters it; picking fills the field; a name not
        -- on the list still submits (email / GID / "me" are all valid)
        -- and is validated properly by _G.asanaSubmitTask.
        local opts = {}
        if type(_G.asanaTeamMembers) == "table" then
            for _, m in ipairs(_G.asanaTeamMembers) do
                if type(m) == "table" and m.name then
                    opts[#opts + 1] = '<option value="' .. escapeHtml(m.name)
                        .. '">' .. escapeHtml(m.email or "") .. '</option>'
                end
            end
        end
        local d = form.draft
        -- 🎨 6.90.0 — shared card colors (ui_style.lua), cascade-last.
        local themeCss = (_G.uiStyle and _G.uiStyle.cssOverride
                          and _G.uiStyle.cssOverride()) or ""

        -- 📋 6.152.0 — THE DETAILS SECTION: the schedule (start/end date
        -- and time, all optional) and the PROJECT'S OWN custom fields,
        -- built from _G.asanaCustomFields (fetched from Asana at boot —
        -- task_creator.lua) so a dropdown edited in Asana appears here on
        -- the next reload with no code change. Unsupported subtypes
        -- (formula, date fields…) are skipped rather than half-drawn.
        local cfRows = {}
        for _, f in ipairs(_G.asanaCustomFields or {}) do
            local cur = d.custom and d.custom[f.gid]
            -- 6.220.0 — a project row is a GRID CELL now (label above
            -- the control); a chips field spans both columns.
            local wide = (f.subtype == "multi_enum") and " wide" or ""
            local label = '<div class="row cf-row' .. wide .. '"><label>'
                          .. escapeHtml(f.name) .. ':</label>'
            if f.subtype == "enum" then
                local sel = {}
                if cur then sel[tostring(cur)] = true end
                local o = { '<select class="cf" data-gid="'
                            .. escapeHtml(f.gid) .. '">',
                            '<option value="">—</option>' }
                for _, opt in ipairs(f.options or {}) do
                    o[#o + 1] = '<option value="' .. escapeHtml(opt.gid) .. '"'
                                .. (sel[opt.gid] and " selected" or "") .. '>'
                                .. escapeHtml(opt.name) .. '</option>'
                end
                o[#o + 1] = '</select></div>'
                cfRows[#cfRows + 1] = label .. table.concat(o)
            elseif f.subtype == "multi_enum" then
                -- ☑️ 6.153.0 — CHECKBOX CHIPS, not a <select multiple>.
                -- LL on that list box: "the SAC Values selector doesn't
                -- look right." Fair three times over: it was the one
                -- system-styled always-open list in a form of dark
                -- dropdowns; its multi-select needed ⌘-click knowledge
                -- that lived in a hover tooltip; and WebKit paints the
                -- focused row solid blue, which reads as "already
                -- picked" when nothing is. A row of labelled checkboxes
                -- says everything the tooltip could not, and the values
                -- travel exactly as before (an array of option gids).
                local sel = {}
                if type(cur) == "table" then
                    for _, g in ipairs(cur) do sel[g] = true end
                end
                local o = { '<div class="cf chips" data-gid="'
                            .. escapeHtml(f.gid) .. '">' }
                for _, opt in ipairs(f.options or {}) do
                    o[#o + 1] = '<label class="chip"><input spellcheck="false" autocorrect="off" type="checkbox" value="'
                                .. escapeHtml(opt.gid) .. '"'
                                .. (sel[opt.gid] and " checked" or "") .. '>'
                                .. escapeHtml(opt.name) .. '</label>'
                end
                o[#o + 1] = '</div></div>'
                cfRows[#cfRows + 1] = label .. table.concat(o)
            elseif f.subtype == "people" then
                cfRows[#cfRows + 1] = label .. '<input spellcheck="false" autocorrect="off" class="cf" data-gid="'
                    .. escapeHtml(f.gid) .. '" list="team" value="'
                    .. escapeHtml(type(cur) == "string" and cur or "")
                    .. '" placeholder="name or email — optional"></div>'
            elseif f.subtype == "number" or f.subtype == "text" then
                cfRows[#cfRows + 1] = label .. '<input spellcheck="false" autocorrect="off" class="cf"'
                    .. (f.subtype == "number" and ' type="number"' or "")
                    .. ' data-gid="' .. escapeHtml(f.gid) .. '" value="'
                    .. escapeHtml(type(cur) ~= "table" and cur or "")
                    .. '"></div>'
            end
        end
        -- 6.220.0 — TWO COLUMNS. LL: "so that the items do not run down
        -- one long list and we can see the blue create task button."
        -- Twelve project fields down one column made the window taller
        -- than the screen, and the Create button was below its bottom
        -- edge. The grid halves the rows; the footer below pins the
        -- button; #wrap scrolls whatever is left over.
        local cfHtml = table.concat(cfRows)
        if cfHtml == "" then
            cfHtml = '<div class="row"><label></label><span class="hint">'
                .. 'project fields load shortly after boot — reopen ⇪T '
                .. 'if this stays empty</span></div>'
        else
            cfHtml = '<div class="cols">' .. cfHtml .. '</div>'
        end
        local detailsHtml = [[
  <div class="sect">Schedule — optional (a start needs an end)</div>
  <div class="row"><label for="sd">Start:</label>
    <input id="sd" spellcheck="false" autocorrect="off" type="date" value="]] .. escapeHtml(d.startDate) .. [[">
    <input id="st" spellcheck="false" autocorrect="off" type="time" value="]] .. escapeHtml(d.startTime) .. [["></div>
  <div class="row"><label for="ed">End:</label>
    <input id="ed" spellcheck="false" autocorrect="off" type="date" value="]] .. escapeHtml(d.dueDate) .. [[">
    <input id="et" spellcheck="false" autocorrect="off" type="time" value="]] .. escapeHtml(d.dueTime) .. [["></div>
  <div class="sect full">Project fields — optional</div>
]] .. cfHtml

        return [[
<meta charset="utf-8">
<style>
  :root { color-scheme: dark; }
  /* 6.220.0 — THREE BANDS: a header that stays, a middle that
     SCROLLS, and a footer that holds the Create button. The button can
     no longer be pushed off the bottom by a project with a dozen
     fields — which is exactly what LL was looking at. */
  html, body { height:100%; }
  body { margin:0; font-family:-apple-system,BlinkMacSystemFont,sans-serif;
         font-size:15px; line-height:1.5; background:#141418; color:#e8e8ec;
         display:flex; flex-direction:column; overflow:hidden; }
  header { flex:none; padding:14px 18px 8px; display:flex;
           justify-content:space-between;
           align-items:baseline; border-bottom:1px solid #2a2a32;
           user-select:none; -webkit-user-select:none; cursor:grab; }
  header.dragging { cursor:grabbing; }
  h1 { font-size:16px; margin:0; font-weight:600; }
  .hint { color:#8a8a96; font-size:13px; }
  #wrap { flex:1 1 auto; min-height:0; overflow-y:auto; padding:14px 18px; }
  .row { display:flex; gap:12px; align-items:flex-start; margin-bottom:12px; }
  /* THE LABELS ARE THE FEATURE — a fixed column that never goes away,
     which is the entire reason this form exists. */
  label { flex:none; width:104px; text-align:right; padding-top:8px;
          color:#a9a9b4; font-size:14px; user-select:none;
          -webkit-user-select:none; }
  input, textarea { flex:1; box-sizing:border-box;
          background:#1d1d24; color:#f2f2f6; border:1px solid #33333e;
          border-radius:8px; padding:8px 12px;
          font-family:-apple-system,BlinkMacSystemFont,sans-serif;
          font-size:15px; line-height:1.4; }
  textarea { height:84px; resize:vertical; }
  #attach { font-size:13px; }
  input:focus, textarea:focus { outline:none; border-color:#4a7fe0; }
  ::placeholder { color:#5c5c68; }
  .after { flex:none; padding-top:4px; }
  button { background:#2a2a34; color:#e8e8ec; border:1px solid #3b3b47;
           border-radius:7px; padding:6px 11px; font-size:13px; cursor:pointer; }
  button.go { background:#3566cc; border-color:#4a7fe0; font-size:14px;
              padding:7px 14px; }
  button:hover { filter:brightness(1.18); }
  footer.bar { flex:none; display:flex; gap:10px; align-items:center;
          padding:10px 18px; border-top:1px solid #2a2a32;
          background:#141418; }
  .bar .hint { margin-left:auto; }
  .sect { color:#8a8a96; font-size:11px; letter-spacing:.5px;
          text-transform:uppercase; margin:12px 0 8px 116px;
          user-select:none; -webkit-user-select:none; }
  .sect.full { margin-left:0; }
  /* 🗂 6.220.0 — the project fields, two to a row, each label ABOVE its
     control: an Asana field name is long ("| 🎯 ACD Strategic Principle
     |:") and a 104-px right-hand gutter wrapped it over four lines. */
  .cols { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr));
          gap:2px 18px; }
  .cols .row { display:block; margin-bottom:10px; }
  .cols label { display:block; width:auto; text-align:left; padding:0 0 4px;
                font-size:12px; line-height:1.3; }
  .cols input, .cols select, .cols .chips { width:100%; }
  .cols .wide { grid-column:1 / -1; }
  select { flex:1; box-sizing:border-box; background:#1d1d24; color:#f2f2f6;
           border:1px solid #33333e; border-radius:8px; padding:7px 10px;
           font-size:14px; }
  select:focus { outline:none; border-color:#4a7fe0; }
  /* ☑️ 6.153.0 — multi_enum chips. :has() only paints the checked wash;
     a WebKit without it still shows the checkbox itself, so nothing is
     lost on an older Hammerspoon build. */
  .chips { flex:1; display:flex; flex-wrap:wrap; gap:8px; padding-top:5px; }
  .chip { display:inline-flex; align-items:center; gap:7px; background:#1d1d24;
          color:#e8e8ec; border:1px solid #33333e; border-radius:15px;
          padding:5px 12px; font-size:13px; cursor:pointer;
          user-select:none; -webkit-user-select:none; }
  .chip input { accent-color:#3566cc; margin:0; }
  .chip:has(input:checked) { background:#243352; border-color:#4a7fe0; }
  input[type=date], input[type=time] { color-scheme: dark; }
  ]] .. themeCss .. [[
</style>
<header>
  <h1>✅ New Asana Task</h1>
  <span class="hint">⏎ send · ⇥ next field · esc keeps the draft</span>
</header>
<div id="wrap">
  <div class="row"><label for="title">Title:</label>
    <input id="title" spellcheck="false" autocorrect="off" value="]] .. escapeHtml(d.title) .. [[" autofocus></div>
  <div class="row"><label for="desc">Description:</label>
    <textarea id="desc" spellcheck="false" autocorrect="off" placeholder="optional — ⌥⏎ for a new line">]]
      .. escapeHtml(d.desc) .. [[</textarea></div>
  <div class="row"><label for="assignee">Assignee:</label>
    <input id="assignee" spellcheck="false" autocorrect="off" list="team" value="]] .. escapeHtml(d.assignee)
      .. [[" placeholder="name, email, GID, or “me”"></div>
  <datalist id="team">]] .. table.concat(opts) .. [[</datalist>
  <div class="row"><label for="attach">Attachment:</label>
    <input id="attach" spellcheck="false" autocorrect="off" value="]] .. escapeHtml(d.attach)
      .. [[" placeholder="/path/to/file — or use the 📸 button">
    <span class="after"><button type="button" onclick="say({a:'latest'})"
      title="Newest file from the ⇪4 screenshots folder (⌘L)">📸 newest</button></span></div>
]] .. detailsHtml .. [[
</div>
<footer class="bar">
  <button class="go" onclick="submitIt()">Create task&nbsp;&nbsp;⏎</button>
  <span class="hint">only Title is required</span>
</footer>
<script>
  // Every message carries every field — the Capture Pad's 6.44.7 lesson,
  // applied from day one: values collected in ONE place, so no button or
  // key path can forget them and cost a redraw the draft.
  function val(id){ var el = document.getElementById(id); return el ? el.value : ''; }
  function say(m){
    m = m || {};
    m.title    = val('title');
    m.desc     = val('desc');
    m.assignee = val('assignee');
    m.attach   = val('attach');
    // 6.152.0 — the Details section rides on every message, same rule
    m.startDate = val('sd'); m.startTime = val('st');
    m.dueDate   = val('ed'); m.dueTime   = val('et');
    var cf = {};
    document.querySelectorAll('.cf').forEach(function(el){
      var g = el.getAttribute('data-gid');
      if (!g) return;
      if (el.classList.contains('chips')) {
        var vals = [];
        el.querySelectorAll('input:checked').forEach(function(cb){
          if (cb.value) vals.push(cb.value);
        });
        cf[g] = vals;
      } else {
        cf[g] = el.value || '';
      }
    });
    m.custom = cf;
    window.webkit.messageHandlers.taskForm.postMessage(m);
  }
  function submitIt(){ say({a:'submit'}); }
  // 6.153.0 — the header is a drag handle (LL: "I can't move this
  // window"). Only the mousedown is reported; the drag itself is driven
  // from Lua by window_move, because JS mousemove dies the moment the
  // pointer outruns the window. Same recipe as ⇪space and the pads.
  var hdr = document.querySelector('header');
  hdr.addEventListener('mousedown', function(e){
    if (e.button !== 0) return;
    e.preventDefault();
    hdr.classList.add('dragging');
    say({a:'dragStart'});
  });
  window.addEventListener('mouseup', function(){ hdr.classList.remove('dragging'); });
  window.addEventListener('keydown', function(e){
    if (e.key === 'Escape') { e.preventDefault(); say({a:'close'}); return; }
    if (e.metaKey && (e.key === 'l' || e.key === 'L')) {
      e.preventDefault(); say({a:'latest'}); return;
    }
    if (e.key === 'Enter') {
      // ⏎ SENDS — everywhere, including the Description box, because
      // that is the promise the form makes ("then I hit enter and the
      // task is sent"). ⌥⏎ is the newline, inserted by hand since the
      // textarea's native newline is the un-modified Enter we just took.
      if (e.altKey && e.target && e.target.id === 'desc') {
        e.preventDefault();
        var t = e.target, s = t.selectionStart, en = t.selectionEnd;
        t.value = t.value.slice(0, s) + '\n' + t.value.slice(en);
        t.selectionStart = t.selectionEnd = s + 1;
        return;
      }
      e.preventDefault(); submitIt();
    }
  });
</script>
]]
    end

    -- ---- messages from the page ------------------------------------------
    local function handleMessage(body)
        if type(body) ~= "table" then return end
        local d = form.draft
        if body.title    ~= nil then d.title    = tostring(body.title)    end
        if body.desc     ~= nil then d.desc     = tostring(body.desc)     end
        if body.assignee ~= nil then d.assignee = tostring(body.assignee) end
        if body.attach   ~= nil then d.attach   = tostring(body.attach)   end
        -- 6.152.0 — the Details section is part of the draft too
        if body.startDate ~= nil then d.startDate = tostring(body.startDate) end
        if body.startTime ~= nil then d.startTime = tostring(body.startTime) end
        if body.dueDate   ~= nil then d.dueDate   = tostring(body.dueDate)   end
        if body.dueTime   ~= nil then d.dueTime   = tostring(body.dueTime)   end
        if type(body.custom) == "table" then d.custom = body.custom end

        if body.a == "submit" then
            if not _G.asanaSubmitTask then
                pcall(function()
                    hs.alert.show("⚠️ Task submit unavailable — is Asana configured?", 4)
                end)
                warn("submit requested but _G.asanaSubmitTask is missing")
                return
            end
            -- Same path cleanup the pipe picker's 4th field gets — quotes
            -- stripped, ~ expanded — published by §4 for exactly this call.
            local attach = d.attach
            if _G.asanaNormalizePath then attach = _G.asanaNormalizePath(attach) end
            local ok = _G.asanaSubmitTask(d.title, d.desc, d.assignee, attach, {
                startDate = d.startDate, startTime = d.startTime,
                dueDate   = d.dueDate,   dueTime   = d.dueTime,
                custom    = d.custom,
            })
            if ok then
                -- Sent: the draft's job is done. Validation failures
                -- (empty title, unknown assignee, a start without an
                -- end) return false AFTER alerting, and the form stays
                -- up with everything typed still in it — fix the one
                -- field and hit ⏎ again.
                form.draft = freshDraft()
                form.hide()
            end
        elseif body.a == "latest" then
            local path = core.call("screenshots.latest")
            if type(path) == "string" and path ~= "" then
                d.attach = path
                form.render()
            else
                pcall(function()
                    hs.alert.show("📸 No screenshots yet — ⇪4 takes one", 3)
                end)
            end
        elseif body.a == "dragStart" then
            -- The form registered itself in _G.movablePanels at setup;
            -- window_move drives the whole drag from that entry and
            -- stops on its own when the button comes up.
            if _G.beginPanelDrag then _G.beginPanelDrag("task form")
            else print("✅ Task Form: window_move is off — the header cannot drag") end
        elseif body.a == "close" then
            form.hide()   -- draft already captured above — kept for reopen
        end
    end

    -- ---- window ----------------------------------------------------------
    -- Read back and verified, never assumed — AppKit silently drops style
    -- bits it will not honour. The full story is at Capture Pad's
    -- applyNonActivating; the arithmetic (not 5.3's `&`) is because this
    -- file runs on whatever Lua the installed Hammerspoon was built with.
    function form.applyNonActivating(view)
        if not view then return false, "there is no window" end
        local masks = hs.webview and hs.webview.windowMasks
        local bit   = type(masks) == "table" and masks.nonactivating or nil
        if type(bit) ~= "number" or bit < 1 then
            return false, "this Hammerspoon has no nonactivating window mask"
        end
        local function isSet(v) return (math.floor(v / bit) % 2) == 1 end
        local okGet, cur = pcall(function() return view:windowStyle() end)
        if not (okGet and type(cur) == "number") then
            return false, "the window style could not be read"
        end
        if not isSet(cur) then
            local okSet = pcall(function() view:windowStyle(cur + bit) end)
            if not okSet then return false, "the window style was rejected" end
        end
        local okRe, now = pcall(function() return view:windowStyle() end)
        if not (okRe and type(now) == "number") then
            return false, "the window style could not be read back"
        end
        if not isSet(now) then return false, "macOS dropped the mask" end
        return true, "applied"
    end

    function form.render()
        if not form.webview then return end
        pcall(function() form.webview:html(form.buildHtml()) end)
    end

    -- 📐 6.220.0 — THE GEOMETRY IS PURE, so the gate can prove it with no
    -- Mac: how wide, how tall, how many columns, for a given field list
    -- and a given screen. The three rules it carries:
    --   · project fields → TWO columns, so twelve rows are six.
    --   · the height NEVER passes form.maxHeight, and never comes within
    --     form.screenGap of the screen's own height. Before 6.220.0 the
    --     window grew with every field and clamped only at sf.h - 40 —
    --     taller than LL's screen with the Create button below its
    --     bottom edge. 6.223.0 raised the ceiling to 1400 and the gap to
    --     80: on his screen the whole form is drawn without scrolling,
    --     which is what he asked for twice.
    --   · the page scrolls inside that height; the footer holding the
    --     button is outside the scroller, so it is always on screen.
    function form.sizeFor(fields, sf)
        fields = fields or {}
        sf = sf or { x = 0, y = 0, w = 1440, h = 900 }
        local rows, wide, n = 0, 0, 0
        for _, f in ipairs(fields) do
            if f.subtype == "multi_enum" then
                -- chips wrap and span both columns
                wide = wide + 30
                     + math.ceil(math.max(1, #(f.options or {})) / 3) * 32
                n = n + 1
            elseif f.subtype == "enum" or f.subtype == "people"
                or f.subtype == "number" or f.subtype == "text" then
                rows = rows + 1
                n = n + 1
            end
        end
        local cols  = (n > 0) and 2 or 1
        local extra = 100 + math.ceil(rows / cols) * form.fieldH + wide
        local w = math.min(cols == 2 and form.wideWidth or form.width,
                           sf.w - 40)
        local h = math.min(form.height + extra, form.maxHeight,
                           sf.h - (tonumber(form.screenGap) or 80))
        return w, h, cols
    end

    function form.hide()
        if form.webview then
            pcall(function() form.webview:delete() end)
            form.webview = nil
        end
        form.uc = nil
        say("form closed")
    end

    function form.show()
        if form.webview then form.hide() return end
        if not (hs.webview and hs.webview.usercontent) then
            -- No WKWebView (old Hammerspoon, stripped build): fall back
            -- to the pipe chooser rather than costing task creation.
            if _G.asanaOpenTaskChooser then _G.asanaOpenTaskChooser() end
            return
        end

        local screen = core.resolveBaseScreen and core.resolveBaseScreen()
                       or (hs.screen and hs.screen.mainScreen and hs.screen.mainScreen())
        local sf = { x = 0, y = 0, w = 1440, h = 900 }
        pcall(function() if screen then sf = screen:frame() end end)
        local w, h, cols = form.sizeFor(_G.asanaCustomFields, sf)
        form.lastSize = { w = w, h = h, cols = cols,
                          fields = #(_G.asanaCustomFields or {}) }
        local rect = { x = sf.x + (sf.w - w) / 2, y = sf.y + (sf.h - h) / 3,
                       w = w, h = h }

        local okUc, uc = pcall(hs.webview.usercontent.new, "taskForm")
        if not (okUc and uc) then
            if _G.asanaOpenTaskChooser then _G.asanaOpenTaskChooser() end
            return
        end
        form.uc = uc    -- HELD: collect this and the JS bridge goes quiet
        pcall(function()
            uc:setCallback(function(msg)
                local ok, err = pcall(handleMessage, msg and msg.body)
                if not ok then warn("message handler — " .. tostring(err)) end
            end)
        end)

        local okV, view = pcall(hs.webview.new, rect, {}, uc)
        if not (okV and view) then
            form.uc = nil
            if _G.asanaOpenTaskChooser then _G.asanaOpenTaskChooser() end
            return
        end
        form.webview = view
        pcall(function() view:windowTitle("New Asana Task") end)
        -- allowTextEntry = canBecomeKeyWindow; without it the form draws
        -- and swallows every keystroke (Capture Pad, 6.44.x).
        pcall(function() view:allowTextEntry(true) end)
        pcall(function() view:closeOnEscape(true) end)
        pcall(function() view:level(hs.drawing.windowLevels.floating) end)
        pcall(function()
            view:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" })
        end)
        -- ⌨️ 6.153.0 — LL: "it doesn't seem active, I have to click on
        -- it." allowTextEntry makes this window ABLE to become key and
        -- bringToFront asks it to — but a plain panel from a background
        -- app only takes the keyboard once macOS activates the app, and
        -- a click is what does that. The non-activating panel mask (the
        -- Capture Pad's recipe, verified by read-back) lets the window
        -- take the keyboard the moment it opens, without dragging
        -- Hammerspoon's other windows forward either.
        form.nonActivatingApplied, form.nonActivatingWhy = false, "not requested"
        if form.nonActivating then
            form.nonActivatingApplied, form.nonActivatingWhy =
                form.applyNonActivating(view)
            if not form.nonActivatingApplied then
                print("✅ Task Form: non-activating panel unavailable — "
                      .. tostring(form.nonActivatingWhy)
                      .. "; the form may need a click before it takes typing.")
            end
        end
        form.render()
        pcall(function() view:show() end)
        if form.focusOnOpen then
            pcall(function() view:bringToFront(true) end)
        end
        say("form opened")
    end

    function form.toggle()
        if form.webview then form.hide() else form.show() end
    end

    -- ---- wiring ----------------------------------------------------------
    -- No hyperAddShortcut here, deliberately: ⇪T is a MIGRATED combo
    -- (⌃⌥⌘T routed through init.lua's hyperKeyMap) and its binding lives
    -- in §5, which calls _G.taskFormShow when it exists. Claiming ⇪T
    -- here as well would be the double-claim the hyper sentry warns about.
    if form.enabled then
        _G.taskFormShow = function() form.show() end
    end

    core.provide("taskform.show",   function() return form.show() end)
    core.provide("taskform.toggle", function() return form.toggle() end)

    -- 6.89.0 — listed for Window Move: ⌘-drag anywhere on the form moves
    -- it (bare clicks belong to its fields and buttons).
    _G.movablePanels = _G.movablePanels or {}
    table.insert(_G.movablePanels, {
        name  = "task form",
        frame = function() return form.webview and form.webview:frame() end,
        move  = function(x, y)
            local f = form.webview and form.webview:frame()
            if f then form.webview:frame({ x = x, y = y, w = f.w, h = f.h }) end
        end,
    })

    -- ⎋ 6.93.0 — in the escape router, so the cheat sheet closes AFTER the
    -- form; its own page already treats Escape as close when focused.
    if _G.claimEscape then
        _G.claimEscape("taskform", nil,
            function() return form.webview ~= nil end,
            function() form.hide() end)
    end

    -- 📋 6.220.0 — the one tool here with no report, and the geometry is
    -- exactly the thing that needed reading: how big the window came out
    -- and why.
    _G.taskFormReport = function()
        local L = { "✅ TASK FORM (⇪T) — " .. (form.enabled and "on" or "off") }
        local n = #(_G.asanaCustomFields or {})
        L[#L + 1] = "   project fields: " .. (n == 0
            and "none yet — they arrive from Asana shortly after boot"
            or (n .. " from the project · two columns"))
        local s = form.lastSize
        L[#L + 1] = "   window        : " .. (s and
            (math.floor(s.w) .. " × " .. math.floor(s.h) .. " pt · "
             .. s.cols .. " column(s) · never taller than "
             .. form.maxHeight .. " pt")
            or "not opened this session")
        L[#L + 1] = "   create button : pinned in a footer below the scroll"
        L[#L + 1] = "   draft         : " .. ((form.draft
            and form.draft.title ~= "" and ('"' .. form.draft.title .. '"'))
            or "empty")
        L[#L + 1] = "   open now      : "
                    .. (form.webview and "yes" or "no")
        print(table.concat(L, "\n"))
    end

    _G.taskForm = form
    M.form   = form
    M.config = form
end

return M
