-- Run from anywhere:  lua5.4 <this file> [path to ~/.hammerspoon]
local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

-- =====================================================================
-- THE PANEL DRAG ENGINE — one exit, and it always tells the caller
-- =====================================================================
-- 🚨 WHY THIS SUITE HAD TO EXIST, and what it found on its first run.
-- _G.makeCanvasDraggable has dragged four panels since 6.67.0 — the
-- cheat sheet, the key caster, the pomodoro and the Mac panel — and NO
-- suite had ever loaded it. That is how the following survived two
-- reports from LL, eleven releases apart, in the same words both times:
-- "Seems like a drag kills the sheet functionality" (6.138.0), and
-- "just because I can launch the cheat sheet doesn't mean it is
-- functional" (6.306.0).
--
-- The engine had FOUR exits and called onDrop from exactly ONE of them:
--
--   the tap's leftMouseUp .............. called onDrop  ✅
--   the canvas's own mouseUp ........... silent        ❌
--   the 20-second watchdog ............. silent        ❌
--   superseded by the next drag ........ silent        ❌
--
-- and onDrop is what moves the cheat sheet's WHEEL HIT BOX (6.138.0's
-- entire fix) and saves the panel's position. The panel has already been
-- moved by the time any exit runs, so a silent exit leaves a panel that
-- is physically somewhere new with every record of it still pointing at
-- the old spot: scrolling dead over the sheet, still swallowed over the
-- bare desk it used to cover, and the next open back in the wrong place.
--
-- 🖥 AND THE SILENT EXITS ARE REACHABLE. The tap returns false on
-- purpose — it observes, it never swallows — so macOS sees the drag too
-- and reads a three-finger one as a swipe between Spaces. A Space switch
-- is exactly the transition macOS switches event taps off across, so the
-- mouseUp never arrives and the watchdog takes it, silently. Both halves
-- of LL's report — "I am jumped to another desktop" and "it is not
-- functional" — are that one mechanism.
--
-- 🧊 6.222.0 SOLVED THIS ALREADY, FOR A PAGE: "a drag ends when the
-- button comes up, WHEREVER that happens — listen for the release, and
-- ALSO treat moving with nothing held as the release." It was written
-- for the screenshot editor's own JS and never asked of this engine.
-- 6.305.0's rule, one release later: a rule written about one caller is
-- not a rule until every caller has been asked.
-- =====================================================================

local PASS, FAIL = 0, 0
local function check(what, cond, got)
  if cond then PASS = PASS + 1
  else FAIL = FAIL + 1
    print("   ✗ " .. what .. (got and ("\n       got: " .. tostring(got)) or ""))
  end
end

-- ---------------------------------------------------------------------
-- The stubs. A stub answers what the real provider answers, refusals
-- included (6.193.0/6.290.0) — so the tap here can be made to REFUSE,
-- and checkMouseButtons can be made to lie in both directions.
-- ---------------------------------------------------------------------
local TAPS, TIMERS, PRINTED = {}, {}, {}
local MOUSE       = { x = 0, y = 0 }
local BUTTONS     = { left = true }
local TAP_REFUSES = false

local T = { leftMouseDragged = 6, leftMouseUp = 2, mouseMoved = 5 }

local function mkTimer(secs, fn)
  local t = { secs = secs, fn = fn, live = true }
  function t:stop() self.live = false; return self end
  table.insert(TIMERS, t); return t
end

-- A canvas that REMEMBERS where it was put, the way a real one does —
-- a getter-only topLeft would let every "it moved" check pass while
-- moving nothing (6.227.0/6.239.0/6.247.0: the getter-only stub has
-- hidden a whole feature four times in this project).
local function mkCanvas(x, y, w, h)
  local c = { f = { x = x, y = y, w = w, h = h }, mouseEvents = nil, cb = nil }
  function c:frame() return { x = self.f.x, y = self.f.y,
                              w = self.f.w, h = self.f.h } end
  function c:topLeft(p) self.f.x, self.f.y = p.x, p.y end
  function c:canvasMouseEvents(a, b, cc, d) self.mouseEvents = { a, b, cc, d } end
  function c:mouseCallback(fn) self.cb = fn end
  return c
end

-- 🎯 6.401.0 — APPS, MODELLED WITH BOTH REFUSALS. hs.application's
-- activate() answers a BOOLEAN and an app that has quit since the borrow
-- answers false or throws; a stub that always succeeded would make the
-- refusal branches unreachable (6.290.0 · 6.265.0 — MISSING is not
-- REFUSING). The watcher is captured so the suite can fire activations.
local HS_BUNDLE = "org.hammerspoon.Hammerspoon"
local FRONT, APP_WATCHERS, WATCHER_REFUSES = nil, {}, false
-- 🕒 A CLOCK THAT CAN MOVE. It was a constant, and the sweep showed
-- what that cost: every loan carried the same timestamp, so "the
-- oldest loan" was whichever pairs() reached first and flipping the
-- comparison picked a different arbitrary one. A fixture where the
-- right and wrong implementations AGREE proves nothing (6.230.0).
local CLOCK = 1000.5
local function mkApp(name, bundle, how)
  local a = { nm = name, bid = bundle or ("com.test." .. name), activated = 0 }
  function a:name() return self.nm end
  function a:bundleID() return self.bid end
  function a:activate()
    self.activated = self.activated + 1
    if how == "throw" then error("macOS refused to activate " .. self.nm, 0) end
    if how == "false" then return false end
    return true
  end
  return a
end
local function fireActivated(app)
  for _, w in ipairs(APP_WATCHERS) do
    if w.on and w.fn then w.fn(app and app:name(), 1, app) end
  end
end

hs = {
  processInfo = { bundleID = HS_BUNDLE },
  application = {
    frontmostApplication = function() return FRONT end,
    watcher = {
      activated = 1,
      new = function(fn)
        if WATCHER_REFUSES then error("no watcher on this Mac", 0) end
        local w = { fn = fn, on = false }
        function w:start() self.on = true; return self end
        function w:stop()  self.on = false; return self end
        table.insert(APP_WATCHERS, w); return w
      end,
    },
  },
  eventtap = {
    event = { types = T },
    checkMouseButtons = function() return BUTTONS end,
    new = function(types, fn)
      if TAP_REFUSES then error("macOS refused the tap", 0) end
      local tap = { types = types, fn = fn, on = false }
      function tap:start() self.on = true; return self end
      function tap:stop()  self.on = false; return self end
      table.insert(TAPS, tap); return tap
    end,
  },
  timer  = { doAfter = function(s, fn) return mkTimer(s, fn) end,
             doEvery = function(s, fn) return mkTimer(s, fn) end,
             -- a FLOAT, as macOS answers — an INTEGER here is a stub gentler
             -- than the provider, which cost 23 checks in 6.282.0
             secondsSinceEpoch = function() return CLOCK end },
  mouse  = { absolutePosition = function() return { x = MOUSE.x, y = MOUSE.y } end },
  canvas = { new = function(r) return mkCanvas(r.x, r.y, r.w, r.h) end },
  alert  = { show = function() end },
  screen = { allScreens = function() return {} end },
  settings = { get = function() end, set = function() end },
  hotkey = { bind = function() return { enable = function() end,
                                        disable = function() end } end },
  pasteboard = { getContents = function() return "" end,
                 setContents = function() return true end,
                 changeCount = function() return 1 end },
  fnutils = { each = function(t, f) for _, v in ipairs(t) do f(v) end end },
  inspect = tostring,
}

local realPrint = print
print = function(...)
  local parts = {}
  for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
  PRINTED[#PRINTED + 1] = table.concat(parts, "\t")
end

-- ---------------------------------------------------------------------
-- Load the engine the way init.lua does: core/coexist.lua returns a
-- function and init.lua calls it with a core table.
-- ---------------------------------------------------------------------
local chunk, loadErr = loadfile(HS .. "/core/coexist.lua")
print = realPrint
if not chunk then
  print("✗ cannot load core/coexist.lua: " .. tostring(loadErr))
  os.exit(1)
end
-- The restore is OUTSIDE the pcall: a throw in setup used to leave print
-- swallowed for the whole run, so the suite exited saying nothing at all
-- — a suite that cannot report its own failure to start (6.186.0).
local realPrint2 = print
print = function() end
local okRun, runErr = pcall(function() chunk()({}) end)
print = realPrint2
if not okRun then
  print("✗ core/coexist.lua threw on setup: " .. tostring(runErr))
  os.exit(1)
end

check("core/coexist.lua publishes the drag engine it was given in 6.306.0",
      type(_G.makeCanvasDraggable) == "function", type(_G.makeCanvasDraggable))
check("and its report, so the engine can be ASKED — it had none, which is "
      .. "why this took two reports and a source read to find",
      type(_G.dragReport) == "function", type(_G.dragReport))

-- ---------------------------------------------------------------------
-- A drag harness: arm a panel, press, move, and then end the drag by
-- whichever of the four exits the check is about.
-- ---------------------------------------------------------------------
local function arm()
  TAPS, TIMERS = {}, {}
  _G.dragTap, _G.dragGuard, _G.dragging = nil, nil, nil
  _G.dragDelivered, _G.dragNoFrame, _G.dragLastEnd = 0, 0, nil
  local drops = {}
  local cv = mkCanvas(100, 100, 400, 300)
  local ok = _G.makeCanvasDraggable(cv, "test panel",
                                    function(f) drops[#drops + 1] = f end)
  return cv, drops, ok
end

local function press(cv, x, y)
  MOUSE.x, MOUSE.y = x, y
  BUTTONS = { left = true }
  cv.cb(cv, "mouseDown")
end

local function moveTo(x, y)
  MOUSE.x, MOUSE.y = x, y
  local tap = TAPS[#TAPS]
  if tap then tap.fn({ getType = function() return T.leftMouseDragged end }) end
end

local function fire(type_)
  local tap = TAPS[#TAPS]
  if tap then tap.fn({ getType = function() return type_ end }) end
end

-- =====================================================================
-- §1 — the exit that always worked, so the rest has something to match
-- =====================================================================
print("§1 the mouseUp the tap sees")
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(250, 220)
  check("the panel follows the pointer",
        cv.f.x == 200 and cv.f.y == 170, cv.f.x .. "," .. cv.f.y)
  fire(T.leftMouseUp)
  check("onDrop is delivered once", #drops == 1, #drops)
  check("and it carries WHERE THE PANEL ENDED, not where it started",
        drops[1] and drops[1].x == 200 and drops[1].y == 170,
        drops[1] and (drops[1].x .. "," .. drops[1].y))
  check("the tap is stopped", _G.dragTap == nil)
  check("the watchdog is stopped",
        TIMERS[1] and TIMERS[1].live == false)
end

-- =====================================================================
-- §2 — THE THREE SILENT EXITS. Each of these delivered NOTHING before
--      6.306.0, and each leaves a panel that has already moved.
-- =====================================================================
print("§2 the exits that used to say nothing")
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(300, 300)
  -- The pointer is still over the panel when the button comes up, so the
  -- canvas's OWN mouseUp fires. It used to tear the drag down silently.
  cv.cb(cv, "mouseUp")
  check("🚨 a mouseUp ON THE PANEL delivers onDrop — it used to be silent, "
        .. "and this is the commonest ending of all: a careful drag that "
        .. "finishes with the pointer still on the thing being dragged",
        #drops == 1, #drops)
  check("with the moved frame",
        drops[1] and drops[1].x == 250 and drops[1].y == 250,
        drops[1] and (drops[1].x .. "," .. drops[1].y))
end
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(400, 500)
  -- macOS switched Spaces mid-drag; the mouseUp went somewhere else and
  -- the 20-second watchdog is the only thing left to end this.
  local guard = TIMERS[1]
  check("the watchdog was armed BEFORE the tap (6.246.0's ordering)",
        guard ~= nil and guard.secs == _G.dragMaxSecs,
        guard and guard.secs)
  guard.fn()
  check("🚨 the WATCHDOG delivers onDrop — this is the desktop-jump case, "
        .. "where the mouseUp never arrives at all",
        #drops == 1, #drops)
  check("with the moved frame, read at the exit rather than at the press",
        drops[1] and drops[1].x == 350 and drops[1].y == 450,
        drops[1] and (drops[1].x .. "," .. drops[1].y))
end
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(200, 200)
  -- A second press without a release: the engine supersedes the old drag.
  press(cv, 200, 200)
  check("🚨 being SUPERSEDED by the next drag delivers the old one's onDrop",
        #drops == 1, #drops)
end

-- =====================================================================
-- §3 — 6.222.0's RULE, FINALLY ASKED OF THIS ENGINE
-- =====================================================================
print("§3 moving with nothing held IS the release")
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(260, 260)
  -- macOS sends leftMouseDragged while the button is held and mouseMoved
  -- when it is not, so a mouseMoved arriving mid-drag IS the release.
  BUTTONS = {}
  fire(T.mouseMoved)
  check("🚨 a mouseMoved with no button held ends the drag and delivers — "
        .. "the rule 6.222.0 wrote for the editor's page, now asked of the "
        .. "engine that drags four panels",
        #drops == 1, #drops)
  check("and it stops the tap rather than leaving a global mouse tap "
        .. "running for the rest of the watchdog's 20 seconds",
        _G.dragTap == nil)
end
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(260, 260)
  -- checkMouseButtons is a VETO ONLY: believed when it says "still down",
  -- never when it says "released". window_move 6.156.0 paid for trusting
  -- it the other way, where a consumed press reads as released on the
  -- first tick and kills a drag before it moves anything.
  BUTTONS = { left = true }
  fire(T.mouseMoved)
  check("a mouseMoved while the button really IS down does NOT end the drag",
        #drops == 0, #drops)
  check("and the drag is still live", _G.dragging ~= nil)
  fire(T.leftMouseUp)
  check("so the real release still ends it", #drops == 1, #drops)
end
do
  -- A Mac whose checkMouseButtons throws must not strand a drag: a reader
  -- that cannot answer is treated as "the button is not down", which ends
  -- the drag and delivers — the safe direction (the other one is the bug
  -- being fixed).
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(260, 260)
  local realCheck = hs.eventtap.checkMouseButtons
  hs.eventtap.checkMouseButtons = function() error("no Accessibility", 0) end
  fire(T.mouseMoved)
  hs.eventtap.checkMouseButtons = realCheck
  check("a checkMouseButtons that THROWS ends the drag rather than "
        .. "stranding it (it degrades, it never breaks)", #drops == 1, #drops)
end

-- =====================================================================
-- §4 — EXACTLY ONCE. Two exits can race; the caller is told one time.
-- =====================================================================
print("§4 one door, once")
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(300, 300)
  local guard = TIMERS[1]
  fire(T.leftMouseUp)          -- the tap wins the race
  cv.cb(cv, "mouseUp")         -- the canvas's callback arrives too
  pcall(function() guard.fn() end)  -- and a watchdog that was not stopped
  check("🚨 onDrop is delivered EXACTLY ONCE across three overlapping "
        .. "exits — a second delivery would write a stale frame over a "
        .. "good one (6.299.0)", #drops == 1, #drops)
  check("the engine counts what it delivered", _G.dragDelivered == 1,
        _G.dragDelivered)
end

-- =====================================================================
-- §5 — the degrades, which must not be silent
-- =====================================================================
print("§5 refusals are counted, never swallowed")
do
  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(300, 300)
  -- A canvas that cannot answer its own frame: the panel moved and there
  -- is nothing to record. "Never told" and "told wrongly" are different
  -- faults (6.196.1), so this is counted apart rather than passed off.
  cv.frame = function() error("canvas is gone", 0) end
  fire(T.leftMouseUp)
  check("a canvas that cannot answer its frame delivers NOTHING rather "
        .. "than a wrong position", #drops == 0, #drops)
  check("and it is COUNTED, so the report can say so",
        _G.dragNoFrame == 1, _G.dragNoFrame)
  check("the drag is still torn down — a dead canvas must not leave a "
        .. "global mouse tap running", _G.dragTap == nil)
end
do
  TAP_REFUSES = true
  local cv, drops, ok = arm()
  press(cv, 150, 150)
  TAP_REFUSES = false
  check("a Mac that REFUSES the drag tap tears the attempt down rather "
        .. "than leaving a watchdog armed over nothing (6.265.0 — MISSING "
        .. "is not REFUSING)", _G.dragging == nil)
  check("and the watchdog it armed first is stopped",
        TIMERS[1] and TIMERS[1].live == false)
end
do
  check("a nil canvas is refused, not thrown at",
        _G.makeCanvasDraggable(nil, "nothing", function() end) == false)
end

-- =====================================================================
-- §6 — the report, measured against the HEALTHY case first (6.269.0)
-- =====================================================================
print("§6 the report")
do
  _G.dragTap, _G.dragGuard, _G.dragging = nil, nil, nil
  _G.dragDelivered, _G.dragNoFrame, _G.dragLastEnd = 0, 0, nil
  PRINTED = {}
  local p = print; print = function(s) PRINTED[#PRINTED + 1] = tostring(s) end
  _G.dragReport()
  print = p
  local txt = table.concat(PRINTED, "\n")
  check("a fresh session says nothing has been dragged, and carries no ⚠️",
        txt:find("no panel has been dragged", 1, true)
        and not txt:find("⚠️", 1, true), txt)

  local cv, drops = arm()
  press(cv, 150, 150)
  moveTo(300, 300)
  fire(T.leftMouseUp)
  PRINTED = {}
  p = print; print = function(s) PRINTED[#PRINTED + 1] = tostring(s) end
  _G.dragReport()
  print = p
  txt = table.concat(PRINTED, "\n")
  check("after a drag it names the panel and how the drag ENDED — which "
        .. "is the whole question this release turned on",
        txt:find("test panel", 1, true) and txt:find("mouseUp", 1, true), txt)
  check("and it does NOT warn on a healthy drag (6.269.0 — a new "
        .. "instrument's first duty is to be silent when nothing is wrong)",
        not txt:find("⚠️", 1, true), txt)
end

-- =====================================================================
-- §7 — source sentries: the class, not the instance
-- =====================================================================
print("§7 sentries")
do
  local f = io.open(HS .. "/core/coexist.lua")
  local src = f and f:read("*a") or ""
  if f then f:close() end
  -- Comments are stripped, because the ones here deliberately quote the
  -- very shape they forbid (6.262.0).
  local code = src:gsub("\n%s*%-%-[^\n]*", "\n")

  check("onDrop is called from ONE place — the moment a second call site "
        .. "appears, an exit can be added that forgets",
        select(2, code:gsub("pcall%(d%.onDrop", "")) == 1,
        select(2, code:gsub("pcall%(d%.onDrop", "")))
  check("and that place is inside dragStop, so every exit reaches it "
        .. "without the exit having to know the caller",
        code:find("function dragStop", 1, true)
        and code:find("pcall%(d%.onDrop") > code:find("function dragStop", 1, true))
  check("exactly-once is STRUCTURAL: the drag is captured and the global "
        .. "nil'd before onDrop runs, so a later exit reads nil and returns "
        .. "— no flag to go stale (6.199.0 removed the one written here)",
        code:find("local d = _G.dragging", 1, true) ~= nil
        and not code:find("d.delivered = true", 1, true))
  check("the tap still OBSERVES and never swallows: the button is the "
        .. "person's, and swallowing it would cost every app below",
        code:find("return false", 1, true) ~= nil)

  local ini = io.open(HS .. "/init.lua")
  local isrc = ini and ini:read("*a") or ""
  if ini then ini:close() end
  local icode = isrc:gsub("\n%s*%-%-[^\n]*", "\n")
  check("init.lua no longer defines the engine — it moved here in 6.306.0 "
        .. "and two copies is how one stops matching the other (6.231.0)",
        not icode:find("function _G.makeCanvasDraggable", 1, true))
end

-- =====================================================================
-- 📋 6.325.0 — THE CLIPBOARD DOOR LIVES HERE TOO
-- =====================================================================
-- This file answers "two features want the same resource, who gets
-- it?", and the PASTEBOARD is one of them — the borrow guard and the
-- suppress window are about the same object. 6.325.0 put the one
-- clipboard WRITE here for that reason, and because init.lua is at its
-- 3,800-line ceiling.
--
-- 🔎 THE RULE IT EXISTS FOR: hs.pasteboard.setContents REFUSES BY
-- RETURNING FALSE and never throws, so
-- `pcall(function() setContents(x) end)` is true either way. Three
-- callers announced "📋 Copied" under exactly that shape.
--
-- 🚨 AND THE SWEEP IS WHY THIS SECTION EXISTS: the mutation that makes
-- the door stop READING the return — `pcall(function()
-- setContents(t) ; wrote = true end)` — survived everything, because
-- every other suite drives a STUB of the door rather than the door
-- (6.273.0: the line is not the finding, the missing check is).
do
  local SAID = {}
  local REFUSE, GOT = false, nil
  hs.pasteboard = { setContents = function(t)
      if REFUSE then return false end
      GOT = t ; return true
  end }
  hs.alert = hs.alert or {}
  local keptAlert = hs.alert.show
  hs.alert.show = function(m) SAID[#SAID + 1] = tostring(m) end
  local keptDeg = _G.degrade
  local DEGRADED = {}
  _G.degrade = function(tool, why) DEGRADED[#DEGRADED + 1] = { tool, why } return false, why end

  check("📋 the door is published", type(_G.clipWrite) == "function")

  GOT = nil
  local ok1 = _G.clipWrite("hello", "a test")
  check("📋 a write macOS takes answers TRUE and really lands",
        ok1 == true and GOT == "hello", tostring(ok1) .. " / " .. tostring(GOT))

  -- 🚨 THE ONE THE SWEEP FOUND UNDRIVEN
  REFUSE, GOT = true, nil
  local ok2, why2 = _G.clipWrite("nope", "a test")
  REFUSE = false
  check("🚨 a write macOS REFUSES answers FALSE — setContents returns a "
        .. "boolean and never throws, so a pcall alone calls it success",
        ok2 == false and why2 ~= nil, tostring(ok2) .. " / " .. tostring(why2))
  check("🔔 …and it takes the degrade door, so the ledger and "
        .. "_G.todayReport() can see it",
        #DEGRADED >= 1 and tostring(DEGRADED[#DEGRADED][2]):find("refused", 1, true) ~= nil,
        DEGRADED[#DEGRADED] and DEGRADED[#DEGRADED][2] or "none")
  check("🔎 …and it is COUNTED, because \"intermittent\" is a count and "
        .. "not a sample (6.229.0)",
        _G.clipWrites.refused >= 1, _G.clipWrites.refused)

  local ok3, why3 = _G.clipWrite("", "a test")
  check("📏 nothing to copy is its OWN answer, not a refusal by macOS",
        ok3 == false and why3 ~= why2 and _G.clipWrites.empty >= 1,
        tostring(why3))
  local ok4 = _G.clipWrite(nil, "a test")
  check("🛟 a nil is refused rather than thrown at", ok4 == false)

  -- 🔎 three states in the report, and the ⚠️ is not forgotten
  local rep = _G.clipboardWriteReport()
  check("🔎 the report names the refusals rather than only the successes",
        rep:find("REFUSED", 1, true) ~= nil and rep:find("last   :", 1, true) ~= nil,
        rep:match("[^\n]*REFUSED[^\n]*") or rep)

  hs.alert.show = keptAlert
  _G.degrade = keptDeg
end

-- =====================================================================
-- 📋 6.421.0 — A KEYBOARD-KILLING EVENT HANDS ITS REPORT OVER
-- =====================================================================
-- LL: "Does the console automatically generate a report for any
-- condition that kills my keyboard and is automatically pasted to the
-- clipboard?" It did not — grepped, and the four files that handle a
-- latched ⇪, a stalled main thread and Secure Input carry ZERO
-- pasteboard writes between them, while the alert names a file path
-- that cannot be copied out of an hs.alert.
--
-- 🔑 THE RULE NEEDS NO CLOCK: a NEW event, or the SAME event's report
-- having GROWN. The second clause is what carries 6.403.0's probe
-- answers, appended a beat after the fire.
do
  local REFUSE, GOT = false, nil
  hs.pasteboard = { setContents = function(t)
      if REFUSE then return false end
      GOT = t ; return true
  end }
  local keptDeg = _G.degrade
  _G.degrade = function(tool, why) return false, why end
  _G.clipHandOffs = { asked = 0, copied = 0, skipped = 0, refused = 0,
                      last = nil, seen = {} }

  check("📋 the planner and the door are both published",
        type(_G.clipHandOffPlan) == "function" and type(_G.clipHandOff) == "function")

  -- ---- the PURE rule: four answers, and the REASONS are what differ ----
  -- 🚨 Two of the four share an ACTION, so a check that asserted only
  -- the action would pass with either branch deleted (6.389.0).
  local a1, w1 = _G.clipHandOffPlan({ event = "storm-100", chars = 40 })
  check("📋 a first report is a NEW event and is handed over",
        a1 == "copy" and w1 == "a new event", tostring(a1) .. " / " .. tostring(w1))

  local a2, w2 = _G.clipHandOffPlan({ event = "storm-100", chars = 40,
                                      lastEvent = "storm-100", lastChars = 40 })
  check("📏 the SAME event at the SAME size is already on the clipboard "
        .. "and is NOT taken again",
        a2 == "skip" and w2:find("already on the clipboard", 1, true) ~= nil,
        tostring(a2) .. " / " .. tostring(w2))

  local a3, w3 = _G.clipHandOffPlan({ event = "storm-100", chars = 90,
                                      lastEvent = "storm-100", lastChars = 40 })
  check("🔑 the SAME event whose report has GROWN is handed over again — "
        .. "this is the clause 6.403.0's probe answers arrive through, and "
        .. "its reason must differ from a new event's or the check above "
        .. "passes with the branch deleted",
        a3 == "copy" and w3:find("has grown", 1, true) ~= nil
        and w3 ~= w1, tostring(a3) .. " / " .. tostring(w3))

  local a4, w4 = _G.clipHandOffPlan({ event = "storm-200", chars = 10,
                                      lastEvent = "storm-100", lastChars = 400 })
  check("🪪 a NEW event SHRINKING is still handed over — the rule is about "
        .. "the event, and a second storm's report is shorter than a first "
        .. "one that has been appended to",
        a4 == "copy" and w4 == "a new event", tostring(a4) .. " / " .. tostring(w4))

  local a5, w5 = _G.clipHandOffPlan({ event = "storm-100", chars = 0 })
  check("📏 nothing to hand over is its OWN answer", a5 == "skip"
        and w5:find("nothing to hand over", 1, true) ~= nil, tostring(w5))

  -- 🚨 FAILS CLOSED. A caller that names no event cannot be told from
  -- the last one, so the alternative to skipping is taking his clipboard
  -- on every poll — and the reason is NAMED rather than silently dropped.
  local a6, w6 = _G.clipHandOffPlan({ chars = 40 })
  check("🚨 a caller that names NO event fails CLOSED and says why, "
        .. "rather than helping itself to the clipboard every poll",
        a6 == "skip" and w6:find("named no event", 1, true) ~= nil
        and w6 ~= w5, tostring(a6) .. " / " .. tostring(w6))
  local a7 = _G.clipHandOffPlan()
  check("🛟 the planner survives being asked nothing at all", a7 == "skip")

  -- ---- the door ----------------------------------------------------------
  GOT = nil
  local ok1, say1 = _G.clipHandOff("⇪ storm guard", "storm-1", "the whole report")
  check("📋 a hand-off really lands on the clipboard",
        ok1 == true and GOT == "the whole report", tostring(ok1) .. " / " .. tostring(GOT))
  check("🗳 …and the sentence SAYS the clipboard was taken and names the way "
        .. "back, because an unannounced correct default is indistinguishable "
        .. "from a tool helping itself (6.398.0)",
        type(say1) == "string" and say1:find("⌘V", 1, true) ~= nil
        and say1:find("⇪V", 1, true) ~= nil, tostring(say1))

  GOT = nil
  local ok2, say2 = _G.clipHandOff("⇪ storm guard", "storm-1", "the whole report")
  check("📏 the same event at the same size is refused, and nothing is "
        .. "written to the pasteboard at all",
        ok2 == false and GOT == nil and _G.clipHandOffs.skipped == 1,
        tostring(ok2) .. " / " .. tostring(GOT))
  check("📏 …and a skip says NOTHING to the caller, because \"already "
        .. "copied\" inside a storm alert is noise", say2 == nil, tostring(say2))

  GOT = nil
  local ok3 = _G.clipHandOff("⇪ storm guard", "storm-1",
                             "the whole report ── why (measured at the storm) ──")
  check("🔑 the probe's appended answers DO reach the clipboard — the same "
        .. "event, grown",
        ok3 == true and GOT:find("why (measured", 1, true) ~= nil,
        tostring(ok3) .. " / " .. tostring(GOT))

  -- 🚨 A REFUSED CLIPBOARD IS NOT A SILENT ONE, and the sentence must not
  -- claim the report is where it is not.
  REFUSE, GOT = true, nil
  local ok4, say4 = _G.clipHandOff("Secure Input", "secure-1", "the lock report")
  REFUSE = false
  check("🚨 a clipboard macOS refuses answers FALSE and is COUNTED",
        ok4 == false and _G.clipHandOffs.refused == 1, tostring(ok4))
  check("🚨 …and the sentence does NOT say it is on the clipboard — a "
        .. "message that is false at the moment it is acted on is the worst "
        .. "shape a message can have (6.198.0)",
        type(say4) == "string" and say4:find("would not take", 1, true) ~= nil
        and say4:find("⌘V", 1, true) == nil, tostring(say4))

  -- 🔎 the report: three states, and the healthy one says what it MEASURED
  local rep = _G.clipboardWriteReport()
  check("🔎 the hand-off rides in the clipboard report rather than getting "
        .. "one of its own (6.413.0)",
        rep:find("hand%-off:") ~= nil and rep:find("handed over", 1, true) ~= nil, rep)
  _G.clipHandOffs = { asked = 0, copied = 0, skipped = 0, refused = 0,
                      last = nil, seen = {} }
  local rep2 = _G.clipboardWriteReport()
  check("🔎 …and with nothing asked it says NOTHING HAS ASKED rather than "
        .. "that all is well — a caller whose nil-guard never resolves "
        .. "reads the same from here (6.308.0)",
        rep2:find("nothing has asked", 1, true) ~= nil, rep2)

  _G.degrade = keptDeg
end

-- =====================================================================
-- 🎯 6.401.0 — THE FOCUS, GIVEN BACK
-- =====================================================================
-- LL, on the 6.397.0 document edit window: "window does not return
-- cursour/ mouse to the active field it was already in like this text
-- box. I just use my trackpad to get back here. That doesn't right as
-- the cheat sheet doesn't do this." The cheat sheet does not do it
-- because it never takes focus; a window that must be TYPED INTO has no
-- such option (6.225.0 · 6.251.0). Those releases paid the price and
-- named it. Neither built the other half.
do
  check("🎯 coexist publishes the focus door",
        type(_G.focusBorrow) == "function" and type(_G.focusReturn) == "function"
        and type(_G.focusDoorReport) == "function")
  check("🎯 ...and started the application watcher AT LOAD, so the FIRST "
        .. "edit of a session has an app to go back to",
        #APP_WATCHERS == 1 and APP_WATCHERS[1].on == true,
        #APP_WATCHERS .. " watcher(s)")

  local function reset()
    _G.focusLoans = {}
    _G.focusState = { asked = 0, returned = 0, refused = 0, moved = 0,
                      wasUs = 0, dropped = 0, kept = 0, last = nil }
    _G.focusLast = nil
  end

  local chrome = mkApp("Google Chrome")
  local me     = mkApp("Hammerspoon", HS_BUNDLE)

  -- 🚨 THE FIXTURE THAT BITES, and it is the whole mechanism. ⇪⇧V, ⇪⇧O
  -- and ⇪⇧W all open a CHOOSER first and the edit window after it, so by
  -- the time the window opens the front app is already Hammerspoon.
  -- "Remember whatever was in front" records US on exactly the paths he
  -- uses. Only a watcher that IGNORES our own activations gets Chrome.
  reset()
  fireActivated(chrome)
  fireActivated(me)          -- the chooser comes up: this must be ignored
  local okB, whyB = _G.focusBorrow("Edit window")
  check("🚨 a borrow made from behind our OWN picker still names HIS app — "
        .. "the watcher ignores Hammerspoon's activations, which is what "
        .. "makes ⇪⇧V, ⇪⇧O and ⇪⇧W work rather than only a bare editor",
        okB == true and _G.focusLoans["Edit window"]
        and _G.focusLoans["Edit window"].name == "Google Chrome",
        tostring(whyB) .. " · "
        .. tostring(_G.focusLoans["Edit window"] and _G.focusLoans["Edit window"].name))

  -- the return, with us still in front
  FRONT = me
  chrome.activated = 0
  local okR, whyR = _G.focusReturn("Edit window")
  check("🎯 the return activates the app he came from, and says so",
        okR == true and chrome.activated == 1 and whyR == nil,
        tostring(okR) .. " · activated " .. chrome.activated)
  check("🎯 ...and the loan is spent, so a second return moves nothing",
        _G.focusLoans["Edit window"] == nil
        and select(1, _G.focusReturn("Edit window")) == false
        and chrome.activated == 1, chrome.activated)

  -- 🚨 THE GUARD: he moved on himself, so the focus is not ours to move.
  reset()
  fireActivated(chrome)
  _G.focusBorrow("Edit window")
  FRONT = mkApp("Microsoft Word")     -- he clicked into Word meanwhile
  chrome.activated = 0
  local okG, whyG = _G.focusReturn("Edit window")
  check("🚨 if he has already moved on, the focus is LEFT where he put it "
        .. "— activating the remembered app then would yank it out of "
        .. "whatever he moved to (6.266.0)",
        okG == false and chrome.activated == 0
        and tostring(whyG):find("moved on", 1, true) ~= nil, tostring(whyG))
  check("🎯 ...and that is counted as MOVED ON, never as a refusal — they "
        .. "are different facts and only one is a fault",
        _G.focusState.moved == 1 and _G.focusState.refused == 0,
        _G.focusState.moved .. " moved · " .. _G.focusState.refused .. " refused")

  -- an app that REFUSES to come back (it quit since the borrow)
  reset()
  local gone = mkApp("Transmission", nil, "false")
  fireActivated(gone)
  _G.focusBorrow("Edit window")
  FRONT = me
  local okF, whyF = _G.focusReturn("Edit window")
  check("🔑 an app that answers FALSE is a refusal, named — the return "
        .. "reads activate()'s answer rather than assuming it (6.325.0)",
        okF == false and _G.focusState.refused == 1
        and tostring(whyF):find("Transmission", 1, true) ~= nil, tostring(whyF))

  -- ...and one that THROWS. MISSING is not REFUSING (6.265.0).
  reset()
  local dead = mkApp("Preview", nil, "throw")
  fireActivated(dead)
  _G.focusBorrow("Edit window")
  FRONT = me
  local okT = _G.focusReturn("Edit window")
  check("🔑 an app whose activate THROWS is a refusal too, not a crash",
        okT == false and _G.focusState.refused == 1, tostring(okT))

  -- nothing but us has ever been in front
  reset()
  fireActivated(me)
  local okU, whyU = _G.focusBorrow("Edit window")
  check("🔎 with nothing but Hammerspoon ever in front, the borrow SAYS "
        .. "there is nothing to give back rather than storing us",
        okU == true and _G.focusLoans["Edit window"] == nil
        and _G.focusState.wasUs == 1
        and tostring(whyU):find("nothing to give back", 1, true) ~= nil,
        tostring(whyU))

  -- 🔑 a second borrow KEEPS the first loan (replacing an open editor)
  reset()
  fireActivated(chrome)
  _G.focusBorrow("Edit window")
  fireActivated(me)                     -- our own window is front now
  local okK, whyK = _G.focusBorrow("Edit window")
  check("🔑 a SECOND borrow keeps the FIRST loan — replacing an open box "
        .. "must not re-record us as the app to go back to",
        okK == true and _G.focusLoans["Edit window"].name == "Google Chrome"
        and _G.focusState.kept == 1
        and tostring(whyK):find("already borrowed", 1, true) ~= nil,
        tostring(whyK))

  -- 🚪 SEPARATE SLOTS: one panel returning never releases another's claim
  reset()
  fireActivated(chrome)
  _G.focusBorrow("Edit window")
  local word = mkApp("Microsoft Word")
  fireActivated(word)
  _G.focusBorrow("⇪D")
  FRONT = me
  _G.focusReturn("Edit window")
  check("🚪 two panels hold SEPARATE slots — returning one leaves the "
        .. "other's loan standing (6.196.1 · 6.304.0)",
        _G.focusLoans["Edit window"] == nil
        and _G.focusLoans["⇪D"] ~= nil
        and _G.focusLoans["⇪D"].name == "Microsoft Word",
        tostring(_G.focusLoans["⇪D"] and _G.focusLoans["⇪D"].name))

  -- the bound, and the bound is a STATE (6.197.2)
  reset()
  _G.focusLoanMax = 3
  for i = 1, 5 do
    CLOCK = 1000.5 + i          -- each borrow is strictly newer than the last
    fireActivated(mkApp("App" .. i))
    _G.focusBorrow("panel" .. i)
  end
  CLOCK = 1000.5
  local held = 0
  for _ in pairs(_G.focusLoans) do held = held + 1 end
  check("📏 the loan register is BOUNDED and says how many it dropped — a "
        .. "register that grows for ever is a leak, and one that drops "
        .. "silently is a panel that cannot give the focus back",
        held <= 3 and _G.focusState.dropped == 2,
        held .. " held · " .. _G.focusState.dropped .. " dropped")
  check("📏 ...and the NEWEST loan survives the bound while the OLDEST is "
        .. "the one dropped — the newest is the one a close is about to ask "
        .. "for, and it is the borrow's own clock that orders them",
        _G.focusLoans["panel5"] ~= nil and _G.focusLoans["panel1"] == nil
        and _G.focusLoans["panel2"] == nil,
        tostring(_G.focusLoans["panel5"] ~= nil) .. " / "
        .. tostring(_G.focusLoans["panel1"] == nil))
  _G.focusLoanMax = 12

  -- the report: three states, and it names the watcher
  reset()
  fireActivated(chrome)
  _G.focusBorrow("Edit window")
  local rep = _G.focusDoorReport(true)
  check("🔎 the report names what is still holding the focus",
        rep:find("Edit window", 1, true) ~= nil
        and rep:find("holding", 1, true) ~= nil, rep)
  check("🔎 ...and says whether the watcher is running at all — without it "
        .. "a panel reached through a picker cannot give the focus back, "
        .. "and that is the one state no count would reveal",
        rep:find("watching", 1, true) ~= nil
        and rep:find("Google Chrome", 1, true) ~= nil, rep)
  FRONT = me
  _G.focusReturn("Edit window")
  local rep2 = _G.focusDoorReport(true)
  check("🔎 ...and reads as healthy when nothing owes the focus back",
        rep2:find("nothing — no panel owes", 1, true) ~= nil
        and rep2:find("refused : none", 1, true) ~= nil, rep2)
  reset()
end

-- =====================================================================
-- ⎋ 6.432.0 — A CLAIMANT THAT RAN AND DID NOT STAND DOWN
-- =====================================================================
-- LL's own `_G.escapeReport()`, pasted from the Console with no panel on
-- screen: `unified 55 🟢 wants esc now`. `closeOnEscape(true)` had let
-- WebKit close that window behind Lua's back, so the handle stayed
-- assigned and the claim stayed live for the whole session — which
-- starved the window switcher, both players, the calendar and the cheat
-- sheet of Esc, every one of them sitting below 55.
--
-- 🚨 AND FROM 6.432.0 A BARE ESCAPE IS ROUTED IN EVERY APP, so the cost
-- of a stuck claim is no longer one panel: it is the key. This is the
-- belt that makes that release safe, and it is a fact about BEHAVIOUR
-- (a handler ran and closed nothing) rather than a platform answer —
-- which is what makes it safe where asking `hswindow()` would not be
-- (6.395.0; the note in unified_search.lua says why that belt was
-- written and taken out again).
do
  local function freshClaims()
    _G.escapeClaims = {}
    _G.escapeStuck, _G.escapeStuckSkips, _G.escapeStuckLast = nil, 0, nil
  end

  -- A panel that really closes itself: ordinary, and must never be skipped.
  freshClaims()
  local open, handled = true, 0
  _G.claimEscape("good", 50, function() return open end,
                 function() handled = handled + 1; open = false end)
  check("⎋ a claimant that closes itself takes the Esc",
        _G.routeEscape() == "good" and handled == 1)
  check("…and is NOT remembered as stuck, because it stood down",
        _G.escapeStuck == nil)
  open = true
  check("…so the very next press reaches it again",
        _G.routeEscape() == "good" and handled == 2)

  -- The one his report caught: a handler that closes nothing.
  freshClaims()
  local ran = 0
  _G.claimEscape("stuck", 55, function() return true end,
                 function() ran = ran + 1 end)
  check("🚨 a handler that closes NOTHING still takes the first Esc — it is "
        .. "allowed one turn to take its window down",
        _G.routeEscape() == "stuck" and ran == 1)
  check("…and is remembered by name, which is the fact a 🟢 row cannot "
        .. "carry: 'a panel is open' and 'a handler closed nothing' print "
        .. "the same green dot", _G.escapeStuck == "stuck")
  check("🚨 …so the NEXT press is not eaten by it — one stuck claim cannot "
        .. "take Escape everywhere for the rest of the session",
        _G.routeEscape() == nil and ran == 1, ran)
  check("…and the skip is counted and named, so the report can say which",
        (_G.escapeStuckSkips or 0) == 1 and _G.escapeStuckLast == "stuck",
        tostring(_G.escapeStuckLast))
  check("📏 …and it is ONE press, not a ban: the claimant is reached again "
        .. "after that, because the belt costs at most a single Escape",
        _G.routeEscape() == "stuck" and ran == 2, ran)

  -- The case that matters most: a stuck claim must not hide a LOWER one.
  freshClaims()
  local lowRan = 0
  _G.claimEscape("stuck", 55, function() return true end, function() end)
  _G.claimEscape("low",   30, function() return true end,
                 function() lowRan = lowRan + 1 end)
  _G.routeEscape()                     -- the stuck one takes the first press
  check("🚨 …and on the next press the panel UNDERNEATH it gets its Esc — "
        .. "which is what LL's switcher, players, calendar and cheat sheet "
        .. "were all being starved of",
        _G.routeEscape() == "low" and lowRan == 1, lowRan)
  -- 🚨 AND THE THIRD PRESS IS WHERE THE SKIP HAS TO END. The sweep found
  -- this: with ONE claimant, clearing the mark inside the skip branch is
  -- unkillable, because the no-claimant exit clears it too. With TWO, a
  -- lower panel becomes `best`, that exit never runs, and a skip that
  -- does not clear itself is a claimant banned for the session — a belt
  -- that costs the very thing it was built to protect. Two presses agree
  -- either way; three is the fixture where they must differ (6.230.0),
  -- and the line was not the finding, the missing check was (6.273.0).
  check("🚨 …and the press AFTER that reaches the skipped claimant again, "
        .. "so the belt is one press and never a ban",
        _G.routeEscape() == "stuck" and lowRan == 1, lowRan)

  -- The report has to be able to SAY all of this, or it is a fix with no
  -- instrument and the next one of these is invisible again.
  freshClaims()
  _G.claimEscape("stuck", 55, function() return true end, function() end)
  _G.routeEscape()
  local rep = ""
  do
    local realPrint = print
    print = function(s) rep = rep .. tostring(s) end   -- luacheck: ignore
    pcall(_G.escapeReport)
    print = realPrint                                  -- luacheck: ignore
  end
  check("🔎 the report NAMES the stuck claimant",
        rep:find("stuck", 1, true) ~= nil
        and rep:find("STILL wants one", 1, true) ~= nil, rep)
  check("🔎 …and says where a bare Escape is heard from at all, which is "
        .. "the line that would have named this in one press",
        rep:find("global", 1, true) ~= nil, rep)
  freshClaims()
end

print(("\n%s  %d passed, %d failed"):format(FAIL == 0 and "✅" or "❌", PASS, FAIL))
os.exit(FAIL == 0 and 0 or 1)
