-- =====================================================================
-- 📝 SCORP PAD — ⇪1: TABS, SAVED AS YOU TYPE, A HISTORY YOU CAN SEARCH
-- =====================================================================
-- 6.164.0 — LL: "I use the Sublime text editor to hold snippets of text
-- or code or anything you can think of as a scratch space. But it's
-- overkill. What I need is a very simple text editor that I can quickly
-- bring up using the shortcut key, type into it, have it automatically
-- saved so I don't lose any of that data, write that data to a
-- searchable database, be able to close it as fast as I can open it …
-- a running history under the main text editor area … open tabs as I
-- need more scratch space … automatically save every few milliseconds
-- … at the end of my workday, 4 PM, an Asana task should be created with
-- the contents … start time of 7:30 AM and an end time of 4 PM, make me
-- the assignee, post to my personal Asana project like any other task …
-- this tool must not lock up my keyboard or the operating system and
-- should degrade gracefully."
--
-- WHAT IT IS. One borderless webview (the Capture Pad / Task Form
-- recipe: allowTextEntry, read-back-verified non-activating mask, held
-- usercontent port, Lua-driven header drag). Inside it: a tab bar, a
-- textarea, and under the textarea a HISTORY strip — every tab you
-- closed, newest first, with a filter box. Click a history row and it
-- comes back as a tab.
--
-- WHERE THE TEXT LIVES. Three places, in this order of truth:
--   1. sp.tabs in Lua — updated on EVERY keystroke (the page posts the
--      whole textarea on each input event; the bridge is cheap and the
--      draft can never be newer than Lua's copy by more than one key).
--   2. <logsDir>/scratch/scratch.json — written sp.saveDelay seconds
--      after the last keystroke (a held hs.timer.doAfter, re-armed per
--      key), and at once on close, tab close, restore and the 4 PM send.
--      "Every few milliseconds" is met by (1); (2) keeps a plist-storm
--      off the disk — the same lesson as unified search's position key.
--   3. ⇪space — unified_search reads sp.tabs and sp.history live, so the
--      whole store is searchable from the one search everything uses.
--
-- 4 PM. sp.send() builds ONE task for the day: every open tab with text
-- under its title, then anything closed today. start 07:30 · due 16:00
-- (both on today), assignee "me", the personal project — all through
-- _G.asanaSubmitTask, the single submit path the ⇪T form uses, so this
-- module owns no Asana request of its own. The identifying comment goes
-- through the same auto-comment hook (extra.comment, 6.164.0). A day
-- with no text, or whose text has not changed since the last send, is
-- skipped and says so in the Console.
--
-- 🗒 ⇪N AND ⇪2 OPEN HERE (6.165.0). LL: "Could I just add these to my
-- new tool? That way I am only opening one text edit tool." The Capture
-- Pad and the Quick Append Pad keep their brains (queue, router, 16:00
-- flush, 16:01 review, services); this pad is their window. ⇪N opens a
-- 🗒 Capture tab, and ⇪2 opened a ➕ Append tab until 6.182.0 took that
-- key for the sequential copy (the Append tab is a row in the vault's
-- 📝 SCRATCH NOTES now). One of each at a time. Closing
-- such a tab — ⌘W, its ×, or closing the pad — FILES its text where the
-- old pad did: capturePad.add (the 4 PM Asana queue) or notePad.fileAll
-- (* idea · + log · ! task · ? note). Failure keeps the tab and the
-- text, exactly as the old pads kept their draft. Those tabs are NOT
-- part of this pad's own 4 PM task — they have their own destinations.
-- pad.viaScratch / np.viaScratch = false in a profile restores the old
-- windows. ⇪⇧N (send now), ⇪pad2/⇪pad*/⇪pad- and the 16:01 review are
-- untouched.
--
-- 📌 PIN. The header's pin keeps the pad up while you work in the app
-- beside it: Esc no longer closes it (it only returns the keyboard),
-- and it stays on every Space above the app. ⇪1 and ✕ always close.
-- No window is tracked, no Accessibility is read: nothing here can stall.
--
-- 🕸 ONE WINDOW WITH THE VAULT (6.173.0). LL: "Can I combine my Scorp
-- Pad and this Vault Pad?" Yes: ⇪1 and ⇪3 now open the SAME window —
-- the Vault's (modules/vault.lua). Its note list carries a 📝 SCRATCH
-- section at the top with every tab here (Capture / Append tabs too),
-- its text box edits them, and closed tabs sit under HISTORY on the
-- right. This module keeps its brains: sp.tabs, the store, the history,
-- the filing of kind tabs and the 4 PM task are all still here — the
-- vault is only the window (sp.host()). `sp.viaVault = false` in a
-- profile, or a Mac without the vault module, brings this module's own
-- window back, unchanged.
--
-- 🚨 WHAT THIS MODULE DELIBERATELY DOES NOT DO. No eventtap (the page's
-- own keydown handles ⌘T/⌘W/⌘1–9/Esc, so nothing can swallow a key
-- system-wide). No AX or window-object reads. No timer that is not held. No
-- write bigger than the store, and that store is registered with the
-- write ledger. Without a webview it falls back to hs.dialog and still
-- saves. Without Asana it still saves — the 4 PM send says "Asana is
-- off on this Mac" and keeps everything.
-- =====================================================================

local M = {
    name    = "Hamsidian tabs",
    order   = 13.37,
    family  = "capture",
    summary = "⇪N a scratch editor: tabs, saved as you type, a searchable "
              .. "history under the text, one Asana task of the day at 4 PM",
    cheatsheet = {
        title = "📝 HAMSIDIAN TABS (⇪N — type, it saves; close as fast as you opened it)",
        entries = {
            { "⇪N",        "Open the tabs — inside the ⇪3 Hamsidian window, on your SCRATCH NOTES (again closes). ⇪1 no longer opens it and is free" },
            { "⌘T · ⌘W",   "New tab · close tab (its text goes to the history)" },
            { "⌘1…⌘9",     "Switch tab · ⌃Tab / ⌃⇧Tab cycle round them" },
            { "history",   "Right pane (in the notes): every closed tab, click to reopen" },
            { "📌",        "Pin: stays up beside the app; Esc only hands the keys back" },
            { "+ 🗒 · + ➕", "OFF since 6.254.0 — the Capture / Append rows are hidden. Nothing was deleted: both stores are intact and still searched by ⇪space. settings = { scratch_pad = { showKindRows = true } } brings the rows back" },
            { "⇪2",        "SEQUENTIAL COPY: select text, press it, select more, press again — the grabs join into ONE block on the clipboard, so ⌘V pastes the lot. Copying anything else starts a new sequence. Nothing is filed into the pad" },
            { "16:00",     "ON again (6.300.0, his own reversal): every unsent tab's tasks go to Asana at 16:00, open window or not. _G.scratchPadSend() sends by hand; settings = { scratch_pad = { sendDaily = false } } switches the schedule off" },
            { "grammar",   "A bare line is a task · = divides · P: title · A: assignee · D: description · S: subtask (a real Asana subtask) · T: dates and times. One Asana task per task, into your default project" },
            { "✅ / ❌",    "After a send each tab is RETITLED \"✅ Success: tasks sent\" or \"❌ Error: tasks not sent\" and kept until you delete it. A ✅ tab is never sent twice; a ❌ tab is retried, and the retry sends ONLY the tasks that did not reach Asana (6.305.0); typing in a tab clears its mark" },
            { "preview",   "_G.scratchPadTasks() shows every task a send WOULD create, and what it did to each T: line — nothing is sent" },
            { "search",    "⇪space finds everything here — tabs and history" },
            { "own window","settings = { scratch_pad = { viaVault = false } } brings the old window back" },
            { "⌘⇧S",       "Export every tab to <Vault>/Scratch as .md — Obsidian opens them" },
            { "Console",   "_G.scratchPadReport() · _G.scratchPadSend() · _G.scorpPadExport() — the COMMANDS keep their old names, like the notes' own did in 6.214.0" },
        },
    },
}

function M.setup(core)
    local sp = {
        enabled       = true,
        -- 🔑 6.182.0 — ⇪N, was ⇪1. LL: "I think hyper+N is enough to open
        -- the Scorp Pad. Do you?" He is right: FOUR keys reached this one
        -- window (⇪1 the pad, ⇪N a Capture tab, ⇪2 an Append tab, ⇪3 the
        -- vault side of it), which is three doors too many into a room
        -- you are already in. ⇪N is the door now, ⇪3 still opens the
        -- vault side, ⇪2 became the sequential copy, and ⇪1 IS FREE — do
        -- not spend it without LL.
        key           = "n",
        width         = 768,
        height        = 1024,
        alpha         = 1,        -- 6.172.1 — SOLID (LL: 0.95 was still not opaque enough); 0–1 in a settings override makes it see-through
        fontSize      = 16,       -- 6.171.2 — pt for the text; the chrome scales off it (LL: "aim for 16pt")
        saveDelay     = 0.3,      -- seconds after the last key before the disk write
        historyRows   = 200,      -- rows embedded in the page for the filter
        historyKeep   = 2000,     -- rows kept in the store (oldest drop past this)
        maxTabs       = 12,
        titleChars    = 40,
        previewChars  = 120,
        focusOnOpen   = true,
        nonActivating = true,
        pinned        = false,
        -- 📤 6.177.0 — the way out: the tabs as .md files Obsidian opens
        exportToVault   = true,     -- ⌘⇧S (and _G.scorpPadExport()) writes them out
        exportSub       = "Scratch",-- the folder inside the vault they land in
        exportHistory   = true,     -- closed tabs too (false = open tabs only)
        exportMax       = 500,      -- most files one export writes
        exportNameChars = 60,       -- longest file name before it is cut
        exportTag       = "scorp-pad",  -- the front-matter tag every exported note wears
        exported        = {},       -- tab id → the file name it keeps forever
        lastExport      = nil,

        viaVault      = true,     -- 6.173.0 — ⇪1 opens inside the ⇪3 Vault window; false = this module's own window

        -- 🗑 6.254.0 — THE THREE DOORS LL SAID HE DOES NOT USE. "I don't
        -- need to send these at 4pm. I don't need capture or append. I
        -- think those features are redundant. Am I wrong?"
        --
        -- NOTHING IS DELETED. capture_pad and note_pad keep their
        -- modules, their stores and their own filing routes; every note
        -- already written is still on disk and still found by ⇪space and
        -- ⇪D. What goes is the DOORS: the daily Asana task, and the two
        -- + rows in the Hamsidian window that open a kind tab. Each is a
        -- switch, so any of the three comes back with no release.
        -- 🗂 6.300.0 — AND HE TURNED THE 4 PM SEND BACK ON, in the same
        -- message that asked for the grammar to be sent: "tasks send at
        -- 4pm whether Hamsidian is open or not". That reverses his own
        -- 6.254.0 decision and it is HIS to reverse; it is said out
        -- loud here rather than changed quietly, because a default that
        -- flips back without a sentence is how a tool starts doing
        -- something nobody remembers asking for.
        sendDaily     = true,     -- settings = { scratch_pad = { sendDaily = false } }
        showKindRows  = false,    -- settings = { scratch_pad = { showKindRows = true } }

        -- 🗂 6.300.0 — WHICH SEND. true = his grammar, one Asana task
        -- per parsed task. false = the pre-6.300.0 behaviour, ONE task
        -- for the whole day with every tab's text as its description.
        -- The old path is kept whole and still tested (6.254.0's shape:
        -- a switch, never a deletion).
        sendGrammar   = true,     -- settings = { scratch_pad = { sendGrammar = false } }
        -- 🏷 THE TWO LABELS, his own words from his own screenshot. A
        -- tab wearing the sent one is SKIPPED by every later send —
        -- the rename IS the memory (6.281.0) — and it stays until he
        -- deletes it, which is what he asked for. A tab wearing the
        -- failed one is RETRIED, which is the whole point of marking
        -- it. Editing a tab clears the mark: new text is new work.
        sentMark      = "✅ Success: tasks sent",
        failMark      = "❌ Error: tasks not sent",
        landedMax     = 400,      -- keys remembered per tab (6.305.0)

        -- the 4 PM task
        sendAt        = "16:00",
        startTime     = "07:30",
        dueTime       = "16:00",
        assignee      = "me",
        titlePrefix   = "Hamsidian · ",
        comment       = "Sent by Hammerspoon Hamsidian \"⇪N\", file init.lua",
        sendOnlyIfChanged = true,

        -- state
        tabs = {}, active = nil, history = {}, sent = {},
        webview = nil, uc = nil, saveTimer = nil, sendTimer = nil,
        dragTimer = nil, dragOffset = nil,
        dirty = false, saves = 0, lastSaveErr = nil, lastSend = nil,
        opens = 0, nonActivatingApplied = false, nonActivatingWhy = "not requested",
        caret = 0, filter = "",
    }
    M.config = sp
    _G.scratchPad = sp

    local function say(m)
        if _G.diag and _G.diag.say then _G.diag.say("scratchPad", m) end
    end
    local function warn(m)
        if _G.diag and _G.diag.warn then _G.diag.warn("scratchPad", m) end
    end

    sp.dir  = (core.logsDir or core.homeDir or ".") .. "/scratch"
    -- 6.177.0 — kept so the export can find the vault's folder even on a
    -- Mac where the vault module never loaded.
    sp.cloudDir = core.cloudDir
    sp.baseDir  = core.logsDir or core.homeDir
    sp.file = sp.dir .. "/scratch.json"
    _G.rewrittenFiles = _G.rewrittenFiles or {}
    _G.rewrittenFiles[sp.file] = "the ⇪N Hamsidian tabs — rewritten after every edit"

    -- ---- small helpers ----------------------------------------------------
    local counter = 0
    local function newId()
        counter = counter + 1
        return tostring(os.time()) .. "-" .. counter
    end
    local function trim(s) return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")) end
    local function oneLine(s) return (tostring(s or ""):gsub("%s+", " ")) end

    -- An empty tab is named for what it IS (6.165.1 — "Untitled ×2 told
    -- me nothing"): "Capture", "Append", or "Scratch N" by its place.
    function sp.titleOf(tab)
        -- 🏷 6.300.0 — a tab the send has answered for wears its answer.
        -- LL: "Can we rewrite the task titles to either of the names in
        -- the screenshot … So they stay until I delete them?"
        local mark = tostring(tab.mark or "")
        if mark ~= "" then return mark end
        local first = tostring(tab.text or ""):match("[^\r\n]*") or ""
        first = trim(first)
        if first == "" then
            local k = tab.kind and sp.kinds and sp.kinds[tab.kind]
            if k then return k.label end
            local _, i = sp.findTab(tab.id)
            return "Scratch " .. tostring(i or "")
        end
        if #first > sp.titleChars then first = first:sub(1, sp.titleChars - 1) .. "…" end
        return first
    end

    function sp.findTab(id)
        for i, t in ipairs(sp.tabs) do if t.id == id then return t, i end end
        return nil
    end
    function sp.activeTab()
        local t = sp.active and sp.findTab(sp.active)
        if not t then t = sp.tabs[1]; sp.active = t and t.id end
        return t
    end

    -- ---- tab kinds: the old pads' text, filed where it always went ------------
    sp.kinds = {
        capture = {
            badge = "🗒", label = "Capture", filed = "→ 4 PM Asana queue",
            hint  = "⌘W queues this for the 4 PM send",
            file  = function(text)
                if not (_G.service and _G.service.has and _G.service.has("capturePad.add")) then
                    return false, "the Capture Pad is not loaded"
                end
                local ok, res = _G.service.call("capturePad.add", text)
                if not ok then return false, tostring(res or "not queued") end
                return true, "queued for the 4 PM send", ""
            end,
        },
        append = {
            badge = "➕", label = "Append", filed = "→ Logs / Ideas / Asana",
            hint  = "* idea · + log · ! task · ? note — ⌘W files it",
            file  = function(text)
                local np = _G.notePad
                if not (np and type(np.fileAll) == "function") then
                    return false, "the Quick Append Pad is not loaded"
                end
                local allOk, summary, leftover = np.fileAll(text)
                return allOk, summary or "filed", leftover or ""
            end,
        },
    }
    function sp.kindOf(tab) return tab and tab.kind and sp.kinds[tab.kind] or nil end

    -- 6.173.0 — the window that shows the tabs: the Vault's when it is
    -- loaded and sp.viaVault is on, else this module's own (below).
    function sp.host()
        if not sp.viaVault then return nil end
        local v = _G.vault
        if type(v) == "table" and v.enabled ~= false and type(v.showScratch) == "function" then return v end
        return nil
    end
    -- The host calls this as its window closes: kind tabs file where
    -- they always did (a failure keeps the tab), the store is written.
    function sp.onHostClose()
        for i = #sp.tabs, 1, -1 do
            local t = sp.tabs[i]
            if sp.kindOf(t) then sp.closeTab(t.id) end
        end
        if sp.dirty then sp.saveNow() end
    end

    -- ---- the store ----------------------------------------------------------
    local function ensureDir()
        if type(hs.fs) == "table" and hs.fs.mkdir then
            pcall(hs.fs.mkdir, sp.dir)
        else
            pcall(os.execute, "mkdir -p '" .. sp.dir:gsub("'", "'\\''") .. "'")
        end
    end

    function sp.load()
        local f = io.open(sp.file, "r")
        if not f then return false end
        local blob = f:read("a"); f:close()
        local ok, data = pcall(hs.json.decode, blob)
        if not (ok and type(data) == "table") then
            warn("store unreadable — starting empty (the file is left in place)")
            sp.lastSaveErr = "unreadable"
            return false
        end
        sp.tabs    = type(data.tabs) == "table" and data.tabs or {}
        sp.history = type(data.history) == "table" and data.history or {}
        sp.sent    = type(data.sent) == "table" and data.sent or {}
        sp.exported = type(data.exported) == "table" and data.exported or {}
        -- 6.182.0 — which tab the ⇪2 block lives in, so a reload keeps
        -- appending to it instead of starting a second Collect tab.
        sp.collectId = type(data.collectId) == "string" and data.collectId or nil
        sp.active  = data.active
        sp.pinned  = data.pinned == true
        return true
    end

    -- Written whole, to a sibling first, then renamed over: a crash
    -- mid-write can only ever lose the write, never the store.
    function sp.saveNow()
        if sp.saveTimer then pcall(function() sp.saveTimer:stop() end); sp.saveTimer = nil end
        ensureDir()
        local okE, blob = pcall(hs.json.encode, {
            tabs = sp.tabs, history = sp.history, sent = sp.sent,
            active = sp.active, pinned = sp.pinned, savedAt = os.time(),
            exported = sp.exported, collectId = sp.collectId,
        }, true)
        if not (okE and type(blob) == "string") then
            sp.lastSaveErr = "encode failed"
            warn("store not written — encode failed")
            return false
        end
        -- A failed write is SAID, once per streak, on screen and in the
        -- Console — the text is safe in Lua and the next keystroke retries.
        -- 🚨 6.316.0 — THE SAME DOOR THE NOTES SIDE TAKES. This half
        -- held every scratch TAB he has ever typed and warned about a
        -- failure exactly once per session, through an alert macOS is
        -- measured to refuse. See vault.lua's saveNow for the whole
        -- note; the two must not drift, which is why there is one
        -- function and not two copies of it (6.231.0).
        local function failed(why)
            sp.lastSaveErr = why
            sp.saveFails = (sp.saveFails or 0) + 1
            if core.warnWriteFailed then core.warnWriteFailed("scratch pad store") end
            if _G.notices and type(_G.notices.notSaved) == "function" then
                pcall(_G.notices.notSaved, "Hamsidian tabs",
                      "your scratch tabs", sp.file, why)
            elseif sp.saveErrSaid ~= why then
                -- 🔕 the gate is per CAUSE, never per session — see
                -- vault.lua's saveNow for why the boolean was the bug.
                pcall(function()
                    hs.alert.show("📝 NOT SAVED — " .. why .. "\nYour text is safe in memory; "
                                  .. "every keystroke retries the write.", 10)
                end)
                pcall(print, "🚨 Hamsidian tabs NOT SAVED — " .. why .. " (" .. sp.file .. ")")
            end
            sp.saveErrSaid = why
            return false
        end
        local tmp = sp.file .. ".tmp"
        local f = io.open(tmp, "w")
        if not f then return failed("cannot open " .. tmp) end
        local okW = f:write(blob)
        f:close()
        if not okW then return failed("write failed") end
        local okR = os.rename(tmp, sp.file)
        if not okR then return failed("rename failed") end
        if sp.saveErrSaid then
            sp.saveErrSaid = false
            if _G.notices and type(_G.notices.saveOK) == "function" then
                pcall(_G.notices.saveOK, "Hamsidian tabs")
            else
                pcall(function() hs.alert.show("📝 Saving again", 2) end)
            end
        end
        sp.dirty, sp.lastSaveErr = false, nil
        sp.saves = sp.saves + 1
        return true
    end

    -- Every keystroke lands here; the disk write waits sp.saveDelay after
    -- the LAST one. The timer is HELD in sp.saveTimer (test_diagnostics).
    function sp.scheduleSave()
        sp.dirty = true
        if sp.saveTimer then pcall(function() sp.saveTimer:stop() end) end
        local ok, t = pcall(hs.timer.doAfter, sp.saveDelay, function()
            sp.saveTimer = nil
            sp.saveNow()
        end)
        sp.saveTimer = ok and t or nil
        if not ok then sp.saveNow() end
    end

    -- ---- tabs ---------------------------------------------------------------
    function sp.newTab(text, kind)
        if #sp.tabs >= sp.maxTabs then
            pcall(function() hs.alert.show("📝 " .. sp.maxTabs .. " tabs already — close one (⌘W)", 2) end)
            return nil
        end
        local t = { id = newId(), text = tostring(text or ""), createdAt = os.time(), updatedAt = os.time(),
                    kind = (kind and sp.kinds[kind]) and kind or nil }
        sp.tabs[#sp.tabs + 1] = t
        sp.active = t.id
        sp.scheduleSave()
        return t
    end

    function sp.setText(id, text)
        local t = sp.findTab(id)
        if not t then return false end
        text = tostring(text or "")
        if t.text ~= text then
            -- 🏷 6.300.0 — TYPING CLEARS THE MARK. A ✅ describes the
            -- text that was sent; the moment that text changes the
            -- label is a claim about something else, and a ✅ tab that
            -- can never be sent again would freeze his new writing out
            -- of the 4 PM run. Its own check.
            t.text, t.updatedAt, t.mark = text, os.time(), nil
            sp.scheduleSave()
        end
        return true
    end

    -- A closed tab with text becomes the newest history row; an empty
    -- one simply goes. The last tab closing leaves one blank tab.
    -- A Capture / Append tab is FILED first; a failure keeps the tab.
    -- Returns ok, why. (why = the filing summary or the failure.)
    function sp.fileTab(t)
        local k = sp.kindOf(t)
        if not k then return true end
        if trim(t.text) == "" then return true, "empty" end
        local ok, why, leftover = k.file(t.text)
        if not ok then
            t.text = (leftover and leftover ~= "") and leftover or t.text
            t.updatedAt = os.time()
            pcall(function() hs.alert.show("📝 Kept in its tab — " .. tostring(why), 4) end)
            sp.scheduleSave()
            return false, why
        end
        if leftover and leftover ~= "" then
            -- Part filed, part not (the router's failed lines): keep those.
            t.text, t.updatedAt = leftover, os.time()
            pcall(function() hs.alert.show(tostring(why), 4) end)
            sp.scheduleSave()
            return false, why
        end
        return true, why
    end

    function sp.closeTab(id)
        local t, i = sp.findTab(id)
        if not t then return false end
        local k = sp.kindOf(t)
        if k then
            local ok, why = sp.fileTab(t)
            if not ok then return false end
            t.filedAs = k.filed .. (why and why ~= "" and (" · " .. tostring(why)) or "")
        end
        table.remove(sp.tabs, i)
        if trim(t.text) ~= "" then
            table.insert(sp.history, 1, {
                id = t.id, text = t.text, title = sp.titleOf(t),
                createdAt = t.createdAt, closedAt = os.time(),
                kind = t.kind, filedAs = t.filedAs,
            })
            while #sp.history > sp.historyKeep do table.remove(sp.history) end
        end
        if #sp.tabs == 0 then sp.newTab("") end
        if sp.active == id then sp.active = sp.tabs[math.min(i, #sp.tabs)].id end
        sp.saveNow()
        return true
    end

    function sp.restore(id)
        for i, h in ipairs(sp.history) do
            if h.id == id then
                local t = sp.newTab(h.text)
                if not t then return false end
                t.createdAt = h.createdAt or t.createdAt
                table.remove(sp.history, i)
                sp.saveNow()
                return true
            end
        end
        return false
    end

    -- ---- 📤 export to the vault (6.177.0) ------------------------------------
    -- LL: "Will I be able to open my Scorp pad files in Obsidian if I ever
    -- decide to move to it?" On their own the tabs are JSON inside one
    -- rewritten store, so: no. This writes every tab — and, by default, the
    -- closed-tab history — out as plain .md files in <Vault>/Scratch, the
    -- same folder Obsidian opens. The store stays the source of truth; the
    -- .md files are a copy you can walk away with.
    --
    -- IT DEGRADES, IT NEVER BREAKS. The vault module does not have to be
    -- loaded (the folder is worked out the same way it would work it out);
    -- OneDrive does not have to exist (a local folder takes its place and
    -- the summary SAYS so); a single unwritable tab costs that one file,
    -- not the export; a failed export never touches a tab, a store or a
    -- keystroke. Every path returns ok, why — nothing here ever throws.
    local BADCHARS = '[/\\:%*%?"<>|]'

    -- The vault's folder: its own if the module is up (that is the truth),
    -- else the very same path it would have chosen from core (work Mac
    -- profiles may not load vault at all).
    function sp.vaultDir()
        local v = _G.vault
        if type(v) == "table" and type(v.dir) == "string" and v.dir ~= "" then
            return v.dir, "vault"
        end
        if sp.cloudDir and sp.cloudDir ~= "" then return sp.cloudDir .. "/Vault", "cloud" end
        return (sp.baseDir or ".") .. "/vault", "local"
    end
    function sp.exportDir()
        local dir, how = sp.vaultDir()
        local sub = trim(tostring(sp.exportSub or ""))
        if sub ~= "" then dir = dir .. "/" .. sub end
        return dir, how
    end

    -- A file name Finder, OneDrive and Obsidian all accept: no slashes,
    -- no colons, no control characters, no leading dot, not endless.
    function sp.exportSafeName(title)
        local s = oneLine(tostring(title or ""))
        s = s:gsub("%c", " "):gsub(BADCHARS, "-")
        s = trim(s:gsub("%s+", " "))
        s = s:gsub("^[%.%-]+", "")
        s = trim(s)
        if #s > sp.exportNameChars then s = trim(s:sub(1, sp.exportNameChars)) end
        if s == "" then s = "Scratch" end
        return s
    end

    -- The name a tab keeps FOREVER, remembered in the store (sp.exported):
    -- a second export of the same tab updates its file instead of leaving
    -- a copy behind. Nothing on disk is ever read to decide this — a
    -- OneDrive placeholder read can block the main thread, and the pad
    -- never blocks.
    function sp.exportNameFor(id, title)
        id = tostring(id or "")
        sp.exported = type(sp.exported) == "table" and sp.exported or {}
        local had = sp.exported[id]
        if type(had) == "string" and had ~= "" then return had end
        local base, taken = sp.exportSafeName(title), {}
        for other, name in pairs(sp.exported) do
            if other ~= id and type(name) == "string" then taken[name:lower()] = true end
        end
        local name, n = base .. ".md", 1
        while taken[name:lower()] do
            n = n + 1
            name = base .. " " .. n .. ".md"
        end
        sp.exported[id] = name
        return name
    end

    -- Front matter Obsidian reads (and this vault's own tag scan reads):
    -- the title, where it came from, when it was written. Then the text,
    -- exactly as typed — no Markdown is invented for LL.
    function sp.exportBody(rec)
        local when = tonumber(rec.updatedAt or rec.closedAt or rec.createdAt) or os.time()
        local made = tonumber(rec.createdAt) or when
        local L = {
            "---",
            "title: " .. tostring(rec.title or "Scratch"),
            "source: Hamsidian",
            "created: " .. os.date("%Y-%m-%d %H:%M", made),
            "updated: " .. os.date("%Y-%m-%d %H:%M", when),
            "tags: " .. tostring(sp.exportTag or "scorp-pad"),
            "---",
            "",
            "",
        }
        local text = tostring(rec.text or "")
        return table.concat(L, "\n") .. text .. (text:sub(-1) == "\n" and "" or "\n")
    end

    local function mkdirpFor(dir)
        local made = false
        if type(hs.fs) == "table" and type(hs.fs.mkdir) == "function" then
            local up, chain = dir, {}
            while up and up ~= "" and up ~= "/" do
                chain[#chain + 1] = up
                up = up:match("^(.*)/[^/]+$")
            end
            for i = #chain, 1, -1 do pcall(hs.fs.mkdir, chain[i]) end
            made = true
        end
        if type(hs.fs) == "table" and type(hs.fs.attributes) == "function" then
            local ok, a = pcall(hs.fs.attributes, dir)
            if ok and type(a) == "table" then return true end
        elseif made then
            return true          -- made what we could and cannot check; the write will say
        end
        pcall(os.execute, "mkdir -p '" .. dir:gsub("'", "'\\''") .. "'")
        return true
    end

    -- One file, written to a sibling and renamed over it — the same
    -- contract as the store: a crash can lose the write, never the file.
    local function writeOne(path, body)
        local tmp = path .. ".tmp"
        local f = io.open(tmp, "w")
        if not f then return false, "cannot write " .. tmp end
        local okW = f:write(body)
        f:close()
        if not okW then return false, "write failed" end
        if not os.rename(tmp, path) then
            pcall(os.remove, tmp)
            return false, "rename failed"
        end
        return true
    end

    -- Everything, in one go. Returns ok, summary — and never raises.
    function sp.exportAll(why)
        if sp.exportToVault == false then
            return false, "export is off (settings: scratch_pad.exportToVault)"
        end
        local dir, how = sp.exportDir()
        local okDir = pcall(mkdirpFor, dir)
        if not okDir then return false, "could not make " .. dir end

        local recs = {}
        for _, t in ipairs(sp.tabs) do
            if trim(t.text or "") ~= "" then
                recs[#recs + 1] = { id = t.id, title = sp.titleOf(t), text = t.text,
                                    createdAt = t.createdAt, updatedAt = t.updatedAt }
            end
        end
        if sp.exportHistory ~= false then
            for _, h in ipairs(sp.history) do
                if trim(h.text or "") ~= "" then
                    recs[#recs + 1] = { id = h.id, title = h.title or "Scratch", text = h.text,
                                        createdAt = h.createdAt, closedAt = h.closedAt }
                end
            end
        end

        local wrote, failed, firstWhy, capped = 0, 0, nil, false
        for i, rec in ipairs(recs) do
            if i > (tonumber(sp.exportMax) or 500) then capped = true break end
            local ok, err = pcall(function()
                local name = sp.exportNameFor(rec.id, rec.title)
                local okW, whyW = writeOne(dir .. "/" .. name, sp.exportBody(rec))
                if not okW then error(whyW, 0) end
            end)
            if ok then wrote = wrote + 1
            else
                failed = failed + 1
                firstWhy = firstWhy or tostring(err)
            end
        end
        sp.saveNow()   -- the names it just handed out are part of the store

        local parts = { wrote .. " note" .. (wrote == 1 and "" or "s") .. " → " .. dir }
        if how == "local" then parts[#parts + 1] = "no OneDrive found — local folder" end
        if capped then parts[#parts + 1] = "stopped at " .. tostring(sp.exportMax) .. " (exportMax)" end
        if failed > 0 then parts[#parts + 1] = failed .. " could not be written (" .. tostring(firstWhy) .. ")" end
        local summary = table.concat(parts, " · ")
        sp.lastExport = { at = os.time(), why = tostring(why or "export"), dir = dir,
                          wrote = wrote, failed = failed, how = how, summary = summary }
        say("exported " .. summary)
        return failed == 0 and wrote > 0, summary
    end

    -- The Console door. Prints what happened either way.
    _G.scorpPadExport = function()
        local ok, summary = sp.exportAll("console")
        print("📤 Hamsidian export — " .. tostring(summary))
        return ok, summary
    end

    -- =================================================================
    -- 🗂 6.297.0 — A LINE IS A TASK: THE HAMSIDIAN TASK GRAMMAR
    -- =================================================================
    -- LL asked what "→ Asana now" does and then described what he wants
    -- it to do instead. THE ANSWER TO THE QUESTION FIRST, because it is
    -- the opposite of what he assumed: sp.dayBody builds ONE task for
    -- the whole day — title "Hamsidian · Fri Sep 26", and every tab's
    -- text underneath it as the description. Never one task per line.
    --
    -- His grammar, as he wrote it:
    --   a bare line                  → one basic task, verb + rest
    --   =                            → a divider between groups
    --   P: <verb + sentence>         → a task with more to say
    --   A: <assignee>                → who (default "me")
    --   D: <description>             → the body
    --   S: <subtask>                 → one per line, many per task
    --   T: <dates and times>         → start/end date, start/end time
    --
    -- 🚨 THIS RELEASE PARSES AND PREVIEWS. IT SENDS NOTHING. That is
    -- deliberate and it is the 6.237.0 habit: on ground this config has
    -- not touched — and his own grammar is exactly that, because only
    -- he knows what he will really type — the FIRST release is the one
    -- that prints what was understood, never a fix built on a belief.
    -- `_G.scratchPadTasks()` shows him every task this would create
    -- before one of them exists in Asana. The send is 6.298.0.
    --
    -- 🔑 PURE, AND THE CLOCK IS AN ARGUMENT (6.234.0). "today" and "one
    -- week from today" cannot be proven by a test that has to wait a
    -- week, so `now` is passed in and every edge is a fixture.

    -- A prefix is a single letter and a colon. Anything else is prose.
    function sp.taskPrefix(line)
        local k, rest = tostring(line or ""):match("^(%a)%s*:%s*(.*)$")
        if not k then return nil end
        k = k:upper()
        if k == "P" or k == "A" or k == "D" or k == "S" or k == "T" then
            return k, rest
        end
        return nil
    end

    -- 📅 PURE. Answers a YYYY-MM-DD, or nil and the word it could not
    -- read. Deliberately narrow: ISO, US with / or -, and the words he
    -- used in his own example. A two-digit year is 20xx (6.200.0's
    -- measured rule about dates, same reasoning).
    function sp.taskDate(word, now)
        local w = tostring(word or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
        now = tonumber(now) or os.time()
        local DAY = 86400
        if w == "" then return nil end
        if w == "today"     then return os.date("%Y-%m-%d", now) end
        if w == "tomorrow"  then return os.date("%Y-%m-%d", now + DAY) end
        if w == "yesterday" then return os.date("%Y-%m-%d", now - DAY) end
        local n, unit = w:match("^%+(%d+)%s*([dwm])$")
        if n then
            n = tonumber(n)
            local mult = (unit == "d" and 1) or (unit == "w" and 7) or 30
            return os.date("%Y-%m-%d", now + n * mult * DAY)
        end
        local y, m, d = w:match("^(%d%d%d%d)-(%d%d?)-(%d%d?)$")
        if y then return ("%04d-%02d-%02d"):format(y, m, d) end
        m, d, y = w:match("^(%d%d?)[/-](%d%d?)[/-](%d%d%d%d)$")
        if not m then m, d, y = w:match("^(%d%d?)[/-](%d%d?)[/-](%d%d)$") end
        if m then
            y = tonumber(y)
            if y < 100 then y = 2000 + y end
            return ("%04d-%02d-%02d"):format(y, m, d)
        end
        return nil
    end

    -- 🕐 PURE. 24-hour HH:MM, or nil. Accepts 7:00 AM, 07:00, 4pm, 16:00.
    function sp.taskTime(word)
        local w = tostring(word or ""):lower():gsub("%s+", "")
        if w == "" then return nil end
        local h, m, ap = w:match("^(%d%d?):(%d%d)(a?p?m?)$")
        if not h then h, ap = w:match("^(%d%d?)(am)$") end
        if not h then h, ap = w:match("^(%d%d?)(pm)$") end
        if not h then return nil end
        h, m = tonumber(h), tonumber(m or 0)
        if m > 59 then return nil end
        if ap == "pm" and h < 12 then h = h + 12 end
        if ap == "am" and h == 12 then h = 0 end
        if h > 23 then return nil end
        return ("%02d:%02d"):format(h, m)
    end

    -- 📅 PURE. Reads a whole T: line. FIRST date is the start and the
    -- second is the due; first time the start, second the end — his own
    -- order. 🚨 WHAT IT CANNOT READ IS NAMED, never dropped: a T: line
    -- he writes in words this does not know must show up in the preview
    -- as an unread word, or he sets a date that never happens and finds
    -- out from Asana a week later.
    -- Words that join a T: line rather than naming a moment. A SET,
    -- not a find() over one string: "a" is inside "and", so a substring
    -- test would wave through every stray letter (6.236.0, boundaries).
    sp.taskFiller = { at = true, to = true, ["and"] = true, from = true,
                      on = true, until_ = true, by = true, start = true,
                      ["end"] = true, ["-"] = true, ["–"] = true }
    sp.taskFiller["until"] = true

    function sp.taskWhen(line, now)
        local out, bad = {}, {}
        -- 🕐 "7:00 AM" IS ONE WORD, and splitting on whitespace makes it
        -- two. His own example is written that way, so the am/pm is
        -- glued back on before anything is split — found by the check
        -- built from his sentence rather than from my own fixture.
        local src = tostring(line or "")
            :gsub("(%d)%s+([AaPp][Mm])%f[%W]", "%1%2")
        for word in src:gmatch("[^%s,]+") do
            local clean = word:gsub("^[<(%[]+", ""):gsub("[>)%]]+$", "")
            if clean ~= "" then
                local d = sp.taskDate(clean, now)
                local t = (not d) and sp.taskTime(clean) or nil
                if d then
                    if not out.startDate then out.startDate = d
                    elseif not out.dueDate then out.dueDate = d
                    else bad[#bad + 1] = clean end
                elseif t then
                    if not out.startTime then out.startTime = t
                    elseif not out.dueTime then out.dueTime = t
                    else bad[#bad + 1] = clean end
                elseif not sp.taskFiller[clean:lower()] then
                    -- 🚨 A WORD IT CANNOT READ IS NAMED, never dropped.
                    -- A T: line written in words this does not know
                    -- would otherwise set a date that never happens,
                    -- and he would find out from Asana a week later.
                    bad[#bad + 1] = clean
                end
            end
        end
        return out, bad
    end

    -- 🗂 PURE. The whole grammar. Answers the tasks IN ORDER and the
    -- problems, because a line he meant as a task that silently became
    -- part of a description is the failure this preview exists to stop.
    function sp.parseTasks(text, now, defaultAssignee)
        local tasks, problems = {}, {}
        local cur
        local function close()
            if cur and cur.title ~= "" then tasks[#tasks + 1] = cur end
            cur = nil
        end
        local function open(title)
            close()
            cur = { title = title, desc = {}, subs = {},
                    assignee = defaultAssignee or "me", when = {}, badWhen = {} }
        end
        local n = 0
        for raw in (tostring(text or "") .. "\n"):gmatch("([^\n]*)\n") do
            n = n + 1
            local line = raw:gsub("^%s+", ""):gsub("%s+$", "")
            -- 🔤 HIS OUTLINE BULLETS. NOT a character class: "•" is
            -- three BYTES in UTF-8, and `[%-%*•]` matches its bytes one
            -- at a time, which strips nothing and corrupts anything
            -- else. 6.226.0's rule, in a Lua pattern.
            line = line:gsub("^\226\128\162%s*", "")   -- •
                       :gsub("^[%-%*]%s*", "")           -- - *
                       :gsub("^%s+", "")
            if line == "" then
                -- a blank line is nothing: it does not end a task, or a
                -- description with a paragraph break would split in two
            elseif line:match("^=+$") then
                close()                                   -- the divider
            else
                local k, rest = sp.taskPrefix(line)
                if k == "P" then
                    if rest == "" then
                        problems[#problems + 1] = "line " .. n .. ": P: with no title — skipped"
                    else open(rest) end
                elseif k == nil then
                    -- 🔑 A BARE LINE IS ALWAYS ITS OWN TASK, which is
                    -- his sentence ("a basic task with no other
                    -- information is verb+title"). Folding it into the
                    -- open description instead would be a guess, and a
                    -- guess here silently loses a task.
                    open(line) ; close()
                elseif not cur then
                    problems[#problems + 1] = "line " .. n .. ": " .. k
                        .. ": before any task — needs a P: line above it"
                elseif k == "D" then
                    cur.desc[#cur.desc + 1] = rest
                elseif k == "S" then
                    if rest == "" then
                        problems[#problems + 1] = "line " .. n .. ": empty S: — skipped"
                    else cur.subs[#cur.subs + 1] = rest end
                elseif k == "A" then
                    if cur.assigneeSet then
                        problems[#problems + 1] = "line " .. n
                            .. ": a second A: for the same task — the last one wins"
                    end
                    cur.assignee, cur.assigneeSet = (rest ~= "" and rest or (defaultAssignee or "me")), true
                elseif k == "T" then
                    local when, bad = sp.taskWhen(rest, now)
                    cur.when = when
                    for _, b in ipairs(bad) do
                        cur.badWhen[#cur.badWhen + 1] = b
                        problems[#problems + 1] = "line " .. n
                            .. ": could not read \"" .. b .. "\" as a date or a time"
                    end
                end
            end
        end
        close()
        for _, t in ipairs(tasks) do t.desc = table.concat(t.desc, "\n") end
        return tasks, problems
    end

    -- ---- the 4 PM task --------------------------------------------------------
    local function checksum(s)
        local h = #s
        for i = 1, #s, 7 do h = (h * 31 + s:byte(i)) % 2147483647 end
        return tostring(h)
    end

    -- (title, notes, count) — every open tab with text, then today's closed
    -- rows. nil when there is nothing to send.
    function sp.dayBody(today)
        today = today or os.date("%Y-%m-%d")
        local parts, n = {}, 0
        for _, t in ipairs(sp.tabs) do
            if trim(t.text) ~= "" and not t.kind then
                n = n + 1
                parts[#parts + 1] = "## " .. sp.titleOf(t) .. "\n" .. trim(t.text)
            end
        end
        for _, h in ipairs(sp.history) do
            if os.date("%Y-%m-%d", h.closedAt or 0) == today and trim(h.text) ~= "" and not h.kind then
                n = n + 1
                parts[#parts + 1] = "## " .. (h.title or "Untitled") .. " (closed "
                    .. os.date("%H:%M", h.closedAt or 0) .. ")\n" .. trim(h.text)
            end
        end
        if n == 0 then return nil end
        local title = sp.titlePrefix .. os.date("%a %b %d", os.time())
        return title, table.concat(parts, "\n\n"), n
    end

    -- 🔔 6.278.0 — A SEND THAT FAILED IS SEEN, NOT ONLY LOGGED.
    --
    -- LL: "for any tool that completes an action, like the 4pm send of
    -- Asana tasks from Hamsidian, how do I know if it didn't work? I
    -- think I need a persistent screen message that tells me if it fails
    -- otherwise I don't know if the tasks I quickly captured were sent.
    -- I could lose important information if not."
    --
    -- 🚨 HE WAS RIGHT AND THIS MODULE HAD NEVER PAID THE RULE. A rejected
    -- send called `warn()`, which is `_G.diag.warn` — the Console and
    -- nothing else. No alert, no notification, nothing on screen. That is
    -- 6.214.0's "A BREAK IS SEEN, NEVER ONLY LOGGED", written from his
    -- own words, unpaid in the one place where not knowing costs him the
    -- thing he captured.
    --
    -- 🔑 ONE PLACE DECIDES WHAT A SEND SAYS. Six exits used to each print
    -- their own sentence in their own channel, which is how one of them
    -- came to be silent without anybody noticing. Three OUTCOMES, and the
    -- channels follow from the outcome rather than from the exit:
    --   · sent    — a short alert and a Console line. SUCCESS IS VISIBLE
    --               TOO, deliberately: if only failure spoke, silence
    --               would mean both "it worked" and "it never ran", which
    --               is 6.196.1 in the instrument he is relying on.
    --   · skipped — Console only. Nothing to send is not a failure.
    --   · failed  — the 🔔 door (a DIRECT hs.alert, the ⚠️ Console line
    --               and the ledger) AND a notification, AND a sticky flag
    --               that outlives all of them.
    --
    -- 🕰 THE NOTIFICATION IS THE PERSISTENT HALF HE ASKED FOR, and it is
    -- the right one rather than a new card: an hs.alert is gone in six
    -- seconds and a 16:00 failure lands while he is in a meeting.
    -- notices.tell HOLDS it while Focus is on and delivers it when Focus
    -- ends — which is exactly "tell me when I get back". It is NOT
    -- forced past Focus: a held notice is still delivered, and forcing
    -- would put a work alert through a meeting for no gain.
    --
    -- 📌 AND THE STICKY FLAG IS WHAT SURVIVES A MISSED ALERT. Both
    -- channels above can be missed — he can be away, the Mac can be
    -- asleep, macOS can refuse the alert outright (6.274.0 counted that
    -- happening three times in eight hours on his Mac). `sp.unsent`
    -- stays set until a send succeeds, so the answer is still there at
    -- 4 PM when he goes looking.
    --
    -- 🚨 AND THE TEXT IS NEVER DISCARDED. `sp.sent[today]` is stamped in
    -- the success branch ONLY, so a failed send is retried rather than
    -- marked done — the tabs still hold every word. Its own check,
    -- because the tempting way to write this is to stamp it early.
    function sp.announce(outcome, detail, reason)
        detail = tostring(detail or "")
        if outcome == "sent" then
            sp.unsent = nil
            print("📝 Hamsidian: " .. sp.sendAt .. " task sent — " .. detail)
            pcall(function() hs.alert.show("✅ Hamsidian → Asana: " .. detail, 3) end)
            return
        end
        if outcome == "skipped" then
            print("📝 Hamsidian: " .. sp.sendAt .. " send skipped — " .. detail)
            return
        end
        -- failed
        sp.unsent = { at = os.time(), why = detail, reason = tostring(reason or "?") }
        sp.sendFails = (sp.sendFails or 0) + 1
        if type(core.degrade) == "function" then
            pcall(core.degrade, "Hamsidian 4 PM send", detail, { seconds = 10 })
        else
            pcall(print, "⚠️ Hamsidian 4 PM send: " .. detail)
            pcall(function() hs.alert.show("⚠️ Hamsidian 4 PM send — " .. detail, 10) end)
        end
        if _G.notices and type(_G.notices.tell) == "function" then
            pcall(_G.notices.tell, "⚠️ Hamsidian did not reach Asana", detail
                  .. " — your text is safe; _G.scratchPadSend() retries.")
        end
    end

    -- 📅 THE PRE-6.300.0 SEND, kept whole: ONE Asana task for the whole
    -- day, every tab's text as its description. `sendGrammar = false`
    -- brings it back (6.254.0's shape — a switch, never a deletion).
    function sp.sendDay(reason)
        reason = reason or "manual"
        local today = os.date("%Y-%m-%d")
        local title, notes, n = sp.dayBody(today)
        if not title then
            sp.lastSend = { at = os.time(), reason = reason, outcome = "nothing to send" }
            sp.announce("skipped", "nothing written today", reason)
            return false, "nothing to send"
        end
        local sum = checksum(notes)
        if sp.sendOnlyIfChanged and sp.sent[today] == sum then
            sp.lastSend = { at = os.time(), reason = reason, outcome = "unchanged since the last send" }
            sp.announce("skipped", "unchanged since the last send", reason)
            return false, "unchanged"
        end
        if not (core.asanaEnabled and _G.asanaSubmitTask) then
            -- 🔎 THIS ONE IS A FAILURE, NOT A SKIP, and telling the two
            -- apart is the point of the release. He wrote the tasks
            -- expecting them to go; "Asana is off on this Mac" means they
            -- did not, and the old code printed it to the Console alone.
            sp.lastSend = { at = os.time(), reason = reason, outcome = "Asana is off on this Mac" }
            sp.announce("failed", "Asana is off on this Mac (secret.lua) — "
                        .. "the text is safe in " .. sp.file, reason)
            return false, "asana off"
        end
        -- 🔔 6.299.0 — IT ANNOUNCES WHEN ASANA ANSWERS, NOT WHEN THE
        -- REQUEST LEAVES. `_G.asanaSubmitTask` returns true the instant
        -- it fires the POST, so this branch used to print "✅ Hamsidian
        -- → Asana: …" over a task Asana went on to refuse with a 400 —
        -- 6.278.0's whole guarantee, defeated by reading an "accepted"
        -- as a "delivered". `extra.onDone` is the real answer and it
        -- fires EXACTLY ONCE, including for a refusal that happens
        -- before the request leaves, which is why nothing below
        -- announces on the synchronous return any more.
        local heard, heardOk = false, false
        local okCall, accepted = pcall(_G.asanaSubmitTask, title, notes,
                                       sp.assignee, "", {
            startDate = today, startTime = sp.startTime,
            dueDate   = today, dueTime   = sp.dueTime,
            comment   = sp.comment,
            onDone    = function(ok, why)
                heard, heardOk = true, (ok and true or false)
                if ok then
                    -- 🚨 STAMPED HERE AND NOWHERE ELSE, and "here" is
                    -- one step later than it used to be: the day is
                    -- marked done only once ASANA has said yes, so a
                    -- refusal is retried rather than recorded as
                    -- finished. Its own check.
                    sp.sent[today] = sum
                    sp.lastSend = { at = os.time(), reason = reason,
                                    outcome = "sent · " .. n .. " section"
                                    .. (n == 1 and "" or "s"), title = title }
                    pcall(sp.saveNow)
                    sp.announce("sent", title, reason)
                else
                    sp.lastSend = { at = os.time(), reason = reason,
                                    outcome = "rejected — " .. tostring(why) }
                    sp.announce("failed", tostring(why) .. " — nothing was "
                                .. "sent and your text is still in the tabs",
                                reason)
                end
            end,
        })
        -- 🚨 AND A SUBMIT THAT THREW ANSWERS NOBODY. finish() covers
        -- every RETURN inside asanaSubmitTask; a raise happens above it,
        -- so this is the one outcome the door cannot report and the one
        -- that would otherwise leave the day silent.
        if not okCall and not heard then
            sp.lastSend = { at = os.time(), reason = reason,
                            outcome = "the Asana submit threw" }
            sp.announce("failed", "the Asana submit threw — "
                        .. tostring(accepted), reason)
            return false, "threw"
        end
        if not heard then
            -- Posted, and Asana has not answered yet. NOT "sent"
            -- (6.196.1): the report says so in its own words and the
            -- announce lands when the answer does.
            sp.lastSend = { at = os.time(), reason = reason,
                            outcome = "posted — waiting on Asana", title = title }
            return true, title
        end
        return heardOk, (heardOk and title or "rejected")
    end

    -- 📅 6.300.0 — WHAT ASANA WILL ACTUALLY TAKE. PURE, and it earns
    -- its place because his simplest likely line would otherwise be
    -- refused: Asana's own rules (enforced in asanaSubmitTask since
    -- 6.152.0) are that a time needs its date, a START date needs an
    -- END date, and with both dates the times come as a pair or not at
    -- all. `T: today` parses to a start date with no end — which Asana
    -- refuses outright, so the tab would wear ❌ for writing the most
    -- natural thing in the grammar.
    --
    -- 🔑 A LONE DATE IS THE DUE DATE. That is a DECISION and it is said
    -- rather than assumed: a single date means "by then" everywhere
    -- else, Asana's own UI reads it that way, and it is the only shape
    -- Asana accepts. His two-date spec — first is the start, second the
    -- end — is untouched, because two dates are unambiguous.
    --
    -- It answers the fields AND the notes, so the preview can SAY what
    -- it did to his line before a task exists (6.237.0).
    function sp.whenForAsana(w)
        w = (type(w) == "table") and w or {}
        local sd, st = w.startDate, w.startTime
        local ed, et = w.dueDate,   w.dueTime
        local notes = {}
        if sd and not ed then
            ed, et, sd, st = sd, st, nil, nil
            notes[#notes + 1] = "one date given — sent as the DUE date"
        end
        if sd and ed and ((st and not et) or (et and not st)) then
            st, et = nil, nil
            notes[#notes + 1] = "two dates but one time — sent all-day, "
                                .. "because Asana cannot mix a timed end "
                                .. "with an all-day start"
        end
        if st and not sd then
            st = nil
            notes[#notes + 1] = "a start time with no date — dropped"
        end
        if et and not ed then
            et = nil
            notes[#notes + 1] = "a time with no date — dropped"
        end
        return { startDate = sd, startTime = st,
                 dueDate = ed, dueTime = et }, notes
    end

    -- =================================================================
    -- 🗂 6.300.0 — THE GRAMMAR SENDS, AND THE TAB WEARS THE ANSWER
    -- =================================================================
    -- 6.297.0 read his grammar and deliberately sent nothing, so that
    -- the first thing either of us learned about a misreading was a
    -- preview and not a wrong task in Asana (6.237.0). This is the
    -- other half: every parsed task becomes an Asana task in his
    -- default project, and the TAB is retitled with his own two
    -- labels.
    --
    -- 🏷 HIS ANSWER TO THE QUESTION 6.297.0 ASKED, and it is better
    -- than any of the three I offered. I asked where the cleared text
    -- should GO — nowhere, the history, or an exported note. He
    -- answered by not clearing it: "rewrite the task titles … so they
    -- stay until I delete them." NOTHING IS DESTROYED, so 6.280.0's
    -- rule is satisfied by construction rather than by a safety net,
    -- and the tab list becomes a ledger of what went and what did not.
    --
    -- 🔑 THE RENAME IS THE MEMORY (6.281.0). A tab wearing the sent
    -- mark is skipped by every later send, so the 4 PM run cannot post
    -- yesterday's tasks again; a tab wearing the FAILED mark is
    -- retried, which is the only reason to mark a failure at all.
    -- 6.305.0 CORRECTS THE LINE THAT SAT HERE ("nothing else is
    -- remembered and nothing else has to be"): a retry re-parses the
    -- tab WHOLE, so everything in it that already reached Asana went
    -- again. What each task landed is remembered now, below.
    --
    -- =================================================================
    -- 🔁 6.305.0 — A RETRY MUST NOT RE-SEND WHAT ALREADY LANDED
    -- =================================================================
    -- LL's first unattended 16:00 run: "1 of 122 task(s) did not reach
    -- Asana … marked ❌ Error: tasks not sent". 121 of those tasks ARE
    -- in Asana. The mark is per TAB, and a ❌ tab is re-parsed WHOLE on
    -- the next run — so tomorrow would have posted all 121 again, and
    -- the day after 242, compounding daily until he happened to fix
    -- the one bad line. 6.301.0 wrote the rule four releases ago —
    -- "before deciding what a partial failure should report, ask what
    -- a RETRY would do; an error that causes a duplicate is worse than
    -- a warning that causes a correction" — and applied it only to
    -- subtasks. The tab mark was doing the thing that rule forbids.
    --
    -- 🚨 AND THE ✅ SIDE HAD THE SAME HOLE WITH NO FAILURE INVOLVED:
    -- typing in a tab clears its mark (sp.setText), and rightly — a ✅
    -- tab that could never be sent again would freeze his new writing
    -- out of the run. So editing ONE character in a sent tab re-armed
    -- every task in it. Two routes to a duplicate, one mechanism for
    -- both.
    --
    -- 🔑 THE MARK IS ABOUT THE TAB; THE RECORD IS ABOUT THE TASKS, and
    -- that separation is the whole design. Each task Asana ACCEPTS is
    -- remembered on its tab by a digest of WHAT IT SAYS — title,
    -- description, assignee, dates, subtasks — never by its position
    -- (6.186.0/6.272.0: an edit renumbers everything under his hand,
    -- so an index forgets a different task than the one that landed).
    -- The content key does double duty: an untouched line keeps its
    -- key and is skipped, an EDITED line has a new key and is
    -- correctly read as new work. Nothing of his text is changed and
    -- nothing is cleared — 6.300.0's design is untouched.
    --
    -- 🔢 COUNTED, NOT A SET. Two identical task lines in one tab are
    -- two tasks; a set would send the pair once and then skip both for
    -- ever, losing one silently. The record holds HOW MANY of each key
    -- landed and the selector is a multiset difference.

    -- PURE. FNV-1a over the bytes with the length mixed in, so a key
    -- is fixed-width ASCII hex. It becomes a JSON object key, and a
    -- truncated slice of his own text could cut a UTF-8 glyph in half
    -- and make the whole store unencodable — 6.204.0's rule about
    -- cutting in characters, in the one place where the answer is to
    -- not carry his characters at all.
    function sp.digest(s)
        s = tostring(s or "")
        local h = 2166136261
        for i = 1, #s do
            h = h ~ s:byte(i)
            h = (h * 16777619) & 0xFFFFFFFF
        end
        return ("%08x%x"):format(h, #s)
    end

    -- PURE. The dates, as one canonical string. Walked with pairs()
    -- rather than read field by field — a field name I get wrong here
    -- is a field that silently stops counting, and the walk cannot be
    -- wrong about one — and then SORTED, which is load-bearing across
    -- a RELOAD rather than within one run: Lua seeds its string hashes
    -- per state, so the order pairs() hands back can differ between
    -- processes, and an unsorted key would stop matching the one in
    -- the store. It is its own function so the sort can be ASSERTED;
    -- a two-field fixture cannot tell sorted from unsorted, because
    -- two tables holding the same two keys iterate the same way
    -- (6.230.0 — pick the input where the two must differ).
    function sp.canonWhen(when)
        local out = {}
        if type(when) == "table" then
            for k, v in pairs(when) do
                out[#out + 1] = tostring(k) .. "=" .. tostring(v)
            end
            table.sort(out)
        end
        return table.concat(out, "\1")
    end

    -- PURE. The canonical form of a task: everything that decides what
    -- Asana receives.
    function sp.taskKey(task)
        local t = type(task) == "table" and task or {}
        local subs = {}
        if type(t.subs) == "table" then
            for _, x in ipairs(t.subs) do subs[#subs + 1] = tostring(x) end
        end
        return sp.digest(table.concat({
            tostring(t.title or ""),
            tostring(t.desc or ""),
            tostring(t.assignee or ""),
            sp.canonWhen(t.when),
            table.concat(subs, "\1"),
        }, "\2"))
    end

    -- PURE. Given a tab's parsed tasks and what it has landed before,
    -- answers the tasks still to send and the ones already in Asana.
    function sp.tasksToSend(tasks, landed)
        local have, seen, send, done = {}, {}, {}, {}
        if type(landed) == "table" then
            for k, v in pairs(landed) do
                -- 🗑 TWO GUARDS WERE WRITTEN HERE AND TAKEN OUT AGAIN
                -- (6.199.0, third and fourth time, and the mutation sweep
                -- is what said so): an `n > 0` test and a math.floor. The
                -- comparison below counts with an INTEGER, so `seen <= n`
                -- and `seen <= floor(n)` can never disagree, and a 0 or a
                -- negative n already fails it. Neither guard could be
                -- killed by any mutation — a guard no test can fail is
                -- dead code with a comment on it. The RULE is still
                -- asserted; it is carried by `seen[k] <= have[k]`.
                have[k] = tonumber(type(v) == "table" and v.n or v) or 0
            end
        end
        for _, task in ipairs(type(tasks) == "table" and tasks or {}) do
            local k = sp.taskKey(task)
            seen[k] = (seen[k] or 0) + 1
            if seen[k] <= (have[k] or 0) then done[#done + 1] = task
            else send[#send + 1] = task end
        end
        return send, done
    end

    -- Records one landed task on its tab. BOUNDED: a tab edited for
    -- months keeps keys for lines no longer in it, and an unbounded
    -- map inside a store rewritten whole on every keystroke only
    -- grows. Past the cap the OLDEST row goes — and the eviction is
    -- COUNTED and said in the report, because a forgotten key is a
    -- task that can be sent twice, which is the one thing this release
    -- exists to stop (6.197.2: a bound that changes the answer is a
    -- state, never a footnote).
    function sp.noteLanded(tab, task, gid)
        if type(tab) ~= "table" then return end
        tab.landed = type(tab.landed) == "table" and tab.landed or {}
        local k = sp.taskKey(task)
        local row = tab.landed[k]
        if type(row) ~= "table" then row = { n = 0 }; tab.landed[k] = row end
        row.n     = (tonumber(row.n) or 0) + 1
        row.title = tostring((type(task) == "table" and task.title) or "")
        row.at    = os.time()
        if gid then row.gid = tostring(gid) end
        local n, oldest, oldK = 0, nil, nil
        for key, r in pairs(tab.landed) do
            n = n + 1
            local at = tonumber(type(r) == "table" and r.at) or 0
            if not oldest or at < oldest then oldest, oldK = at, key end
        end
        if n > (tonumber(sp.landedMax) or 400) and oldK then
            tab.landed[oldK] = nil
            sp.landedEvicted = (sp.landedEvicted or 0) + 1
        end
    end

    -- 📏 OPEN TABS ONLY, and that is a real narrowing from the day
    -- task, which also swept today's CLOSED rows. A closed row has no
    -- title to rewrite and no way to show him an answer, so sending
    -- one would be sending into silence. It is NAMED rather than
    -- dropped quietly (6.201.1): the report counts them and says so.
    function sp.sendTasks(reason)
        reason = reason or "manual"
        local now = os.time()
        local today = os.date("%Y-%m-%d", now)

        local jobs, alreadySent, noTasks, landedSkip = {}, 0, 0, 0
        for _, t in ipairs(sp.tabs) do
            if not t.kind and trim(t.text or "") ~= "" then
                if tostring(t.mark or "") == sp.sentMark then
                    alreadySent = alreadySent + 1
                else
                    local tasks = sp.parseTasks(t.text, now, sp.assignee)
                    local toSend, already = sp.tasksToSend(tasks, t.landed)
                    landedSkip = landedSkip + #already
                    if #toSend > 0 then
                        jobs[#jobs + 1] = { tab = t, tasks = toSend }
                    elseif #tasks > 0 then
                        -- 🔁 EVERY TASK IN THIS TAB IS ALREADY IN ASANA.
                        -- That is not "nothing to send", it is DONE — so
                        -- it wears the sent mark and stops being a ❌
                        -- retried for ever over one bad line he has since
                        -- fixed or deleted.
                        t.mark = sp.sentMark
                        alreadySent = alreadySent + 1
                    else
                        noTasks = noTasks + 1
                    end
                end
            end
        end
        local closedToday = 0
        for _, h in ipairs(sp.history or {}) do
            if not h.kind and trim(h.text or "") ~= ""
               and os.date("%Y-%m-%d", h.closedAt or 0) == today then
                closedToday = closedToday + 1
            end
        end
        sp.lastTaskSend = { at = now, reason = reason, tabs = #jobs,
                            alreadySent = alreadySent, noTasks = noTasks,
                            closedToday = closedToday, sent = 0, failed = 0,
                            landed = landedSkip }

        if #jobs == 0 then
            sp.lastSend = { at = now, reason = reason,
                            outcome = "nothing new to send" }
            sp.announce("skipped", landedSkip > 0
                        and (landedSkip .. " task(s) are already in Asana — "
                             .. "nothing new to send")
                        or (alreadySent > 0
                            and (alreadySent .. " tab(s) already sent")
                            or "nothing written today"), reason)
            return false, "nothing to send"
        end
        if not (core.asanaEnabled and _G.asanaSubmitTask) then
            for _, j in ipairs(jobs) do j.tab.mark = sp.failMark end
            pcall(sp.saveNow)
            sp.lastSend = { at = now, reason = reason,
                            outcome = "Asana is off on this Mac" }
            sp.announce("failed", "Asana is off on this Mac (secret.lua) — "
                        .. "the text is safe in " .. sp.file, reason)
            return false, "asana off"
        end

        -- 🔢 ONE COUNTER PER TAB AND ONE FOR THE RUN. A tab is marked
        -- when ITS tasks have all answered; the run announces when
        -- every tab has. Marking on the first answer would put a ✅ on
        -- a tab whose second task was still in flight.
        local openJobs, sentN, failN, lastWhy = #jobs, 0, 0, nil
        local subN, subBad = 0, 0
        local function runDone()
            sp.lastTaskSend.sent, sp.lastTaskSend.failed = sentN, failN
            sp.lastTaskSend.subs, sp.lastTaskSend.subFailed = subN, subBad
            pcall(sp.saveNow)
            if failN == 0 then
                sp.lastSend = { at = os.time(), reason = reason,
                                outcome = "sent · " .. sentN .. " task"
                                          .. (sentN == 1 and "" or "s") }
                sp.announce("sent", sentN .. " task" .. (sentN == 1 and "" or "s")
                            .. " from " .. #jobs .. " tab" .. (#jobs == 1 and "" or "s")
                            .. (subN > 0 and (" · " .. subN .. " subtask"
                                              .. (subN == 1 and "" or "s")) or "")
                            .. (subBad > 0 and (" · ⚠️ " .. subBad
                                                .. " subtask(s) refused") or "")
                            .. (landedSkip > 0 and (" · " .. landedSkip
                                                    .. " already in Asana, not sent again") or ""),
                            reason)
            else
                sp.lastSend = { at = os.time(), reason = reason,
                                outcome = failN .. " of " .. (sentN + failN)
                                          .. " task(s) refused" }
                sp.announce("failed", failN .. " of " .. (sentN + failN)
                            .. " task(s) did not reach Asana ("
                            .. tostring(lastWhy or "?") .. ") — every word is "
                            .. "still in the tab, marked " .. sp.failMark, reason)
            end
        end
        local function jobDone(job)
            job.tab.mark = (job.bad == 0) and sp.sentMark or sp.failMark
            openJobs = openJobs - 1
            if openJobs == 0 then runDone() end
        end

        for _, job in ipairs(jobs) do
            job.left, job.bad = #job.tasks, 0
            for _, task in ipairs(job.tasks) do
                local heard = false
                local function answer(ok, why, gid, info)
                    if heard then return end
                    heard = true
                    -- 🔁 6.305.0 — REMEMBERED ON THE ANSWER, never on
                    -- the ask: `asanaSubmitTask` returns the moment the
                    -- POST is fired (6.299.0), so recording it there
                    -- would mark a refused task as landed and lose it
                    -- from every future retry.
                    if ok then sentN = sentN + 1
                         pcall(sp.noteLanded, job.tab, task, gid)
                    else failN = failN + 1 ; job.bad = job.bad + 1
                         lastWhy = why end
                    -- 🗂 6.301.0 — the S: lines. A refused subtask does
                    -- NOT fail its task: the parent is already in Asana
                    -- and a retry would put a second copy of it on his
                    -- board. It is counted, said in the announce and
                    -- alerted by the submit itself at the moment it
                    -- happens.
                    if type(info) == "table" then
                        subN  = subN + (tonumber(info.subs) or 0)
                        subBad = subBad + (tonumber(info.subFail) or 0)
                    end
                    job.left = job.left - 1
                    if job.left == 0 then jobDone(job) end
                end
                local w = sp.whenForAsana(task.when)
                local okCall, err = pcall(_G.asanaSubmitTask, task.title,
                                          task.desc or "", task.assignee or sp.assignee, "", {
                    startDate = w.startDate, startTime = w.startTime,
                    dueDate   = w.dueDate,   dueTime   = w.dueTime,
                    comment   = sp.comment,
                    subtasks  = task.subs,
                    onDone    = function(ok, why, gid, info)
                        answer(ok, why, gid, info)
                    end,
                })
                -- 🚨 A SUBMIT THAT RAISES ANSWERS NOBODY, and one tab
                -- left un-marked would hold the whole run open — no
                -- announce, no ✅, no ❌, for ever.
                if not okCall then answer(false, "the Asana submit threw — "
                                          .. tostring(err)) end
            end
        end
        return true, sentN .. " task(s) posted"
    end

    -- 🚪 ONE DOOR, TWO SENDS. Every caller — the button, the 4 PM
    -- timer, the service and the Console — goes through here, so the
    -- switch is real in both directions rather than reachable from one
    -- of them (6.228.0's lesson about a flag nobody reads).
    function sp.send(reason)
        if sp.sendGrammar then return sp.sendTasks(reason) end
        return sp.sendDay(reason)
    end
    _G.scratchPadSend = function() return sp.send("manual") end

    -- 🗂 6.297.0 — THE PREVIEW. Every tab this would read, every task
    -- it found, and every line it could not. Nothing is sent.
    --
    -- 🔎 IT PRINTS WHAT IT UNDERSTOOD, not what it will do, and that is
    -- the whole point of shipping it first: his grammar is ground this
    -- config has not touched, only he knows what he will really type,
    -- and 6.237.0's habit says the first release on new ground is the
    -- one that shows what the Mac actually answered (6.201.0 — get the
    -- artefact before building on a belief).
    function sp.taskPreview(now)
        local L = { "🗂 HAMSIDIAN → ASANA — what \"Asana now\" WOULD send" }
        -- 🗂 6.300.0 — it SENDS now, so the preview says which send is
        -- armed rather than describing the one it used to be.
        if sp.sendGrammar then
            L[#L + 1] = "   sends   : ONE ASANA TASK PER TASK BELOW, into your "
                        .. "default project. Nothing here has been sent yet."
            L[#L + 1] = "   marks   : each tab is then retitled \"" .. sp.sentMark
                        .. "\" or \"" .. sp.failMark .. "\" and KEPT until you "
                        .. "delete it; a ✅ tab is never sent twice."
        else
            L[#L + 1] = "   today   : ONE task for the whole day (title + every tab "
                        .. "as its description) — sendGrammar is off."
            L[#L + 1] = "   below   : what the grammar reads out of the same "
                        .. "tabs. NOTHING here would be sent."
        end
        local total, probs = 0, 0
        for _, t in ipairs(sp.tabs or {}) do
            local body = tostring(t.text or "")
            if body:gsub("%s", "") ~= "" and not t.kind then
                local tasks, problems = sp.parseTasks(body, now, sp.assignee)
                -- 🔁 6.305.0 — ONE FUNCTION, TWO CALLERS (6.231.0). The
                -- preview asks the same selector the send asks, or it
                -- would promise tasks the send will correctly skip.
                local _, already = sp.tasksToSend(tasks, t.landed)
                local landedKeys = {}
                for _, k in ipairs(already) do
                    landedKeys[sp.taskKey(k)] = (landedKeys[sp.taskKey(k)] or 0) + 1
                end
                L[#L + 1] = ""
                L[#L + 1] = "   📝 " .. tostring(sp.titleOf(t)) .. " — "
                            .. #tasks .. " task(s)"
                            .. (#already > 0 and ("  (" .. #already
                                .. " already in Asana — not sent again)") or "")
                            .. (tostring(t.mark or "") == sp.sentMark
                                and "  (already sent — this tab is skipped)" or "")
                for i, k in ipairs(tasks) do
                    total = total + 1
                    local kk = sp.taskKey(k)
                    local done = (landedKeys[kk] or 0) > 0
                    if done then landedKeys[kk] = landedKeys[kk] - 1 end
                    L[#L + 1] = ("      %d. %s"):format(i, k.title)
                                .. (done and "   ✅ already in Asana — not sent again" or "")
                    -- A task Asana already holds is named and nothing
                    -- else: its dates and subtasks describe a send that
                    -- is not going to happen (6.196.1 — "would send" and
                    -- "already sent" must not read alike).
                    if not done then
                    if k.assignee ~= "" then
                        L[#L + 1] = "         👤 " .. k.assignee
                    end
                    if k.desc ~= "" then
                        L[#L + 1] = "         📄 " .. k.desc:gsub("\n", " ⏎ "):sub(1, 90)
                    end
                    for _, sub in ipairs(k.subs) do
                        L[#L + 1] = "         ↳ " .. sub
                    end
                    -- 📅 SHOWN AS ASANA WILL RECEIVE IT, not as the line
                    -- was typed: `T: today` is a start date with no end,
                    -- which Asana refuses outright, so the preview that
                    -- printed the parse would promise a task that cannot
                    -- exist. Every adjustment is NAMED under the row.
                    local w, notes = sp.whenForAsana(k.when)
                    if w.startDate or w.dueDate or w.startTime or w.dueTime then
                        L[#L + 1] = ("         📅 start %s %s · due %s %s"):format(
                            w.startDate or "—", w.startTime or "", w.dueDate or "—", w.dueTime or "")
                    end
                    for _, note in ipairs(notes) do
                        L[#L + 1] = "         ↳ " .. note
                    end
                    -- 🗂 6.301.0 — they GO now, as real Asana subtasks
                    -- under this task. Said beside the row rather than
                    -- in a footnote, and the one caveat is said with
                    -- it, because it is the one that can lose a line.
                    if #k.subs > 0 then
                        L[#L + 1] = "         ↳ " .. #k.subs .. " subtask(s) sent "
                                    .. "under this task · a refused one does NOT "
                                    .. "fail the task (retrying would duplicate it)"
                    end
                    end
                end
                for _, why in ipairs(problems) do
                    probs = probs + 1
                    L[#L + 1] = "      ⚠️ " .. why
                end
            end
        end
        if total == 0 then
            L[#L + 1] = ""
            L[#L + 1] = "   nothing to send — no open tab holds text "
                        .. "(a 🗒 Capture or ➕ Append tab is never swept in)"
        else
            L[#L + 1] = ""
            L[#L + 1] = ("   TOTAL   : %d task(s)%s"):format(total,
                probs > 0 and (" · ⚠️ " .. probs .. " line(s) it could not read") or "")
        end
        L[#L + 1] = "   grammar : a bare line is a task · = divides · P: title · "
                    .. "A: assignee · D: description · S: subtask · T: dates"
        local out = table.concat(L, "\n")
        print(out)
        return out
    end
    _G.scratchPadTasks = function(now) return sp.taskPreview(now) end

    -- ---- the page -------------------------------------------------------------
    local function escapeHtml(s)
        return (tostring(s or ""):gsub("&", "&amp;"):gsub("<", "&lt;")
                :gsub(">", "&gt;"):gsub('"', "&quot;"))
    end
    local function jstr(s)
        s = tostring(s or "")
        s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "")
             :gsub("</", "<\\/")
        return '"' .. s .. '"'
    end

    function sp.historyJson()
        local rows = {}
        for i = 1, math.min(#sp.history, sp.historyRows) do
            local h = sp.history[i]
            local k = h.kind and sp.kinds[h.kind]
            rows[#rows + 1] = "{id:" .. jstr(h.id) .. ",t:" .. jstr((k and (k.badge .. " ") or "") .. (h.title or "Untitled"))
                .. ",w:" .. jstr(os.date("%b %d %H:%M", h.closedAt or 0))
                .. ",p:" .. jstr(oneLine(h.text):sub(1, sp.previewChars)) .. "}"
        end
        return "[" .. table.concat(rows, ",") .. "]"
    end

    function sp.buildHtml()
        local cur = sp.activeTab() or sp.newTab("")
        local tabsHtml = {}
        for i, t in ipairs(sp.tabs) do
            tabsHtml[#tabsHtml + 1] = '<div class="tab' .. (t.kind and (" " .. t.kind) or "") .. (t.id == cur.id and " on" or "")
                .. '" data-id="' .. escapeHtml(t.id) .. '"><span class="tt">'
                .. (sp.kindOf(t) and (sp.kindOf(t).badge .. " ") or "")
                .. escapeHtml(sp.titleOf(t)) .. '</span><span class="x" title="Close ⌘W">×</span></div>'
        end
        local theme = (_G.uiStyle and _G.uiStyle.cssOverride and _G.uiStyle.cssOverride()) or ""
        -- 6.171.2 — one number sizes the page: text at sp.fontSize, chrome 2–3 pt under it.
        local fs = tonumber(sp.fontSize) or 16
        if fs < 8 then fs = 8 end
        local function sized(html)
            return (html:gsub("FS1px", math.floor(fs - 2) .. "px"):gsub("FS2px", math.floor(fs - 3) .. "px")
                        :gsub("FSpx", math.floor(fs) .. "px"))
        end
        return sized([[<!doctype html><html><head><meta charset="utf-8"><style>
:root{color-scheme:dark}
html,body{margin:0;height:100%;background:#141418;color:#e8e8ec;font-family:-apple-system,Helvetica,sans-serif;font-size:FSpx;overflow:hidden}
#wrap{display:flex;flex-direction:column;height:100%}
header{display:flex;align-items:center;gap:8px;padding:6px 10px;background:#1c1c22;cursor:grab;user-select:none;-webkit-user-select:none}
header.dragging{cursor:grabbing}
header .grip{opacity:.5}
header .name{font-weight:600;flex:1}
header .hint{opacity:.55;font-size:FS2px}
header button{background:#2a2a33;color:#e8e8ec;border:0;border-radius:6px;padding:3px 8px;font-size:FS1px;cursor:pointer}
header button.pin.on{background:#4a7fe0;color:#fff}
header .bad{background:#7a2a2a;color:#ffd9d9;border-radius:6px;padding:3px 8px;font-size:FS2px}
#tabs{display:flex;gap:4px;padding:6px 8px 0;background:#18181d;overflow-x:auto}
.tab{display:flex;align-items:center;gap:6px;padding:4px 8px;border-radius:6px 6px 0 0;background:#202027;max-width:180px;cursor:default}
.tab.on{background:#3a3a48;box-shadow:inset 0 -3px 0 #4a7fe0;color:#fff}
.tab.capture{background:#1f2a33}.tab.capture.on{background:#2b3f4d;box-shadow:inset 0 -3px 0 #4fb3d9}
.tab.append{background:#2f2a1c}.tab.append.on{background:#4a4024;box-shadow:inset 0 -3px 0 #e0b04a}
.tab .tt{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tab .x{opacity:.5;cursor:pointer;padding:0 2px}
.tab .x:hover{opacity:1}
.tab.add{padding:4px 10px;opacity:.7;cursor:pointer}
textarea{flex:1;margin:0;padding:10px;border:0;outline:0;resize:none;background:#141418;color:#e8e8ec;
  font-family:Menlo,monospace;font-size:FSpx;line-height:1.45;font-weight:normal;font-style:normal}
#hist{height:34%;min-height:96px;display:flex;flex-direction:column;border-top:1px solid #2a2a33;background:#17171c}
#hist .bar{display:flex;align-items:center;gap:8px;padding:5px 10px}
#hist .bar .lab{opacity:.6;font-size:FS2px;letter-spacing:.04em}
#hist input{flex:1;background:#202027;border:1px solid #2a2a33;border-radius:6px;color:#e8e8ec;padding:3px 8px;font-size:FS1px;outline:0}
#hist input:focus{border-color:#4a7fe0}
#rows{overflow-y:auto;flex:1}
.row{display:flex;gap:10px;padding:4px 10px;cursor:pointer;border-bottom:1px solid #1f1f26}
.row:hover{background:#202027}
.row.sel{background:#2a2f45;outline:1px solid #7aa2f7}
.row .w{opacity:.5;white-space:nowrap;font-size:FS2px;min-width:86px}
.row .t{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:40%}
.row .p{opacity:.65;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.empty{opacity:.45;padding:8px 10px;font-size:FS1px}
]] .. theme .. [[</style></head><body><div id="wrap">
<header id="bar"><span class="grip">⠿</span><span class="name">📝 Hamsidian</span>
<span class="hint">]] .. escapeHtml(sp.kindOf(cur) and sp.kindOf(cur).hint or "⌘T new · ⌘W close · ⌃Tab cycle · Esc") .. [[</span>
]] .. (sp.lastSaveErr and ('<span class="bad" title="' .. escapeHtml(sp.lastSaveErr) .. '">⚠ not saved</span>') or "") .. [[
<button class="pin]] .. (sp.pinned and " on" or "") .. [[" id="pin" title="Pin: the pad stays up beside the app; Esc only hands the keyboard back">📌 ]] .. (sp.pinned and "Pinned" or "Pin") .. [[</button>
<button id="send" title="Create today's Asana task now instead of waiting for 16:00">→ Asana now</button>
<button id="close" title="Close (⇪1)">✕</button></header>
<div id="tabs">]] .. table.concat(tabsHtml) .. [[<div class="tab add" id="add" title="New tab ⌘T">+</div></div>
<textarea id="t" spellcheck="false" autocorrect="off" autofocus>]] .. escapeHtml(cur.text) .. [[</textarea>
<div id="hist"><div class="bar"><span class="lab">HISTORY</span><input id="q" spellcheck="false" autocorrect="off" placeholder="filter closed tabs…" value="]] .. escapeHtml(sp.filter) .. [["><span class="lab" id="cnt"></span></div><div id="rows"></div></div>
</div><script>
var ROWS = ]] .. sp.historyJson() .. [[;
var t = document.getElementById('t'), q = document.getElementById('q');
var ACTIVE = ]] .. jstr(cur.id) .. [[;
var CARET = ]] .. tostring(tonumber(sp.caret) or 0) .. [[;
function say(m){ m.text = t.value; m.sel = t.selectionStart; m.id = ACTIVE;
  try { window.webkit.messageHandlers.scratchPad.postMessage(m); } catch(e){} }
function esc(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
function draw(){
  var f = q.value.toLowerCase(), out = [], n = 0;
  for (var i = 0; i < ROWS.length; i++) { var r = ROWS[i];
    if (f && (r.t + ' ' + r.p).toLowerCase().indexOf(f) < 0) continue;
    n++; out.push('<div class="row" data-id="' + esc(r.id) + '"><span class="w">' + esc(r.w)
      + '</span><span class="t">' + esc(r.t) + '</span><span class="p">' + esc(r.p) + '</span></div>'); }
  document.getElementById('rows').innerHTML = out.length ? out.join('') :
    '<div class="empty">' + (ROWS.length ? 'nothing matches' : 'closed tabs land here — ⌘W') + '</div>';
  document.getElementById('cnt').textContent = n + ' / ' + ROWS.length;
}
draw();
q.addEventListener('input', function(){ SEL = -1; draw(); });
t.addEventListener('input', function(){ say({a:'edit'}); });
document.getElementById('rows').addEventListener('click', function(e){
  var el = e.target.closest('.row'); if (el) say({a:'restore', rid: el.getAttribute('data-id')}); });
document.getElementById('tabs').addEventListener('click', function(e){
  var x = e.target.closest('.x'); var tab = e.target.closest('.tab');
  if (e.target.id === 'add' || (tab && tab.id === 'add')) { say({a:'new'}); return; }
  if (!tab) return;
  if (x) say({a:'close', tid: tab.getAttribute('data-id')});
  else if (tab.getAttribute('data-id') !== ACTIVE) say({a:'switch', tid: tab.getAttribute('data-id')}); });
document.getElementById('pin').addEventListener('click', function(){ say({a:'pin'}); });
document.getElementById('send').addEventListener('click', function(){ say({a:'send'}); });
document.getElementById('close').addEventListener('click', function(){ say({a:'hide'}); });
var hdr = document.getElementById('bar');
hdr.addEventListener('mousedown', function(e){ if (e.button !== 0 || e.target.tagName === 'BUTTON') return;
  e.preventDefault(); hdr.classList.add('dragging'); say({a:'dragStart'}); });
window.addEventListener('mouseup', function(){ hdr.classList.remove('dragging'); });
document.addEventListener('keyup', function(e){
  if (e.key === 'F18' || e.keyCode === 79) say({a:'f18up'}); });

// ⌨️ 6.170.0 — ARROW THROUGH THE ROWS. LL: "in any window that has a
// list, we need to be able to arrow up and down." ⌥↑ / ⌥↓ always move
// the highlight; plain ↑ / ↓ do too whenever the caret is NOT in the
// text box (the text box keeps its own arrows). ⏎ (⌥⏎ from the text
// box) acts on the highlighted row. Every DOM call is guarded so a
// page without rows, or a test shim without a DOM, never throws.
var SEL = -1, ROWSEL = '#rows .row';
function rowsList(){ try { return Array.prototype.slice.call(document.querySelectorAll(ROWSEL)); } catch(e){ return []; } }
function inText(){ var a = null; try { a = document.activeElement; } catch(e){} return !!(a && a.tagName === 'TEXTAREA'); }
function moveSel(d){
  var rows = rowsList(); if (!rows.length) return false;
  var from = SEL < 0 ? (d > 0 ? -1 : rows.length) : SEL;
  SEL = Math.max(0, Math.min(rows.length - 1, from + d));
  for (var i = 0; i < rows.length; i++) { try { if (i === SEL) rows[i].classList.add('sel'); else rows[i].classList.remove('sel'); } catch(e){} }
  try { rows[SEL].scrollIntoView({ block: 'nearest' }); } catch(e){}
  return true;
}
function selRow(){ var rows = rowsList(); return (SEL >= 0 && SEL < rows.length) ? rows[SEL] : null; }
function rowKey(e){
  var arrow = e.key === 'ArrowDown' ? 1 : (e.key === 'ArrowUp' ? -1 : 0);
  if (arrow && (e.altKey || !inText())) { e.preventDefault(); moveSel(arrow); return true; }
  if (e.key === 'Enter' && !e.metaKey && (e.altKey || !inText())) {
    var r = selRow(); if (r) { e.preventDefault(); rowAct(r); return true; }
  }
  return false;
}
// ⏎ on a highlighted history row restores it (a click does the same).
function rowAct(r){ say({a:'restore', rid: r.getAttribute('data-id')}); }
document.addEventListener('keydown', function(e){
  var meta = e.metaKey || e.ctrlKey;
  if (e.key === 'Escape') { e.preventDefault(); say({a:'esc'}); return; }
  if (rowKey(e)) return;
  if (meta && (e.key === 't' || e.key === 'T')) { e.preventDefault(); say({a:'new'}); return; }
  if (meta && (e.key === 'w' || e.key === 'W')) { e.preventDefault(); say({a:'close', tid: ACTIVE}); return; }
  if (meta && e.key >= '1' && e.key <= '9') { e.preventDefault(); say({a:'nth', n: e.key}); return; }
  if (e.ctrlKey && e.key === 'Tab') { e.preventDefault(); say({a:'cycle', d: e.shiftKey ? -1 : 1}); return; }
  if (meta && e.shiftKey && (e.key === 's' || e.key === 'S')) { e.preventDefault(); say({a:'export'}); return; }
  if (meta && (e.key === 'f' || e.key === 'F')) { e.preventDefault(); q.focus(); q.select(); return; }
});
t.focus(); try { t.setSelectionRange(CARET, CARET); } catch(e){}
</script></body></html>]])
    end

    function sp.render()
        if not sp.webview then return end
        pcall(function() sp.webview:html(sp.buildHtml()) end)
    end

    -- ---- messages from the page ----------------------------------------------
    local function handleMessage(body)
        if type(body) ~= "table" then return end
        -- The text rides on EVERY message: whatever the action, the draft
        -- is in Lua before anything else happens.
        if body.id and body.text ~= nil then sp.setText(body.id, body.text) end
        sp.caret = tonumber(body.sel) or 0
        local a = body.a
        if a == "edit" then
            return
        elseif a == "new" then
            if sp.newTab("") then sp.caret = 0; sp.render() end
        elseif a == "close" then
            if sp.closeTab(tostring(body.tid or "")) then sp.caret = 0; sp.render() end
        elseif a == "switch" then
            if sp.findTab(tostring(body.tid or "")) then
                sp.active = tostring(body.tid); sp.caret = 0; sp.scheduleSave(); sp.render()
            end
        elseif a == "cycle" then
            -- ⌃Tab / ⌃⇧Tab (6.166.0) — round the tabs, wrapping
            local n = #sp.tabs
            if n > 1 then
                local _, i = sp.findTab(sp.active)
                local d = (tonumber(body.d) or 1) < 0 and -1 or 1
                local j = ((i or 1) - 1 + d) % n + 1
                sp.active = sp.tabs[j].id; sp.caret = 0; sp.scheduleSave(); sp.render()
            end
        elseif a == "nth" then
            local t = sp.tabs[tonumber(body.n) or 0]
            if t and t.id ~= sp.active then sp.active = t.id; sp.caret = 0; sp.scheduleSave(); sp.render() end
        elseif a == "restore" then
            if sp.restore(tostring(body.rid or "")) then sp.caret = 0; sp.render() end
        elseif a == "pin" then
            sp.pinned = not sp.pinned
            sp.saveNow()
            sp.render()
            pcall(function() hs.alert.show(sp.pinned and "📌 Pinned — Esc hands the keys back, ⇪1 closes"
                                           or "📌 Unpinned", 1.5) end)
        elseif a == "export" then
            local ok, summary = sp.exportAll("⌘⇧S")
            pcall(function() hs.alert.show((ok and "📤 Exported — " or "📤 ") .. tostring(summary), 4) end)
        elseif a == "send" then
            local ok, why = sp.send("button")
            if not ok then pcall(function() hs.alert.show("📝 Not sent — " .. tostring(why), 2) end) end
        elseif a == "esc" then
            if sp.pinned then sp.blur() else sp.hide() end
        elseif a == "hide" then
            sp.hide()
        elseif a == "dragStart" then
            sp.beginDrag()
        elseif a == "f18up" then
            if _G.hyperReleaseSeen then pcall(_G.hyperReleaseSeen, "the scratch pad") end
        end
    end
    sp.handleMessage = handleMessage   -- exposed for the test suite

    -- ---- dragging (Lua polls the mouse; JS mousemove dies past the edge) ----
    local function mousePosition()
        if type(hs.mouse) ~= "table" then return nil end
        for _, name in ipairs({ "absolutePosition", "getAbsolutePosition" }) do
            local fn = hs.mouse[name]
            if type(fn) == "function" then
                local ok, p = pcall(fn)
                if ok and type(p) == "table" and p.x and p.y then return p end
            end
        end
        return nil
    end
    local function leftButtonDown()
        local ok, btns = pcall(hs.eventtap.checkMouseButtons)
        if not ok or type(btns) ~= "table" then return false end
        return btns.left == true or btns[1] == true
    end
    function sp.endDrag()
        if sp.dragTimer then pcall(function() sp.dragTimer:stop() end); sp.dragTimer = nil end
        sp.dragOffset = nil
    end
    function sp.beginDrag()
        if not sp.webview then return end
        local okF, f = pcall(function() return sp.webview:frame() end)
        if not (okF and type(f) == "table") then return end
        local m = mousePosition()
        if not m then return end
        sp.endDrag()
        sp.dragOffset = { x = m.x - f.x, y = m.y - f.y }
        sp.dragTimer = hs.timer.doEvery(0.016, function()
            if not (sp.webview and sp.dragOffset) then sp.endDrag() return end
            if not leftButtonDown() then sp.endDrag() return end
            local p = mousePosition()
            if not p then sp.endDrag() return end
            pcall(function()
                local cur = sp.webview:frame()
                sp.webview:frame({ x = p.x - sp.dragOffset.x, y = p.y - sp.dragOffset.y,
                                   w = cur.w, h = cur.h })
            end)
        end)
    end

    -- ---- the window -------------------------------------------------------------
    function sp.applyNonActivating(view)
        if not view then return false, "there is no window" end
        local masks = hs.webview and hs.webview.windowMasks
        local bit   = type(masks) == "table" and masks.nonactivating or nil
        if type(bit) ~= "number" or bit < 1 then
            return false, "this Hammerspoon has no nonactivating window mask"
        end
        local function isSet(v) return (math.floor(v / bit) % 2) == 1 end
        local okGet, cur = pcall(function() return view:windowStyle() end)
        if not (okGet and type(cur) == "number") then return false, "the window style could not be read" end
        if not isSet(cur) then
            local okSet = pcall(function() view:windowStyle(cur + bit) end)
            if not okSet then return false, "the window style was rejected" end
        end
        local okRe, now = pcall(function() return view:windowStyle() end)
        if not (okRe and type(now) == "number") then return false, "the window style could not be read back" end
        if not isSet(now) then return false, "macOS dropped the mask" end
        return true, "applied"
    end

    function sp.isOpen() return sp.webview ~= nil end

    -- Pinned + Esc: the pad stays; the keyboard goes back to the app.
    -- Hiding and re-showing the same window is the only focus hand-off a
    -- non-activating panel has that touches no other app's windows.
    function sp.blur()
        if not sp.webview then return end
        pcall(function() sp.webview:hide() end)
        pcall(function() sp.webview:show() end)
    end

    function sp.hide()
        local host = sp.host()
        if not sp.webview and host and host.webview then host.hide() return end
        sp.endDrag()
        -- The old pads filed on close; their tabs still do. A failure
        -- keeps that tab (and the text) for next time.
        for i = #sp.tabs, 1, -1 do
            local t = sp.tabs[i]
            if sp.kindOf(t) then sp.closeTab(t.id) end
        end
        if sp.webview then
            pcall(function() sp.webview:delete() end)
            sp.webview = nil
        end
        sp.uc = nil
        if sp.dirty then sp.saveNow() end
        say("pad closed")
    end

    -- No webview must not mean no scratch space: the plain prompt edits
    -- the active tab and saves it the same way.
    local function promptFallback()
        local cur = sp.activeTab() or sp.newTab("")
        local okP, button, typed = pcall(hs.dialog.textPrompt, "Hamsidian",
            "No web view on this Hammerspoon — this box edits the current tab.",
            cur.text or "", "Save", "Cancel")
        if not okP or button ~= "Save" then return end
        sp.setText(cur.id, typed)
        sp.saveNow()
    end

    function sp.show()
        if not sp.enabled then return end
        if sp.webview then sp.hide() return end
        local host = sp.host()
        if host then return host.toggleScratch() end
        return sp.open()
    end

    -- ⇪N / ⇪2 land here: one tab of that kind, made active, the pad up.
    -- opts.text replaces the tab's text; opts.prefix seeds an empty one.
    function sp.openKind(kind, opts)
        if not sp.kinds[kind] then return false end
        opts = opts or {}
        local t
        for _, x in ipairs(sp.tabs) do if x.kind == kind then t = x break end end
        if not t then t = sp.newTab("", kind) end
        if not t then return false end
        if opts.text ~= nil then t.text = tostring(opts.text) end
        if opts.prefix ~= nil and trim(t.text) == "" then t.text = tostring(opts.prefix) end
        t.updatedAt = os.time()
        sp.active, sp.caret = t.id, #t.text
        sp.scheduleSave()
        local host = sp.host()
        if host and not sp.webview then host.showScratch(t.id) return true end
        if sp.webview then sp.render() else sp.open() end
        return true
    end

    -- =====================================================================
    -- 📎 SEQUENTIAL COPY (6.182.0, ⇪2 — rebuilt 6.201.0)
    -- =====================================================================
    -- LL: "Can I select some text, and then immediately select some more
    -- text and have it append the text I just copied a few seconds before
    -- … so I can build a block of text that I can then edit quickly
    -- instead of having to make multiple copy/pastes to gather all the
    -- info."
    --
    -- 🚨 6.201.0 — ⌘V NEVER PASTED WHAT HE HAD JUST GRABBED. Until now
    -- each press appended the selection to a 📎 Collect TAB in the pad and
    -- put `t.text` — THE WHOLE TAB — on the clipboard. That tab is
    -- remembered in the store (sp.collectId) and was never emptied, so the
    -- block grew for as long as LL owned the feature; the COUNT beside it
    -- was not remembered (sp.collectCount, a plain 0 reset by every
    -- reload), so the alert said "1 grab" over a clipboard holding months
    -- of text. LL pasted the proof: the literal word "Collect", then every
    -- grab he had ever made, with the two from that minute at the very
    -- bottom. He also said he had no idea anything was being filed into
    -- the pad at all. His decision: "I'd like copy1, copy to be retained.
    -- And put on the clipboard, not into Scorp Pad."
    --
    -- 🔎 AND THE DIAGNOSIS THAT WAS WRONG, kept because the method matters.
    -- This was blamed on the borrowed clipboard first — 6.198.0 shipped a
    -- guard so pt.copySelection's restore could not land on the caller's
    -- own write. That guard is real and it works (LL's report: 10 borrows
    -- left alone, 0 put back). It was never this bug. What was never
    -- checked, through two releases, was the ONE question that settles a
    -- clipboard complaint: what does ⌘V actually paste? Ask for the
    -- artefact before theorising about the mechanism.
    --
    -- So the sequence lives in MEMORY and nothing here touches a tab, the
    -- store, the 4 PM task or the export. LL's existing Collect tab is left
    -- exactly where it is — it is his text, and this release stops feeding
    -- it, it does not delete it.
    --
    -- 🔑 THE RESET RULE, LL's choice of the three offered: COPYING ANYTHING
    -- ELSE STARTS A NEW SEQUENCE. Nothing else marks where one run of grabs
    -- ends, and a sequence that never ends is the bug above with a shorter
    -- memory. We know the change counter we last wrote, so a counter that
    -- has moved means somebody else copied and the next ⇪2 starts clean.
    --
    -- 🪟 IT NEVER RAISES THE WINDOW. The whole point is that you stay in
    -- the page you are reading; an alert names the running count instead.
    --
    -- 🛟 DEGRADES: no power_tools → it says the selection cannot be read
    -- and does nothing. A pasteboard that refuses the write is REPORTED,
    -- not swallowed, and the grabs STAY in the sequence — the next press
    -- carries them all, so a refused write costs a paste, never a grab.
    sp.collectTitle = "Collect"  -- the old tab's name; the report still points at it
    sp.collectJoin  = "\n\n"     -- between grabs; a settings override changes it
    sp.collectId    = nil        -- 6.182.0's tab, still remembered so the report can name it
    sp.collectSeq   = {}         -- the grabs in the CURRENT sequence, in order
    sp.collectCount = 0          -- #sp.collectSeq, kept beside it for the alert
    sp.collectMark  = nil        -- the pasteboard change counter we last wrote
    sp.collectLast  = nil        -- the block we last wrote, for the degrade below
    sp.collectResets = 0         -- sequences ended because something else copied
    sp.collectWhy   = "nothing grabbed yet"

    -- 🔑 IS THE CLIPBOARD STILL THE ONE WE LEFT? Pure, and it is the whole
    -- reset rule. The change counter is asked FIRST because it sees the two
    -- writes a comparison never can — the same text copied again, and
    -- anything that is not text. The CONTENTS are the degrade, for a
    -- Hammerspoon that cannot answer changeCount.
    --
    -- 🚨 NEITHER READABLE MEANS "NOT OURS" — the OPPOSITE default to
    -- pt.borrowIntact, deliberately. There the last resort has to be
    -- 6.132.0's promise that your clipboard comes back; here it has to be
    -- the promise this release exists to make, that ⌘V never pastes
    -- something you did not just grab. Each default protects the thing its
    -- own feature would otherwise destroy, and neither is a house style.
    function sp.collectContinues(markNow, textNow)
        if type(sp.collectMark) == "number" and type(markNow) == "number" then
            return markNow == sp.collectMark
        end
        if type(sp.collectLast) == "string" and type(textNow) == "string" then
            return textNow == sp.collectLast
        end
        return false
    end

    -- Start a fresh sequence, saying why. ONE place decides, so "how many
    -- grabs did that drop" is answered rather than guessed at.
    function sp.collectReset(why)
        local had = #sp.collectSeq
        sp.collectSeq, sp.collectCount = {}, 0
        sp.collectLast, sp.collectMark = nil, nil
        sp.collectWhy = why or "reset"
        if had > 0 then sp.collectResets = (sp.collectResets or 0) + 1 end
        return had
    end

    -- text → ok, block-or-why. PURE now — no tab, no store, no window, no
    -- alert — which is why the whole rule can be proven without a Mac.
    function sp.collect(text)
        text = trim(text)
        if text == "" then return false, "nothing was selected" end
        sp.collectSeq[#sp.collectSeq + 1] = text
        sp.collectCount = #sp.collectSeq
        return true, table.concat(sp.collectSeq, tostring(sp.collectJoin or "\n\n"))
    end

    function sp.open()
        if not sp.enabled then return end
        if sp.webview then return end
        if not (hs.webview and hs.webview.usercontent) then promptFallback() return end
        if #sp.tabs == 0 then sp.newTab("") end

        local screen = hs.screen.mainScreen and hs.screen.mainScreen()
        local sf = screen and screen:frame() or { x = 0, y = 0, w = 1440, h = 900 }
        local w = math.min(sp.width, sf.w - 40)
        local h = math.min(sp.height, sf.h - 40)
        local rect = { x = sf.x + (sf.w - w) / 2, y = sf.y + (sf.h - h) / 3, w = w, h = h }
        if sp.pos and _G.clampToScreen then
            local okC, p = pcall(_G.clampToScreen, sp.pos, w, h)
            if okC and type(p) == "table" then rect.x, rect.y = p.x, p.y end
        end

        local okUc, uc = pcall(hs.webview.usercontent.new, "scratchPad")
        if not (okUc and uc) then promptFallback() return end
        sp.uc = uc     -- HELD: collect this and the JS bridge goes quiet
        pcall(function()
            uc:setCallback(function(msg)
                local ok, err = pcall(handleMessage, msg and msg.body)
                if not ok then print("📝 Hamsidian: message handler — " .. tostring(err)) end
            end)
        end)
        local okV, view = pcall(hs.webview.new, rect, {}, uc)
        if not (okV and view) then sp.uc = nil; promptFallback() return end
        sp.webview = view
        pcall(function() view:windowTitle("Hamsidian") end)
        pcall(function() view:allowTextEntry(true) end)
        pcall(function() view:closeOnEscape(false) end)
        pcall(function() view:level(hs.drawing.windowLevels.floating) end)
        -- 6.171.0 — the window itself is translucent (LL: 35%); the page keeps its own colours.
        if type(sp.alpha) == "number" and sp.alpha > 0 and sp.alpha < 1 then
            pcall(function() view:alpha(sp.alpha) end)
        end
        pcall(function() view:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" }) end)
        sp.nonActivatingApplied, sp.nonActivatingWhy = false, "not requested"
        if sp.nonActivating then
            sp.nonActivatingApplied, sp.nonActivatingWhy = sp.applyNonActivating(view)
            if not sp.nonActivatingApplied then
                print("📝 Hamsidian: non-activating panel unavailable — "
                      .. tostring(sp.nonActivatingWhy) .. "; opening the pad will bring Hammerspoon forward.")
            end
        end
        sp.render()
        pcall(function() view:show() end)
        if sp.focusOnOpen then pcall(function() view:bringToFront(true) end) end
        -- 6.165.1 — this pad has the keyboard now; nobody holds ⇪ through
        -- that. If the F18 keyUp was lost on the way in, the watchdog
        -- lets go after 1.5 s of silence instead of 8.
        if _G.hyperExpectRelease then pcall(_G.hyperExpectRelease, 1.5, "the scratch pad") end
        sp.opens = sp.opens + 1
        say("pad opened — " .. #sp.tabs .. " tab" .. (#sp.tabs == 1 and "" or "s"))
    end
    sp.toggle = sp.show

    -- ---- registrations ------------------------------------------------------------
    sp.load()
    if #sp.tabs == 0 then sp.tabs = { { id = newId(), text = "", createdAt = os.time(), updatedAt = os.time() } }; sp.active = sp.tabs[1].id end

    core.hyperAddShortcut({}, sp.key, function() sp.toggle() end, "scratch pad")

    -- 📎 6.182.0 — ⇪2, the sequential copy. The selection is read through
    -- power_tools' one reader (accessibility first, ⌘C as the fallback,
    -- and it is the thing that says so honestly when an app answers
    -- neither), so this module never grows a second way to read a
    -- selection. No power_tools → the key says so and does nothing.
    sp.collectKey = "2"
    function sp.collectFromSelection()
        if not (_G.service and _G.service.has and _G.service.has("power.readSelection")) then
            pcall(function() hs.alert.show("📎 Sequential copy needs Power Tools\n(it is what reads the selection)", 3) end)
            return false, "power_tools is not loaded"
        end
        -- 🔑 6.201.0 — THE RESET IS DECIDED HERE, BEFORE THE SELECTION IS
        -- READ, and that is not a preference. power_tools BORROWS the
        -- pasteboard to read a ⌘C selection: it saves it, clears it,
        -- presses ⌘C and hands the result over, so by the time `text`
        -- arrives the change counter has moved two or three times and no
        -- longer says anything about who copied last. This is the only
        -- moment the question can be asked honestly.
        local markNow, textNow
        pcall(function() markNow = hs.pasteboard.changeCount() end)
        pcall(function() textNow = hs.pasteboard.getContents() end)
        if not sp.collectContinues(markNow, textNow) then
            sp.collectReset("something else was copied")
        end
        _G.service.call("power.readSelection", "📎", function(text)
            local ok, blockOrWhy = sp.collect(text)
            if not ok then
                pcall(function() hs.alert.show("📎 " .. tostring(blockOrWhy), 2) end)
                return
            end
            -- 📋 6.198.0 — THREE values, not two. hs.pasteboard.setContents
            -- answers FALSE on a refusal without throwing, so reading only
            -- pcall's own ok reported every refusal as a copy that worked
            -- — and the alert below then promised "⌘V pastes the block"
            -- over a pasteboard that had just said no. CLAUDE.md's 6.179.0
            -- rule, in the place it mattered most: this alert is the ONLY
            -- thing standing between LL and a ⌘V that pastes the wrong
            -- thing, so it is not allowed to be optimistic.
            local wrote  = false
            local okSet  = pcall(function()
                wrote = hs.pasteboard.setContents(blockOrWhy) ~= false
            end)
            local copied = okSet and wrote
            -- 🔑 REMEMBER WHAT WE LEFT so the NEXT press can tell whether
            -- anything else has copied since. Read AFTER the write — this
            -- is the counter the reset rule compares against, and reading
            -- it before would compare against the borrow's own clearing.
            -- A REFUSED write leaves no block of ours out there, so
            -- collectLast is cleared; the counter is still recorded,
            -- because nothing else copied either and the grabs already in
            -- the sequence are still worth carrying to the next press.
            sp.collectMark = nil
            pcall(function() sp.collectMark = hs.pasteboard.changeCount() end)
            sp.collectLast = copied and blockOrWhy or nil
            sp.collectWhy  = copied
                and (sp.collectCount .. (sp.collectCount == 1 and " grab" or " grabs")
                     .. " on the clipboard")
                or  "⚠️ the pasteboard REFUSED the block"
            local words = select(2, tostring(blockOrWhy):gsub("%S+", ""))
            pcall(function()
                hs.alert.show(string.format("📎 %d %s · %d words%s", sp.collectCount,
                    sp.collectCount == 1 and "grab" or "grabs", words,
                    copied and "  ·  ⌘V pastes the block"
                            or "\n⚠️ the clipboard refused — press again to retry"), 2)
            end)
        end)
        return true
    end
    core.hyperAddShortcut({}, sp.collectKey, function() sp.collectFromSelection() end,
                          "sequential copy")

    if _G.claimEscape then
        _G.claimEscape("scratchpad", nil, function() return sp.webview ~= nil and not sp.pinned end,
                       function() sp.hide() end)
    end

    _G.movablePanels = _G.movablePanels or {}
    table.insert(_G.movablePanels, {
        name  = "scratch pad",
        frame = function() return sp.webview and sp.webview:frame() end,
        move  = function(x, y)
            if not sp.webview then return end
            local f = sp.webview:frame()
            sp.webview:frame({ x = x, y = y, w = f.w, h = f.h })
            sp.pos = { x = x, y = y }
        end,
    })

    _G.editors = _G.editors or {}
    table.insert(_G.editors, {
        name  = "Hamsidian tabs",
        key   = "⇪" .. sp.key,
        what  = "tabs saved as you type; ⇪N / ⇪2 open here too",
        order = 22,
        view  = function()
            if sp.webview then return sp.webview end
            local host = sp.host()
            if host and host.webview and host.doc and host.doc.scratch then return host.webview end
            return nil
        end,
        show  = function()
            local host = sp.host()
            if sp.webview then return end
            if host then if not (host.webview and host.doc and host.doc.scratch) then host.showScratch(nil) end
            else sp.show() end
        end,
        size  = function() local t = sp.activeTab(); return t and #(t.text or "") or 0 end,
        text  = function() local t = sp.activeTab(); return t and t.text or "" end,
    })

    core.provide("scratch.show",   function() sp.show() return true end)
    core.provide("scratch.send",   function() return sp.send("service") end)
    core.provide("scratch.report", function() return _G.scratchPadReport() end)

    function _G.scratchPadReport()
        local L = {}
        -- 🚨 6.316.0 — WHAT IS NOT SAVED RIGHT NOW GOES FIRST. Every
        -- other line here is history; this one is still true, and it is
        -- cleared by a real write and by nothing else — so an alert he
        -- missed and a Console line that scrolled both end up here.
        if _G.notices and type(_G.notices.unsavedLines) == "function" then
            for _, line in ipairs(_G.notices.unsavedLines()) do L[#L + 1] = line end
            if #L > 0 then L[#L + 1] = "" end
        end
        L[#L + 1] = "📝 Hamsidian tabs — ⇪" .. sp.key .. (sp.enabled and "" or " (disabled)")
        L[#L + 1] = "   store: " .. sp.file .. (sp.lastSaveErr and ("  ⚠️ " .. sp.lastSaveErr) or "")
        L[#L + 1] = "   tabs: " .. #sp.tabs .. " · history: " .. #sp.history
                    .. " · saves: " .. sp.saves .. " · failed writes: " .. (sp.saveFails or 0)
                    .. (sp.dirty and " · unsaved keystrokes pending" or "")
        -- 📎 6.201.0 — THE SEQUENTIAL COPY HAD NO REPORT AT ALL, which is
        -- how it shipped a clipboard nobody could inspect: the alert said
        -- "1 grab" while ⌘V pasted months of text and there was no line
        -- anywhere that disagreed. Say what ⌘V would paste RIGHT NOW, and
        -- why the sequence is the length it is.
        local seqChars = #table.concat(sp.collectSeq or {}, tostring(sp.collectJoin or "\n\n"))
        L[#L + 1] = "   📎 ⇪2: " .. (sp.collectCount or 0)
                    .. ((sp.collectCount == 1) and " grab" or " grabs")
                    .. " in this sequence · " .. seqChars .. " characters"
                    .. " · " .. tostring(sp.collectWhy)
        L[#L + 1] = "      sequences ended by another copy: " .. (sp.collectResets or 0)
                    .. " · THIS SESSION only — a reload starts a new sequence"
        if sp.collectId then
            local old
            for _, t in ipairs(sp.tabs) do if t.id == sp.collectId then old = t end end
            L[#L + 1] = "      the pre-6.201.0 📎 " .. tostring(sp.collectTitle) .. " tab is "
                        .. (old and ("still in the pad, untouched — " .. #tostring(old.text)
                                     .. " characters, and nothing writes to it now")
                                 or "no longer among the tabs (⌘W sent it to the history)")
            -- 🚨 6.201.1 — AND IT IS STILL IN THE 4 PM TASK. sp.newTab was
            -- called without a `kind` (358), so dayBody's `not t.kind`
            -- test (646) has swept that tab into LL's Asana task EVERY DAY
            -- since 6.182.0, growing with it. 6.201.0 stopped feeding the
            -- tab; it cannot stop this without deleting or closing his
            -- text, which is not a release's decision to make. So it is
            -- SAID, with the one keystroke that ends it.
            if old and trim(old.text) ~= "" and not old.kind then
                L[#L + 1] = "      ⚠️ …and it still rides the 4 PM Asana task, as every open"
                            .. " tab does — ⌘W on that tab in ⇪N is what ends it"
            end
        end
        -- 6.177.0 — the way out, and whether it has been taken
        if sp.exportToVault == false then
            L[#L + 1] = "   export: off (settings: scratch_pad.exportToVault)"
        else
            local dir, how = sp.exportDir()
            L[#L + 1] = "   export: ⌘⇧S → " .. dir
                        .. (how == "local" and "  (no OneDrive found — local only)" or "")
                        .. (how == "cloud" and "  (the vault module is not loaded)" or "")
            local e = sp.lastExport
            L[#L + 1] = "   last  : " .. (e and (e.wrote .. " written " .. os.date("%b %d %H:%M", e.at)
                        .. " (" .. tostring(e.why) .. ")"
                        .. (e.failed > 0 and (" · " .. e.failed .. " failed") or ""))
                        or "never — _G.scorpPadExport() writes them now")
        end
        local host = sp.host()
        L[#L + 1] = "   window: " .. (host and "Hamsidian's (⇪N opens the tabs there; viaVault = false for its own)" or "its own")
        L[#L + 1] = "   pad: " .. ((sp.webview or (host and host.webview)) and "open" or "closed") .. (sp.pinned and " · 📌 pinned" or "")
                    .. " · opens: " .. sp.opens .. " · non-activating: " .. tostring(sp.nonActivatingWhy)
        -- 🗑 6.254.0 — OFF is its own state, not a failure. "NOT armed"
        -- on a Mac that was asked not to arm it reads like a fault.
        -- 📌 6.278.0 — THE STICKY ANSWER TO "DID MY TASKS GO?". Both the
        -- alert and the notification can be missed (away from the desk,
        -- asleep, or macOS refusing to draw the alert — 6.274.0 counted
        -- that three times in eight hours on his Mac). This line is still
        -- here at 4 PM when he comes looking, and it clears itself only
        -- when a send actually succeeds.
        if sp.unsent then
            L[#L + 1] = "   ⚠️ NOT SENT: " .. tostring(sp.unsent.why)
            L[#L + 1] = "      at " .. os.date("%b %d %H:%M", sp.unsent.at)
                        .. " (" .. tostring(sp.unsent.reason) .. ") · your text is still "
                        .. "in the tabs · _G.scratchPadSend() retries it"
        else
            L[#L + 1] = "   sends  : nothing is waiting — the last send either worked "
                        .. "or there was nothing to send"
        end
        if sp.sendFails and sp.sendFails > 0 then
            L[#L + 1] = "   failed : " .. sp.sendFails .. " send(s) did not reach Asana this session"
        end
        if not sp.sendDaily then
            L[#L + 1] = "   4 PM: OFF — no daily Asana task is sent"
                        .. " (settings = { scratch_pad = { sendDaily = true } })"
            L[#L + 1] = "          _G.scratchPadSend() still sends one by hand"
            -- 6.201.1: the Collect tab rode into this task every day. With
            -- the send off it cannot, and that is worth saying where the
            -- old warning was read.
            L[#L + 1] = "          ↳ nothing is swept into Asana at all now,"
                        .. " the 📎 Collect tab included (6.201.1)"
        else
            L[#L + 1] = "   4 PM: at " .. sp.sendAt .. " · " .. sp.startTime .. " → " .. sp.dueTime
                        .. " · assignee " .. sp.assignee .. " · "
                        .. (sp.sendTimer and "armed" or "NOT armed")
                        .. " · Asana " .. (core.asanaEnabled and "on" or "off on this Mac")
        end
        -- 🗂 6.300.0 — WHICH SEND IS ARMED, and what the last run did.
        -- Two sends ship and only one can be right for what he expects
        -- to appear in Asana, so the report names it rather than
        -- leaving him to infer it from the tasks that turn up.
        L[#L + 1] = "   send  : " .. (sp.sendGrammar
                    and ("HIS GRAMMAR — one Asana task per parsed task; "
                         .. "each tab is then retitled and KEPT")
                    or ("the DAY task — ONE task, every tab as its "
                        .. "description (settings = { scratch_pad = "
                        .. "{ sendGrammar = true } } for the grammar)"))
        if sp.sendGrammar then
            L[#L + 1] = "   marks : \"" .. sp.sentMark .. "\" is never sent "
                        .. "again · \"" .. sp.failMark .. "\" is retried · "
                        .. "typing in a tab clears its mark"
            local marked, failed = 0, 0
            for _, t in ipairs(sp.tabs or {}) do
                if tostring(t.mark or "") == sp.sentMark then marked = marked + 1
                elseif tostring(t.mark or "") == sp.failMark then failed = failed + 1 end
            end
            L[#L + 1] = "           " .. marked .. " tab(s) sent · " .. failed
                        .. " tab(s) failed and waiting to retry"
            -- 🔁 6.305.0 — THE LEDGER THAT STOPS A RETRY DUPLICATING.
            -- Counted here rather than claimed: a retry sends only what
            -- is NOT in this list, so a number that is 0 on a tab that
            -- has sent is the bug back.
            local landedN, landedTabs = 0, 0
            for _, t in ipairs(sp.tabs or {}) do
                if type(t.landed) == "table" then
                    local n = 0
                    for _, r in pairs(t.landed) do
                        n = n + (tonumber(type(r) == "table" and r.n or r) or 0)
                    end
                    if n > 0 then landedN, landedTabs = landedN + n, landedTabs + 1 end
                end
            end
            L[#L + 1] = "   landed: " .. (landedN == 0
                        and "nothing has reached Asana from a tab yet"
                        or (landedN .. " task(s) across " .. landedTabs
                            .. " tab(s) are remembered as already in Asana — a "
                            .. "retry, and a tab you type in again, send only "
                            .. "what has not landed"))
            if (sp.landedEvicted or 0) > 0 then
                L[#L + 1] = "   ⚠️ " .. sp.landedEvicted .. " remembered task(s) "
                            .. "were forgotten this session (a tab passed "
                            .. tostring(sp.landedMax) .. " keys) — those can be "
                            .. "sent a second time if they are still in the tab"
            end
            local ls = sp.lastTaskSend
            if ls then
                L[#L + 1] = "   run   : " .. os.date("%b %d %H:%M", ls.at or 0)
                            .. " (" .. tostring(ls.reason) .. ") — "
                            .. tostring(ls.tabs) .. " tab(s) read · "
                            .. tostring(ls.sent) .. " task(s) sent · "
                            .. tostring(ls.failed) .. " refused"
                            .. ((tonumber(ls.landed) or 0) > 0
                                and (" · " .. ls.landed .. " skipped (already in Asana)")
                                or "")
                -- 📏 NAMED, NOT SWEPT (6.201.1): the day task also swept
                -- rows closed today; this send does not, because a
                -- closed row has no title to carry an answer back on.
                if (ls.closedToday or 0) > 0 then
                    L[#L + 1] = "           ↳ " .. ls.closedToday .. " row(s) "
                                .. "closed today were NOT read — this send "
                                .. "reads OPEN tabs only, so each one can "
                                .. "be told what happened to it"
                end
                if (ls.subs or 0) > 0 or (ls.subFailed or 0) > 0 then
                    L[#L + 1] = "           ↳ " .. tostring(ls.subs)
                                .. " subtask(s) sent"
                                .. ((ls.subFailed or 0) > 0
                                    and (" · ⚠️ " .. ls.subFailed .. " refused — "
                                         .. "re-add those lines by hand; a retry "
                                         .. "would duplicate their task") or "")
                end
                if (ls.alreadySent or 0) > 0 then
                    L[#L + 1] = "           ↳ " .. ls.alreadySent
                                .. " tab(s) skipped, already sent"
                end
            else
                L[#L + 1] = "   run   : nothing sent this session"
            end
        end
        L[#L + 1] = "   + rows: " .. (sp.showKindRows
                    and "🗒 Capture and ➕ Append are offered in the window"
                    or ("hidden — the Capture and Append stores are untouched"
                        .. " and still searched by ⇪space / ⇪D"
                        .. " (settings = { scratch_pad = { showKindRows = true } })"))
        if sp.lastSend then
            L[#L + 1] = "   last send: " .. os.date("%b %d %H:%M", sp.lastSend.at) .. " (" .. sp.lastSend.reason
                        .. ") — " .. sp.lastSend.outcome
        else
            L[#L + 1] = "   last send: never this session"
        end
        local out = table.concat(L, "\n")
        print(out)
        return out
    end
end

function M.warm(core)
    local sp = M.config
    if not sp then return end
    -- 🗑 6.254.0 — the switch is read HERE, in warm, which is the only
    -- place it can be: a profile's `settings` land AFTER setup returns
    -- (6.228.0), and a timer armed in setup could never be stopped by
    -- one. `_G.scratchPadSend()` still sends by hand, on purpose.
    if not sp.sendDaily then
        sp.sendTimer = nil
        return
    end
    local ok, t = pcall(hs.timer.doAt, sp.sendAt, "1d", function() pcall(sp.send, "scheduled") end)
    if ok and t then sp.sendTimer = t     -- HELD
    else
        -- 🔔 6.278.0 — THE WORST CASE OF ALL, and it used to be the
        -- quietest: the schedule never armed, so 16:00 comes and NOTHING
        -- RUNS. There is no rejection to report because nothing was
        -- attempted, so every other instrument in this release stays
        -- silent and the day's captures sit there looking sent. It takes
        -- the door, with the sticky flag, like a rejection.
        sp.armFailed = tostring(t)
        sp.announce("failed", "the " .. sp.sendAt .. " schedule did not arm ("
                    .. tostring(t) .. ") — nothing will be sent today "
                    .. "unless you run _G.scratchPadSend()", "arm")
    end
end

return M
