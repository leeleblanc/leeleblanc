-- Run from anywhere:  lua5.4 <this file> [path to ~/.hammerspoon]
local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

-- =====================================================================
-- THE HYPER KEY — BOTH WAYS IN, AND THE TEST THAT PRESSES IT
-- =====================================================================
-- 🚨 WHY THIS SUITE EXISTS. LL's work Mac booted to "32 modules · 80 ⇪
-- shortcuts · 1.03s / All green" and not one shortcut worked. Every
-- number on that line was correct. Registering a shortcut is not the same
-- as being able to fire it, and until 6.76.0 nothing in this config could
-- tell the two apart — including this test suite, which is the more
-- uncomfortable half of that sentence.
--
-- So this file models the ONE distinction that mattered:
--
--   hs.hotkey   → Carbon's RegisterEventHotKey, dispatched by the system
--   hs.eventtap → a CGEventTap, which sees the key BEFORE Carbon does
--
-- The stub below has a switch for each layer, and the delivery order is
-- the real one: every running tap first, and Carbon only if no tap
-- consumed the event. Turn Carbon off and you have the work Mac. That
-- machine is a test case now, not an anecdote.
--
-- 🧪 AND IT RUNS THE SHIPPED CODE. §3.12's hyperEnter/hyperExit/hyperBind
-- are lifted out of init.lua as source and executed here, the same way
-- test_keyboard_stack lifts the real injection guard. A private copy
-- would agree with itself. The point is that init.lua and
-- core/hyper_key.lua agree with EACH OTHER — that a shortcut filed by
-- hyperBind is one the dispatcher can find, under the same name.
-- =====================================================================

local pass, fail = 0, 0
local function out(s) io.write(s) end
local function check(label, ok, detail)
  if ok then pass = pass + 1; out("  ✅ " .. label .. "\n")
  else
    fail = fail + 1
    out("  ❌ " .. label .. (detail ~= nil and ("  [" .. tostring(detail) .. "]") or "") .. "\n")
  end
end
local function section(s) out("\n" .. s .. "\n") end

local function readAll(p)
  local f = io.open(p, "r"); if not f then return nil end
  local s = f:read("*a"); f:close(); return s
end

local INIT_SRC = readAll(HS .. "/init.lua")
assert(INIT_SRC, "cannot read init.lua at " .. HS)
local COEXIST_SRC = readAll(HS .. "/core/coexist.lua")
assert(COEXIST_SRC, "cannot read core/coexist.lua")

-- ---- the two blocks of §3.12 this suite runs for real ----------------
local BLOCK_ENTER = INIT_SRC:match(
  "(_G%.hyperCarbonPresses = 0.-_G%.hyperEnter, _G%.hyperExit = hyperEnter, hyperExit)")
local BLOCK_BIND = INIT_SRC:match(
  "(_G%.hyperBound = %{%}.-_G%.hyperCombo = hyperCombo)")
assert(BLOCK_ENTER, "could not lift hyperEnter/hyperExit + the F18 bind from init.lua")
assert(BLOCK_BIND,  "could not lift hyperCombo/hyperBind from init.lua")

-- hyperBind is a LOCAL inside that block, so the only way to reach it is
-- from inside the same chunk. Appended, not re-declared: a second copy
-- here would be the private-copy mistake this whole file exists to avoid.
BLOCK_BIND = BLOCK_BIND .. "\n_G.hyperBindForTest = hyperBind"

-- ---- §0.3's REAL hs.hotkey.bind wrapper ------------------------------
-- The global fallback can only be as correct as the table it reads, and
-- that table is filled by one wrapper in init.lua. Lifted and RUN for the
-- same reason as the blocks above: a test that hand-fills _G.globalDispatch
-- proves the dispatcher right about a table nothing produces.
local BLOCK_NORM = INIT_SRC:match(
  "(local function normalizeCombo%(mods, key%).-_G%.globalCombo = normalizeCombo)")
local BLOCK_STUB = INIT_SRC:match("(_G%.hyperBindStub = function%(%).-\nend)")
local BLOCK_WRAP = INIT_SRC:match(
  "(local hsHotkeyBindOriginal = hs%.hotkey%.bind.-\n    return _G%.hyperBindStub%(%)\nend)")
assert(BLOCK_NORM, "could not lift normalizeCombo/_G.globalCombo from init.lua")
assert(BLOCK_STUB, "could not lift _G.hyperBindStub from init.lua")
assert(BLOCK_WRAP, "could not lift the hs.hotkey.bind wrapper from init.lua")
-- normalizeCombo is a chunk-local, so the wrapper has to be in the SAME
-- chunk to see it. Concatenated in source order, exactly as init.lua has
-- them.
local BLOCK_GLOBALS = BLOCK_NORM .. "\n" .. BLOCK_STUB .. "\n" .. BLOCK_WRAP

-- ---- the real injection guard, out of core/coexist.lua ---------------
local BLOCK_GUARD = COEXIST_SRC:match("(_G%.injectDepth = 0.-\n    return ok, err\nend)")
assert(BLOCK_GUARD, "could not lift the injection guard from core/coexist.lua")

-- =====================================================================
-- THE MAC
-- =====================================================================
local W          -- the world under test, rebuilt for every scenario

local function comboOf(mods, key)
  local m = {}
  for _, x in ipairs(mods or {}) do m[#m + 1] = tostring(x):lower() end
  table.sort(m)
  if #m == 0 then return tostring(key):lower() end
  return table.concat(m, "+") .. "+" .. tostring(key):lower()
end

local KEYCODES = { f18 = 79, f19 = 80, a = 0, d = 2, q = 12, x = 7,
                   l = 37, g = 5, escape = 53 }

local function newWorld(opts)
  opts = opts or {}
  local w = {
    carbon    = opts.carbon ~= false,    -- does RegisterEventHotKey deliver?
    tapKeys   = opts.tapKeys ~= false,   -- do event taps receive posted keys?
    dropKeyUp = opts.dropKeyUp == true,  -- swallow F18 keyUp on the way out
    tapNewThrows = opts.tapNewThrows == true,
    taps = {}, timers = {}, printed = {}, told = {}, recorded = {},
    tasks = {},
    carbonBinds = {}, enters = 0, exits = 0, tapThrows = 0, posts = {},
  }

  local TYPES = { keyDown = 10, keyUp = 11 }

  local modal = { entered = false, binds = {} }
  function modal:bind(mods, key, p, r, rep)
    self.binds[comboOf(mods, key)] = { p, r, rep }; return self
  end
  function modal:enter() self.entered = true; w.enters = w.enters + 1; return self end
  function modal:exit()  self.entered = false; w.exits  = w.exits  + 1; return self end
  w.modal = modal

  -- 🚨 THE DELIVERY ORDER IS THE REAL ONE: taps first, Carbon only if
  -- nothing consumed the event. Getting this backwards would make the tap
  -- fallback look like it works when it cannot, which is the exact
  -- direction of error that put a green boot line on a dead keyboard.
  local function deliver(ev)
    w.posts[#w.posts + 1] = { key = ev.key, down = ev.down, posted = ev.posted }
    if w.dropKeyUp and ev.key == "f18" and not ev.down then return end
    if w.tapKeys then
      for _, t in ipairs(w.taps) do
        if t.on then
          local ok, ret = pcall(t.fn, ev)
          if not ok then w.tapThrows = w.tapThrows + 1 end
          if ok and ret == true then return end
        end
      end
    end
    -- 🚨 A POSTED EVENT DOES NOT REACH CARBON. This one line is the whole
    -- of 6.76.0's mistake: event taps see a synthesised keystroke exactly
    -- like a real one, Carbon's RegisterEventHotKey dispatch does not, so
    -- a probe built on hs.eventtap.event:post() read zero in the Carbon
    -- column on EVERY Mac and 6.76.0 read that zero as "Carbon is dead".
    -- The old stub delivered posted events to both layers, which is why
    -- 33 mutations and 98 checks all passed over a bug that misdiagnosed
    -- LL's Mac on the first boot.
    if ev.posted then return end
    if not w.carbon then return end
    -- 🚨 CARBON DISPATCHES ON THE RUN LOOP, NOT INSIDE THE TAP CALLBACK.
    -- The tap runs in the event stream and returns; the hotkey handler
    -- comes afterwards. Modelling it as a same-instant call would let a
    -- verification that checks the Carbon counter IMMEDIATELY look
    -- correct here and misdiagnose every Mac in the world — which is the
    -- exact class of stub-is-kinder-than-reality bug this file exists
    -- because of. 0.05 against the check's 0.25.
    w.hs.timer.doAfter(0.05, function()
      local c = comboOf(ev.mods, ev.key)
      local g = w.carbonBinds[c]
      if g then
        local fn = ev.down and g[1] or g[2]
        if fn then fn() end
        return
      end
      if modal.entered then
        local b = modal.binds[c]
        if b then
          local fn = ev.down and b[1] or b[2]
          if fn then fn() end
        end
      end
    end)
  end
  w.deliver = deliver

  local function mkEvent(mods, key, down, autorepeat, posted)
    local flags = {}
    for _, m in ipairs(mods or {}) do flags[m] = true end
    local e = { down = down, key = key, mods = mods or {}, posted = posted }
    e.getType     = function() return down and TYPES.keyDown or TYPES.keyUp end
    e.getKeyCode  = function() return KEYCODES[key] end
    e.getFlags    = function() return flags end
    e.getProperty = function() return autorepeat and 1 or 0 end
    e.post        = function() deliver(e) end
    return e
  end
  w.mkEvent = mkEvent

  local hs = {
    eventtap = {
      event = {
        types = TYPES,
        properties = { keyboardEventAutorepeat = 8 },
        -- Everything built through the real API is POSTED, by definition.
        newKeyEvent = function(mods, key, down)
          return mkEvent(mods, key, down, false, true)
        end,
      },
      new = function(types, fn)
        if w.tapNewThrows then error("Accessibility withheld", 0) end
        local t = { types = types, fn = fn, on = false }
        function t:start() self.on = true; return self end
        function t:stop()  self.on = false; return self end
        function t:isEnabled() return self.on end
        w.taps[#w.taps + 1] = t
        return t
      end,
      keyStroke = function() end,
    },
    hotkey = {
      bind = function(mods, key, p, r)
        w.carbonBinds[comboOf(mods, key)] = { p, r }
        return { enable = function(s) return s end, disable = function(s) return s end,
                 delete = function(s) return s end }
      end,
      modal = { new = function() return modal end },
    },
    timer = {
      secondsSinceEpoch = function() return w.now or 1000 end,
      doAfter = function(s, fn)
        local t = { secs = s, fn = fn, live = true }
        function t:stop() self.live = false; return self end
        w.timers[#w.timers + 1] = t
        return t
      end,
      doEvery = function(s, fn)
        local t = { secs = s, fn = fn, live = true, every = true }
        function t:stop() self.live = false; return self end
        w.timers[#w.timers + 1] = t
        return t
      end,
    },
    keycodes = { map = setmetatable({}, { __index = function(_, k)
      if type(k) == "number" then
        for name, code in pairs(KEYCODES) do if code == k then return name end end
        return nil
      end
      return KEYCODES[k]
    end }) },
    -- 🔬 6.302.0 — hs.caffeinate.watcher, modelled rather than mimed.
    -- 6.290.0's rule: a stub must answer what the real provider answers.
    -- The two that matter here are that it KEEPS the callback (a stub
    -- whose new() throws the function away makes every wake path
    -- untestable — 6.273.0's service.provide hole exactly), and that
    -- macOS hands that callback a NUMBER, never a name.
    caffeinate = (not opts.noCaffeinate) and {
      watcher = {
        systemDidWake         = 1,
        screensDidUnlock      = 2,
        sessionDidBecomeActive = 3,
        screensDidLock        = 4,
        systemWillSleep       = 5,
        new = function(fn)
          if opts.watcherNewThrows then error("no caffeinate here", 0) end
          if opts.watcherNewNil then return nil end
          local wat = { fn = fn, on = false }
          function wat:start()
            if opts.watcherStartThrows then error("refused to start", 0) end
            self.on = true; return self
          end
          function wat:stop() self.on = false; return self end
          w.wakeWatcher = wat
          return wat
        end,
      },
    } or nil,
    -- 🔬 6.303.0 — hs.task. The fidelity that matters (6.290.0): it is
    -- ASYNCHRONOUS. A stub that calls back from inside :start() would
    -- make "nothing starts a task from inside another task's callback"
    -- untestable and would hide 6.196.1's whole class, so the callback
    -- is parked and the test fires it deliberately. Three values, in
    -- macOS's own order: exit code, stdout, stderr.
    task = (not opts.noTask) and {
      new = function(bin, cb, args)
        if opts.taskNewThrows then error("no hs.task here", 0) end
        local t = { bin = bin, cb = cb, args = args or {}, started = false }
        function t:start() self.started = true; w.tasks[#w.tasks + 1] = self; return self end
        return t
      end,
    } or nil,
    configdir = HS,
  }
  w.hs = hs

  -- the newest started task whose argv contains `which`
  function w.taskFor(which)
    for i = #w.tasks, 1, -1 do
      for _, a in ipairs(w.tasks[i].args) do
        if tostring(a):find(which, 1, true) then return w.tasks[i] end
      end
    end
  end
  function w.answerTask(which, code, out, err)
    local t = w.taskFor(which)
    if not t then return false, "no such task started" end
    t.answered = true
    return pcall(t.cb, code, out, err)
  end

  -- macOS firing a caffeinate event: by CONSTANT, the way it really does.
  function w.fireWake(const)
    if not w.wakeWatcher then return false, "no watcher was made" end
    return pcall(w.wakeWatcher.fn, const)
  end

  -- The sandbox every lifted block and core/hyper_key.lua runs inside.
  local SB = {
    hs = hs, pcall = pcall, ipairs = ipairs, pairs = pairs, type = type,
    tostring = tostring, tonumber = tonumber, table = table, math = math,
    string = string, error = error, select = select, loadfile = loadfile,
    setmetatable = setmetatable,
    -- 6.179.1: the real environment has both, and hyperBind's timing
    -- wrapper takes the xpcall + debug.traceback branch when they exist —
    -- leaving them out of the sandbox meant that branch never ran here.
    xpcall = xpcall, debug = debug,
    -- 6.303.0: the probe stamps os.time() and the report renders it.
    -- time comes off the world's clock so a report is reproducible;
    -- date is the real one, because formatting is not the thing here.
    os = { time = function() return math.floor(w.now or 1000) end,
           date = os.date },
    print = function(...)
      local p = {}
      for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
      w.printed[#w.printed + 1] = table.concat(p, " ")
    end,
  }
  SB._G = SB
  SB.diag = { say = function() end, warn = function() end, err = function() end }
  SB.notices = {
    record = function(kind, src, msg) w.recorded[#w.recorded + 1] = tostring(msg) end,
    tell   = function(title, body) w.told[#w.told + 1] = tostring(title) end,
  }
  SB.hyperShortcutCount = 107
  w.SB = SB

  -- the real injection guard, then the real §3.12 blocks
  load(BLOCK_GUARD, "coexist-guard", "t", SB)()
  SB.hyperModal = modal
  SB.hyperActive = false
  load(BLOCK_ENTER, "init-hyperEnter", "t", SB)()
  load(BLOCK_BIND,  "init-hyperBind",  "t", SB)()

  -- §0.3's own state, then §0.3's own wrapper over hs.hotkey.bind.
  SB.globalDispatch = {}
  SB.hyperKeyMap, SB.hyperMigrations, SB.hyperMigrationsSeen = {}, {}, {}
  SB.hotkeyRegistry, SB.knownSystemCombos = {}, {}
  SB.hotkeyBoundCount, SB.hotkeyConflictCount = 0, 0
  load(BLOCK_GLOBALS, "init-bindWrapper", "t", SB)()

  return w
end

-- Runs pending timers, oldest first, including any created while running.
-- The clock ADVANCES with them: _G.suppressTypingFor() is a deadline, and
-- a world where time never moves is one where the self-test's own
-- suppression window never closes. That is not a hypothetical — it is
-- what this stub did on its first run, and every dispatcher assertion
-- below passed for the wrong reason because of it.
local function runTimers(w, rounds)
  for _ = 1, (rounds or 6) do
    local due = w.timers
    w.timers = {}
    if #due == 0 then return end
    -- In DELAY ORDER. A round that fires a 0.25s check before a 0.05s
    -- dispatch is a round in which "wait for Carbon" and "do not wait for
    -- Carbon" are the same program.
    table.sort(due, function(x, y) return (x.secs or 0) < (y.secs or 0) end)
    for _, t in ipairs(due) do
      if t.live and not t.every then
        w.now = (w.now or 1000) + (t.secs or 0)
        t.fn()
      end
    end
  end
end

-- Everything the boot did is over and the clock has moved on — the state
-- you are actually in when you reach for ⇪.
local function timePasses(w, secs)
  w.now = (w.now or 1000) + (secs or 5)
end

-- 🚨 A REAL CAPS LOCK PRESS, delivered the way the Mac delivers one: down
-- the whole event chain, taps first and Carbon after. This is the ONLY
-- thing that verifies ⇪ from 6.79.0 on, so it is the only thing the
-- scenarios below use to trigger verification. Posting a synthetic key
-- and watching for Carbon is exactly what got a healthy Mac misdiagnosed.
local function pressCapsLock(w, runTimersFn)
  w.mkEvent({}, "f18", true, false, false).post()
  if runTimersFn then runTimersFn(w) end
  w.mkEvent({}, "f18", false, false, false).post()
end

local function loadHyperKey(w)
  local chunk, err = loadfile(HS .. "/core/hyper_key.lua", "t", w.SB)
  assert(chunk, err)
  local init = chunk()
  assert(type(init) == "function", "core/hyper_key.lua must return an initialiser")
  w.SB.hyperSelfTestPending = true
  init({ enter = w.SB.hyperEnter, exit = w.SB.hyperExit, combo = w.SB.hyperCombo })
end

-- A minimal but REAL set of hyper shortcuts, registered the way every
-- shortcut in the config is: through §3.12's own hyperBind.
local function bindShortcuts(w)
  w.ran = {}
  w.SB.hyperBindForTest({}, "d", function() w.ran[#w.ran + 1] = "d-pressed" end,
      function() w.ran[#w.ran + 1] = "d-released" end,
      function() w.ran[#w.ran + 1] = "d-repeat" end, "test")
  w.SB.hyperBindForTest({ "shift" }, "x",
      function() w.ran[#w.ran + 1] = "shift-x" end, nil, nil, "test")
  w.SB.hyperBindForTest({}, "a", function() error("this shortcut throws", 0) end,
      nil, nil, "test")
end

local function printedFinding(w, needle)
  for _, l in ipairs(w.printed) do
    if l:find(needle, 1, true) then return l end
  end
  return nil
end

local world = newWorld

local function toldFinding(w, needle)
  for _, t in ipairs(w.told) do
    if t:find(needle, 1, true) then return t end
  end
  return nil
end

out("\n=== HYPER KEY ==========================================\n")

-- =====================================================================
section("1. A MAC WHERE CARBON WORKS — the personal MacBook Air")
-- =====================================================================
do
  local w = world{ carbon = true, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)

  check("nothing is claimed before you have pressed the key",
        w.SB.hyperVerified == nil, tostring(w.SB.hyperVerified))

  pressCapsLock(w, runTimers)

  check("one real Caps Lock press proves the hyper key",
        w.SB.hyperVerified == true, tostring(w.SB.hyperVerified))
  check("...and names both paths, because both delivered F18",
        w.SB.hyperPath == "carbon + tap", tostring(w.SB.hyperPath))
  check("🚨 the event tap does NOT swallow F18 — Carbon still sees it, or "
     .. "the fallback would break the very Mac it is meant to leave alone",
        w.SB.hyperCarbonPresses == 1, w.SB.hyperCarbonPresses)
  check("...and the tap saw it too", w.SB.hyperTapPresses == 1,
        w.SB.hyperTapPresses)
  check("🚨 the Carbon-free dispatcher stays OFF when Carbon works — this "
     .. "is the regression 6.76.0 shipped, and it cost a working Mac the "
     .. "cheat sheet's type-to-filter and ⌥Tab's arrows",
        w.SB.hyperDispatchEngaged == false)
  check("nothing is shouted at a Mac where everything is fine",
        printedFinding(w, "🚨") == nil and printedFinding(w, "WITHOUT CARBON") == nil,
        printedFinding(w, "🚨") or printedFinding(w, "WITHOUT CARBON"))
  check("...and nothing reaches the screen", #w.told == 0, w.told[1])
  check("⇪ is not left latched after the press",
        w.SB.hyperActive == false)

  -- Once answered, it must cost nothing: this runs inside a keystroke.
  local timersBefore = #w.timers
  for _ = 1, 5 do pressCapsLock(w, runTimers) end
  check("🚨 ...and it never checks again — the check lives in a callback "
     .. "every keystroke goes through",
        w.SB.hyperRealChecks == 1, w.SB.hyperRealChecks)
end

-- =====================================================================
section("2. THE WORK MAC — F18 arrives, Carbon never fires")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)

  check("a real press with no Carbon behind it switches ⇪ to the "
     .. "event-tap dispatcher",
        w.SB.hyperDispatchEngaged == true)
  check("...and the hyper key is PROVEN, not counted",
        w.SB.hyperVerified == true, tostring(w.SB.hyperVerified))
  check("...named for the path actually carrying it",
        w.SB.hyperPath == "event tap (dispatcher)", tostring(w.SB.hyperPath))
  check("🚨 and it SAYS SO — this is a real difference between two Macs "
     .. "and rule 7 does not allow it to be silent",
        printedFinding(w, "WITHOUT CARBON") ~= nil)
  check("...naming the REAL press as the evidence, not a synthetic one",
        printedFinding(w, "real Caps Lock press") ~= nil)
  check("...on screen as well as in the Console", #w.told > 0, #w.told)
  check("...and in the notices ledger", #w.recorded > 0, #w.recorded)

  -- and now the part that matters: does a shortcut actually run?
  timePasses(w)
  w.enters, w.exits = 0, 0
  w.mkEvent({}, "f18", true).post()
  check("holding ⇪ marks the hyper key active through the tap",
        w.SB.hyperActive == true)
  check("...and deliberately does NOT enter a modal whose hotkeys are dead",
        w.modal.entered == false and w.enters == 0, w.enters)

  local consumed = w.taps[1].fn(w.mkEvent({}, "d", true))
  check("⇪D RUNS ITS SHORTCUT on a Mac with no working hotkey layer",
        w.ran[1] == "d-pressed", w.ran[1])
  check("...and EATS the keystroke, or ⇪D would also type a letter d",
        consumed == true, tostring(consumed))

  local up = w.taps[1].fn(w.mkEvent({}, "d", false))
  check("...the release handler runs on the way up", w.ran[2] == "d-released")
  check("...and the keyUp is consumed too", up == true)

  w.mkEvent({}, "f18", false).post()
  check("releasing ⇪ ends it", w.SB.hyperActive == false)
end

-- =====================================================================
section("3. THE DISPATCHER, key by key")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  local tap = w.taps[1]
  w.mkEvent({}, "f18", true).post()   -- ⇪ held

  w.ran = {}
  check("⇪⇧X finds the shift-qualified shortcut and not the bare one",
        tap.fn(w.mkEvent({ "shift" }, "x", true)) == true and w.ran[1] == "shift-x",
        w.ran[1])

  w.ran = {}
  check("🚨 an UNBOUND hyper key is passed through, never eaten",
        tap.fn(w.mkEvent({}, "q", true)) == false and #w.ran == 0, #w.ran)

  -- 🔁 The pathological binding, registered on purpose. NOTHING in the
  -- config claims all four modifiers today — every hyper shortcut is bare
  -- or ⇧-qualified — so with the shipped shortcut set this guard never
  -- fires. That is exactly why it has to be tested against a shortcut
  -- that WOULD match: an unclaimed hyper key forwards ⌘⇧⌃⌥+itself, that
  -- synthetic chord comes straight back through this same tap, and if it
  -- ever found an entry the dispatcher would forward it again. Forever.
  -- One hyperAddShortcut with four modifiers is all it would take, and
  -- the person who writes it will not be looking here.
  w.SB.hyperBindForTest({ "cmd", "shift", "ctrl", "alt" }, "d",
      function() w.ran[#w.ran + 1] = "CHORD LOOP" end, nil, nil, "pathological")
  w.ran = {}
  check("🔁 the forwarded ⌘⇧⌃⌥ chord is refused outright even when a "
     .. "shortcut IS registered on it — this is what stops the dispatcher "
     .. "feeding itself its own output, forever",
        tap.fn(w.mkEvent({ "cmd", "shift", "ctrl", "alt" }, "d", true)) == false
        and #w.ran == 0, w.ran[1])

  w.ran = {}
  tap.fn(w.mkEvent({}, "d", true, true))    -- autorepeat
  check("a held key runs the REPEAT handler, not the press handler again",
        w.ran[1] == "d-repeat" and #w.ran == 1, w.ran[1])

  -- ⌨️ 6.179.0 — THE KEY TRAIL. hyperBind times the shortcut and hands
  -- the result to core/key_trail.lua. Recorded here against the REAL
  -- wrapper: a trail fed by a copy of the logic proves nothing.
  local TRAIL = {}
  w.SB.keyTrailRecord = function(combo, source, ms, why)
    TRAIL[#TRAIL + 1] = { combo = combo, source = source, ms = ms, why = why }
  end
  w.ran = {}
  tap.fn(w.mkEvent({}, "d", true))
  check("⌨️ a shortcut that ran is in the key trail, under the combo it was bound as",
        #TRAIL == 1 and TRAIL[1].combo == "d" and TRAIL[1].source == "test"
        and TRAIL[1].why == nil, TRAIL[1] and TRAIL[1].combo)
  -- ⏱ THE DURATION IS THE FEATURE, so it is measured, not merely typed:
  -- the shortcut moves the sandbox clock while it runs, and the recorded
  -- ms has to be that gap in MILLISECONDS. Asserting ms >= 0 would pass
  -- with `local ms = 0` in the shipped code, and the trail would then
  -- report "0 ms" for the four-second press it exists to catch.
  TRAIL = {}
  w.SB.hyperBindForTest({}, "s", function() w.now = (w.now or 1000) + 1.5 end,
      nil, nil, "slow one")
  w.SB.hyperDispatch["s"].pressed()      -- the real wrapper, called directly
  check("⏱ the recorded duration is the time the shortcut actually took",
        #TRAIL == 1 and math.abs(TRAIL[1].ms - 1500) < 1,
        #TRAIL .. " rows; " .. (TRAIL[1] and (TRAIL[1].combo .. "=" .. tostring(TRAIL[1].ms)) or "none"))
  w.now = 1000

  TRAIL = {}
  w.ran = {}
  check("🛟 a shortcut that THROWS does not throw into the event system",
        tap.fn(w.mkEvent({}, "a", true)) == true, "threw out of the tap")
  check("...and the tap is still running afterwards", tap.on == true)
  check("⌨️ ...and the throw is IN the trail rather than lost — the timing "
     .. "wrapper records the fault, it does not swallow it",
        #TRAIL == 1 and TRAIL[1].combo == "a" and TRAIL[1].why == "threw",
        TRAIL[1] and tostring(TRAIL[1].why))
  -- 🛟 AND THE RE-RAISE ITSELF. The wrapper pcalls the shortcut to time
  -- it; if it then returned quietly instead of re-raising, every module
  -- bug behind a ⇪ key would become an invisible no-op with nothing in
  -- the Console — a dead shortcut that still answers. The tap-level check
  -- above cannot see that (the tap pcalls either way), so the wrapper is
  -- called DIRECTLY here.
  check("🛟 the error really leaves the wrapper — the timing pcall is not an error sink",
        (function()
            local entry = w.SB.hyperDispatch["a"]
            if not (entry and entry.pressed) then return false end
            local ok, err = pcall(entry.pressed)
            return ok == false and tostring(err):find("this shortcut throws", 1, true) ~= nil
        end)())
  check("🔎 ...and it carries the traceback, so the frames between the key and "
     .. "the throw are still in the log",
        (function()
            local ok, err = pcall(w.SB.hyperDispatch["a"].pressed)
            return ok == false and tostring(err):find("stack traceback", 1, true) ~= nil
        end)(), select(2, pcall(w.SB.hyperDispatch["a"].pressed)))
  -- 6.268.0 — A CHECK THAT A THROWN SHORTCUT DREW NO HINT CARD STOOD
  -- HERE. It was proving an ORDERING inside hyperBind: the error left the
  -- wrapper before the `_G.shortcutHint` line, so a shortcut that failed
  -- never claimed to have succeeded. The hint module is deleted and that
  -- call with it, so there is no longer an ordering to get wrong. The two
  -- checks above still prove the half that matters and did not go away —
  -- the error really leaves the wrapper, carrying its traceback.

  -- and a press the pause switch stands down is recorded as such
  TRAIL, w.ran = {}, {}
  w.SB.hsPaused, w.SB.hsPauseCombo = true, "shift+1"
  tap.fn(w.mkEvent({}, "d", true))
  w.SB.hsPaused = false
  check("⏸ a press swallowed by the pause switch is in the trail, marked — "
     .. "the dead keyboard is explained instead of leaving a gap",
        #TRAIL == 1 and TRAIL[1].why == "paused" and #w.ran == 0,
        TRAIL[1] and tostring(TRAIL[1].why))
  check("...named by the module that OWNS the key, not by the pause itself",
        TRAIL[1] and TRAIL[1].source == "test", TRAIL[1] and TRAIL[1].source)
  w.SB.keyTrailRecord = nil
  TRAIL, w.ran = {}, {}
  tap.fn(w.mkEvent({}, "d", true))
  check("⌨️ ...and with no trail loaded at all the shortcut still runs",
        w.ran[1] == "d-pressed" and #TRAIL == 0, w.ran[1])

  w.ran = {}
  check("nothing dispatches when ⇪ is not held", (function()
      w.mkEvent({}, "f18", false).post()
      return tap.fn(w.mkEvent({}, "d", true)) == false and #w.ran == 0
    end)(), w.ran[1])
end

-- =====================================================================
section("4. THE INJECTION GUARD — a shortcut must not run because "
        .. "ANOTHER module typed")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  local tap = w.taps[1]
  w.mkEvent({}, "f18", true).post()

  w.ran = {}
  w.SB.withInjection(function()
    check("🚨 an injected keystroke never fires a hyper shortcut",
          tap.fn(w.mkEvent({}, "d", true)) == false and #w.ran == 0, w.ran[1])
  end)

  w.ran = {}
  check("...and a real one right afterwards still does",
        tap.fn(w.mkEvent({}, "d", true)) == true and w.ran[1] == "d-pressed",
        w.ran[1])

  -- The deliberate exception, and the reason it has to exist.
  w.ran = {}
  w.SB.suppressTypingFor(0.8)
  check("the time-bounded window suppresses too",
        tap.fn(w.mkEvent({}, "d", true)) == false and #w.ran == 0, w.ran[1])
  w.SB.hyperSelfTestInFlight = true
  w.ran = {}
  check("🚨 ...EXCEPT for the self-test's own keystroke, which exists to "
     .. "reach the dispatcher — without this the test measures its own "
     .. "suppression and calls a working hyper key dead",
        tap.fn(w.mkEvent({}, "d", true)) == true and w.ran[1] == "d-pressed",
        w.ran[1])
  w.SB.hyperSelfTestInFlight = false
end

-- =====================================================================
section("5. WHEN THE KEY NEVER ARRIVES AT ALL")
-- =====================================================================
-- There is no real press to measure, so there is nothing to conclude —
-- and saying so is the honest answer. "Not yet known" is reported by the
-- boot line and by ⇪⇧D; what must NEVER happen is a confident claim in
-- either direction on no evidence.
do
  local w = world{ carbon = false, tapKeys = false }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)

  check("🚨 no evidence produces no verdict, in either direction",
        w.SB.hyperVerified == nil, tostring(w.SB.hyperVerified))
  check("...and the dispatcher is NOT engaged on a guess",
        w.SB.hyperDispatchEngaged == false)
  check("...and nothing is claimed on screen", #w.told == 0, w.told[1])
  check("the unproven state is the one the boot line and ⇪⇧D report",
        w.SB.hyperSelfTestPending == true)
end

-- =====================================================================
section("6. THE PROBE IS A DIAGNOSTIC NOW, NOT A DECISION")
-- =====================================================================
-- 🚨 6.76.0 posted a synthetic F18 and treated a silent Carbon as proof
-- that Carbon was dead. It is not proof: a posted CGEvent does not
-- reliably reach Carbon's hotkey dispatch, so the Carbon column read zero
-- on EVERY Mac. LL's MacBook Air — where ⇪ has worked for sixty releases
-- — was switched onto the fallback by it, losing the cheat sheet's
-- type-to-filter and ⌥Tab's arrows in the process.
do
  local w = world{ carbon = true, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)

  -- The world that caused the bug: Carbon works, but posted events do
  -- not reach it, so the probe sees exactly what it saw on LL's Mac.
  w.SB.hyperSelfTest()
  runTimers(w)

  check("the probe still reports what each layer saw",
        (w.SB.hyperSelfTestResult or {}).tap == 1,
        (w.SB.hyperSelfTestResult or {}).tap)
  check("🚨 ...but it CHANGES NOTHING. A silent Carbon column here is not "
     .. "evidence, and acting on it is what misdiagnosed a healthy Mac",
        w.SB.hyperDispatchEngaged == false and w.SB.hyperVerified == nil,
        tostring(w.SB.hyperDispatchEngaged) .. "/" .. tostring(w.SB.hyperVerified))
  check("...and it says so in the output rather than leaving you to infer it",
        printedFinding(w, "proves NOTHING") ~= nil)
  check("🚨 the probe never leaves ⇪ latched on",
        w.SB.hyperActive == false and w.modal.entered == false)

  -- and the real press still decides, afterwards
  pressCapsLock(w, runTimers)
  check("the real press is what settles it, probe or no probe",
        w.SB.hyperVerified == true and w.SB.hyperPath == "carbon + tap",
        tostring(w.SB.hyperPath))
end

do
  local w = world{ carbon = true, tapKeys = true, tapNewThrows = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)

  check("a Mac that refuses the event tap still boots", w.SB.hyperKeyTap == nil)
  check("...and says the fallback is missing rather than dropping it quietly",
        printedFinding(w, "could not start") ~= nil)
  check("🚨 ...and admits ⇪ can no longer be VERIFIED either, because the "
     .. "check lives inside that tap",
        printedFinding(w, "no longer be verified") ~= nil)
end

-- =====================================================================
section("7. THE TAP STANDS DOWN RATHER THAN DEGRADE THE KEYBOARD")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  local tap = w.taps[1]
  w.mkEvent({}, "f18", true).post()

  -- A dispatcher that throws on every keystroke is the shape macOS
  -- punishes by switching the tap off without telling anyone.
  w.SB.hyperTapDispatch = function() error("broken", 0) end
  local everConsumed, everThrew = false, false
  for _ = 1, 5 do
    local ok, ret = pcall(tap.fn, w.mkEvent({}, "d", true))
    if not ok then everThrew = true end
    if ok and ret == true then everConsumed = true end
  end
  check("🛟 a failing callback never throws into the event system",
        everThrew == false)
  check("...and never eats the keystroke on the failure path",
        everConsumed == false)
  check("...it counts its failures", w.SB.hyperTapFailures == 5,
        w.SB.hyperTapFailures)
  check("...and takes ITSELF out at five rather than slow the whole keyboard",
        tap.on == false)
  check("...saying so on screen, by name",
        toldFinding(w, "switched itself off") ~= nil, w.told[#w.told])
end

-- =====================================================================
section("8. THE TWO FILES AGREE WITH EACH OTHER")
-- =====================================================================
do
  local w = world{ carbon = true, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  check("🚨 every shortcut hyperBind files is one the dispatcher can find, "
     .. "under the same name — the two are the same function, so they "
     .. "cannot drift",
    (function()
      for combo in pairs(w.SB.hyperBound) do
        if not w.SB.hyperDispatch[combo] then return false, combo end
      end
      return true
    end)())
  check("...and the dispatch entry carries all three handlers", (function()
      local e = w.SB.hyperDispatch["d"]
      return e and type(e.pressed) == "function"
             and type(e.released) == "function"
             and type(e.repeated) == "function"
    end)())
  check("...and the probe key is NOT counted as one of your shortcuts",
        w.SB.hyperBound["shift+f19"] == nil
        and w.SB.hyperDispatch["shift+f19"] ~= nil)
end

-- =====================================================================
section("9. THE SOURCE CONTRACT")
-- =====================================================================
do
  local code = {}
  for line in (INIT_SRC .. "\n"):gmatch("([^\n]*)\n") do
    code[#code + 1] = line:match("^%s*%-%-") and "" or line
  end
  local initCode = table.concat(code, "\n")

  check("init.lua publishes the two handlers core/hyper_key.lua drives ⇪ with",
        initCode:find("_G.hyperEnter, _G.hyperExit = hyperEnter, hyperExit", 1, true) ~= nil)
  check("...and the combo normaliser the dispatcher matches keys with",
        initCode:find("_G.hyperCombo = hyperCombo", 1, true) ~= nil)
  check("🚨 core/hyper_key.lua is loaded AFTER _G.hyperFinalize(), or the "
     .. "dispatcher would be built against an empty shortcut table",
    (function()
      local fin = initCode:find("_G.hyperFinalize()", 1, true)
      local load_ = initCode:find("/core/hyper_key.lua", 1, true)
      return fin and load_ and fin < load_, tostring(fin) .. " vs " .. tostring(load_)
    end)())
  check("...inside a pcall, so a missing core file degrades the fallback "
     .. "instead of killing the boot",
        initCode:find("local hkOK, hkErr = pcall(", 1, true) ~= nil)
  check("...and a failure prints, because a silent one looks like success",
        initCode:find("if not hkOK then", 1, true) ~= nil)

  -- 🚨 RUN, not grepped. A check for the string "hyperSelfTestPending" in
  -- core/boot_report.lua stays green under `false and
  -- _G.hyperSelfTestPending` — mutation testing found exactly that, and
  -- a source match that survives the code being switched off is not a
  -- test. So the real file is executed, twice, and the line it prints is
  -- read.
  local function bootLines(pending)
    local lines = {}
    local SB = {
      hs = { timer = { secondsSinceEpoch = function() return 1000.4231 end },
             settings = { get = function() return false end,
                          set = function() end } },
      pcall = pcall, ipairs = ipairs, type = type, tostring = tostring,
      table = table, string = string, math = math,
      print = function(...)
        local p2 = {}
        for i = 1, select("#", ...) do p2[#p2 + 1] = tostring((select(i, ...))) end
        lines[#lines + 1] = table.concat(p2, " ")
      end,
    }
    SB._G = SB
    SB.hotkeyBoundCount, SB.hotkeyConflictCount = 5, 0
    SB.moduleLoaded, SB.moduleFailed = 32, 0
    SB.moduleProfileName, SB.moduleDir = "BASE", "modules"
    SB.hyperShortcutCount, SB.hyperForwardCount, SB.hyperConflictCount = 80, 40, 0
    SB.autocorrectStatus = "on"
    SB.textExpander = { status = "2006 snippets" }
    SB.diagBootStart = 999
    SB.hyperSelfTestPending = pending
    local chunk = assert(loadfile(HS .. "/core/boot_report.lua", "t", SB))
    chunk()({ hostTag = "TestMac", cloudDir = "/cloud", logsDir = "/logs",
              backupDir = "/bk", asanaEnabled = true, secretsStatus = "loaded",
              axOK = true })
    return table.concat(lines, "\n")
  end

  local waiting = bootLines(true)
  check("🚨 the healthy boot line no longer lets \"All green\" imply a key "
     .. "nobody has tried — it says the proof is still coming",
        waiting:find("All green", 1, true) ~= nil
        and waiting:find("⇪", 1, true) ~= nil
        and waiting:find("Caps Lock press", 1, true) ~= nil, waiting)
  check("...and does not promise a proof on a Mac with the hyper key off",
    (function()
      local off = bootLines(false)
      return off:find("All green", 1, true) ~= nil
             and off:find("Caps Lock press", 1, true) == nil
    end)())

  local diag = readAll(HS .. "/core/diagnostics.lua") or ""
  check("⇪⇧D reports whether ⇪ was PROVEN, next to the count that was not "
     .. "enough on its own",
        diag:find("hyper PROVEN", 1, true) ~= nil
        and diag:find("hyperVerified", 1, true) ~= nil)
end

-- =====================================================================
section("10. suppressTypingFor — an injection that outlives its caller")
-- =====================================================================
do
  local w = world{}
  local SB = w.SB
  w.now = 1000
  check("no injection by default", SB.typingInjection() == false)
  SB.suppressTypingFor(0.5)
  check("a posted-keystroke window stands the typing watchers down",
        SB.typingInjection() == true)
  w.now = 1000.4
  check("...for as long as it was given", SB.typingInjection() == true)
  w.now = 1000.6
  check("🚨 ...and then ends BY ITSELF — a deadline cannot leak the way a "
     .. "counter with no matching decrement does",
        SB.typingInjection() == false)
  SB.injectUntil = 0
  check("it is capped, so no caller can switch typing off for a session",
        SB.suppressTypingFor(600) == 2.0)
  SB.injectUntil = 0
  check("a zero or negative window is a no-op",
        SB.suppressTypingFor(0) == 0 and SB.typingInjection() == false)

  -- 🚨 A SHORTER WINDOW MUST NOT SHORTEN A LONGER ONE ALREADY OPEN. Two
  -- callers overlap all the time — the self-test posts its four keys
  -- while an expansion is still going out — and last-write-wins would let
  -- the shorter one end the longer one's suppression early, which is the
  -- injection bug this guard exists to prevent, one level up.
  SB.injectUntil = 0
  w.now = 1000
  SB.suppressTypingFor(1.0)          -- open until 1001.0
  SB.suppressTypingFor(0.1)          -- would close at 1000.1
  w.now = 1000.5
  check("...and a shorter window never shortens a longer one already open",
        SB.typingInjection() == true)
end


-- =====================================================================
section("11. THE PLAIN GLOBAL HOTKEYS RIDE THE SAME TAP")
-- =====================================================================
-- 🚨 6.76.0 rescued ⇪ and left everything else where it found it, with a
-- line in the GUIDE admitting so. That was a report, not a fix — and it
-- left a TRAP: ⇪/ opens a full-screen cheat sheet whose Escape is a
-- Carbon hotkey. A panel you can open and cannot close is worse than one
-- you cannot open.
do
  local w = world{ carbon = false, tapKeys = true }
  local fired = {}
  -- Through the REAL §0.3 wrapper, which is what fills _G.globalDispatch.
  w.SB.hs.hotkey.bind({ "ctrl", "alt", "cmd" }, "L",
      function() fired[#fired + 1] = "ctrl-alt-cmd-L" end,
      function() fired[#fired + 1] = "L-up" end,
      function() fired[#fired + 1] = "L-repeat" end)
  w.SB.hs.hotkey.bind({ "cmd", "ctrl", "alt", "shift" }, "X",
      function() fired[#fired + 1] = "VEIL ESCAPE" end)

  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  local tap = w.taps[1]

  check("a standalone hs.hotkey.bind is recorded where the tap can find it",
        w.SB.globalDispatch["alt+cmd+ctrl+l"] ~= nil,
        (function() local n = {} for k in pairs(w.SB.globalDispatch) do n[#n+1] = k end
                    table.sort(n); return table.concat(n, " ") end)())
  check("🚨 ...and a ⇪ MODAL binding is not, because a table consulted "
     .. "while ⇪ is NOT held must never contain a bare letter",
        w.SB.globalDispatch["+d"] == nil and w.SB.globalDispatch["d"] == nil)

  fired = {}
  check("⌃⌥⌘L runs on a Mac with no working hotkey layer",
        tap.fn(w.mkEvent({ "ctrl", "alt", "cmd" }, "l", true)) == true
        and fired[1] == "ctrl-alt-cmd-L", fired[1])
  fired = {}
  check("...and its release handler runs on the way up",
        tap.fn(w.mkEvent({ "ctrl", "alt", "cmd" }, "l", false)) == true
        and fired[1] == "L-up", fired[1])
  fired = {}
  check("...and a held key runs the repeat handler",
        tap.fn(w.mkEvent({ "ctrl", "alt", "cmd" }, "l", true, true)) == true
        and fired[1] == "L-repeat", fired[1])

  fired = {}
  check("an unbound chord is passed straight through",
        tap.fn(w.mkEvent({ "ctrl", "cmd" }, "q", true)) == false and #fired == 0)

  -- 🚨 RAIL 1. This branch runs while you are ordinarily typing.
  w.SB.globalDispatch["+d"] = { pressed = function() fired[#fired + 1] = "BARE" end }
  fired = {}
  check("🚨 a bare key is NEVER dispatched from the global table — this "
     .. "branch runs while you are typing, and a letter that ran a "
     .. "shortcut instead of typing itself is the worst outcome here",
        tap.fn(w.mkEvent({}, "d", true)) == false and #fired == 0, fired[1])
  w.SB.globalDispatch["+d"] = nil

  -- 🚨 RAIL 2. The forwarded chord echoes back through this same tap.
  fired = {}
  w.SB.hyperForwardChord("x")           -- stamps _G.hyperChordUntil
  check("🔁 the echo of a forwarded ⌘⇧⌃⌥ chord is refused, so releasing ⇪ "
     .. "mid-forward cannot fire the chord's global hotkey",
        tap.fn(w.mkEvent({ "cmd", "ctrl", "alt", "shift" }, "x", true)) == false
        and #fired == 0, fired[1])
  timePasses(w, 1)
  fired = {}
  check("...and once the echo window has passed, the same chord pressed by "
     .. "hand works normally",
        tap.fn(w.mkEvent({ "cmd", "ctrl", "alt", "shift" }, "x", true)) == true
        and fired[1] == "VEIL ESCAPE", fired[1])

  -- the injection guard applies here too
  fired = {}
  w.SB.withInjection(function()
    check("an injected chord never fires a global hotkey either",
          tap.fn(w.mkEvent({ "ctrl", "alt", "cmd" }, "l", true)) == false
          and #fired == 0, fired[1])
  end)
end

do
  local w = world{ carbon = true, tapKeys = true }
  local fired = {}
  w.SB.hs.hotkey.bind({ "ctrl", "alt", "cmd" }, "L",
      function() fired[#fired + 1] = "L" end)
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  timePasses(w)
  check("🚨 on a Mac where Carbon works the tap does NOT also run globals "
     .. "— that would fire every one of them twice",
        w.taps[1].fn(w.mkEvent({ "ctrl", "alt", "cmd" }, "l", true)) == false
        and #fired == 0, fired[1])
end

-- =====================================================================
section("12. ESCAPE IS RESCUED, so nothing can trap you")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  local tap = w.taps[1]

  check("Escape with no panel open is left alone — it belongs to the app",
        tap.fn(w.mkEvent({}, "escape", true)) == false)

  local closed = 0
  w.SB.routeEscape = function() closed = closed + 1; return "cheatsheet" end
  check("🚨 Escape reaches whichever panel claims it, so ⇪/ can never open "
     .. "a sheet that Carbon is too dead to close",
        tap.fn(w.mkEvent({}, "escape", true)) == true and closed == 1, closed)

  closed = 0
  w.SB.routeEscape = function() closed = closed + 1; return nil end
  check("...and when nothing wants it, it is passed through rather than "
     .. "eaten", tap.fn(w.mkEvent({}, "escape", true)) == false and closed == 1)

  w.SB.routeEscape = function() error("router is broken", 0) end
  check("🛟 a router that throws costs the Escape, not the keyboard",
        tap.fn(w.mkEvent({}, "escape", true)) == false)

  w.SB.routeEscape = function() return "cheatsheet" end
  check("⇧Escape and ⌘Escape are not the panel Escape and stay untouched",
        tap.fn(w.mkEvent({ "shift" }, "escape", true)) == false)
end

-- =====================================================================
section("13. THE FORWARDED CHORD IS STAMPED BEFORE IT IS SENT")
-- =====================================================================
do
  local w = world{ carbon = false, tapKeys = true }
  loadHyperKey(w)
  runTimers(w)
  pressCapsLock(w, runTimers)
  timePasses(w)
  w.SB.hyperMods = { "cmd", "shift", "ctrl", "alt" }
  w.SB.hyperChordUntil = 0
  w.SB.hyperForwardChord("g")
  check("forwarding writes down when it happened",
        w.SB.hyperChordUntil > (w.now or 0), w.SB.hyperChordUntil)
  check("...and the window is short enough to be over before you could "
     .. "press the same chord by hand", w.SB.hyperChordGrace <= 0.5,
        w.SB.hyperChordGrace)

  local code = {}
  for line in (INIT_SRC .. "\n"):gmatch("([^\n]*)\n") do
    code[#code + 1] = line:match("^%s*%-%-") and "" or line
  end
  local initCode = table.concat(code, "\n")
  check("🚨 §3.12 forwards THROUGH that helper rather than calling "
     .. "keyStroke straight, or the stamp would never be written",
        initCode:find("_G.hyperForwardChord(key)", 1, true) ~= nil)
  check("...with a plain send still behind it, so forwarding never depends "
     .. "on core/hyper_key.lua having loaded",
        initCode:find("if _G.hyperForwardChord then", 1, true) ~= nil
        and initCode:find("hs.eventtap.keyStroke(_G.hyperMods, key,", 1, true) ~= nil)
end

-- =====================================================================
section("15. A LOST F18 keyUp DOES NOT LATCH ⇪ FOR THE SESSION (6.162.1)")
-- =====================================================================
-- 🚨 LL: "everything I would type or click went haywire. I lost control
-- of my MacBook." With the modal entered and no release ever arriving,
-- every letter is a shortcut or a forwarded ⌘⇧⌃⌥ chord and nothing
-- types until Hammerspoon dies. The watchdog lets a SILENT hold go; a
-- real hold, which keeps producing key events, is never cut short.
do
  local w = world{ dropKeyUp = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  w.now = 1000
  w.mkEvent({}, "f18", true, false, false).post()     -- keyDown; keyUp is lost
  check("⇪ is down after the press", w.SB.hyperActive == true and w.modal.entered)
  check("...and a held watchdog timer exists for it",
        w.SB.hyperLatchTimer ~= nil and w.SB.hyperLatchSecs == 8)
  -- the release never comes; the clock passes the latch window
  w.now = 1000 + w.SB.hyperLatchSecs + 1
  runTimers(w)
  check("🚨 the watchdog lets the phantom hold go — hyperActive false, modal exited",
        w.SB.hyperActive == false and w.modal.entered == false,
        tostring(w.SB.hyperActive) .. "/" .. tostring(w.modal.entered))
  local said = false
  for _, l in ipairs(w.printed) do if l:find("released by the watchdog", 1, true) then said = true end end
  check("...and says so in the Console, counting the release",
        said and w.SB.hyperLatchReleases == 1)
  -- and typing is typing again: a bare 'd' must NOT run ⇪D
  w.ran = {}
  w.mkEvent({}, "d", true, false, false).post()
  w.mkEvent({}, "d", false, false, false).post()
  check("...so a bare letter afterwards is a letter, not a shortcut", #w.ran == 0, w.ran[1])
  -- the next real press works as ever, and its release ends it
  w.now = w.now + 1
  w.dropKeyUp = false                                   -- the release arrives this time
  pressCapsLock(w, nil)
  check("the next ⇪ press enters and its release exits as before",
        w.SB.hyperActive == false and w.SB.hyperLatchTimer == nil)
end

do
  -- A REAL long hold with keys arriving is never cut short.
  local w = world{}
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  w.now = 2000
  w.mkEvent({}, "f18", true, false, false).post()
  w.now = 2006
  w.mkEvent({}, "d", true, false, false).post()        -- a key under the hold
  w.mkEvent({}, "d", false, false, false).post()
  check("a key seen under the hold restamps it", w.SB.hyperHeldAt == 2006)
  w.now = 2009                                          -- 9s since the press, 3s since the key
  local t = w.SB.hyperLatchTimer
  w.SB.hyperLatchTimer = nil                            -- fire it by hand at THIS clock
  t.fn()
  check("🔒 the watchdog does NOT release a hold that is still producing keys",
        w.SB.hyperActive == true and w.modal.entered == true)
  check("...it re-arms for the remainder instead", w.SB.hyperLatchTimer ~= nil)
  w.mkEvent({}, "f18", false, false, false).post()
  check("the real release still ends it and clears the timer",
        w.SB.hyperActive == false and w.SB.hyperLatchTimer == nil)
end

do
  -- 6.165.1 — A TEXT PANEL TOOK THE KEYBOARD: the deadline shortens, the
  -- way in does not change. LL's first ⇪1 press: "held 8s with no key
  -- event and no F18 keyUp" — eight seconds of letters going to shortcuts.
  local w = world{ dropKeyUp = true }
  loadHyperKey(w)
  bindShortcuts(w)
  runTimers(w)
  w.now = 3000
  w.mkEvent({}, "f18", true, false, false).post()      -- keyDown; keyUp is lost
  check("(6.165.1) _G.hyperExpectRelease exists and answers true under a hold",
        type(w.SB.hyperExpectRelease) == "function" and w.SB.hyperExpectRelease(1.5, "a pad") == true)
  local t = w.SB.hyperLatchTimer
  check("...it re-arms the held watchdog for the short deadline", t ~= nil and t.secs == 1.5, t and t.secs)
  w.now = 3002                                           -- 2s after the press: silence
  w.SB.hyperLatchTimer = nil
  t.fn()
  check("🚨 after 1.5s of silence the phantom hold is let go",
        w.SB.hyperActive == false and w.modal.entered == false)
  -- 🚨 6.248.0 — THIS CHECK ASSERTED A SENTENCE 6.285.0 DELIBERATELY
  -- CHANGES. The old line read "released by the watchdog — held 8s …
  -- a pad had taken the keyboard", which is the sentence this config
  -- prints when ⇪ is genuinely STUCK — printed on a Mac where nothing
  -- was wrong, every time LL opened the music card. The RULE it existed
  -- for (the panel is named, and the hold really ends) is unchanged and
  -- is what it asserts now.
  local said = false
  for _, l in ipairs(w.printed) do
      if l:find("a pad took the keyboard", 1, true) then said = true end
  end
  check("...and the Console line names the panel that took the keyboard",
        said, w.printed[#w.printed])
  check("🔔 …and says it is NORMAL rather than reading as a stuck ⇪", (function()
      for _, l in ipairs(w.printed) do
          if l:find("a pad took the keyboard", 1, true) then
              return l:find("Normal, not a stuck", 1, true) ~= nil
          end
      end
      return false
  end)())
  check("🚨 …and it is NOT counted as a latch. That number is what the storm "
        .. "report prints as a fault, and it used to climb on a healthy Mac",
        w.SB.hyperLatchReleases == 0 and w.SB.hyperPanelHandovers == 1,
        tostring(w.SB.hyperLatchReleases) .. "/" .. tostring(w.SB.hyperPanelHandovers))
  -- Said ONCE per panel: he opens that card all day.
  local before = #w.printed
  w.now = 3003
  w.mkEvent({}, "f18", true, false, false).post()
  w.SB.hyperExpectRelease(1.5, "a pad")
  local t2 = w.SB.hyperLatchTimer; w.SB.hyperLatchTimer = nil
  w.now = 3005
  t2.fn()
  check("🔕 the same panel is explained ONCE, then counted in silence",
        w.SB.hyperPanelHandovers == 2 and #w.printed == before,
        tostring(w.SB.hyperPanelHandovers) .. " / +" .. (#w.printed - before))
  check("...expectation cleared", w.SB.hyperReleaseExpected == nil)
  check("with ⇪ up the call is a no-op (false)", w.SB.hyperExpectRelease(1.5) == false)

  -- a key under the shortened hold still pushes the deadline out
  w.now = 3010
  w.mkEvent({}, "f18", true, false, false).post()
  w.SB.hyperExpectRelease(1.5, "a pad")
  w.now = 3011
  w.mkEvent({}, "d", true, false, false).post()
  w.mkEvent({}, "d", false, false, false).post()
  t = w.SB.hyperLatchTimer; w.SB.hyperLatchTimer = nil
  w.now = 3011.6
  t.fn()
  check("🔒 a key under the shortened hold keeps it (re-armed, not released)",
        w.SB.hyperActive == true and w.SB.hyperLatchTimer ~= nil)
  w.mkEvent({}, "f18", false, false, false).post()

  -- the page saw the F18 keyUp itself
  w.now = 3020
  w.mkEvent({}, "f18", true, false, false).post()
  -- 🚨 6.248.0 again: this asserted hyperLatchReleases == 2, which made a
  -- RELAYED keyUp — the cleanest ending there is, the release really
  -- happened and a panel passed it on — indistinguishable from ⇪ sticking.
  check("_G.hyperReleaseSeen releases at once and counts it as a RELAY, "
        .. "never as a latch",
        w.SB.hyperReleaseSeen("the scratch pad") == true and w.SB.hyperActive == false
        and w.SB.hyperLatchTimer == nil and w.SB.hyperRelayReleases == 1
        and w.SB.hyperLatchReleases == 0,
        tostring(w.SB.hyperRelayReleases) .. "/" .. tostring(w.SB.hyperLatchReleases))
  check("...and is a no-op with ⇪ up", w.SB.hyperReleaseSeen("x") == false)
end

-- =====================================================================
section("13b. 🔔 6.285.0 — A HANDOVER IS NOT A LATCH")
-- =====================================================================
-- LL's Console on an ordinary ⇪⇧pad.: "⇪ released by the watchdog — held
-- 8s … musicPlayer had taken the keyboard." Nothing was wrong; the card
-- takes the keys on purpose and the handshake ends the hold. But that is
-- the sentence printed when ⇪ is genuinely stuck, and it incremented the
-- number the storm report calls a fault.
do
  local w = world{}
  loadHyperKey(w)
  local V = w.SB.hyperEndVerdict
  check("the verdict is PURE and reachable", type(V) == "function")

  local k = V({ expected = "musicPlayer" })
  check("a panel that DECLARED itself is a handover, not a latch", k == "handover", k)
  check("no panel declared anything → latch", V({}) == "latch")
  check("an EMPTY panel name is nobody, not a handover", V({ expected = "" }) == "latch")
  check("a relayed keyUp outranks everything — the release really happened",
        V({ relayed = true, expected = "musicPlayer" }) == "relay")

  local _, w1 = V({ expected = "musicPlayer" })
  check("the handover sentence names the panel and says it is normal",
        w1 and w1:find("musicPlayer", 1, true) and w1:find("Normal, not a stuck", 1, true), w1)
  local _, w2 = V({ expected = "musicPlayer", said = true })
  check("🔕 …and is silent the second time for the same panel", w2 == nil)
  local _, w3 = V({ quiet = 8, count = 3 })
  check("the LATCH sentence keeps its urgency and its numbers",
        w3 and w3:find("released by the watchdog", 1, true)
        and w3:find("release #3", 1, true) and w3:find("held 8s", 1, true), w3)
  -- 🚨 The fault sentence must NOT be reachable for a declared panel:
  -- that is the entire complaint.
  local _, w4 = V({ expected = "musicPlayer", quiet = 8, count = 3 })
  check("🚨 a declared panel can never be handed the watchdog's wording",
        w4 and w4:find("released by the watchdog", 1, true) == nil, w4)
  check("nil arguments answer a latch and a sentence, never throw", (function()
      local ok, kk, ww = pcall(V, nil)
      return ok and kk == "latch" and type(ww) == "string"
  end)())

  -- the report
  w.SB.hyperRelayReleases, w.SB.hyperPanelHandovers, w.SB.hyperLatchReleases = 2, 5, 0
  w.SB.hyperSaidHandover = { musicPlayer = true }
  w.printed = {}
  check("_G.hyperKeyReport exists", type(w.SB.hyperKeyReport) == "function")
  w.SB.hyperKeyReport()
  local rep = table.concat(w.printed, "\n")
  -- 🧪 THREE DISTINCT NUMBERS, or the check passes with two lines reading
  -- the same counter — which is the exact defect this release is about,
  -- one layer out (6.212.0: assert what is UNIQUE to the branch).
  check("…and prints all three endings apart, each from its OWN counter",
        rep:find("relay    : 2", 1, true) and rep:find("handover : 5", 1, true)
        and rep:find("latch    : 0", 1, true), rep)
  check("…with a clean latch line reading 0, no ⚠️",
        rep:find("latch    : 0", 1, true) ~= nil, rep)
  check("…and it names the panels that have taken the keyboard",
        rep:find("musicPlayer", 1, true) ~= nil)
  w.SB.hyperLatchReleases = 1
  w.printed = {}
  w.SB.hyperKeyReport()
  check("🚨 a real latch DOES get the ⚠️ — the fault must still shout",
        table.concat(w.printed, "\n"):find("⚠️ 1", 1, true) ~= nil,
        table.concat(w.printed, "\n"))
end

do
  -- 🚨 IT DEGRADES: a Hammerspoon where core/hyper_key.lua did not load
  -- must still release a phantom hold and still say so.
  local w = world{ dropKeyUp = true }
  -- deliberately NOT loadHyperKey(w): hyperEndVerdict is undefined
  bindShortcuts(w)
  runTimers(w)
  w.now = 5000
  w.mkEvent({}, "f18", true, false, false).post()
  w.now = 5000 + w.SB.hyperLatchSecs + 1
  runTimers(w)
  check("🛟 with no verdict function the watchdog still releases the hold",
        w.SB.hyperActive == false)
  local said = false
  for _, l in ipairs(w.printed) do
      if l:find("released by the watchdog", 1, true) then said = true end
  end
  check("🛟 …and still says so, with the old sentence", said)
end

-- =====================================================================
section("13c. 🌅 6.302.0 — A WAKE IS A RELEASE")
-- =====================================================================
-- LL's 10:57 storm report: ⇪ held 10.5 s, six shortcuts fired inside it,
-- 266 Caps Lock autorepeats that session so the key really does repeat
-- on his Mac, and "My laptop travelled with me in my car and I just
-- plugged it in." The hold's AGE is what decides it — 10.5 s, not the
-- 58 minutes since the previous ⇪ key — so it began after the wake.
-- Nothing in this config watched the wake side at all.
do
  local w = world{}
  loadHyperKey(w)
  local V = w.SB.hyperWakeVerdict
  check("the wake verdict is PURE and reachable", type(V) == "function")

  check("systemDidWake with ⇪ HELD is a release", V("systemDidWake", true) == "release")
  check("screensDidUnlock too", V("screensDidUnlock", true) == "release")
  check("sessionDidBecomeActive too", V("sessionDidBecomeActive", true) == "release")
  -- 🔎 THREE ANSWERS (6.196.1): a wake that found nothing held is health,
  -- and it is NOT the same fact as no wake at all. A verdict with two
  -- answers would make a Mac whose watcher never ran read identically to
  -- a Mac that woke five times with ⇪ up.
  check("🔎 a wake with ⇪ UP is 'clear', not 'release' and not 'ignored'",
        V("systemDidWake", false) == "clear")
  check("the SLEEP side is ignored — that half was never the bug",
        V("systemWillSleep", true) == "ignored"
        and V("screensDidLock", true) == "ignored")
  check("an unknown event is ignored, and nil never throws", (function()
      local ok, k = pcall(V, nil, true)
      return ok and k == "ignored"
  end)())
  local _, words = V("systemDidWake", true)
  check("the release sentence says it is NOT a stuck ⇪",
        words and words:find("Not a stuck", 1, true) and words:find("systemDidWake", 1, true),
        words)
  check("...and 'clear' and 'ignored' say nothing at all",
        select(2, V("systemDidWake", false)) == nil
        and select(2, V("systemWillSleep", true)) == nil)

  -- 📐 6.239.0 — THE EVENT LIST IS CONFIG, so the check MOVES it and
  -- requires the verdict to follow. Asserting the three literals would
  -- pass against a verdict that spells them out a second time.
  local keep = w.SB.hyperWakeEvents
  w.SB.hyperWakeEvents = { "somethingNobodyHasHeardOf" }
  check("🔌 the verdict reads the event TABLE, not three names of its own",
        V("somethingNobodyHasHeardOf", true) == "release"
        and V("systemDidWake", true) == "ignored")
  w.SB.hyperWakeEvents = keep
end

do
  -- THE DOOR, driven end to end through the real §3.12 hold.
  local w = world{}
  bindShortcuts(w)
  loadHyperKey(w)
  runTimers(w)
  w.now = 7000
  w.mkEvent({}, "f18", true, false, false).post()
  check("⇪ is held", w.SB.hyperActive == true)

  local before = w.SB.hyperLatchReleases
  local ok = w.fireWake(1)                      -- hs.caffeinate systemDidWake
  check("macOS fires the watcher by CONSTANT and nothing throws", ok)
  check("🌅 the hold is let go", w.SB.hyperActive == false)
  check("...through the same door every other ending uses (modal exited, "
        .. "watchdog timer dropped)",
        w.modal.entered == false and w.SB.hyperLatchTimer == nil)
  -- 🚨 THE HEADLINE RULE. hyperLatchReleases is what the storm report
  -- prints as a fault; a wake release happens every morning on a healthy
  -- Mac, so counting it there would make the fault counter climb on
  -- health — 6.285.0's lesson one release later.
  check("🚨 …and it is NOT counted as a latch",
        w.SB.hyperLatchReleases == before and w.SB.hyperWakeReleases == 1,
        tostring(w.SB.hyperLatchReleases) .. "/" .. tostring(w.SB.hyperWakeReleases))
  check("…nor as a handover or a relay",
        w.SB.hyperPanelHandovers == 0 and w.SB.hyperRelayReleases == 0)
  check("…and the wake was SEEN as well as acted on",
        w.SB.hyperWakesSeen == 1, w.SB.hyperWakesSeen)
  check("🔕 it says so in the Console and nowhere else — no alert",
        (function()
            local said = false
            for _, l in ipairs(w.printed) do
                if l:find("nobody holds", 1, true) then said = true end
            end
            return said and #w.told == 0
        end)(), table.concat(w.told, ","))

  -- a wake with ⇪ up is counted and silent
  local quiet = #w.printed
  w.fireWake(2)
  check("a wake with ⇪ UP is counted, releases nothing and says nothing",
        w.SB.hyperWakesSeen == 2 and w.SB.hyperWakeReleases == 1
        and #w.printed == quiet,
        tostring(w.SB.hyperWakesSeen) .. "/" .. tostring(w.SB.hyperWakeReleases))
  -- 🚨 an event we do not watch must not even count as a wake, or the
  -- report's "N wake(s) seen" becomes "N caffeinate events", which is a
  -- different and useless number on a Mac that locks its screen all day.
  w.fireWake(4)                                 -- screensDidLock
  check("🚨 the sleep side is not counted as a wake either",
        w.SB.hyperWakesSeen == 2, w.SB.hyperWakesSeen)

  -- 🔑 THE EXPECTATION IS CLEARED — a stale name would attribute the
  -- NEXT hold's ending to a panel that is long gone. Earned by
  -- hyperExit(), not by a line in the wake door: a second assignment
  -- there survived its own mutation and was taken out (6.199.0).
  w.now = 7100
  w.mkEvent({}, "f18", true, false, false).post()
  w.SB.hyperExpectRelease(1.5, "a pad")
  w.fireWake(1)
  check("🔑 a wake release clears the panel expectation",
        w.SB.hyperReleaseExpected == nil, tostring(w.SB.hyperReleaseExpected))

  check("the door answers false with ⇪ up rather than throwing",
        w.SB.hyperWakeRelease("systemDidWake") == false)
  check("...and false for an event it does not watch",
        w.SB.hyperWakeRelease("systemWillSleep") == false)

  -- 🔒 6.235.0 — INSIDE A PLATFORM CALLBACK A THROW IS A SILENCE, so the
  -- guard goes around the WHOLE body.
  -- 🧪 AND THE FIRST VERSION OF THIS CHECK PASSED ITS OWN MUTATION: it
  -- nil'd hyperWakeVerdict, which makes the RELEASE throw — and the
  -- release is already the pcall's argument, so `pcall(f, wakeName(ev))`
  -- catches it just as happily as the wrapped form. The only thing that
  -- tells the two apart is a throw in the ARGUMENT, i.e. inside
  -- wakeName itself. 6.235.0's own sentence, unpaid until the sweep ran:
  -- the check that proves a guard makes something throw that is not
  -- already guarded on its own.
  w.SB.hyperWakeEvents = 5                 -- ipairs(5) raises in wakeName
  check("🔒 a throw while RESOLVING the event cannot escape the callback",
        w.fireWake(1) == true)
  w.SB.hyperWakeEvents = { "systemDidWake" }
  w.SB.hyperWakeVerdict = nil
  check("🔒 …and so can a throw inside the release itself",
        w.fireWake(1) == true)
end

do
  -- 🔎 THE REPORT'S THREE STATES.
  local w = world{}
  loadHyperKey(w)
  check("the watcher is HELD in a global — a collected one never fires",
        w.SB.hyperWakeWatcher ~= nil and w.SB.hyperWakeWatcher.on == true)
  check("...and the state says so", w.SB.hyperWakeState == "watching")

  w.SB.hyperWakesSeen, w.SB.hyperWakeReleases = 4, 0
  w.printed = {}; w.SB.hyperKeyReport()
  local rep = table.concat(w.printed, "\n")
  check("🔎 health reads as wakes SEEN with none held — not as silence",
        rep:find("wake     : 4 wake(s) seen, none found ⇪ held", 1, true) ~= nil, rep)
  check("...and carries no ⚠️ on the wake line", (function()
      for _, l in ipairs(w.printed) do
          if l:find("wake     :", 1, true) then return l:find("⚠️") == nil end
      end
      return false
  end)())

  w.SB.hyperWakeReleases = 2
  w.printed = {}; w.SB.hyperKeyReport()
  rep = table.concat(w.printed, "\n")
  check("a wake that DID find ⇪ held is named, and said not to be a latch",
        rep:find("2 found ⇪ STILL HELD", 1, true)
        and rep:find("Not a latch", 1, true), rep)
  -- 🧪 6.212.0's rule: assert what is UNIQUE to the branch. Two lines
  -- reading one counter would pass a check that only looked for a number.
  check("🧪 …from its OWN counter, distinct from latch/handover/relay",
        rep:find("latch    : 0", 1, true) and rep:find("handover : 0", 1, true)
        and rep:find("relay    : 0", 1, true), rep)
end

do
  -- 🛟 A MAC THAT CANNOT HEAR ITS OWN WAKE SAYS SO — three ways in, one
  -- honest answer each. 6.196.1: "not watching" must never read as
  -- "no wake has happened yet".
  for _, case in ipairs({
        { "hs.caffeinate missing",   { noCaffeinate = true },      "not available" },
        { "watcher.new throws",      { watcherNewThrows = true },  "no caffeinate here" },
        { "watcher.new answers nil", { watcherNewNil = true },     "answered nothing" },
        { "start() throws",          { watcherStartThrows = true }, "refused to start" },
      }) do
    local w = world(case[2])
    loadHyperKey(w)
    check("🛟 " .. case[1] .. ": the boot survives and the state NAMES it",
          w.SB.hyperWakeState ~= "watching"
          and tostring(w.SB.hyperWakeState):find(case[3], 1, true) ~= nil,
          w.SB.hyperWakeState)
    check("   ↳ …no half-made watcher is left holding the slot",
          w.SB.hyperWakeWatcher == nil)
    w.printed = {}; w.SB.hyperKeyReport()
    check("   ↳ …and the report line is a ⚠️, never a count of zero",
          table.concat(w.printed, "\n"):find("wake     : ⚠️", 1, true) ~= nil,
          table.concat(w.printed, "\n"))
  end
  -- and the ⚠️ reaches him at boot, once
  local w = world{ watcherNewThrows = true }
  local degraded = {}
  w.SB.degrade = function(tool, why) degraded[#degraded + 1] = tostring(tool) end
  loadHyperKey(w)
  check("🔔 …and it takes the degrade door once, naming the tool",
        #degraded == 1 and degraded[1] == "Hyper wake release",
        table.concat(degraded, ","))
end

do
  -- 🌩 THE STORM REPORT'S FINGERPRINT. The `before :` line is what named
  -- 6.282.0 as the build LL was running; it has to carry the new ending
  -- or the next storm cannot say whether the wake release was even up.
  local src = readAll(HS .. "/modules/hyper_storm.lua") or ""
  check("🌩 the storm report's `before :` line carries the wake count",
        src:find("wake releases %d", 1, true) ~= nil)
  check("   ↳ …and its STATE beside it, so 0 releases on a Mac that was "
        .. "not watching cannot read as 0 releases on one that was",
        src:find("_G.hyperWakeState", 1, true) ~= nil)
  check("   ↳ …read through tonumber, so a build without core/hyper_key.lua "
        .. "prints a number rather than throwing (6.282.0)",
        src:find("tonumber(_G.hyperWakeReleases) or 0", 1, true) ~= nil)
end

-- =====================================================================
section("13d. 🔬 6.303.0 — WHAT THE KEYBOARD LOOKS LIKE AFTER A WAKE")
-- =====================================================================
-- 6.302.0 could not have prevented the 10:57 storm. This is the release
-- aimed at it, and it is a PROBE because this is new ground: three
-- things can latch ⇪ with the key physically up, and none of them was
-- visible from Lua.

-- hidutil's REAL output shape. The usage codes come back as DECIMAL,
-- not as the hex this config sets them with — a parser written for the
-- hex would read "no remap" on every healthy Mac and repair a keyboard
-- that was never broken.
local HID_OK = [[(
    {
        HIDKeyboardModifierMappingDst = 30064771181;
        HIDKeyboardModifierMappingSrc = 30064771129;
    }
)]]
local HID_EMPTY = "(\n)\n"
-- 🚨 THE FIXTURE THAT DECIDES IT: Caps Lock remapped to ESCAPE. A
-- Src-only test — the plausible wrong implementation — calls this
-- health while ⇪ is dead (6.230.0: pick the input where the right and
-- wrong answers must DIFFER).
local HID_ELSEWHERE = [[(
    {
        HIDKeyboardModifierMappingDst = 30064771113;
        HIDKeyboardModifierMappingSrc = 30064771129;
    }
)]]
local HID_SECOND = [[(
    {
        HIDKeyboardModifierMappingDst = 30064771113;
        HIDKeyboardModifierMappingSrc = 30064771111;
    },
    {
        HIDKeyboardModifierMappingDst = 30064771181;
        HIDKeyboardModifierMappingSrc = 30064771129;
    }
)]]

do
  local w = world{}
  loadHyperKey(w)
  local R = w.SB.hyperRemapPresent
  check("the remap parser is PURE and reachable", type(R) == "function")
  check("🔢 hidutil's DECIMAL answer reads as present", R(HID_OK) == true)
  check("...and the hex spelling too, since tonumber takes both",
        R((HID_OK:gsub("30064771181", "0x70000006D")
                 :gsub("30064771129", "0x700000039"))) == true)
  check("an EMPTY mapping list is a real answer: false, not nil",
        R(HID_EMPTY) == false)
  check("🚨 Caps Lock remapped to something ELSE is NOT our remap — the "
        .. "Src alone would call a dead ⇪ healthy", R(HID_ELSEWHERE) == false)
  check("...and our pair is found when it is not the first entry",
        R(HID_SECOND) == true)
  -- 🔎 6.196.1: "it answered and the mapping is gone" and "it could not
  -- be asked" are opposite facts, and only the first may repair.
  check("🔎 handed no string at all, it answers nil — never false",
        R(nil) == nil and R(42) == nil)
  check("...and junk it cannot parse is false, not a throw", (function()
      local ok, v = pcall(R, "not a plist at all")
      return ok and v == false
  end)())
end

do
  -- THE PROBE, driven end to end.
  local w = world{}
  w.SB.hyperRemapJSON = '{"UserKeyMapping":[{"a":1}]}'
  w.SB.secureInput = { on = false }
  bindShortcuts(w)
  loadHyperKey(w)
  runTimers(w)
  w.now = 9000

  check("nothing has been looked at before the first wake",
        w.SB.hyperWakeProbe.at == nil)
  w.printed = {}; w.SB.hyperKeyReport()
  check("...and the report SAYS so, and names the command to ask by hand",
        table.concat(w.printed, "\n"):find("hyperWakeProbeRun", 1, true) ~= nil,
        table.concat(w.printed, "\n"))

  -- a wake fires it, but only after a beat: macOS re-enumerates the
  -- keyboard asynchronously, so asking inside the callback measures the
  -- moment BEFORE the one that matters.
  w.fireWake(1)
  check("🔬 a wake does not probe immediately — it arms a HELD timer",
        w.SB.hyperWakeProbe.at == nil and w.SB.hyperWakeProbeTimer ~= nil)
  -- 🧪 GUARDED, because the mutation that fires the probe inline leaves
  -- this slot nil and indexing it ENDS the run with "0 failed" never
  -- printed — a dead suite reads as a passing one in a gate that greps
  -- the tail. 6.186.0, tenth time: a test answers falsely, never dies.
  check("...for the configured beat, not a number of its own",
        w.SB.hyperWakeProbeTimer ~= nil
        and w.SB.hyperWakeProbeTimer.secs == w.SB.hyperWakeProbeAfter,
        w.SB.hyperWakeProbeTimer and w.SB.hyperWakeProbeTimer.secs)
  runTimers(w)
  check("...and then it looks", w.SB.hyperWakeProbe.at ~= nil
        and w.SB.hyperWakeProbe.at >= 9000, tostring(w.SB.hyperWakeProbe.at))

  check("the tap was asked, and answered about the object we HOLD",
        w.SB.hyperWakeProbe.tap == true)
  check("Secure Input is READ from capabilities.lua, not re-probed",
        w.SB.hyperWakeProbe.secure == "clear")
  local t = w.taskFor("UserKeyMapping")
  check("🔎 the remap is asked OUT OF PROCESS — hidutil, --get, started",
        t ~= nil and t.bin == "/usr/bin/hidutil" and t.started == true
        and t.args[2] == "--get", t and t.bin)
  check("...and nothing is decided until it answers",
        w.SB.hyperWakeProbe.remap == nil and w.SB.hyperWakeProbe.reads == 0)

  w.answerTask("UserKeyMapping", 0, HID_OK)
  check("a healthy Mac reads present, repairs nothing, says nothing",
        w.SB.hyperWakeProbe.remap == true
        and w.SB.hyperWakeProbe.repaired == 0
        and w.taskFor("--set") == nil)
end

do
  -- 🚨 THE REMAP IS GONE. This is the candidate for LL's storm, and the
  -- only thing this probe is allowed to repair.
  local w = world{}
  w.SB.hyperRemapJSON = '{"UserKeyMapping":[{"a":1}]}'
  bindShortcuts(w); loadHyperKey(w); runTimers(w)
  w.now = 9100
  w.fireWake(1); runTimers(w)
  local degraded = {}
  w.SB.degrade = function(tool, why) degraded[#degraded + 1] = tostring(tool) end
  w.answerTask("UserKeyMapping", 0, HID_EMPTY)

  check("🚨 hidutil says the mapping is GONE", w.SB.hyperWakeProbe.remap == false)
  -- 🪜 6.196.1 / 6.262.0: the repair must NOT be started from inside the
  -- read's own callback. It steps off a held doAfter(0) first.
  check("🪜 the repair is armed off a HELD hop, not fired inside the "
        .. "read's callback", w.SB.hyperRemapRepairHop ~= nil
        and w.taskFor("--set") == nil)
  runTimers(w)
  local fix = w.taskFor("--set")
  check("...and then it runs", fix ~= nil and fix.started == true)
  check("🔑 …with init.lua's OWN published mapping, never a second copy",
        fix and fix.args[3] == w.SB.hyperRemapJSON, fix and fix.args[3])
  check("🪜 …in its own slot, so starting it never dropped the read",
        w.SB.hyperRemapRepairTask ~= nil and w.SB.hyperRemapReadTask ~= nil
        and w.SB.hyperRemapRepairTask ~= w.SB.hyperRemapReadTask)

  w.answerTask("--set", 0)
  check("🔔 a remap that was GONE is the one thing this shouts about — ⇪ "
        .. "had stopped existing", #degraded == 1
        and degraded[1] == "Hyper wake probe", table.concat(degraded, ","))
  check("...and it is counted", w.SB.hyperWakeProbe.repaired == 1)
  check("...and the Console says what it means, not just that it happened",
        (function()
            for _, l in ipairs(w.printed) do
                if l:find("was GONE", 1, true) then
                    return l:find("latch across a wake", 1, true) ~= nil
                end
            end
            return false
        end)(), w.printed[#w.printed])
end

do
  -- 🔎 "COULD NOT BE ASKED" MUST NEVER REPAIR. A Mac that cannot run
  -- hidutil would otherwise re-apply the remap after every wake, for
  -- ever, on no evidence at all.
  local w = world{}
  w.SB.hyperRemapJSON = '{"x":1}'
  bindShortcuts(w); loadHyperKey(w); runTimers(w)
  w.fireWake(1); runTimers(w)
  w.answerTask("UserKeyMapping", 1, "")
  check("🔎 a non-zero exit is nil — not 'gone'",
        w.SB.hyperWakeProbe.remap == nil)
  runTimers(w)
  check("🚨 …and NOTHING is repaired on an answer nobody got",
        w.taskFor("--set") == nil and w.SB.hyperWakeProbe.repaired == 0)
  check("...it is counted as unreadable instead",
        w.SB.hyperWakeProbe.failed == 1, w.SB.hyperWakeProbe.failed)
end

do
  -- 🛟 A BUILD WHOSE init.lua DID NOT PUBLISH THE MAPPING refuses the
  -- repair and says why, rather than inventing a literal of its own.
  local w = world{}
  w.SB.hyperRemapJSON = nil
  bindShortcuts(w); loadHyperKey(w); runTimers(w)
  w.fireWake(1); runTimers(w)
  w.answerTask("UserKeyMapping", 0, HID_EMPTY)
  runTimers(w)
  check("🛟 with no published mapping the repair is REFUSED and named",
        w.taskFor("--set") == nil
        and w.SB.hyperWakeProbe.repairFailed == 1
        and table.concat(w.printed, "\n"):find("hyperRemapJSON", 1, true) ~= nil,
        table.concat(w.printed, "\n"))
end

do
  -- 🛟 NO hs.task AT ALL — the probe still answers the two free
  -- questions and does not throw.
  local w = world{ noTask = true }
  bindShortcuts(w); loadHyperKey(w); runTimers(w)
  w.fireWake(1); runTimers(w)
  check("🛟 with no hs.task the probe still ran and still answered",
        w.SB.hyperWakeProbe.at ~= nil and w.SB.hyperWakeProbe.tap == true
        and w.SB.hyperWakeProbe.remap == nil
        and w.SB.hyperWakeProbe.failed == 1)
end

do
  -- 🔎 THE REPORT — three states per row, and the third is always
  -- "could not be asked", which must never read like health.
  local w = world{}
  loadHyperKey(w)
  local P = w.SB.hyperWakeProbe
  P.at, P.why = 9000, "systemDidWake"
  P.remap, P.tap, P.secure, P.reads = true, true, "clear", 1
  w.printed = {}; w.SB.hyperKeyReport()
  local rep = table.concat(w.printed, "\n")
  check("🔎 a healthy probe prints three plain rows and no ⚠️",
        rep:find("Caps Lock → F18 still set", 1, true)
        and rep:find("the F18 event tap is running", 1, true)
        and rep:find("Secure Input clear", 1, true), rep)
  check("...with no warning anywhere in the probe block", (function()
      for _, l in ipairs(w.printed) do
          if l:find("remap :", 1, true) or l:find("tap   :", 1, true)
             or l:find("secure:", 1, true) then
              if l:find("⚠️") then return false end
          end
      end
      return true
  end)(), rep)

  P.remap, P.tap, P.secure = false, false, "loginwindow"
  w.printed = {}; w.SB.hyperKeyReport()
  rep = table.concat(w.printed, "\n")
  check("🚨 …and each fault is named in its own words, not one summary",
        rep:find("GONE — ⇪ had stopped existing", 1, true)
        and rep:find("event tap was NOT running", 1, true)
        and rep:find("Secure Input held by loginwindow", 1, true), rep)

  P.remap, P.tap, P.secure = nil, nil, nil
  w.printed = {}; w.SB.hyperKeyReport()
  rep = table.concat(w.printed, "\n")
  check("🔎 …and 'could not be asked' is its OWN third answer, distinct "
        .. "from both health and fault",
        rep:find("could not be read", 1, true)
        and rep:find("capabilities.lua has not answered yet", 1, true), rep)

  P.repairFailed = 2
  w.printed = {}; w.SB.hyperKeyReport()
  check("a FAILED repair is a ⚠️ on the counts line — the worst state "
        .. "here is a dead ⇪ that could not be revived",
        table.concat(w.printed, "\n"):find("2 repair(s) FAILED", 1, true) ~= nil,
        table.concat(w.printed, "\n"))
end

do
  -- 🔒 SOURCE SENTRIES, both about a CLASS rather than a line.
  local src = readAll(HS .. "/core/hyper_key.lua") or ""
  -- 🚨 6.262.0's STRIPPER EATS `--get`. A naive `%-%-[^\n]*` removes
  -- everything after the first double dash on a line, and hidutil's
  -- argv is `{ "property", "--get", "UserKeyMapping" }` — so the
  -- stripped source lost the one occurrence this sentry needed and the
  -- check went red on a healthy tree. Full-LINE comments only, and the
  -- next check proves the argument survived, so a stripper that eats it
  -- again cannot pass by making the haystack empty.
  -- 📏 NAMED, NOT SWEPT: other sentries in this config strip comments
  -- the naive way. None of them reads an argv today; if one comes to,
  -- it inherits this bug.
  local bare = src:gsub("\n%s*%-%-[^\n]*", "\n")
  -- 🧪 AND THE FIRST VERSION OF THIS SENTRY WENT RED ON A HEALTHY TREE:
  -- it forbade `HIDKeyboardModifierMappingSrc`, which is exactly what
  -- the PARSER has to match on. A sentry that cannot tell the thing
  -- from the thing that reads it is one that gets switched off in a
  -- week (6.269.0). What must not be here is the JSON we would SET
  -- with, so that is what it looks for.
  check("🔒 the hidutil --get argument really is in the stripped source, "
        .. "so the sentry below has a haystack to search",
        bare:find('"--get", "UserKeyMapping"', 1, true) ~= nil)
  check("🔒 this file grows no second copy of the UserKeyMapping JSON "
        .. "— the repair uses init.lua's published one",
        bare:find('UserKeyMapping":', 1, true) == nil
        and bare:find('UserKeyMapping\\":', 1, true) == nil
        and bare:find("HIDKeyboardModifierMappingDst:", 1, true) == nil,
        "found a mapping literal in core/hyper_key.lua")
  check("   ↳ …and the comment explaining why still exists, so the sentry "
        .. "cannot be satisfied by deleting the reason (6.280.0)",
        src:find("hyperRemapJSON", 1, true) ~= nil
        and src:find("6.231.0", 1, true) ~= nil)
  check("🔒 …and it never grows its own ioreg — Secure Input belongs to "
        .. "core/capabilities.lua, which asks it on its own clock (6.242.0)",
        bare:find("ioreg", 1, true) == nil)
  local init = INIT_SRC or ""
  check("🔑 init.lua publishes the mapping it actually applies",
        init:find("_G.hyperRemapJSON = HYPER_REMAP_ON", 1, true) ~= nil)
end

-- =====================================================================
section("14. THE CHANGELOG CSV CANNOT GO STALE AGAIN")
-- =====================================================================
-- It sat on 6.63.0 for thirteen releases: version, date and the whole
-- notes paragraph were hard-coded, so the file quietly stopped describing
-- the config while continuing to look like it did.
do
  local dir = os.tmpname(); os.remove(dir); os.execute("mkdir -p '" .. dir .. "'")
  local written = {}
  local function runCsv(version, configdir)
    local SB = {
      hs = { configdir = configdir or HS }, io = io, os = os,
      print = function(...)
        local p2 = {}
        for i = 1, select("#", ...) do p2[#p2 + 1] = tostring((select(i, ...))) end
        written[#written + 1] = table.concat(p2, " ")
      end,
      tostring = tostring, pairs = pairs, ipairs = ipairs, type = type,
      string = string, table = table,
    }
    SB._G = SB
    SB.configVersion = version
    local chunk = assert(loadfile(HS .. "/core/changelog_csv.lua", "t", SB))
    chunk()({ logsDir = dir,
              csvQuote = function(v) return '"' .. tostring(v):gsub('"', '""') .. '"' end })
  end

  runCsv("6.76.0")
  local f = io.open(dir .. "/changelog.csv", "r")
  local body = f and f:read("*a") or ""
  if f then f:close() end
  check("the row is written from CHANGELOG.md, not from a string somebody "
     .. "has to remember to retype",
        body:find("6.76.0", 1, true) ~= nil
        and body:find("HYPER KEY", 1, true) ~= nil, body:sub(1, 120))
  check("...with a header on a brand new file",
        body:sub(1, 4) == "Date")
  check("...and the notes are one CSV cell, newlines flattened",
        select(2, body:gsub("\n", "")) == 2, select(2, body:gsub("\n", "")))

  written = {}
  runCsv("6.76.0")
  local f2 = io.open(dir .. "/changelog.csv", "r")
  local again = f2 and f2:read("*a") or ""
  if f2 then f2:close() end
  check("🚨 a second boot on the same version appends nothing",
        again == body, #again .. " vs " .. #body)

  written = {}
  runCsv("9.99.0")
  check("🚨 a version with NO CHANGELOG.md entry is REPORTED, not written "
     .. "as a blank row — the exact silence that let it sit on 6.63.0",
    (function()
      for _, l in ipairs(written) do
        if l:find("no CHANGELOG.md entry", 1, true) then return true end
      end
      return false
    end)(), written[1])
  local f3 = io.open(dir .. "/changelog.csv", "r")
  local after = f3 and f3:read("*a") or ""
  if f3 then f3:close() end
  check("...and really writes nothing", after == body)

  written = {}
  runCsv("6.75.0", "/nonexistent")
  check("🛟 an unreadable CHANGELOG.md degrades to a message, not a throw",
    (function()
      for _, l in ipairs(written) do
        if l:find("no CHANGELOG.md entry", 1, true) then return true end
      end
      return false
    end)())

  os.execute("rm -rf '" .. dir .. "'")
end

out(("\n%d passed, %d failed\n\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
