-- =====================================================================
-- MODULE: MOUSE GRID (⇪X) — type three letters, the pointer goes there
-- =====================================================================
-- ⇪X lays a labelled grid over every display. Every cell carries a
-- three-letter code ("agl"). Type it and the pointer jumps to that cell's
-- centre. Then either click with the trackpad, or stay on the keyboard:
-- SPACE clicks, arrows nudge, ⎋ backs out.
--
-- ⇪⇧X is the same thing that clicks for you the moment you finish typing.
-- ⌃⌥⌘⇧X is the panic key — see SAFETY below.
--
-- ---------------------------------------------------------------------
-- WHAT THIS IS, AND THE THING IT DELIBERATELY IS NOT
-- ---------------------------------------------------------------------
-- This is a COORDINATE tool. It divides screen area into cells and moves
-- the pointer. It knows nothing about what is underneath, which is
-- exactly why it never fails: it works over video, PDFs, a Photoshop
-- canvas, a remote desktop session, a game, a screen-shared window — any
-- pixel is reachable.
--
-- The other family of tool (Vimac, Homerow, Scoot's element mode) walks
-- the ACCESSIBILITY TREE, finds real buttons and links, and labels only
-- those. It is more precise where it works, and it is what "like tabbing
-- onto a button" literally means. It was not built here, on purpose:
--
--   · it returns nothing in Electron apps, nothing in Java apps, and
--     nothing in anything that draws its own controls
--   · a full AX walk of a large window costs 100–500ms, every invocation
--   · it needs Accessibility, which a managed Mac can withhold — and
--     this module has to work on the work MacBook
--
-- So the FEEL of "tab onto it, press space" is provided instead, without
-- the fragility: after the jump the pointer stays live (see LANDED MODE)
-- so SPACE activates whatever it is sitting on. If the grid ever proves
-- too coarse for real targets, element detection can be added later as a
-- second stage sharing this same key handling. It should not be merged
-- into this one — the two have opposite failure modes.
--
-- 🎯 6.154.0 — AND THE SECOND STAGE ARRIVED, ON THE TERMS ABOVE. LL: "If
-- the grid letters are close to a dialog box or tab, can we jump the
-- cursor on top of that button? But, only if that button or field is
-- within the box that I select by typing two letters and then the third
-- of course would jump to that element." It is NOT a tree walk: it is at
-- most five HIT-TESTS ("what is under this point?") inside the one cell
-- you typed, centre first, one AX round-trip each, with a per-question
-- timeout and a budget. A control whose centre lies inside that cell
-- wins; anything else — no Accessibility, an Electron app that answers
-- nothing, a budget spent — leaves the cell-centre jump exactly as it
-- was. See SNAP ONTO A CONTROL below. The failure mode is therefore
-- "no snap", never "no jump".
--
-- ---------------------------------------------------------------------
-- 🚨 SAFETY — THE REAL RISK IN THIS FILE
-- ---------------------------------------------------------------------
-- A full-screen overlay that captures keystrokes is the most dangerous
-- thing in this config. Get the state machine wrong and the Mac is
-- unusable until Hammerspoon is force-quit. Four defences, each of which
-- works when the other three have failed:
--
--   1. ONE INVARIANT, ONE EXIT. `grid.state ~= nil` ⟺ a modal is entered
--      ⟺ a canvas is visible. Every path out goes through grid.hide(),
--      which is idempotent and pcalls each teardown step separately, so
--      one failing step cannot strand the others.
--   2. WATCHDOG. An overlay that outlives its keypress tears itself down
--      (grid.timeoutSecs). Nothing here can sit on your screen forever.
--   3. PANIC KEY. ⌃⌥⌘⇧X is a PLAIN global chord, not a ⇪ shortcut —
--      because if ⇪ itself is what broke, a ⇪ panic key is no panic key.
--      Same reasoning as Screen Veil's ⌃⌥⌘⇧G.
--   4. UNBOUND KEYS PASS THROUGH. Only the alphabet plus a handful of
--      control keys are claimed. ⌘Q, ⌘Tab and ⌃F2 keep working while the
--      grid is up. This is a deliberate refusal to capture everything:
--      an overlay you can always ⌘Q out of cannot lock you out.
--
-- And LANDED MODE is never invisible. Whenever keys are being captured
-- there is something on screen saying so — the grid itself, or the
-- crosshair badge. A keyboard-eating mode with no visual is the hazard;
-- the badge is not decoration.
--
-- ---------------------------------------------------------------------
-- HOW MANY CELLS YOU GET — the arithmetic, because it is not obvious
-- ---------------------------------------------------------------------
-- Labels are FIXED length, which a grid requires: uniform cells cannot
-- carry a prefix-free variable-length code. So capacity is exactly
--
--        #alphabet ^ labelLength
--
-- Default since 6.184.0: the 9 home-row keys, 3 deep = 729 cells, ~45pt
-- on a 1512×982 panel and ~70pt on a 4K — labels you can read at a
-- glance without leaving the home row. 6.176.0 tried 16 keys / 4,096
-- cells / ~30pt to beat the 44pt minimum control size, and LL's verdict
-- was "HOLY SHIT! The grid is insane. Way too small." The coarse grid is
-- safe again because 6.181.0 moved precision into the SNAP: a control
-- whose frame CONTAINS the landing point wins on a second pass, so a
-- cell wider than the button still lands ON it. Fine cells buy accuracy
-- you now get for free, and cost reading and typing you do not.
--
-- ⚠️ TWO OR MORE DISPLAYS SPLIT THAT 729 BY AREA. Two screens roughly
-- doubles the cell, which can be coarser than a button — the nudge in
-- landed mode exists for exactly that. If you run multiple displays and
-- want the fine grid back, buy capacity by widening the alphabet:
--
--        "asdfghjkl"          9  ->    729 cells
--        "asdfghjklzxcvbnm"  16  ->  4,096 cells   (adds the bottom row)
--        "asdfghjkl", len 4   9  ->  6,561 cells   (home row, 4 keystrokes)
--
-- `_G.mouseGridReport()` prints what this Mac actually resolved to —
-- per screen, cols × rows and the real cell size in points. Run it once
-- on each machine; it is the fastest way to see whether the grid is fine
-- enough for the way you work.
--
-- ---------------------------------------------------------------------
-- WHY IT IS FAST — and it has to be, or you will not use it
-- ---------------------------------------------------------------------
-- 729 cells is ~1,500 canvas elements. Rebuilding that on every press
-- would put a visible stall between the keystroke and the grid, which is
-- the difference between a tool you reach for and one you forget. So:
--
--   · GRID LINES AND SCRIM are one canvas per screen, built ONCE for a
--     given display layout and cached forever after. ~50 elements.
--   · LABELS are a SECOND canvas, and the only thing rebuilt. The full
--     unfiltered element table is cached too, so even the first draw is
--     a table reuse rather than a build, from the second invocation on.
--   · FILTERING SHRINKS IT. Type one letter and 729 candidates become
--     81; another and 81 become 9. Every redraw after the first is
--     cheaper than the one before it.
--   · The cache is keyed on the display layout and invalidated by a
--     screen watcher, so plugging in a monitor rebuilds rather than
--     drawing yesterday's grid over today's screens.
--
-- Timings go to the diagnostic trail on every show; `_G.diag.verbose =
-- true` puts them in the Console.
--
-- ⚠️ ACCESSIBILITY: MOVING AND CLICKING ARE NOT THE SAME PERMISSION.
-- Warping the pointer needs nothing at all, so the JUMP always works,
-- on any Mac, granted or not. Synthesising a CLICK goes through
-- hs.eventtap, which macOS gates behind Accessibility. Without it the
-- grid still jumps and SPACE reports why it could not click, rather than
-- doing nothing and looking broken.
--
-- ---------------------------------------------------------------------
-- ✂️ 6.428.0 — EVERY CELL IS SPLIT INTO FOUR, AND THE LETTERS ARE THE
-- TIMER'S YELLOW
-- ---------------------------------------------------------------------
-- LL: "Split all boxes into fours again. Overall, the boxes are too big
-- and not useful enough at that size. Make the grid letters the same
-- translucent yellow as the Timer card tool that flashes yellow when the
-- timer is up. Do this instead of white letters in the boxes. If you can
-- think of a better system for the grid, do it."
--
-- 📐 HIS TWO SENTENCES ARE ONE NUMBER, AND IT IS THE ARITHMETIC ABOVE.
-- "Split into fours" and "the boxes are too big" are the same request
-- read from two sides: capacity is `#alphabet ^ labelLength`, and at 26
-- letters squared that is 676 cells — ~45pt on the Air panel, ~71pt on
-- the 4K, against a toolbar button of 28–40pt. The cell was about twice
-- the target, every time. So every cell `planScreen` lays out is now
-- DIVIDED 2 × 2 before anything is drawn (`grid.subdivisions`), which
-- quarters the area without touching the label length: the code he types
-- is the same length it was, and the box it lands in is a quarter of the
-- size. That is the whole release, and it is why the answer was not
-- "type a fourth letter" — the label is the binding constraint (6.176.0
-- proved a 30pt cell with a three-character label is unreadable, and his
-- verdict then was "HOLY SHIT! The grid is insane"), so the fix buys
-- precision with GEOMETRY and spends none of his typing on it.
--
-- 🎯 AND "AGAIN" IS THE SECOND HALF — the landed box refines FOUR WAYS
-- now, not two. 6.192.0's ⌥+arrow halving was removed on his own word
-- ("Too convoluted"), 6.252.0 replaced it with a two-letter split along
-- the longer side, and this makes it a/s/d/f → top-left, top-right,
-- bottom-left, bottom-right, repeatable, with ⌫ restoring the parent.
-- `grid.quarterOf` is PURE and built from `grid.halfOf`, so the 16pt
-- floor, the refusals and their reasons are the ones already proven;
-- `grid.refineSpec` answers the keys AND the parts AND where they came
-- from, so a bad `quarterKeys` override falls back to asdf and SAYS so
-- rather than binding nothing. Two-way splitting is still reachable
-- (`refineParts = 2`) because it is his muscle memory from 6.252.0.
--
-- 🟡 THE LETTERS ARE THE CONFIG'S ACCENT, READ AND NEVER RETYPED.
-- `grid.labelInk()` reads `_G.uiStyle.accent` — ui_style.lua:157, "the
-- pomodoro flash amber — THE accent of this config" — which is the same
-- table modules/timer.lua:439 takes its ⏱ TIME UP flash from. One
-- literal, three readers (6.231.0): the Timer card, the grid labels and
-- the fallback inside each are the same four numbers, so "the same
-- yellow as the Timer" is true by construction rather than by eye. White
-- was not a taste: 6.372.0 measured white-on-white at 1.00:1, which is
-- the ring being invisible on most of what is on screen, and a label is
-- the same problem. Each label keeps a small dark backplate so the
-- translucent yellow has something to be legible against.
--
-- 🔎 AND AN UNREADABLE GRID IS REFUSED BEFORE IT TAKES THE KEYBOARD.
-- Quartering costs cells, and cells cost points: `fittedLabelSize`
-- answers the point size a three-character label really gets in the cell
-- this screen produces, the layout reduces density rather than drawing
-- letters nobody can read, and a frame that still cannot carry one
-- DECLINES — no modal, no capture, a sentence saying why. That order is
-- the rule this file already lives by: a keyboard-eating mode with no
-- legible visual is the hazard, so the check happens while the keyboard
-- is still his.
--
-- 🚨 AND THE CARBON FALLBACK DECLINES THIS TOOL, said rather than left
-- to be discovered. When ⇪ is running on the Carbon dispatcher rather
-- than the event tap, this Carbon-modal overlay is not entered at all —
-- an explicit loss of the grid on that path, never a claim that it
-- works there. ⇪⇧L (find the pointer) is a separate tool and is
-- unaffected.
--

local M = {
    version = "6.428.0",   -- printed by the report: which file is loaded
    name  = "Mouse Grid",
    order = 13.6,
    family = "windows",
    cheatsheet = {
        title = "🎯 MOUSE GRID (⇪X — type 3 letters, the pointer goes there)",
        entries = {
            { "⇪X",       "Overlay the labelled grid on every display" },
            { "⇪⇧X",      "Same, but click the moment you finish typing" },
            { "a–z",     "Type a cell's 3 letters — the pointer jumps there" },
            { "snap",     "Off by default: land in the chosen cell without querying app controls. Optional Accessibility snapping remains available" },
            { "⌫",        "Undo one letter while typing" },
            { "⎋",        "Cancel — the pointer does not move" },
            { "-- after it lands --", "" },
            { "space",    "Left click · ⇧space right click · 2 double click" },
            { "↑↓←→",     "Nudge 8pt a press — HOLD it and it repeats at that same 8pt, like an arrow in a text box (the old climb to 64pt is gone, 6.360.0) · with ⇧ nudge 1pt for a tight target" },
            { "3 letters", "Smaller initial cells: every former cell is divided into four" },
            { "a s / d f", "After landing: top-left / top-right / bottom-left / bottom-right. Repeat to refine; the letters are drawn in Timer yellow" },
            { "⌫", "Undo the last refinement; Escape finishes without clicking" },
            { "⎋",        "Done — leave the pointer where it is" },
            { "⇪⇧L",      "Find the pointer — three coloured rings pulse out from it, again and again, for 5 s" },
            { "",         "6.372.0: BIGGER (180 pt, was 110) and in colour — magenta, orange, violet in turn. It shipped WHITE, which is 1.00:1 on a white window, so over Finder or Word the ring was genuinely not there. Every colour now clears 2.5:1 on white AND on black" },
            { "",         "Sized to the screen (×1.5 on a 4K at full points); grid.locateRadius / locateColors / locateSecs / locateScale to taste" },
            { "⌃⌥⌘⇧X",   "PANIC — tear the overlay down whatever state it is in" },
            { "check it", "_G.mouseGridReport() — cell size on THIS Mac" },
        },
    },
}

-- 6.167.0: a positive number from whatever a settings override holds
-- ("2" is 2; 0, a negative or a word is `default`). Used by the pointer
-- ring's scale, its frame function and the report alike.
local function num(v, default)
    v = tonumber(v)
    if v and v > 0 then return v end
    return default
end

function M.setup(core)
    local grid = {}

    -- ✏️ EDIT HERE ---------------------------------------------------------
    grid.enabled     = true
    grid.key         = "x"          -- ⇪X. ⇪⇧X is the click-on-arrival twin.
    -- 🖱 6.66.0 — THE POINTER RING GETS A REAL KEY AT LAST. grid.locate()
    -- has existed since 6.45.0 and was bound to nothing on the argument
    -- that macOS shake-to-grow already covers it. 6.65.0 put it on ⇪pad*,
    -- and 6.66.0 cleared the pad layer — so it lands on a letter, which is
    -- also the only kind of key that cannot turn out to be missing from
    -- this keyboard (see _G.padProbe and the ⇪pad+ story).
    grid.locateKey   = "l"          -- ⇪⇧L — L for locate

    -- Capacity is alphabet^labelLength — see the arithmetic block above.
    -- These two are ONE decision, not two: changing either changes how
    -- many cells exist and therefore how precise the grid is.
    -- 6.176.0 went the other way and it was WRONG for this Mac. LL had
    -- said "each cell is rather large … I'm still rather far off from a
    -- dialogue", so the bottom row joined the home row: 16 cubed, 4,096
    -- cells, ~30 pt where they had been ~70. LL, on seeing it:
    -- "HOLY SHIT! The grid is insane. Way too small."
    -- 6.184.0 puts the home row back. The reason it is safe to be coarse
    -- now is 6.181.0: the SNAP takes a second chance on any control whose
    -- frame CONTAINS the landing point, so a cell wider than the button
    -- still puts the pointer ON it. Precision moved out of the grid and
    -- into the snap, which is where it costs no reading and no typing.
    -- 729 cells is ~45 pt on a 1512×982 panel and ~70 pt on the 4K:
    -- labels you can read at a glance, three keystrokes on one row.
    -- ✏️ Finer again, if it is ever wanted — one line, no release:
    --    settings = { mouse_grid = { alphabet = "asdfghjklzxcvbnm" } }
    --      16 keys ->  4,096 cells (the 6.176.0 grid)
    --    settings = { mouse_grid = { labelLength = 4 } }
    --      9 keys, 4 deep ->  6,561 cells, four keystrokes
    --    `_G.mouseGridReport()` prints the REAL cell size on this Mac —
    --    read it after any change here rather than guessing.
    -- ⌨️ 6.373.0 — TWO KEYSTROKES, HIS ANSWER. The ask was "too much work
    -- to get to a specific element", said across 6.176.0, 6.181.0 and
    -- 6.360.0, and the arithmetic nobody had written down is what
    -- settles it: cells = #alphabet ^ labelLength.
    --
    --     9 home-row keys, 3 deep  =   729 cells, THREE keystrokes
    --    26 letters,       2 deep  =   676 cells, TWO keystrokes
    --
    -- Within 4% of the same cell — so the boxes stay the size he has
    -- already accepted — for a THIRD of the typing removed. And a
    -- two-character label is wider-spaced in the same box, so it reads
    -- better rather than worse, which is the trap 6.176.0 fell into:
    -- 4,096 cells was a 30 pt box carrying a three-character label, and
    -- his reaction ("HOLY SHIT! The grid is insane") was correct.
    --
    -- 📏 ITS ONE COST, NAMED: the letters are the whole keyboard rather
    -- than the home row, so two reaches replace three home-row taps.
    -- That was his to judge, and he judged it.
    grid.alphabet    = "abcdefghijklmnopqrstuvwxyz"
    grid.labelLength = 2
    grid.subdivisions = 1       -- 1 = no pre-draw division; precision is a/s/d/f
    grid.maxCells = 4096        -- bounded canvas/label work across all displays
    -- ✏️ How slow a geometry build has to be before the Console says so
    -- (milliseconds). See the note where it is used: the cost is once
    -- per display layout, never per press.
    grid.buildSlowMs = 120

    -- 🎨 The look you asked for. Read as COVERAGE and BRIGHTNESS, which is
    -- the only reading that works: a 30% *opaque* grey would hide the very
    -- thing you are aiming at.
    --   scrim = black at 30% alpha  ("a 30% shade of grey")
    --   lines = 80% white           ("lines are 80% grey")
    -- 🌓 6.248.0 — TWO SCRIMS, NOT ONE. LL: "When I first bring up the
    -- grid, please make the boxes less translucent so I can read the
    -- letters easier, then on first key press make the box 100% see
    -- through." Those are two different jobs asked of one number: the
    -- FIRST draw is a reading surface (three letters per cell, over
    -- whatever was on screen), and after a keystroke it is an aiming
    -- surface where the darkening is only in the way.
    --   scrimAlpha      — the wash before you type. 0.30 -> 0.55 on his
    --                     word; the labels are white on it.
    --   scrimAlphaTyped — the wash after the first character. 0 means
    --                     exactly what he said: the screen comes back and
    --                     only the amber survivors are drawn over it.
    -- Both are settings-overridable and BOTH draw sites ask the same pure
    -- function, so the two can never drift.
    grid.scrimWhite       = 0.00
    grid.scrimAlpha       = 0.55
    grid.scrimAlphaTyped  = 0.00
    -- ✒️ 6.438.0 — THE LINES ARE FAINTER THAN THE LETTERS, AND THAT IS A
    -- RULE RATHER THAN A NUMBER I LIKED. LL, 2026-11-14: "Make the mouse
    -- grid box lines fainter, the letters are more important."
    -- 🔎 HE IS DESCRIBING A TIE. The lines drew at alpha 0.55 and the
    -- labels at the accent's own 0.96 — but a one-point hairline running
    -- the full height of the screen covers far more of it than a
    -- two-character label does, so the thing with the LOWER alpha was
    -- winning the screen on area alone. That is 6.429.0's finding in the
    -- other direction: occlusion is area, not opacity.
    -- 📏 SO THE LINES GET THE SMALLER SHARE OF BOTH. 0.22 over this
    -- module's own 0.55 black scrim leaves them visible as STRUCTURE —
    -- you can still see where a cell ends — without competing with the
    -- glyph you are actually reading. The floor is that they must stay
    -- visible at all: a grid with no cell edges is a wall of letters
    -- with no geometry, which is a different complaint he has already
    -- made once (6.429.0).
    -- 🧪 AND THE CHECK ASSERTS THE RULE AGAINST THE SHIPPED DEFAULTS,
    -- never a value the suite pinned — 6.429.0 shipped a regression past
    -- 614 green checks because every section pinned its own numbers
    -- first. `grid.lineAlpha = 0.55` puts the old weight back.
    grid.lineWhite   = 0.80
    grid.lineAlpha   = 0.22
    grid.lineWidth   = 1.0

    -- 🔠 6.65.0 — LABEL SIZE IS NOW A FLOOR PLUS A FIT, not one number.
    -- 12pt was chosen when the only question was "does it fit". The
    -- question that actually matters is "can you read it at a glance from
    -- normal sitting distance", and 12 loses that on a 4K panel where a
    -- cell is physically small. labelSize is the MINIMUM; labelFitFrac
    -- lets a label grow to fill its box on a coarse grid, and the whole
    -- thing is clamped by width so a 3-character label can never spill
    -- out of a narrow cell (see fittedLabelSize below).
    grid.labelSize    = 14      -- preferred; dense cells shrink it to fit
    grid.labelFitFrac = 0.55    -- of cell HEIGHT, when there is room for more
    grid.labelMaxSize = 34      -- ceiling, so a 2-column grid isn't absurd
    grid.labelWhite  = 1.00
    grid.labelAlpha  = nil      -- inherit the Timer card accent alpha
    -- 📏 THE PLATE IS OCCLUSION, AND HE SAW IT FIRST: "I can't see past
    -- the boxes." A plate exists only so the yellow reads over a white
    -- window (6.372.0 measured white-on-white at 1.00:1), so it hugs the
    -- glyphs and nothing more. labelBackplates = false removes them.
    grid.labelBackplates = true -- small dark plates keep yellow readable over white apps
    -- 0.72 is MEASURED, not chosen: it is the value at which this yellow
    -- clears 4.5:1 over a white application, and the suite recomputes that
    -- ratio from whatever is set here (6.239.0). Lower it and the gate
    -- says so rather than letting the letters quietly go unreadable.
    grid.labelPlateAlpha = 0.72 -- how opaque that plate is (0 = invisible, 1 = solid)

    -- 🟡 6.65.0 — THE MATCH HIGHLIGHT. Once you type a letter, the cells
    -- that are still reachable get a thick yellow box and everything else
    -- gets out of the way (see redraw() — the lattice itself is dropped on
    -- the first keystroke, so what is left on screen is only what you can
    -- still choose). Before this the survivors were distinguished purely
    -- by "the other labels went away", which is a difference you have to
    -- look for rather than one that arrives on its own.
    grid.matchStroke  = { red = 1.00, green = 0.84, blue = 0.00 }  -- amber
    grid.matchWidth   = 3.0     -- border thickness, in points
    grid.matchFill    = { red = 1.00, green = 0.84, blue = 0.00, alpha = 0.13 }
    grid.matchRadius  = 4       -- rounded corners; 0 for square
    -- Drop the grid lines once typing starts, so the survivors stand alone
    -- on the scrim. false keeps the full lattice up the whole time.
    grid.dropLattice  = true

    -- 🎯 6.154.0 — SNAP ONTO A CONTROL INSIDE THE CELL (see the header).
    -- A handful of hit-tests, not a tree walk; every question has its
    -- own timeout and the whole thing a budget. Roles that count as "a
    -- button or field": macOS tabs are AXRadioButtons inside a tab group,
    -- web buttons/links in Chrome answer AXButton/AXLink, an open menu's
    -- rows are AXMenuItems. Text, images and table cells are left out —
    -- landing on a paragraph's centre is not what "jump onto it" means.
    grid.snapToControls = false  -- precise coordinate targeting; no AX hit-tests by default
    grid.snapBudget     = 0.08      -- seconds of hit-testing per landing
    grid.snapTimeout    = 0.05      -- per AX question (setTimeout)
    -- 🎯 6.181.0 — THE SECOND-CHANCE SNAP. LL: "I am still a bit too far
    -- off from buttons and have to use the arrow keys more than I should
    -- have to." The cells were not the problem. Snap only accepted a
    -- control whose CENTRE fell inside the typed cell, so every button
    -- WIDER than a cell — which, at 729 cells, is nearly all of them — was
    -- found, identified, and then refused: the report literally said
    -- "AXButton under the cell, but its centre is outside it", and the
    -- pointer was left in the middle of the cell for the arrows to
    -- finish. A control that CONTAINS the point you typed is now a
    -- second-tier answer: taken only when nothing centres inside the
    -- cell, and only when it is small enough to be a control rather than
    -- a container that happens to carry a control's role.
    grid.snapContains   = true
    grid.snapMaxArea    = 60000     -- pt² (≈300×200) — bigger is furniture, not a button
    grid.snapRoles      = {
        AXButton = true, AXTextField = true, AXTextArea = true,
        AXCheckBox = true, AXRadioButton = true, AXPopUpButton = true,
        AXComboBox = true, AXLink = true, AXMenuButton = true,
        AXMenuItem = true, AXMenuBarItem = true, AXDisclosureTriangle = true,
        AXSlider = true, AXIncrementor = true, AXColorWell = true,
    }

    -- After the jump, stay live so SPACE can click (the "tab onto it"
    -- feel). false = jump and get out of the way immediately.
    grid.landedMode  = true
    grid.nudgeStep   = 8            -- arrows, in points
    grid.nudgeFine   = 1            -- ⇧ + arrows
    -- 🗑 6.360.0 — A HELD ARROW DOES NOT ACCELERATE (LL: "Take the grid
    -- arrow acceleration away."). 6.172.1 built the climb and 6.195.0 made
    -- its first repeat four steps, BOTH on his own earlier asks ("the
    -- arrow keys … do not make enough jumps … cover more ground by holding
    -- the key down"). So this is a premise expiring rather than code that
    -- was wrong — 6.311.0's rule — and his word closes it without an
    -- argument. DELETED, NOT SWITCHED OFF (6.261.0: keeping everything is
    -- right for a door and wrong for behaviour he does not want):
    -- nudgeAccelFirst/Every/Max/Window and grid.accelFor are gone, so a
    -- hold repeats at nudgeStep — what an arrow in a text box does.
    -- 📏 COST, NAMED: crossing a 4K display by arrow is 8 pt a repeat
    -- rather than up to 64, so the long haul belongs to the grid again and
    -- the arrows are for the last few points. A bigger nudgeStep would buy
    -- that distance back AND the overshoot with it, which is the likeliest
    -- reason the climb was unwanted — so it is NOT raised here on a guess.

    -- 🚨 Watchdogs. Neither of these is a nicety.
    grid.timeoutSecs = 12           -- overlay up, nothing typed
    -- ✂️ 6.192.0 — HALVE THE BOX YOU LANDED IN. LL, with a diagram: "A
    -- big cell one misses a button and I have to arrow a lot to get to
    -- it … Once I select a box, can the box be broken in half so I have
    -- a better chance of landing on the button."
    -- ⌥ + an arrow keeps the HALF of the current box on that side and
    -- puts the pointer in its middle. Press it again and it halves
    -- again, so each press doubles the precision — three presses is a
    -- 70 pt cell down to under 9 pt, where the old way was arrow taps.
    -- WHY AN ARROW AND NOT A LETTER LABEL on each half, which is what
    -- LL's picture shows: landed mode is FORBIDDEN from capturing any
    -- alphabet key (see the bind block below — it is a rule with a test,
    -- and it exists so LL's typing reaches the app he just landed on).
    -- An arrow needs no label to read: the direction IS the name of the
    -- half, and it composes — ⌥← ⌥← ⌥↑ walks in without a mode to enter
    -- or leave.
    grid.halve       = true         -- rollback: settings = { mouse_grid = { halve = false } }
    grid.halveMin    = 8            -- points; it will not make a box smaller than this
    -- ✂️ 6.252.0 — THE TWO LETTERS. LL: "When I reach the yellow box
    -- level, split each box in half putting one letter of the alphabet in
    -- each box. Remove the ⌥halve option as I don't use that. Too
    -- convoluted." nil means "the first two of grid.alphabet"; a string of
    -- two DIFFERENT characters overrides it.
    grid.refineParts = 4        -- four quarters; 2 retains the older two-way mode
    grid.quarterKeys = "asdf"   -- top-left, top-right, bottom-left, bottom-right
    grid.halveKeys   = nil          -- settings = { mouse_grid = { halveKeys = "jk" } }
    grid.landedSecs  = 8            -- landed badge up, nothing pressed
    -- 🖱 6.155.0 — a click by HAND ends landed mode. LL's Console, after
    -- ⇪X had landed on a button: "watchdog fired after 8s — landed badge
    -- left open". The click that used the landing came from the trackpad,
    -- not the space bar, and nothing was listening for it. A mouse-down
    -- tap now runs only while landed; the click passes through untouched.
    grid.clickEnds   = true

    -- "screenSaver" draws ABOVE the menu bar, which is required: at
    -- "overlay" the top ~25pt of the grid hides behind it and menu-bar
    -- items become unreachable. The cost is that it also covers
    -- hs.alert, so every error path below hides the grid BEFORE it
    -- alerts. Change this only if something pokes through.
    grid.windowLevel = "screenSaver"
    -- ----------------------------------------------------------------------

    function grid.labelInk()
        local style = type(_G.uiStyle) == "table" and _G.uiStyle or {}
        local accent = type(style.accent) == "table" and style.accent or {}
        local function channel(value, fallback)
            local n = tonumber(value)
            if not n or n ~= n or n == math.huge or n == -math.huge then return fallback end
            return math.max(0, math.min(1, n))
        end
        return { red = channel(accent.red, 1), green = channel(accent.green, 0.84),
                 blue = channel(accent.blue, 0),
                 alpha = channel(grid.labelAlpha, channel(accent.alpha, 0.96)) }
    end

    -- ---- state -----------------------------------------------------------
    -- 🚨 THE INVARIANT: state ~= nil  ⟺  a modal is entered  ⟺  a canvas
    -- is visible. Nothing may break this. grid.hide() is the only way out
    -- and it restores all three together.
    grid.state    = nil
    grid.cache    = nil    -- geometry + canvases, keyed on the screen layout
    grid.watchdog = nil    -- HELD: an unreferenced hs.timer is collected and
                           -- silently never fires. That lesson cost 6.33.0 a
                           -- warm-up, and here it would cost the watchdog.
    grid.screenWatch = nil -- HELD for the same reason
    grid.cross    = nil    -- the landed-mode badge canvas
    grid.boxDraw  = nil    -- HELD: the halved-box outline (6.192.0)
    grid.clickTap = nil    -- HELD while landed: the hand-click listener (6.155.0)

    -- 🐛 A FLAT LIST OF WHAT IS ON SCREEN, KEPT DELIBERATELY SEPARATE FROM
    -- grid.cache. The first version of hide() walked `grid.cache.screens or
    -- {}` to put the overlay away, and the test suite caught what that
    -- means: when the thing that broke IS the cache, `or {}` makes the
    -- teardown a no-op. The modal exited, the state cleared, and the sheet
    -- stayed on screen at screenSaver level over everything.
    --
    -- Teardown must never depend on the structure that just failed. So
    -- every canvas made visible is recorded here, and hide() walks THIS.
    grid.shown = {}

    local function showCanvas(c)
        if not c then return false end
        local owner = grid.state
        local function late(panel)
            -- A callback belongs to this exact invocation, not whichever
            -- newer grid happens to be open when it finally arrives.
            if not owner or grid.state ~= owner then return end
            local ok, shown = pcall(function() return panel:show() end)
            if not ok or not shown then return end
            grid.shown[#grid.shown + 1] = panel
        end
        -- Register even a partial native show before trying it: AppKit can
        -- order a window and then throw. hide() must still be able to reach it.
        grid.shown[#grid.shown + 1] = c
        local ok, shown
        if _G.showCanvasSafely then
            ok, shown = pcall(_G.showCanvasSafely,c,"mouse grid",late)
        else
            ok, shown = pcall(function() return c:show() end)
        end
        return ok and shown ~= false and shown ~= nil
    end

    -- Idempotent, and each canvas is pcall'd on its own: one throwing must
    -- not leave the rest of them up.
    local function hideAllShown()
        for _, c in ipairs(grid.shown) do
            pcall(function() c:hide() end)
        end
        grid.shown = {}
    end

    local function say(msg) if _G.diag then _G.diag.say("mouseGrid", msg) end end
    local function warn(msg) if _G.diag then _G.diag.warn("mouseGrid", msg) end end

    -- =====================================================================
    -- LABELS
    -- =====================================================================
    -- Index -> label, plain base-N in the alphabet. Row-major assignment
    -- means the FIRST letter always selects a contiguous horizontal band,
    -- so typing it lights up a block you can see rather than a scatter.
    -- ⚠️ ONLY KEYS THIS KEYBOARD CAN ACTUALLY SEND. hs.hotkey's getKeycode
    -- RAISES on a name your keymap has no code for — it does not return nil
    -- — so one exotic character in grid.alphabet would take the whole
    -- module down at setup(). Numpad Layer learned the same lesson against
    -- the same API; this is the same guard.
    --
    -- Filtering HERE rather than at bind time is deliberate: the alphabet
    -- feeds the geometry as well, so a letter you cannot type would
    -- otherwise label cells you can never reach.
    local warnedKeys = false
    local function alphabetChars()
        local t, dropped = {}, {}
        local map = (hs.keycodes and hs.keycodes.map) or nil
        for ch in tostring(grid.alphabet):gmatch(".") do
            local c = ch:lower()
            -- No keycodes table at all (a test harness) means take it as
            -- given rather than silently returning an empty alphabet.
            if map == nil or map[c] ~= nil then t[#t + 1] = c
            else dropped[#dropped + 1] = c end
        end
        if #dropped > 0 and not warnedKeys then
            warnedKeys = true
            print("🎯 Mouse Grid: this keyboard layout has no key code for "
                  .. table.concat(dropped, ", ") .. " — dropped from the alphabet")
            warn("dropped unusable alphabet keys: " .. table.concat(dropped, ", "))
        end
        return t
    end

    local function labelFor(index, chars)
        local n, out = #chars, {}
        for place = grid.labelLength, 1, -1 do
            local digit = math.floor(index / (n ^ (place - 1))) % n
            out[#out + 1] = chars[digit + 1]
        end
        return table.concat(out)
    end

    -- =====================================================================
    -- GEOMETRY
    -- =====================================================================
    -- fullFrame(), NOT frame(). frame() excludes the menu bar and the Dock,
    -- and a pointer tool that cannot reach the menu bar or the Dock has
    -- given away two of the places you most want to click.
    -- ⚠️ NO "%d" ON SCREEN GEOMETRY, ANYWHERE. In Lua 5.4
    -- string.format("%d", x) RAISES "number has no integer representation"
    -- for any float that is not exactly integral, and a scaled display's
    -- frame is not something this module controls. A cache key only has to
    -- be stable and unique, so tostring() is both safer and sufficient.
    local function layoutKey()
        local parts = {}
        local okAll, screens = pcall(hs.screen.allScreens)
        if not (okAll and screens) then return "no-screens" end
        for _, s in ipairs(screens) do
            local okF, f = pcall(function() return s:fullFrame() end)
            local okI, id = pcall(function() return s:id() end)
            if okF and type(f) == "table" then
                parts[#parts + 1] = table.concat({ tostring(okI and id or "?"),
                    tostring(f.x), tostring(f.y), tostring(f.w), tostring(f.h) }, ",")
            end
        end
        -- 🌓 6.248.0 — scrimAlphaTyped is deliberately NOT in this key,
        -- and it was written in and taken out again: BOTH scrims are built
        -- at DRAW time (gridElements and scrimOnly are called from
        -- redraw(), never cached), so a changed knob is picked up by the
        -- next draw with no rebuild at all. No mutation could catch its
        -- absence, and a guard no test can fail is dead code with a
        -- comment on it (6.199.0). scrimAlpha's own entry here predates
        -- that and is left alone.
        parts[#parts + 1] = string.format("|%s^%s|%.2f|%.2f|%.2f",
            tostring(grid.alphabet), tostring(grid.labelLength), grid.scrimAlpha, grid.lineAlpha,
            grid.labelSize)
        local ink = grid.labelInk()
        parts[#parts + 1] = table.concat({ tostring(grid.subdivisions), tostring(grid.maxCells), tostring(grid.labelBackplates),
            tostring(ink.red), tostring(ink.green), tostring(ink.blue), tostring(ink.alpha) }, ",")
        return table.concat(parts, ";")
    end

    -- Split the label space across displays BY AREA, then pick the
    -- cols×rows that lands closest to square cells for that display's
    -- aspect. Doing it by area rather than per-screen-equally is what
    -- stops a 27" monitor getting the same 200 cells as a laptop panel.
    -- 🚨 ONE EXPRESSION DOES TWO JOBS, AND IT STOPS A HANG.
    --
    -- `math.max(1, math.min(cols, share))` is not defensive padding:
    --
    --   · CORRECTNESS. cols <= share means cols*rows <= share, so every
    --     cell gets a label. Without it an extreme aspect ratio on a small
    --     share produces more cells than there are labels, and the surplus
    --     is a region of your screen you can never reach. The fuzzer finds
    --     this within ~50 layouts once the clamp is gone.
    --
    --   · NO HANG. A display reporting height 0 — one disconnecting
    --     between allScreens() and fullFrame(), a virtual display, some
    --     screen-sharing sessions — makes w/h infinite, and
    --     math.floor(math.huge) is math.huge in Lua. `cols` becomes inf
    --     and the loop below becomes `for c = 0, inf`: Hammerspoon spins
    --     forever, with no error and no recovery but a force-quit. A hang
    --     is strictly worse than a crash, because a crash tells you what
    --     happened. share is bounded by capacity, and min()/max() collapse
    --     BOTH inf and NaN into [1, share], so the loop is always finite.
    --
    -- ⚠️ An earlier version had a separate `if cols ~= cols or cols ==
    -- math.huge` line above this. It was deleted, not because it was
    -- wrong, but because it was UNREACHABLE: the clamp already handles
    -- both cases, so nothing could ever test that line. Untested code that
    -- looks like a safety net is worse than no code — the next reader
    -- trusts it.
    local function planScreen(frame, share)
        if share < 1 then share = 1 end
        local cols = math.floor(math.sqrt(share * frame.w / frame.h) + 0.5)
        cols = math.max(1, math.min(cols, share))
        local rows = math.max(1, math.floor(share / cols))
        return cols, rows
    end

    -- A frame we can actually divide. Anything else is skipped and named,
    -- because a display quietly missing from the grid is a region of screen
    -- you cannot reach and no clue as to why.
    local function usableFrame(f)
        if type(f) ~= "table" then return false end
        for _, v in ipairs({ f.x, f.y, f.w, f.h }) do
            if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then
                return false
            end
        end
        return f.w > 0 and f.h > 0
    end

    local function buildGeometry()
        local t0     = hs.timer.secondsSinceEpoch()
        local chars  = alphabetChars()
        -- ⚠️ THE PARENTHESES ARE LOAD-BEARING. In Lua `^` binds TIGHTER than
        -- the unary `#`, so `#chars ^ n` parses as `#(chars ^ n)` and tries
        -- to exponentiate a table. Same family of precedence trap that
        -- crashed capabilities.lua's word-wrap in 6.44.13 — clever
        -- one-liners in arithmetic buy nothing and cost a crash.
        local depth = tonumber(grid.labelLength)
        if not depth or depth ~= math.floor(depth) or depth < 1 or depth > 4 then
            return nil, "labelLength must be a whole number from 1 to 4"
        end
        local capacity = (#chars) ^ depth
        if capacity < 1 then return nil, "no usable label keys" end
        local divisions = tonumber(grid.subdivisions) == 1 and 1 or 2
        local limit = math.min(4096, math.max(4, math.floor(num(grid.maxCells, 4096))))
        local budget = math.min(capacity, limit)
        local coarseCapacity = divisions == 1 and budget
            or math.min((#chars) ^ math.max(1, depth - 1), math.floor(budget / 4))
        if coarseCapacity < 1 then return nil, "not enough labels for four-way cells" end
        local screens  = hs.screen.allScreens()

        -- Sanity-filter FIRST. Every number below is divided by or looped
        -- over, so one bad frame reaching planScreen is the hang described
        -- there. A skipped display is named rather than silently absent.
        local usable, totalArea, skipped = {}, 0, 0
        for _, s in ipairs(screens) do
            local okF, f = pcall(function() return s:fullFrame() end)
            if okF and usableFrame(f) then
                usable[#usable + 1] = f
                totalArea = totalArea + (f.w * f.h)
            else
                skipped = skipped + 1
            end
        end
        if skipped > 0 then
            warn(skipped .. " display(s) reported an unusable frame and were "
                 .. "left out of the grid")
        end
        if #usable == 0 or totalArea <= 0 then
            return nil, "no display reported a usable frame"
        end

        local plan, slots = {}, 0
        for _, f in ipairs(usable) do
            local share = math.floor(coarseCapacity * (f.w * f.h) / totalArea)
            local cols, rows = planScreen(f, share)
            cols, rows = cols * divisions, rows * divisions
            local adjusted = false
            if divisions == 2 then
                local function fit()
                    return math.min((f.w / cols * 0.92) / (depth * 0.62), f.h / rows / 1.25)
                end
                while fit() < 8 and share > 1 do
                    share = math.max(1, math.floor(share / 2))
                    cols, rows = planScreen(f, share)
                    cols, rows = cols * divisions, rows * divisions
                    adjusted = true
                end
                if fit() < 8 then return nil, "display cannot fit readable grid labels" end
            end
            slots = slots + cols * rows
            plan[#plan + 1] = { frame = f, cols = cols, rows = rows,
                cellW = f.w / cols, cellH = f.h / rows, cells = {}, densityReduced=adjusted }
        end
        if slots > budget then return nil, "display layout exceeds the bounded label budget" end
        local index, truncated = 0, 0
        for _, p in ipairs(plan) do
            for r = 0, p.rows - 1 do
                for c = 0, p.cols - 1 do
                    -- Spread three-character codes across the alphabet so
                    -- the first character still narrows a contiguous band.
                    local code = divisions == 1 and index or math.floor(index * capacity / slots)
                    p.cells[#p.cells + 1] = {
                        label = labelFor(code, chars),
                        rx = c * p.cellW, ry = r * p.cellH, rw = p.cellW, rh = p.cellH,
                        ax = p.frame.x + (c + 0.5) * p.cellW,
                        ay = p.frame.y + (r + 0.5) * p.cellH }
                    index = index + 1
                end
            end
        end

        local ms = (hs.timer.secondsSinceEpoch() - t0) * 1000
        if truncated > 0 then
            warn(string.format("%d cells had no label left (capacity %d) — "
                .. "widen grid.alphabet or raise grid.labelLength", truncated, capacity))
        end
        say(string.format("geometry: %d screens, %d cells of %d capacity, %.1fms",
            #plan, index, capacity, ms))
        -- 6.176.0 — 4,096 cells is ~5x the canvas elements 729 was, and
        -- this build runs on the MAIN thread. It is cached per display
        -- layout, so the cost lands once, on the first press after a
        -- reload or a monitor change — but "once" is still a stall LL
        -- would feel and have no explanation for. So a slow build says
        -- so ONCE, in plain words, with the knob that fixes it. This is
        -- a print, not a warn: it is a tuning note, not a fault.
        if ms > grid.buildSlowMs then
            print(string.format("🎯 mouse grid: laying out %d cells took %.0f ms on "
                .. "this Mac — that happens once per display layout, not per press. "
                .. "If the first ⇪X after a reload feels slow, a smaller grid is "
                -- 📏 6.373.0 — THE OVERRIDE HAS TO MAKE IT SMALLER, and
                -- labelLength is 2 already. A shorter alphabet is what
                -- is left: 9 home-row keys at 2 deep is 81 cells, which
                -- is a coarse grid that builds instantly.
                .. "settings = { mouse_grid = { alphabet = \"asdfghjkl\" } } "
                .. "(fewer labels; larger cells).", index, ms))
        end
        return { screens = plan, used = index, capacity = capacity,
                 truncated = truncated, chars = chars }
    end

    -- =====================================================================
    -- DRAWING
    -- =====================================================================
    -- The scrim and the lines never change for a given layout, so they are
    -- built once and then only shown/hidden. Lines are drawn as segments
    -- (2 points, stroked) rather than thin rectangles so strokeWidth means
    -- exactly what it says at any scale factor.
    -- 🌓 6.248.0 — PURE, and the ONE place either draw decides. Answers
    -- the alpha AND why, so the report can say which state a Mac is in
    -- rather than printing a number with no name on it.
    function grid.scrimFor(typed)
        typed = tonumber(typed) or 0
        if typed > 0 then
            return num(grid.scrimAlphaTyped, 0), "typed — the screen is back"
        end
        return num(grid.scrimAlpha, 0.55), "before you type — a reading surface"
    end

    local function gridElements(p)
        local els = {
            { type = "rectangle", action = "fill",
              fillColor = { white = grid.scrimWhite, alpha = (grid.scrimFor(0)) },
              frame = { x = 0, y = 0, w = p.frame.w, h = p.frame.h } },
        }
        local stroke = { white = grid.lineWhite, alpha = grid.lineAlpha }
        for c = 1, p.cols - 1 do
            local x = c * p.cellW
            els[#els + 1] = { type = "segments", action = "stroke",
                strokeColor = stroke, strokeWidth = grid.lineWidth,
                coordinates = { { x = x, y = 0 }, { x = x, y = p.frame.h } } }
        end
        for r = 1, p.rows - 1 do
            local y = r * p.cellH
            els[#els + 1] = { type = "segments", action = "stroke",
                strokeColor = stroke, strokeWidth = grid.lineWidth,
                coordinates = { { x = 0, y = y }, { x = p.frame.w, y = y } } }
        end
        return els
    end

    -- One text element per visible cell. `typedLen` chars are dropped from
    -- the front of every label: once you have typed "a", every remaining
    -- candidate starts with "a", so repeating it is noise — showing only
    -- what is left to type is both clearer and progressively cheaper to
    -- draw, which is the whole performance story on the next redraw.
    -- 🚨 6.62.0 — NEVER HAND hs.canvas AN EMPTY ELEMENT LIST.
    -- Reported from LL's Console, four times in one session:
    --   canvas.lua:382: bad argument #1 to 'assignElement'
    --   (invalid element definition; must contain key-value pairs)
    --
    -- replaceElements(...) packs its varargs and only unwraps the
    -- single-table form when that table is NON-EMPTY:
    --     if elementList.n == 1 and #elementList[1] ~= 0 then ...
    -- so replaceElements({}) does not mean "draw nothing". It means "draw
    -- this one element", the element being `{}` — which has no key-value
    -- pairs, so it throws.
    --
    -- WHERE IT BIT: typeChar filters cells by the typed prefix and then
    -- redraws EVERY screen. With two displays the matches for a letter
    -- can all live on one of them, leaving the other with zero elements.
    -- typeChar's own `n == 0` guard does not catch it, because n counts
    -- matches ACROSS ALL SCREENS — it is non-zero while an individual
    -- screen has none. And because typeChar runs inside a pcall, the
    -- throw did not just log: it HID THE GRID. Typing the first letter
    -- made the grid vanish.
    --
    -- An element with action = "skip" is a valid definition that draws
    -- nothing, which is exactly "this screen has no candidates". Built
    -- fresh each call rather than shared, so no canvas can ever hold a
    -- reference to a table another canvas might be handed.
    local function setElements(canvas, els)
        if not canvas then return end
        if type(els) ~= "table" or #els == 0 then
            els = { { type = "rectangle", action = "skip" } }
        end
        canvas:replaceElements(els)
    end

    -- 🔠 6.65.0 — HOW BIG THE LABEL ACTUALLY GETS.
    -- Two constraints, and the SMALLER of them wins, then the floor is
    -- applied last so a genuinely tiny cell still gets legible text even
    -- if that means the glyphs touch the cell edges:
    --   · HEIGHT — labelFitFrac of the cell, so text sits in its box.
    --   · WIDTH  — the remaining characters have to fit across the cell.
    --     0.62 is the measured average advance of this config's alphabet
    --     (home row, no wide glyphs) as a fraction of point size; it is
    --     the same constant §mouseGridReport already uses to warn about
    --     cells too narrow to label, so the two agree by construction.
    -- `chars` is how many characters are still to be typed, NOT the full
    -- label: after "a" the cell shows two characters and may therefore
    -- use a larger size than it could have at three.
    local function fittedLabelSize(p, chars)
        chars = math.max(1, tonumber(chars) or tonumber(grid.labelLength) or 3)
        local byHeight = p.cellH * num(grid.labelFitFrac,0.55)
        local byWidth = (p.cellW * 0.92) / (chars * 0.62)
        local ceiling = math.max(8,math.min(100,num(grid.labelMaxSize,34)))
        local preferred = math.max(8,num(grid.labelSize,14))
        local size = math.min(byHeight,byWidth,ceiling)
        return math.max(1,math.min(math.max(preferred,size),byWidth,p.cellH/1.25,ceiling))
    end

    -- The label canvas carries BOTH the amber match boxes and the text,
    -- boxes first so the text paints on top of them. One list, one
    -- replaceElements — two canvases would mean two draws per keystroke
    -- and a way for them to disagree about which cells still match.
    local function labelElements(p, typedLen, matches)
        local els  = {}
        local size = fittedLabelSize(p, grid.labelLength - typedLen)
        local pad  = math.max(0, (p.cellH - size * 1.25) / 2)
        for _, cell in ipairs(p.cells) do
            if matches == nil or matches[cell.label] then
                -- Highlight only while narrowing. With nothing typed every
                -- cell matches, and boxing all of them is not a highlight,
                -- it is a second lattice on top of the first.
                if matches ~= nil then
                    els[#els + 1] = {
                        type = "rectangle", action = "strokeAndFill",
                        strokeColor = { red   = grid.matchStroke.red,
                                        green = grid.matchStroke.green,
                                        blue  = grid.matchStroke.blue, alpha = 1.0 },
                        fillColor   = grid.matchFill,
                        strokeWidth = grid.matchWidth,
                        roundedRectRadii = { xRadius = grid.matchRadius,
                                             yRadius = grid.matchRadius },
                        -- Inset by half the stroke so the border sits
                        -- INSIDE the cell. Drawn on the boundary, adjacent
                        -- survivors share a doubled line and read as one
                        -- wide box rather than two separate targets.
                        frame = { x = cell.rx + grid.matchWidth / 2,
                                  y = cell.ry + grid.matchWidth / 2,
                                  w = math.max(1, cell.rw - grid.matchWidth),
                                  h = math.max(1, p.cellH - grid.matchWidth) },
                    }
                end
                if grid.labelBackplates then
                    local w=math.min(cell.rw-1,size*(grid.labelLength-typedLen)*0.58+2)
                    local h=math.min(p.cellH-1,size*1.06+1)
                    els[#els+1]={type="rectangle",action="fill",
                        fillColor={white=0,alpha=grid.labelPlateAlpha},roundedRectRadii={xRadius=2,yRadius=2},
                        frame={x=cell.rx+(cell.rw-w)/2,y=cell.ry+(p.cellH-h)/2,w=w,h=h}}
                end
                els[#els + 1] = {
                    type = "text",
                    text = cell.label:sub(typedLen + 1),
                    textSize  = size,
                    textColor = grid.labelInk(),
                    textAlignment = "center",
                    frame = { x = cell.rx, y = cell.ry + pad,
                              w = cell.rw, h = p.cellH - pad },
                }
            end
        end
        return els
    end

    -- Build (or reuse) every canvas for the current layout.
    local function ensureCache()
        local key = layoutKey()
        if grid.cache and grid.cache.key == key then return grid.cache end

        if grid.cache then
            for _, s in ipairs(grid.cache.screens or {}) do
                pcall(function() if s.gridCanvas then s.gridCanvas:delete() end end)
                pcall(function() if s.labelCanvas then s.labelCanvas:delete() end end)
            end
        end

        local geo, err = buildGeometry()
        if not geo then return nil, err end

        local t0 = hs.timer.secondsSinceEpoch()
        local level = (hs.canvas.windowLevels or {})[grid.windowLevel]
                      or (hs.canvas.windowLevels or {}).overlay
        for _, p in ipairs(geo.screens) do
            local gc = hs.canvas.new(p.frame)
            local lc = hs.canvas.new(p.frame)
            if not (gc and lc) then
                return nil, "hs.canvas.new returned nil — cannot draw the overlay"
            end
            setElements(gc, gridElements(p))
            for _, c in ipairs({ gc, lc }) do
                pcall(function() c:level(level) end)
                pcall(function()
                    c:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" })
                end)
            end
            p.gridCanvas  = gc
            p.labelCanvas = lc
            -- The unfiltered label table is the expensive one; cached so
            -- that from the second invocation on, showing the grid is a
            -- table reuse rather than a build.
            p.fullLabels  = labelElements(p, 0, nil)
        end

        say(string.format("canvases built: %.1fms (level %s)",
            (hs.timer.secondsSinceEpoch() - t0) * 1000, grid.windowLevel))
        grid.cache = { key = key, screens = geo.screens, used = geo.used,
                       capacity = geo.capacity, truncated = geo.truncated,
                       chars = geo.chars }
        return grid.cache
    end

    -- =====================================================================
    -- THE LANDED BADGE — the visual proof that keys are being captured
    -- =====================================================================
    -- `hint` (6.154.0) names the control the pointer snapped onto, so the
    -- badge reads "🎯 Save · space click …" and you know what SPACE hits.
    -- ✂️ 6.192.0 — THE HALVING, kept PURE and separate from the drawing so
    -- the gate can prove the geometry without a screen. Returns the new
    -- box, or nil + why. The floor is real: below grid.halveMin a box is
    -- smaller than the pointer's own hot spot, and a target you cannot
    -- see is not a finer target, it is a lie about where you are.
    function grid.halfOf(box, dir, minPt)
        if type(box) ~= "table" then return nil, "there is no box to halve" end
        local x, y = tonumber(box.x), tonumber(box.y)
        local w, h = tonumber(box.w), tonumber(box.h)
        if not (x and y and w and h) or w <= 0 or h <= 0 then
            return nil, "the box has no size"
        end
        for _, v in ipairs({ x, y, w, h }) do
            if v ~= v or v == math.huge or v == -math.huge then return nil, "non-finite box" end
        end
        local floorPt = tonumber(minPt) or 0
        if floorPt ~= floorPt or floorPt == math.huge or floorPt == -math.huge then floorPt = 8 end
        if floorPt < 0 then floorPt = 0 end
        if dir == "up" or dir == "down" then
            if h / 2 < floorPt then
                return nil, "already as short as it goes"
            end
            local nh = h / 2
            return { x = x, y = (dir == "up") and y or (y + nh), w = w, h = nh }
        elseif dir == "left" or dir == "right" then
            if w / 2 < floorPt then
                return nil, "already as narrow as it goes"
            end
            local nw = w / 2
            return { x = (dir == "left") and x or (x + nw), y = y, w = nw, h = h }
        end
        return nil, "not a direction"
    end

    -- ✂️ 6.252.0 — WHICH TWO KEYS SPLIT THE BOX. PURE, and it answers
    -- WHERE they came from so the report and the badge agree with the
    -- binding. Two DIFFERENT characters or nothing: one letter cannot
    -- name two halves, and a pair that is the same letter twice would
    -- bind one key to both halves and pick whichever was bound last.
    function grid.halvePair(keys, alphabet)
        local function firstTwo(str)
            str = tostring(str or "")
            local a, b = str:sub(1, 1), str:sub(2, 2)
            if a ~= "" and b ~= "" and a ~= b then return a, b end
            return nil
        end
        local a, b = firstTwo(keys)
        if a then return a, b, "grid.halveKeys" end
        a, b = firstTwo(alphabet)
        if a then return a, b, "the first two of grid.alphabet" end
        return nil, nil, "no two distinct keys to split with"
    end

    -- ✂️ 6.252.0 — THE BOX, SPLIT IN TWO ALONG ITS LONGER SIDE. PURE, and
    -- built on 6.192.0's halfOf so the floor, the arithmetic and the
    -- refusal wording are all still in one place. The LONGER side is the
    -- one worth splitting: halving a 200x20 strip top-to-bottom gives two
    -- 200x10 strips and no more precision where the precision is missing.
    function grid.splitOf(box, minPt)
        if type(box) ~= "table" then return nil, "there is no box to split" end
        local w, h = tonumber(box.w) or 0, tonumber(box.h) or 0
        if w <= 0 or h <= 0 then return nil, "there is no box to split" end
        local wide = (w >= h)
        local d1, d2 = (wide and "left" or "up"), (wide and "right" or "down")
        local first,  why1 = grid.halfOf(box, d1, minPt)
        local second, why2 = grid.halfOf(box, d2, minPt)
        if not (first and second) then
            return nil, (why1 or why2 or "it will not split any further")
        end
        return { first = first, second = second,
                 axis = wide and "x" or "y", sides = { d1, d2 } }
    end

    function grid.quarterOf(box, minPt)
        if type(box) ~= "table" then return nil, "there is no box to quarter" end
        local top, why = grid.halfOf(box, "up", minPt)
        local bottom = grid.halfOf(box, "down", minPt)
        if not top or not bottom then return nil, why end
        local a, wa = grid.halfOf(top, "left", minPt)
        local b = grid.halfOf(top, "right", minPt)
        local c = grid.halfOf(bottom, "left", minPt)
        local d = grid.halfOf(bottom, "right", minPt)
        if not (a and b and c and d) then return nil, wa end
        return { first = a, second = b, third = c, fourth = d, axis = "xy" }
    end

    function grid.refineSpec()
        if grid.splitBound and grid.splitBound.ok then
            return grid.splitBound.keys, grid.splitBound.parts, grid.splitBound.from
        end
        if tonumber(grid.refineParts) == 2 then
            local a, b, from = grid.halvePair(grid.halveKeys, grid.alphabet)
            return a and (a .. b) or nil, 2, from
        end
        local function four(value)
            if type(value) ~= "string" or #value ~= 4 or value:find("[^a-z]") then return nil end
            local seen = {}
            for ch in value:gmatch(".") do if seen[ch] then return nil end; seen[ch] = true end
            return value
        end
        return four(grid.quarterKeys) or "asdf", 4,
            four(grid.quarterKeys) and "grid.quarterKeys" or "default asdf (invalid override)"
    end

    function grid.refinementOf(box)
        local _, parts = grid.refineSpec()
        if parts == 2 then return grid.splitOf(box, grid.halveMin) end
        return grid.quarterOf(box, grid.halveMin)
    end

    function grid.refreshCheatsheet()
        local keys, parts = grid.refineSpec()
        M.cheatsheet.title = "🎯 MOUSE GRID (⇪X — type " .. tostring(grid.labelLength) .. " letters)"
        M.cheatsheet.entries[3] = { tostring(grid.alphabet), "Type " .. tostring(grid.labelLength) .. " letters from the visible label" }
        M.cheatsheet.entries[4] = { "snap", grid.snapToControls == true
            and "Optional app-control snapping is ON; it can move the pointer to a control centre"
            or "OFF: coordinate targeting, without app-control Accessibility hit-tests" }
        M.cheatsheet.entries[10] = { tostring(grid.labelLength) .. " letters", (tonumber(grid.subdivisions) or 1) > 1
            and ("Initial cells are divided " .. tostring(grid.subdivisions) .. " × " .. tostring(grid.subdivisions) .. " before drawing")
            or ("Type " .. tostring(grid.labelLength) .. ", then " .. (select(1, grid.refineSpec())) .. " to quarter what you landed in") }
        M.cheatsheet.entries[11] = { keys or "unavailable", parts == 4
            and "Four quarters: top-left, top-right, bottom-left, bottom-right; repeat to refine"
            or "Two halves along the longer side; repeat to refine" }
    end

    -- =====================================================================
    -- 🏃 6.247.0 — A HELD ARROW MOVES THE CANVAS, IT DOES NOT REBUILD IT
    -- =====================================================================
    -- LL: "After I isolate to a grid box (using three letters), then
    -- holding down the arrow key should repeat about the same cadence as
    -- holding down arrow key in a text box."
    --
    -- 🚨 AND THE CADENCE WAS THE WORK, not the key repeat. nudge() ran
    -- showBox() AND showCrosshair() on every repeat, and each of those
    -- DELETED its canvas and built a new one: hs.canvas.new is an NSWindow,
    -- replaceElements marshals eight element tables through LuaSkin, and
    -- :show() orders a window in. Two NSWindows created, populated and
    -- ordered in per keystroke, on the main thread — and 6.228.0's rule
    -- says what main-thread work does to every other app's input, never
    -- mind our own.
    --
    -- 🔎 CHECKED IN THE SOURCE, FILE NAMED (6.233.0's rule, because this
    -- is a platform fact deciding an implementation):
    -- extensions/canvas/libcanvas.m's canvas_topLeft (line 2842) is a
    -- SETTER as well as a getter, and all it does is
    --     [canvasWindow setFrame:newFrame display:YES animate:NO]
    -- — no elements, no LuaSkin marshalling, no new window. It refuses
    -- (luaL_argerror) only for a canvas used as a SUBVIEW, which ours
    -- never is; that refusal is a throw, so it is caught and falls back
    -- to the rebuild rather than leaving the overlay stale.
    --
    -- A NUDGE NEVER RESIZES — 6.192.0 made that a rule ("a nudge is a
    -- move, and only ⌥+arrow changes precision") — so on the hot path
    -- nothing but x and y differs, which is exactly what canMove asks.
    -- grid.canMove is PURE: everything BUT x and y must match, in both
    -- directions (a key present in one table and absent from the other is
    -- a difference, and pairs() cannot see a nil).
    function grid.canMove(prev, want)
        if type(prev) ~= "table" or type(want) ~= "table" then
            return false, "nothing drawn yet"
        end
        for k, v in pairs(want) do
            if k ~= "x" and k ~= "y" and prev[k] ~= v then
                return false, tostring(k) .. " changed"
            end
        end
        for k, v in pairs(prev) do
            if k ~= "x" and k ~= "y" and want[k] ~= v then
                return false, tostring(k) .. " changed"
            end
        end
        return true, "position only"
    end

    -- What is on screen right now, so the next draw can ask canMove.
    grid.boxAt, grid.crossAt = nil, nil
    -- 🔎 COUNTED APART, and the report prints both: a release that claims
    -- to have stopped rebuilding is a release that must be able to PROVE
    -- it on his Mac. Moves climbing while rebuilds stay flat is the claim;
    -- rebuilds climbing with every arrow is this release doing nothing.
    grid.draws = { boxMove = 0, boxBuild = 0, crossMove = 0, crossBuild = 0 }

    -- Move the canvas if that is all this draw needs. Returns true when it
    -- moved — a false answer means the caller must build.
    local function moveCanvas(canvas, prevAt, want, which)
        if not canvas then return false end
        local ok = grid.canMove(prevAt, want)
        if not ok then return false end
        local moved = pcall(function() canvas:topLeft({ x = want.x, y = want.y }) end)
        if not moved then return false end
        grid.draws[which] = (grid.draws[which] or 0) + 1
        return true
    end

    -- The outline over the live box. Its own canvas, not the badge's:
    -- the badge is a fixed 232x78 near the pointer and a box can be any
    -- size anywhere. Returns false the same way showCrosshair does, and
    -- for the same reason — the caller must act on it.
    local function showBox(box)
        if not box then
            pcall(function() if grid.boxDraw then grid.boxDraw:delete() end end)
            grid.boxDraw, grid.boxAt = nil, nil
            return true
        end
        -- ✂️ 6.252.0 — the split rides in `want`. It depends on the box's
        -- SIZE (already here) and on grid.halve, which the Console can
        -- turn off between two draws of an identically sized box — and a
        -- canvas that only MOVED would keep drawing letters that no longer
        -- do anything.
        local sp = grid.halve and grid.refinementOf(box) or nil
        local ink, keys, parts = grid.labelInk(), grid.refineSpec()
        local want = { x = box.x, y = box.y, w = box.w, h = box.h,
                       split = sp and true or false, keys=keys, parts=parts,
                       ink=table.concat({ink.red,ink.green,ink.blue,ink.alpha},",") }
        -- 🏃 6.247.0 — the hot path: a nudge changes x and y and nothing
        -- else, so the window moves and the elements are left alone.
        if moveCanvas(grid.boxDraw, grid.boxAt, want, "boxMove") then
            grid.boxAt = want
            return true
        end
        pcall(function() if grid.boxDraw then grid.boxDraw:delete() end end)
        grid.boxDraw = nil
        grid.draws.boxBuild = (grid.draws.boxBuild or 0) + 1
        local c = hs.canvas.new({ x = box.x, y = box.y, w = box.w, h = box.h })
        if not c then return false end
        local els = {
            { type = "rectangle", action = "fill",
              fillColor = { red = 1, green = 0.78, blue = 0.25, alpha = 0.10 },
              frame = { x = 0, y = 0, w = box.w, h = box.h } },
            { type = "rectangle", action = "stroke", strokeWidth = 2,
              strokeColor = { red = 1, green = 0.78, blue = 0.25, alpha = 0.95 },
              frame = { x = 1, y = 1, w = math.max(1, box.w - 2), h = math.max(1, box.h - 2) } },
        }
        -- ✂️ 6.252.0 — AND THE TWO HALVES, each with its letter in it.
        -- Drawn in the box's OWN coordinates (the canvas is the box), so a
        -- move carries them without a thought.
        if sp then
            local keys, parts = grid.refineSpec()
            if keys then
                local ink = grid.labelInk()
                local function divider(x1, y1, x2, y2)
                    els[#els + 1] = { type = "segments", action = "stroke", strokeColor = ink,
                        strokeWidth = 1, coordinates = { { x=x1,y=y1 }, { x=x2,y=y2 } } }
                end
                if sp.axis == "xy" or sp.axis == "x" then divider(box.w/2,0,box.w/2,box.h) end
                if sp.axis == "xy" or sp.axis == "y" then divider(0,box.h/2,box.w,box.h/2) end
                for i, name in ipairs({ "first", "second", "third", "fourth" }) do
                    if i <= parts then
                        local q = sp[name]
                        local size = math.max(8, math.min(22, math.min(q.w, q.h)*0.55))
                        if grid.labelBackplates then
                            local w,h=math.min(q.w-1,size*0.66+4),math.min(q.h-1,size*1.25+2)
                            els[#els+1]={type="rectangle",action="fill",fillColor={white=0,alpha=0.72},
                                roundedRectRadii={xRadius=2,yRadius=2},
                                frame={x=q.x-box.x+(q.w-w)/2,y=q.y-box.y+(q.h-h)/2,w=w,h=h}}
                        end
                        els[#els+1] = { type="text",text=keys:sub(i,i),textSize=size,
                            textAlignment="center",textColor=grid.labelInk(),
                            frame={ x=q.x-box.x,y=q.y-box.y+math.max(0,(q.h-size*1.25)/2),
                                    w=q.w,h=q.h } }
                    end
                end
            end
        end
        c:replaceElements(els)
        pcall(function()
            c:level((hs.canvas.windowLevels or {})[grid.windowLevel]
                    or (hs.canvas.windowLevels or {}).overlay)
        end)
        pcall(function() c:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" }) end)
        -- 🚨 The box must never eat the click it is helping LL aim. It is
        -- decoration over the target, so it is transparent to the mouse.
        pcall(function() c:canvasMouseEvents(false, false, false, false) end)
        grid.boxDraw = c
        local okShow, shown
        if _G.showCanvasSafely then
            okShow, shown = pcall(_G.showCanvasSafely,c,"grid quarter box")
        else
            okShow, shown = pcall(function() return c:show() end)
        end
        if not okShow or not shown then return false end
        grid.boxAt   = want
        return true
    end

    local function showCrosshair(px, py, hint)
        local W, H = 232, 78
        local scr  = hs.mouse.getCurrentScreen() or hs.screen.mainScreen()
        local sf   = scr and scr:fullFrame() or { x = 0, y = 0, w = 1440, h = 900 }
        -- Clamped into the display, then the rings are drawn wherever the
        -- point ended up INSIDE that box — so the badge stays on screen at
        -- an edge without the crosshair drifting off the actual target.
        local cx = math.max(sf.x, math.min(px - W / 2, sf.x + sf.w - W))
        local cy = math.max(sf.y, math.min(py - 26,    sf.y + sf.h - H))
        local rx, ry = px - cx, py - cy

        -- 🏃 6.247.0 — rx/ry ride in the comparison, not just the frame.
        -- Away from a screen edge they are constant (px - cx is W/2), so a
        -- nudge is a pure move; AT an edge the clamp changes them and the
        -- rings would be drawn in the wrong place inside the badge, so
        -- that draw rebuilds. The hint is in there for the same reason —
        -- landing swaps the text, and a moved canvas keeps the old words.
        local want = { x = cx, y = cy, w = W, h = H,
                       rx = rx, ry = ry, hint = hint or false }
        if moveCanvas(grid.cross, grid.crossAt, want, "crossMove") then
            grid.crossAt = want
            return true
        end
        pcall(function() if grid.cross then grid.cross:delete() end end)
        grid.cross = nil
        grid.draws.crossBuild = (grid.draws.crossBuild or 0) + 1
        local c = hs.canvas.new({ x = cx, y = cy, w = W, h = H })
        -- 🚨 RETURNS FALSE, AND THE CALLER MUST ACT ON IT. The old cross has
        -- already been destroyed by this point, so carrying on would leave
        -- landed mode capturing the keyboard with NOTHING on screen saying
        -- so — the precise hazard the whole design forbids.
        if not c then return false end
        local ink = { white = 1.0, alpha = 0.95 }
        c:replaceElements({
            { type = "circle", action = "stroke", strokeColor = ink, strokeWidth = 2,
              center = { x = rx, y = ry }, radius = 13 },
            { type = "circle", action = "fill", fillColor = { white = 1.0, alpha = 0.9 },
              center = { x = rx, y = ry }, radius = 2 },
            { type = "segments", action = "stroke", strokeColor = ink, strokeWidth = 1.5,
              coordinates = { { x = rx - 22, y = ry }, { x = rx - 17, y = ry } } },
            { type = "segments", action = "stroke", strokeColor = ink, strokeWidth = 1.5,
              coordinates = { { x = rx + 17, y = ry }, { x = rx + 22, y = ry } } },
            { type = "segments", action = "stroke", strokeColor = ink, strokeWidth = 1.5,
              coordinates = { { x = rx, y = ry - 22 }, { x = rx, y = ry - 17 } } },
            { type = "segments", action = "stroke", strokeColor = ink, strokeWidth = 1.5,
              coordinates = { { x = rx, y = ry + 17 }, { x = rx, y = ry + 22 } } },
            { type = "rectangle", action = "fill",
              fillColor = { white = 0.0, alpha = 0.72 }, roundedRectRadii = { xRadius = 5, yRadius = 5 },
              frame = { x = 8, y = H - 24, w = W - 16, h = 18 } },
            { type = "text",
              -- 6.192.0 — ⌥↑↓←→ is on the badge because a shortcut nobody
              -- is told about is a shortcut nobody has. It is dropped when
              -- halving is switched off, so the badge never offers a key
              -- that does nothing.
              -- ✂️ 6.252.0 — the badge names the two letters, because a
              -- key nobody is told about is a key nobody has.
              text = (hint and ("🎯 " .. hint .. " · space click · ⎋ done")
                      or ("space click · ↑↓←→ nudge"
                          .. (function()
                                if not grid.halve then return "" end
                                local keys, parts = grid.refineSpec()
                                if not keys then return "" end
                                return " · " .. keys .. (parts == 4 and " quarters" or " split")
                             end)() .. " · ⎋ done")),
              textSize = 11, textColor = { white = 1.0, alpha = 0.95 },
              textAlignment = "center",
              frame = { x = 8, y = H - 23, w = W - 16, h = 17 } },
        })
        pcall(function()
            c:level((hs.canvas.windowLevels or {})[grid.windowLevel]
                    or (hs.canvas.windowLevels or {}).overlay)
        end)
        pcall(function() c:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" }) end)
        -- 6.88.0 — the LAST bare canvas:show() in the config, found the
        -- hard way: LL's Console caught the NSRemoteView throw killing a
        -- whole hotkey callback. Through showCanvasSafely like the rest.
        grid.cross,grid.crossAt = c,want
        local okShow,shown
        if _G.showCanvasSafely then
            okShow,shown=pcall(_G.showCanvasSafely,c,"grid crosshair")
        else
            okShow,shown=pcall(function() return c:show() end)
        end
        return okShow and shown ~= false and shown ~= nil
    end

    -- =====================================================================
    -- TEARDOWN — the single exit. Everything else calls this.
    -- =====================================================================
    -- 🚨 Idempotent, and every step is pcall'd SEPARATELY on purpose: if
    -- hiding one canvas throws, the modal must still exit and the rest
    -- must still come down. A shared pcall would let one failure strand
    -- the overlay, which is precisely the lock-out this guards against.
    local function stopClickTap()
        if grid.clickTap then
            pcall(function() grid.clickTap:stop() end)
            grid.clickTap = nil
        end
    end

    function grid.hide(reason)
        grid.watchdogSerial=(grid.watchdogSerial or 0)+1
        if grid.watchdog then
            pcall(function() grid.watchdog:stop() end)
            grid.watchdog = nil
        end
        stopClickTap()
        hideAllShown()
        pcall(function() if grid.cross then grid.cross:delete() end end)
        grid.cross, grid.crossAt = nil, nil
        pcall(function() if grid.boxDraw then grid.boxDraw:delete() end end)
        grid.boxDraw, grid.boxAt = nil, nil
        pcall(function() if grid.pickModal then grid.pickModal:exit() end end)
        pcall(function() if grid.landModal then grid.landModal:exit() end end)
        if grid.state then
            say("closed (" .. tostring(reason or "done") .. ")")
            grid.state = nil
        end
    end

    local function armWatchdog(secs, why)
        if grid.watchdog then pcall(function() grid.watchdog:stop() end) end
        grid.watchdog = nil
        grid.watchdogSerial=(grid.watchdogSerial or 0)+1
        local serial,owner=grid.watchdogSerial,grid.state
        local ok, timer = pcall(hs.timer.doAfter, secs, function()
            if grid.watchdogSerial~=serial or grid.state~=owner then return end
            warn("watchdog fired after " .. secs .. "s — " .. why)
            grid.hide("watchdog")
        end)
        if not ok or not timer then
            grid.hide("watchdog unavailable")
            warn("watchdog unavailable — grid closed; keyboard capture refused")
            return false
        end
        grid.watchdog = timer
        return true
    end

    -- 🖱 The hand-click listener (6.155.0). The badge is click-through
    -- (an hs.canvas ignores the mouse unless asked to track it, and the
    -- ring's middle is transparent anyway), so the click reaches the
    -- control underneath exactly as before — the badge just stops
    -- outstaying it. The teardown is deferred one turn: the click is on
    -- its way to the app, and a tap callback that tears the world down
    -- mid-delivery is the kind of thing this module's safety section
    -- exists to forbid. The tap is pcall'd end to end: no Accessibility,
    -- no tap — the watchdog stays as the only exit, as it was.
    local function startClickTap()
        stopClickTap()
        if not grid.clickEnds then return false end
        local types = {}
        pcall(function()
            local T = hs.eventtap.event.types
            for _, k in ipairs({ "leftMouseDown", "rightMouseDown", "otherMouseDown" }) do
                if T[k] then types[#types + 1] = T[k] end
            end
        end)
        if #types == 0 then return false end
        local okNew, tap = pcall(hs.eventtap.new, types, function()
            if grid.state and grid.state.phase == "landed" then
                pcall(function()
                    grid.endTimer = hs.timer.doAfter(0, function()   -- HELD
                        grid.endTimer = nil
                        grid.hide("clicked by hand")
                    end)
                end)
            end
            return false      -- never consumed: the click is the person's
        end)
        if not (okNew and tap) then return false end
        local okStart = pcall(function() tap:start() end)
        if not okStart then return false end
        grid.clickTap = tap
        return true
    end

    -- =====================================================================
    -- CLICKING
    -- =====================================================================
    -- Moving the pointer needs no permission; clicking does. Kept apart so
    -- the failure is specific: on a Mac without Accessibility the jump
    -- still works and only the click reports why.
    local function axAvailable()
        local ok, granted = pcall(hs.accessibilityState)
        return ok and granted == true
    end

    local function clickAt(point, kind)
        if not axAvailable() then
            grid.hide("click refused")
            hs.alert.show("🎯 Pointer moved. macOS will not let Hammerspoon "
                .. "click without Accessibility —\nSystem Settings → Privacy & "
                .. "Security → Accessibility. Trackpad click still works.")
            warn("click requested with Accessibility off")
            return false
        end
        local ok, err = pcall(function()
            if kind == "right" then
                hs.eventtap.rightClick(point)
            elseif kind == "double" then
                -- A real double click is ONE property, not two fast clicks:
                -- without clickState = 2 most apps see two singles and you
                -- get two selections instead of an open. Falls back to two
                -- clicks if this build has no such property.
                local e  = hs.eventtap.event
                local okd = pcall(function()
                    for _, t in ipairs({ e.types.leftMouseDown, e.types.leftMouseUp,
                                         e.types.leftMouseDown, e.types.leftMouseUp }) do
                        e.newMouseEvent(t, point)
                         :setProperty(e.properties.mouseEventClickState, 2)
                         :post()
                    end
                end)
                if not okd then
                    hs.eventtap.leftClick(point); hs.eventtap.leftClick(point)
                end
            else
                hs.eventtap.leftClick(point)
            end
        end)
        if not ok then
            grid.hide("click failed")
            hs.alert.show("🎯 Could not click — see the Console")
            warn("click failed: " .. tostring(err))
            return false
        end
        say(kind .. " click at " .. math.floor(point.x) .. "," .. math.floor(point.y))
        return true
    end

    local function movePointer(point)
        -- ⚠️ NO setAbsolutePosition FALLBACK. It looks like a safety net and
        -- is not one: in Hammerspoon's source setAbsolutePosition is a
        -- deprecated shim whose entire body calls absolutePosition and
        -- prints a deprecation notice. Retrying through it would re-run the
        -- call that just failed and spam the Console for the privilege.
        local ok, err = pcall(function() hs.mouse.absolutePosition(point) end)
        if not ok then warn("could not move the pointer: " .. tostring(err)) end
        return ok
    end

    -- =====================================================================
    -- 🎯 SNAP ONTO A CONTROL (6.154.0)
    -- =====================================================================
    -- What is under the cell? Asked of the system-wide AX element at the
    -- cell's centre and its four quarter points — five questions at most,
    -- centre first so the common case costs one — each with its own
    -- timeout, the lot under grid.snapBudget. An answer counts when it is
    -- a control (grid.snapRoles) whose CENTRE lies inside the cell: that
    -- is LL's "only if that button or field is within the box". Several?
    -- The one nearest the cell's centre. Our own windows are ignored by
    -- pid (the overlay is hidden before asking, but a belt is cheap).
    -- Returns { x, y, role, title } or nil plus the reason, for the trail.
    local function ownPid()
        local ok, p = pcall(function() return hs.processInfo.processID end)
        return ok and p or nil
    end

    local function samplePoints(cell)
        local cx, cy = cell.ax, cell.ay
        local dx, dy = cell.rw / 4, cell.rh / 4
        return { { x = cx, y = cy },
                 { x = cx - dx, y = cy - dy }, { x = cx + dx, y = cy - dy },
                 { x = cx - dx, y = cy + dy }, { x = cx + dx, y = cy + dy } }
    end

    function grid.snapPoint(cell)
        if grid.snapToControls ~= true then return nil, "snap is off" end
        if not axAvailable() then return nil, "no Accessibility" end
        local okSys, sys = pcall(function() return hs.axuielement.systemWideElement() end)
        if not (okSys and sys) then return nil, "no system-wide element" end
        pcall(function() sys:setTimeout(grid.snapTimeout) end)
        local me = ownPid()
        local left, top = cell.ax - cell.rw / 2, cell.ay - cell.rh / 2
        local right, bottom = left + cell.rw, top + cell.rh
        local t0 = hs.timer.secondsSinceEpoch()
        local best, bestD, asked = nil, math.huge, 0
        -- the second-tier candidate: the SMALLEST control whose frame
        -- contains the point we asked about. Smallest, because a button
        -- inside a toolbar inside a group all contain the same point and
        -- the innermost one is the thing you were aiming at.
        local near, nearArea = nil, math.huge
        local why, seen = "nothing under the cell", {}
        for i, p in ipairs(samplePoints(cell)) do
            -- the budget is a ceiling on what is ASKED, checked before
            -- each question — the ⌥Tab listBudget rule
            if hs.timer.secondsSinceEpoch() - t0 > grid.snapBudget then
                why = "budget spent"
                break
            end
            -- the CENTRE was asked first and it is a control: the pointer
            -- would land on it anyway, so the common case costs one
            if i > 1 and best then break end
            asked = asked + 1
            local el
            pcall(function() el = sys:elementAtPosition(p.x, p.y) end)
            if el then
                pcall(function() el:setTimeout(grid.snapTimeout) end)
                local pid, role, frame
                pcall(function() pid = el:pid() end)
                if me ~= nil and pid == me then
                    why = "only our own window under the cell"
                else
                    pcall(function() role = el:attributeValue("AXRole") end)
                    if role and grid.snapRoles[role] then
                        pcall(function() frame = el:attributeValue("AXFrame") end)
                        if type(frame) == "table" and frame.w and frame.h then
                            local fx = frame.x + frame.w / 2
                            local fy = frame.y + frame.h / 2
                            local key = tostring(fx) .. "," .. tostring(fy)
                            if not seen[key] then
                                seen[key] = true
                                if fx >= left and fx <= right
                                   and fy >= top and fy <= bottom then
                                    local d = (fx - cell.ax) ^ 2 + (fy - cell.ay) ^ 2
                                    if d < bestD then
                                        local title
                                        pcall(function()
                                            title = el:attributeValue("AXTitle")
                                        end)
                                        best, bestD = { x = fx, y = fy, role = role,
                                                        title = title }, d
                                    end
                                elseif grid.snapContains
                                       and p.x >= frame.x and p.x <= frame.x + frame.w
                                       and p.y >= frame.y and p.y <= frame.y + frame.h then
                                    local area = frame.w * frame.h
                                    if area > 0 and area <= (grid.snapMaxArea or 0)
                                       and area < nearArea then
                                        local title
                                        pcall(function()
                                            title = el:attributeValue("AXTitle")
                                        end)
                                        near, nearArea = { x = fx, y = fy, role = role,
                                                           title = title, wide = true }, area
                                    elseif not near then
                                        why = role .. " under the cell, but it is too "
                                              .. "big to be a control (grid.snapMaxArea)"
                                    end
                                else
                                    why = role .. " under the cell, but its centre "
                                          .. "is outside it"
                                end
                            end
                        end
                    elseif role then
                        why = tostring(role) .. " is not a control"
                    end
                end
            end
        end
        -- ⚠️ %.0f, never %d: these are screen coordinates (see layoutKey)
        local ms = (hs.timer.secondsSinceEpoch() - t0) * 1000
        -- tier 1 wins outright; tier 2 only when nothing centred in the cell
        if not best and near then best = near end
        if best then
            say(string.format("snapped to %s%s at %.0f,%.0f (%d asked, %.0fms%s)",
                best.role,
                best.title and (" '" .. tostring(best.title):sub(1, 30) .. "'") or "",
                best.x, best.y, asked, ms, best.wide and ", wider than the cell" or ""))
            return best
        end
        say(string.format("no snap: %s (%d asked, %.0fms)", why, asked, ms))
        return nil, why
    end

    -- =====================================================================
    -- LANDED MODE
    -- =====================================================================
    local function enterLanded(point, snap, box)
        -- ✂️ 6.252.0 — before the modal is entered, and after any settings
        -- override has landed. Idempotent.
        if grid.halve then
            local ok, bound = pcall(grid.ensureSplitKeys)
            if not ok or not bound or not bound.ok then
                grid.hide("refinement keys unavailable")
                warn("refinement keys unavailable — pointer moved, keyboard capture refused")
                return false
            end
        end
        hideAllShown()
        pcall(function() grid.pickModal:exit() end)
        local okEnter = pcall(function() grid.landModal:enter() end)
        if not okEnter then
            -- Could not take the keyboard, so do not pretend to have it:
            -- the pointer has already moved, which is most of the value.
            grid.hide("could not enter landed mode")
            warn("landModal:enter() failed — pointer moved, keys not captured")
            return
        end
        grid.state = { phase = "landed", point = point, snapped = snap,
                       box = box, halvings = 0, history = {} }
        if select(2, grid.refineSpec()) == 4 and not showBox(box) then
            grid.hide("quarter labels could not be drawn")
            return false
        end
        local hint
        if snap then
            hint = tostring(snap.title or snap.role or ""):sub(1, 18)
            if hint == "" then hint = nil end
        end
        if not showCrosshair(point.x, point.y, hint) then
            grid.hide("no badge could be drawn")
            warn("landed badge could not be drawn — refusing to capture keys "
                 .. "invisibly; the pointer has still moved")
            return
        end
        if not armWatchdog(grid.landedSecs, "landed badge left open") then return false end
        startClickTap()
        say("landed at " .. math.floor(point.x) .. "," .. math.floor(point.y))
    end

    local function nudge(dx, dy)
        local s = grid.state
        if not (s and s.phase == "landed") then return end
        local p = { x = s.point.x + dx, y = s.point.y + dy }
        s.point = p
        movePointer(p)
        -- 6.192.0 — a NUDGE CARRIES THE BOX WITH IT, same size, pointer
        -- still at its centre. Leaving the box behind would make the
        -- outline a lie about where you are, and dropping it would make
        -- ⌥+arrow refuse after any nudge — nudge a little, then halve, is
        -- exactly how these two get used together. It never resizes: a
        -- nudge is a move, and only ⌥+arrow changes precision.
        if s.history then
            for _, old in ipairs(s.history) do
                old.box = { x=old.box.x+dx,y=old.box.y+dy,w=old.box.w,h=old.box.h }
                old.point = { x=old.point.x+dx,y=old.point.y+dy }
            end
        end
        if s.box then
            s.box.x, s.box.y = s.box.x + dx, s.box.y + dy
            if not showBox(s.box) then
                grid.hide("box lost during nudge")
                warn("the box could not be redrawn mid-nudge — refusing to "
                     .. "capture keys invisibly")
                return
            end
        end
        if not showCrosshair(p.x, p.y) then
            grid.hide("badge lost during nudge")
            warn("badge could not be redrawn mid-nudge — refusing to capture "
                 .. "keys invisibly")
            return
        end
        if not armWatchdog(grid.landedSecs, "landed badge left open") then return false end
    end

    -- ✂️ 6.252.0 — PRESS A LETTER, KEEP THAT HALF. The box you landed in
    -- is drawn split along its longer side with one letter in each half;
    -- pressing that letter keeps it, puts the pointer in its middle and
    -- SPLITS AGAIN, so it repeats exactly as ⌥+arrow did — which is gone.
    -- A refusal (no box, or the floor) SAYS so and changes nothing: it
    -- never silently nudges instead, which would be the pointer moving
    -- somewhere LL did not ask for (6.195.0).
    local function splitTo(which)
        local s = grid.state
        -- 🚨 6.195.0 — NO SILENT NO-OP. A press that does nothing must not
        -- look the same whichever reason it was.
        if not (s and s.phase == "landed") then
            say("split ignored: not landed")
            return
        end
        if not grid.halve then
            hs.alert.show("🎯 splitting is switched off (mouse_grid.halve)")
            say("split ignored: grid.halve is false")
            return
        end
        local sp, whySplit = grid.refinementOf(s.box)
        local box, why = (sp and sp[which]), whySplit
        if not box then
            hs.alert.show("🎯 " .. tostring(why))
            say("halve refused: " .. tostring(why))
            if not armWatchdog(grid.landedSecs, "landed badge left open") then return false end
            return
        end
        local p = { x = box.x + box.w / 2, y = box.y + box.h / 2 }
        s.history = s.history or {}
        s.history[#s.history + 1] = { box = s.box, point = s.point }
        s.box, s.point, s.halvings = box, p, (s.halvings or 0) + 1
        movePointer(p)
        if not showBox(box) or not showCrosshair(p.x, p.y) then
            grid.hide("badge lost while splitting")
            warn("the box or badge could not be drawn while splitting — "
                 .. "refusing to capture keys invisibly")
            return
        end
        if not armWatchdog(grid.landedSecs, "landed badge left open") then return false end
        say(string.format("split %s -> %.0fx%.0f at %.0f,%.0f (%d deep)",
            which, box.w, box.h, p.x, p.y, s.halvings))
    end

    -- ✂️ 6.252.0 — THE TWO LETTERS ARE BOUND ON THE FIRST LANDING, not at
    -- setup. init.lua applies a profile's `settings` AFTER setup returns
    -- (6.228.0's 🔌 rule), so a `halveKeys` override read at setup time
    -- would draw one pair of letters and bind another. hs.hotkey.modal has
    -- no unbind, so this can only be done once — hence the guard, and
    -- hence resolving the pair at the last possible moment rather than the
    -- first.
    function grid.ensureSplitKeys()
        if grid.splitBound then return grid.splitBound end
        local keys, parts, from = grid.refineSpec()
        if not keys then
            grid.splitBound = { ok = false, why = from }
            return grid.splitBound
        end
        local names = { "first", "second", "third", "fourth" }
        local okB, bindErr = pcall(function()
            for i=1,parts do
                local which = names[i]
                local binding = grid.landModal:bind({},keys:sub(i,i),function()
                    local ok, err = pcall(splitTo, which)
                    if not ok then grid.hide("refinement error");warn("refinement: "..tostring(err)) end
                end)
                if not binding then error("modal refused "..keys:sub(i,i)) end
            end
        end)
        grid.splitBound = { ok=okB, keys=keys,parts=parts,from=from,
            why=okB and ("bound "..keys.." from "..from) or ("modal refused keys: "..tostring(bindErr)) }
        return grid.splitBound
    end

    function grid.undoRefinement()
        local st=grid.state
        if not (st and st.phase=="landed") then return false end
        local old=st.history and table.remove(st.history)
        if not old then return false end
        st.box,st.point,st.halvings=old.box,old.point,math.max(0,(st.halvings or 0)-1)
        movePointer(st.point)
        if not showBox(st.box) or not showCrosshair(st.point.x,st.point.y) then
            grid.hide("undo could not draw");return false
        end
        return armWatchdog(grid.landedSecs,"landed badge left open")
    end

    local function landedClick(kind)
        local s = grid.state
        if not (s and s.phase == "landed") then return end
        local point = s.point
        -- Hide FIRST. The badge sits at screenSaver level, directly over
        -- the thing being clicked, and a menu opening underneath an
        -- overlay is a confusing half-second. It also means the alert in
        -- clickAt() is visible rather than covered.
        grid.hide("clicked")
        clickAt(point, kind)
    end

    -- =====================================================================
    -- TYPING
    -- =====================================================================
    -- 🟡 6.65.0 — "the other boxes fall away". The lattice is one scrim
    -- plus (cols-1)+(rows-1) line segments; dropping the segments and
    -- keeping the scrim leaves the survivors' amber boxes alone on a dark
    -- field. That is ONE element to draw, not one per discarded cell, so
    -- the more the grid narrows the CHEAPER this gets — the opposite of
    -- greying out each loser individually.
    -- 🌓 6.248.0 — and this is the one he sees after the first keystroke,
    -- so it asks scrimFor with the count. A 0 alpha still draws its
    -- rectangle: setElements refuses an empty list (an empty table is ONE
    -- element with no key-value pairs and hs.canvas throws on it), and a
    -- transparent fill is the cheapest honest way to say "nothing here".
    local function scrimOnly(p, typed)
        return { { type = "rectangle", action = "fill",
                   fillColor = { white = grid.scrimWhite,
                                 alpha = (grid.scrimFor(typed or 1)) },
                   frame = { x = 0, y = 0, w = p.frame.w, h = p.frame.h } } }
    end

    local function redraw()
        local s = grid.state
        if not (s and s.phase == "pick") then return end
        local t0, shown = hs.timer.secondsSinceEpoch(), 0
        -- Tracked so the lattice is rebuilt exactly once when you
        -- backspace all the way out, rather than on every keystroke.
        local bare = grid.dropLattice and #s.typed > 0
        for _, p in ipairs(grid.cache.screens) do
            if bare ~= s.latticeDropped then
                setElements(p.gridCanvas,
                            bare and scrimOnly(p, #s.typed) or gridElements(p))
            end
            if #s.typed == 0 then
                setElements(p.labelCanvas, p.fullLabels)
                shown = shown + #p.fullLabels
            else
                local els = labelElements(p, #s.typed, s.matches)
                setElements(p.labelCanvas, els)
                shown = shown + #els
            end
        end
        s.latticeDropped = bare
        say(string.format("typed '%s' -> %d candidates, redraw %.1fms",
            s.typed, shown, (hs.timer.secondsSinceEpoch() - t0) * 1000))
    end

    local function cellFor(label)
        for _, p in ipairs(grid.cache.screens) do
            for _, c in ipairs(p.cells) do
                if c.label == label then return c end
            end
        end
        return nil
    end

    function grid.typeChar(ch)
        local s = grid.state
        if not (s and s.phase == "pick") then return end

        local nextTyped = s.typed .. ch
        local matches, n = {}, 0
        for _, p in ipairs(grid.cache.screens) do
            for _, c in ipairs(p.cells) do
                if c.label:sub(1, #nextTyped) == nextTyped then
                    matches[c.label] = true; n = n + 1
                end
            end
        end

        -- With a full grid every prefix has candidates, so this is a
        -- can't-happen — which is exactly why it is handled rather than
        -- assumed away. A dead end rejects the keystroke and leaves you
        -- where you were, instead of stranding you in a grid with nothing
        -- selectable and no idea why.
        if n == 0 then
            hs.alert.show("🎯 no cell '" .. nextTyped .. "'")
            warn("dead-end prefix '" .. nextTyped .. "' rejected")
            return
        end

        s.typed, s.matches = nextTyped, matches
        if not armWatchdog(grid.timeoutSecs, "grid left open mid-type") then return false end

        if #s.typed >= grid.labelLength then
            local cell = cellFor(s.typed)
            if not cell then
                grid.hide("lost cell")
                warn("matched '" .. s.typed .. "' but no cell carried it")
                return
            end
            local point = { x = cell.ax, y = cell.ay }
            -- 🎯 6.154.0 — THE OVERLAY COMES DOWN BEFORE THE HIT-TEST, or
            -- "what is under this point?" is answered by our own scrim.
            -- hideAllShown() is idempotent; every path below calls it
            -- again on its way to hide()/enterLanded().
            hideAllShown()
            local snap = grid.snapPoint(cell)
            if snap then point = { x = snap.x, y = snap.y } end
            movePointer(point)
            if s.clickOnArrival then
                grid.hide("jumped + clicked")
                clickAt(point, "left")
            elseif grid.landedMode then
                    -- 6.192.0 — the CELL travels into landed mode, because that
            -- is the box ⌥+arrow halves. Nothing else knows its bounds:
            -- the pointer is a point and the snap is a control's centre.
            enterLanded(point, snap,
                        { x = cell.ax - cell.rw / 2, y = cell.ay - cell.rh / 2,
                          w = cell.rw, h = cell.rh })
            else
                grid.hide("jumped")
            end
            return
        end
        redraw()
    end

    function grid.backspace()
        local s = grid.state
        if not (s and s.phase == "pick") then return end
        if #s.typed == 0 then grid.hide("backspaced out") return end
        s.typed = s.typed:sub(1, #s.typed - 1)
        local matches = {}
        if #s.typed > 0 then
            for _, p in ipairs(grid.cache.screens) do
                for _, c in ipairs(p.cells) do
                    if c.label:sub(1, #s.typed) == s.typed then matches[c.label] = true end
                end
            end
        end
        s.matches = matches
        if not armWatchdog(grid.timeoutSecs, "grid left open mid-type") then return false end
        redraw()
    end

    -- =====================================================================
    -- SHOW
    -- =====================================================================
    function grid.show(clickOnArrival)
        if not grid.enabled then return false end
        if _G.hyperDispatchEngaged == true then
            grid.hide("Carbon modal unavailable")
            warn("grid unavailable while Carbon fallback is active; no keyboard capture attempted")
            return false
        end
        grid.refreshCheatsheet()
        -- Pressing the trigger while it is already up means "put it away".
        if grid.state then grid.hide("toggled off") return false end

        local t0 = hs.timer.secondsSinceEpoch()
        local cache, err = ensureCache()
        if not cache then
            hs.alert.show("🎯 Mouse Grid could not draw — see the Console")
            warn("show failed: " .. tostring(err))
            return false
        end

        -- 🚨 STATE FIRST, THEN THE SCREEN, THEN THE KEYBOARD — and if
        -- either of the last two fails, hide() undoes all three. Setting
        -- state last would mean a throw halfway through left canvases up
        -- that grid.hide() did not yet believe existed.
        grid.state = { phase = "pick", typed = "", matches = nil,
                       clickOnArrival = clickOnArrival == true }

        local okDraw, drawErr = pcall(function()
            for _, p in ipairs(cache.screens) do
                -- 🚨 6.65.0 — THE LATTICE IS RESTORED HERE, NOT ASSUMED.
                -- The canvases are CACHED across hide/show, and redraw()
                -- strips the grid lines the moment you type (dropLattice).
                -- Without this line the next ⇪X would open a grid that
                -- still had no lines in it — a stale canvas that looks
                -- like a rendering bug and is really just last session's
                -- final frame.
                setElements(p.gridCanvas, gridElements(p))
                setElements(p.labelCanvas, p.fullLabels)
                if not showCanvas(p.gridCanvas) or not showCanvas(p.labelCanvas) then
                    error("native grid canvas could not be shown")
                end
            end
        end)
        if not okDraw then
            grid.hide("draw failed")
            hs.alert.show("🎯 Mouse Grid could not draw — see the Console")
            warn("draw failed: " .. tostring(drawErr))
            return false
        end

        -- Taking the keyboard is the step that can strand you, so its
        -- failure is handled rather than assumed away: no modal means the
        -- overlay comes straight back down instead of sitting there
        -- swallowing nothing and answering nothing.
        if not pcall(function() grid.pickModal:enter() end) then
            grid.hide("could not take the keyboard")
            hs.alert.show("🎯 Mouse Grid could not capture the keyboard")
            warn("pickModal:enter() failed")
            return false
        end
        if not armWatchdog(grid.timeoutSecs, "grid left open with nothing typed") then return false end

        say(string.format("shown: %d cells across %d screens in %.1fms%s",
            cache.used, #cache.screens,
            (hs.timer.secondsSinceEpoch() - t0) * 1000,
            clickOnArrival and " (clicks on arrival)" or ""))
        return true
    end

    -- =====================================================================
    -- REPORT — run this once per Mac
    -- =====================================================================
    -- Answers the only question that decides whether this tool is usable
    -- on a given machine: how big is a cell here, really.
    function _G.mouseGridReport()
        local cache, err = ensureCache()
        if not cache then
            print("🎯 Mouse Grid: " .. tostring(err))
            return
        end
        local out = {
            "🎯 MOUSE GRID on " .. tostring(core.hostTag),
            string.format("   alphabet %q ^ %d = %d labels; %d cells in use",
                grid.alphabet, grid.labelLength, cache.capacity, cache.used),
            "   layout   : "..tostring(grid.subdivisions).." x "..tostring(grid.subdivisions).." children per former cell; bounded at "..tostring(grid.maxCells).." cells",
            string.format("   letters  : Timer accent rgba(%.2f, %.2f, %.2f, %.2f)",
                grid.labelInk().red,grid.labelInk().green,grid.labelInk().blue,grid.labelInk().alpha),
            "   contrast : small dark label plates "..tostring(grid.labelBackplates).."; the rest of each cell remains transparent after typing",
        }
        for i, p in ipairs(cache.screens) do
            out[#out + 1] = string.format(
                "   screen %d  %.0fx%.0f pt   %d x %d cells   cell = %.0f x %.0f pt",
                i, p.frame.w, p.frame.h, p.cols, p.rows, p.cellW, p.cellH)
            if p.densityReduced then
                out[#out+1]="            density reduced to preserve readable three-letter labels"
            end
            -- 44pt is Apple's own minimum control size. Below it, most
            -- targets are a straight hit; above it, expect to nudge.
            if p.cellW > 60 or p.cellH > 60 then
                out[#out + 1] = "              ⚠️  coarser than most buttons — "
                    .. "arrow-nudge after landing, or widen grid.alphabet"
            end
            -- The opposite failure, and easier to cause than the first: a
            -- big alphabet makes cells too small for their own label, and
            -- overlapping text is a grid you cannot read at all.
            if p.cellW < grid.labelSize * grid.labelLength * 0.62 then
                out[#out + 1] = "              ⚠️  cells are narrower than "
                    .. "their labels — text will overlap. Lower "
                    .. "grid.labelSize or shorten grid.alphabet"
            end
        end
        if cache.truncated > 0 then
            out[#out + 1] = string.format(
                "   ❌ %d cells have NO label and are unreachable — widen "
                .. "grid.alphabet or raise grid.labelLength", cache.truncated)
        end
        out[#out + 1] = "   clicking: " .. (axAvailable()
            and "✅ Accessibility granted"
            or  "⚪️ Accessibility OFF — the jump works, space-to-click does not")
        out[#out + 1] = "   snap    : " .. (grid.snapToControls ~= true
            and "off (grid.snapToControls)"
            or (axAvailable()
                and string.format("✅ a control inside the typed cell is landed on "
                                  .. "(≤5 hit-tests, %.0fms budget)%s", grid.snapBudget * 1000,
                                  grid.snapContains
                                    and string.format(", and one WIDER than the cell up to %d pt² "
                                        .. "(6.181.0 — grid.snapContains / snapMaxArea)",
                                        math.floor(num(grid.snapMaxArea, 0)))
                                    or  ", centre inside the cell only (grid.snapContains is off)")
                or  "⚪️ needs Accessibility — the cell centre stands in"))
        -- ✂️ 6.192.0 — the halve line names the FLOOR as well as the state,
        -- because "it stopped halving" is the one thing about this that
        -- will read as broken when it is working exactly as written.
        do
            local st = grid.state
            local keys, parts, from = grid.refineSpec()
            local bound = grid.splitBound
            out[#out + 1] = "   split   : " .. (not grid.halve and "off (grid.halve)"
                or not keys and ("unavailable: "..tostring(from))
                or table.concat((function()
                    local t={};for k in keys:gmatch(".") do t[#t+1]=k end;return t end)()," / ")
                   .. " keep that " .. (parts==4 and "quarter" or "half")
                   .. " · floor "..tostring(grid.halveMin).." pt · "..tostring(from))
            -- 🔎 THREE STATES: never landed yet ≠ bound ≠ the modal refused
            -- them. "the letters do nothing" is answered by this line.
            out[#out + 1] = "             keys: " .. (bound == nil
                and "not bound yet — they are claimed on the first landing"
                or tostring(bound.why))
        end
        -- 🗑 6.360.0 — what a HELD arrow does, in points. It used to climb
        -- (8 → 32 → 64) and LL asked for the climb to go, so a hold repeats
        -- at the SAME step as a tap. The line still prints the numbers,
        -- because "the arrows are too slow" was the report twice and the
        -- numbers behind it were nowhere in the report either time — and
        -- it says there is no acceleration rather than leaving a reader to
        -- infer it from a line that stopped mentioning one (6.196.1).
        out[#out + 1] = string.format(
            "   nudge   : tap %d pt · ⇧ %d pt · HOLD repeats at %d pt — "
            .. "no acceleration, on his word (6.360.0)",
            math.floor(num(grid.nudgeStep, 8)), math.floor(num(grid.nudgeFine, 1)),
            math.floor(num(grid.nudgeStep, 8)))
        -- 🌓 6.248.0 — the two washes, named, because "the grid is too
        -- dark" and "the grid does not get out of the way" are different
        -- complaints about different numbers.
        do
            local a0, why0 = grid.scrimFor(0)
            local a1, why1 = grid.scrimFor(1)
            out[#out + 1] = string.format(
                "   scrim   : %.2f %s · %.2f once you type%s",
                a0, why0, a1,
                a1 <= 0 and " (fully see-through)" or "")
        end
        -- 🏃 6.247.0 — WHAT A HELD ARROW COSTS, counted apart. A release
        -- that claims it stopped rebuilding must be able to prove it on
        -- HIS Mac: moves climbing while rebuilds stay flat is the claim
        -- working; rebuilds climbing with every arrow is this release
        -- doing nothing, quietly (6.241.0's rule).
        do
            local d = grid.draws or {}
            local moves  = (d.boxMove or 0) + (d.crossMove or 0)
            local builds = (d.boxBuild or 0) + (d.crossBuild or 0)
            if moves + builds == 0 then
                out[#out + 1] = "   canvas  : nothing drawn this session"
            else
                out[#out + 1] = string.format(
                    "   canvas  : %d move(s) · %d rebuild(s) — box %d/%d, "
                    .. "badge %d/%d (move/rebuild)",
                    moves, builds, d.boxMove or 0, d.boxBuild or 0,
                    d.crossMove or 0, d.crossBuild or 0)
                if moves == 0 then
                    out[#out + 1] = "              ⚠️  every draw was a REBUILD — "
                        .. "hs.canvas:topLeft is refusing on this Mac, and a "
                        .. "held arrow is paying for two new windows a repeat"
                end
            end
        end
        -- 6.167.0: the ring's size IN EFFECT where the pointer is now, and
        -- what the last press actually drew, for "still small".
        do
            local s = grid.locateScaleFor()
            local last = grid.locateLast
            out[#out + 1] = string.format(
                "   ring    : ⇪⇧L (%s) · radius %d pt here (scale %.2f%s) · %s rings pulsing every %ss for %ss%s",
                tostring(M.version), math.floor(num(grid.locateRadius, 110) * s + 0.5), s,
                grid.locatePinned() and ", pinned by grid.locateScale" or " from the pointer's screen",
                tostring(grid.locateRings), tostring(grid.locateCycle), tostring(grid.locateSecs),
                last and string.format(" · last press drew radius %d at scale %.2f",
                                       last.radius, last.scale) or "")
            -- 🎯 6.310.0 — the rings step outward, and the line says by how
            -- much and how far the OUTERMOST one reaches, because that
            -- number is the whole answer to "is it obvious enough yet".
            local base = math.floor(num(grid.locateRadius, 110) * s + 0.5)
            local g = grid.locateRingGrowth()
            out[#out + 1] = string.format(
                "   ↳ growth : each ring %+.0f%% on the one before it · "
                .. "outermost %d pt of a %d pt canvas%s",
                (g - 1) * 100, math.floor(grid.locateRingR(
                    math.max(0, math.floor(num(grid.locateRings, 3)) - 1), base) + 0.5),
                grid.locateSpan(base) * 2,
                (g <= 1 and "  ⚠️ growth is 1.00 — every ring is the same size"
                         or ""))
        end
        print(table.concat(out, "\n"))
        return table.concat(out, "\n")
    end

    -- =====================================================================
    -- KEYS
    -- =====================================================================
    -- 🚨 TWO MODALS, NOT ONE, and this is not tidiness. hs.hotkey.modal has
    -- no unbind: once "a" is bound to typeChar it is bound forever. A
    -- single modal would therefore keep eating the alphabet in landed mode,
    -- where those keys must reach the app underneath. Two modals, and never
    -- both entered — grid.hide() exits both regardless of which was live.
    grid.pickModal = hs.hotkey.modal.new()
    grid.landModal = hs.hotkey.modal.new()

    for _, ch in ipairs(alphabetChars()) do
        grid.pickModal:bind({}, ch, function()
            -- Wrapped: a throw inside a modal binding would otherwise leave
            -- the overlay up with its state half-changed. Any error tears
            -- the whole thing down rather than leaving it on your screen.
            local ok, err = pcall(grid.typeChar, ch)
            if not ok then grid.hide("error"); warn("typeChar: " .. tostring(err)) end
        end)
    end
    -- ⎋ 6.78.0 — CLAIMED at the top of the order: the grid is drawn at
    -- screenSaver level, above literally everything, so Esc belongs to it
    -- while it is up. See core/coexist.lua.
    if _G.claimEscape then
        _G.claimEscape("mousegrid", nil,
            function() return grid.state ~= nil end,
            function() grid.hide("escape") end)
    end

    -- ✂️ 6.252.0 — 6.195.0's ⌥+arrow hint binds are GONE with the feature
    -- they explained. A key that says "⌥+arrow halves the cell after you
    -- land in one" is worse than an unbound key once ⌥+arrow does not
    -- halve anything.
    grid.pickModal:bind({}, "escape", function() grid.hide("escape") end)
    grid.pickModal:bind({}, "delete", function()
        local ok, err = pcall(grid.backspace)
        if not ok then grid.hide("error"); warn("backspace: " .. tostring(err)) end
    end)

    grid.landModal:bind({}, "escape", function() grid.hide("escape") end)
    grid.landModal:bind({}, "delete", function()
        local ok,err=pcall(grid.undoRefinement)
        if not ok then grid.hide("undo error");warn(tostring(err)) end
    end)
    grid.landModal:bind({}, "space",  function() landedClick("left")   end)
    grid.landModal:bind({}, "return", function() landedClick("left")   end)
    grid.landModal:bind({ "shift" }, "space", function() landedClick("right") end)
    -- ⚠️ NOT a letter, on purpose. Landed mode must capture NO alphabet key,
    -- so everything you type still reaches the app you just landed on. "d
    -- for double" would have cost that rule for one mnemonic; "2" for two
    -- clicks is as memorable and keeps the rule absolute and testable.
    grid.landModal:bind({}, "2",      function() landedClick("double") end)
    -- ✂️ 6.252.0 — ⌥+arrow IS GONE. LL: "Remove the ⌥halve option as I
    -- don't use that. Too convoluted." The two split letters are bound
    -- lazily by grid.ensureSplitKeys on the first landing, because a
    -- settings override of halveKeys lands after setup.
    --
    -- 🚨 AND THE RULE ABOVE IS NARROWED, NOT DELETED. Landed mode may now
    -- capture EXACTLY TWO alphabet keys — the pair drawn in the box — and
    -- no others; the suite still forbids every other letter. THE COST,
    -- named: type one of those two letters immediately after landing and
    -- it splits the box instead of reaching the app. The badge shows the
    -- pair, the watchdog closes landed mode in grid.landedSecs, and a
    -- click by hand ends it at once (6.155.0).
    -- ⏱ 6.115.0 — HOLD AN ARROW AND IT KEEPS MOVING. LL: "Can you make it
    -- so that hyper+X allows the arrows to be pressed and held down? Right
    -- now you have to rapidly hit the key to move."
    --
    -- The cause was the SHAPE OF THE CALL, not the nudge. Every bind here
    -- passed one function, which hs.hotkey.modal:bind takes as pressedfn
    -- and nothing else — so one keypress was one nudge forever, and a
    -- 1-point fine nudge meant forty taps to cross an icon.
    --
    -- Passing the same function as BOTH pressedfn and repeatfn is the fix,
    -- and it is not a new idea in this config: init.lua's popup nudge keys
    -- (bindNudge, §1.5) have done exactly this since they were written,
    -- with a comment explaining that a tap nudges once and a hold repeats
    -- at the OS key-repeat rate. The mouse grid simply never got it.
    --
    -- 🚨 THE ARGUMENT LIST IS LOAD-BEARING: (mods, key, fn, nil, fn).
    -- modal:bind's signature is (mods, key, message, pressedfn, releasedfn,
    -- repeatfn), and it only shifts those along when the third argument is
    -- a function. Passing (mods, key, fn, fn) — the obvious-looking
    -- "pressed and repeat" — actually lands the second fn in RELEASEDFN,
    -- which fires the nudge a second time when you let go and still never
    -- repeats. The nil is what puts the repeat in the right slot.
    --
    -- Safe to repeat because nudge() is idempotent per call and cheap: it
    -- moves the pointer, redraws the crosshair, and re-arms the watchdog.
    -- If the badge can't be redrawn it tears the overlay down rather than
    -- capturing keys invisibly — which holds on the hundredth repeat
    -- exactly as it does on the first.
    -- 🗑 6.360.0 — ONE PLAIN STEP PER PRESS **AND** PER REPEAT. The
    -- multiplier that used to sit here (grid.accelFor, with its own run
    -- state) is deleted outright; see nudgeStep above for why and for what
    -- it costs. A held arrow is still the repeatfn — it repeats, it just
    -- does not climb — and 6.247.0's rule still governs what it may do on
    -- the way: it MOVES the overlay, it never rebuilds it.
    local dirs = { up = { 0, -1 }, down = { 0, 1 }, left = { -1, 0 }, right = { 1, 0 } }
    for key, d in pairs(dirs) do
        local coarse = function()
            nudge(d[1] * grid.nudgeStep, d[2] * grid.nudgeStep)
        end
        local fine = function()
            nudge(d[1] * grid.nudgeFine, d[2] * grid.nudgeFine)
        end
        grid.landModal:bind({}, key, coarse, nil, coarse)
        grid.landModal:bind({ "shift" }, key, fine, nil, fine)
    end

    if grid.enabled then
        core.hyperAddShortcut({}, grid.key, function() grid.show(false) end, "mouse grid")
        core.hyperAddShortcut({ "shift" }, grid.locateKey,
                              function() grid.locate() end, "find the pointer")
        core.hyperAddShortcut({ "shift" }, grid.key, function() grid.show(true) end,
                              "mouse grid (click on arrival)")
    end

    -- 🚨 THE PANIC KEY IS A PLAIN CHORD, NOT A ⇪ SHORTCUT. If ⇪ itself is
    -- what failed — the remap refused, the hyper modal stuck — then a ⇪
    -- panic key cannot be pressed. Bound directly, same as Screen Veil's.
    hs.hotkey.bind({ "ctrl", "alt", "cmd", "shift" }, "X", function()
        grid.hide("panic key")
        hs.alert.show("🎯 Mouse Grid: overlay cleared")
    end)

    -- A display change invalidates every cached frame. HELD, or it is
    -- collected and the grid quietly keeps drawing yesterday's layout.
    grid.screenWatch = hs.screen.watcher.new(function()
        grid.hide("displays changed")
        if grid.cache then
            for _, p in ipairs(grid.cache.screens or {}) do
                pcall(function() p.gridCanvas:delete() end)
                pcall(function() p.labelCanvas:delete() end)
            end
        end
        grid.cache = nil
        say("display layout changed — geometry cache dropped")
    end)
    pcall(function() grid.screenWatch:start() end)

    -- Said once, at boot, rather than discovered the first time SPACE does
    -- nothing. The jump works either way; only the click is gated.
    if not axAvailable() then
        print("🎯 Mouse Grid: Accessibility is OFF — ⇪X still moves the pointer, "
              .. "but space-to-click cannot work until it is granted.")
    end

    -- =====================================================================
    -- WHERE IS THE POINTER? — the MouseCircle Spoon, done natively
    -- =====================================================================
    -- Flashes a ring at the pointer so you can find it on a wide or
    -- multi-monitor desktop. This is what the MouseCircle Spoon does; it
    -- is ~20 lines, so it lives here rather than pulling in SpoonInstall
    -- and a second loading system alongside the module loader.
    --
    -- 🅿️ DELIBERATELY BOUND TO NO KEY. macOS's own shake-to-grow already
    -- does this, and doubling it up is clutter. It is published as a
    -- service so you can put it on a free pad key the day you want it —
    -- ⇪pad+ and friends are unclaimed for exactly this.
    --       numpad.actions["pad+"] = "mouseGrid.locate"
    -- 6.166.0 — LL: "make the mouse ring flash white and pulsate as three
    -- rings outward, similar to a WiFi signal indicator." Three white
    -- rings leave the pointer one after another, growing and fading, on a
    -- held frame timer; the whole thing is over in locateSecs.
    -- 6.167.0 — LL: "bigger, and stay up for at least 5 seconds." The
    -- radius nearly doubles and is SIZED BY THE SCREEN (the same rule as
    -- the hint card: ×1.5 on a 4K at full points, never below 1), the
    -- pulse REPEATS every locateCycle seconds until locateSecs, and a
    -- white dot flashes at the pointer with each pulse.
    -- 🎨 6.372.0 — BIGGER AND MORE COLOURFUL, and the colour half turned
    -- out to be measurable rather than a taste. LL: "I need the rings
    -- that help find the mouse to be bigger and more colorful."
    --
    -- 🚨 THE RING SHIPPED WHITE, WHICH IS 1.00:1 ON A WHITE WINDOW —
    -- it does not exist there. Measured with ui_style's WCAG arithmetic
    -- (6.369.0) against both extremes:
    --     white   on white 1.00   on black 21.00   ← invisible one way
    --     magenta on white 3.06   on black  6.86
    --     orange  on white 2.84   on black  7.41
    --     violet  on white 2.77   on black  7.59
    -- So "I cannot find the pointer" is a correct report of a ring that
    -- is genuinely absent over Finder, Word, a browser — anything light.
    -- The rule this ships with: EVERY ring colour must be visible on a
    -- white background AND on a black one, because the pointer is over
    -- both in the same minute. 6.361.0's lesson in a third place — when
    -- a tool goes unused, check that it can be SEEN.
    grid.locateColor  = { red = 1, green = 1, blue = 1 }   -- the fallback
    grid.locateColors = {
        { red = 1.00, green = 0.30, blue = 0.65 },   -- magenta  3.06 / 6.86
        { red = 1.00, green = 0.42, blue = 0.21 },   -- orange   2.84 / 7.41
        { red = 0.69, green = 0.52, blue = 1.00 },   -- violet   2.77 / 7.59
    }
    grid.locateRadius = 180     -- at scale 1 (was 110, and 60 before that)
    grid.locateSecs   = 6       -- how long the pointer is marked (was 1.2): five whole pulses
    grid.locateCycle  = 1.2     -- one pulse of three rings; repeats until locateSecs
    grid.locateRings  = 3
    -- 🎯 6.310.0 — EACH RING 10% WIDER THAN THE ONE BEFORE IT. LL: "⇪⇧L
    -- needs to be more obvious. Can you make each ring grow in size by
    -- 10% each time?" His answer, his number. Three rings at 1.10 puts
    -- the outermost 21% past where it used to stop, so the whole mark is
    -- bigger as well as more clearly a ripple travelling outward — and
    -- the canvas grows with it (grid.locateSpan) rather than clipping
    -- the very ring that makes it obvious.
    grid.locateRingGrow = 1.10
    grid.locateStagger = 0.22   -- seconds between one ring leaving and the next
    grid.locateFps    = 30
    grid.locateScale  = nil     -- nil = from the pointer's screen; a number pins it
    grid.locateScaleBase = 1440 -- a screen this many points tall is scale 1
    grid.locateScaleMax  = 2.5
    grid.locateCanvas = nil   -- HELD: an unreferenced canvas is collected
    grid.locateTimer  = nil   -- HELD: so is an unreferenced timer
    grid.locateAnim   = nil   -- HELD: the frame timer

    -- The scale the ring is drawn at: pinned by grid.locateScale, else
    -- the pointer's screen height over locateScaleBase, floor 1. A
    -- CoreGraphics read (hs.mouse.getCurrentScreen is hs.screen), not AX.
    -- A settings override is whatever LL typed: "2" is 2; 0, a negative
    -- or a word is not a pin — one test (num, file scope) for the drawing
    -- AND the report.
    function grid.locatePinned() return num(grid.locateScale, nil) end
    function grid.locateScaleFor()
        local pin = grid.locatePinned()
        if pin then return pin end
        local f
        pcall(function()
            local scr = hs.mouse.getCurrentScreen()
            if not scr then return end
            -- fullFrame(), NOT frame(): frame() loses the menu bar and the
            -- Dock, and a Dock that hides would resize the ring between
            -- presses (the geometry rule this file already states).
            local okFull, full = pcall(function() return scr:fullFrame() end)
            f = (okFull and full) or scr:frame()
        end)
        local h = f and tonumber(f.h) or 0
        local s = (h > 0) and (h / num(grid.locateScaleBase, 1440)) or 1
        if s < 1 then s = 1 end
        local max = num(grid.locateScaleMax, 2.5)
        if s > max then s = max end
        return s
    end

    -- The rings at time t (seconds since the press), drawn at radius r:
    -- within each locateCycle the rings leave the pointer one after
    -- another, locateStagger apart, grow from a dot to the edge over
    -- their life and fade as they go; the cycle repeats until locateSecs,
    -- with a white dot at the centre that flashes as each cycle starts.
    -- Pure, so the suite can check it frame by frame.
    -- PURE. The outer radius ring `i` (0-based) reaches. A grow below 1
    -- would SHRINK the rings, which is the opposite of what was asked,
    -- so it is clamped — a typo in a settings line degrades to "no
    -- growth", never to an invisible mark.
    function grid.locateRingGrowth()
        local g = tonumber(grid.locateRingGrow) or 1.10
        if g ~= g or g < 1 then g = 1 end        -- NaN and shrink both floor
        if g > 2 then g = 2 end
        return g
    end
    -- PURE. The colour ring i is drawn in: the list, cycled, with
    -- `locateColor` as the floor. A settings override that is not a list
    -- of colours must fall back rather than draw nothing — this is the
    -- mark that exists to be FOUND, so an empty answer is the one
    -- outcome it cannot have.
    function grid.locateRingColor(i, list, fallback)
        fallback = (type(fallback) == "table" and tonumber(fallback.red))
                   and fallback or { red = 1, green = 1, blue = 1 }
        if type(list) ~= "table" or #list == 0 then return fallback end
        local c = list[(math.max(0, math.floor(tonumber(i) or 0)) % #list) + 1]
        if type(c) ~= "table" or not tonumber(c.red)
           or not tonumber(c.green) or not tonumber(c.blue) then
            return fallback
        end
        return c
    end

    function grid.locateRingR(i, r)
        r = tonumber(r) or num(grid.locateRadius, 110)
        return r * (grid.locateRingGrowth() ^ math.max(0, math.floor(i or 0)))
    end
    -- PURE. How big the canvas must be: the OUTERMOST ring's radius, not
    -- the base one. Sized off the base and it would clip exactly the
    -- ring this release added (6.270.0: reserve the room before you draw
    -- the thing, or it covers or crops what is already there).
    function grid.locateSpan(r)
        r = tonumber(r) or num(grid.locateRadius, 110)
        local rings = math.floor(num(grid.locateRings, 3))
        if rings < 1 then rings = 1 end
        local outer = grid.locateRingR(rings - 1, r)
        return math.max(r, math.ceil(outer))
    end

    function grid.locateFrame(t, r)
        r = r or grid.locateRadius
        local els = {}
        -- 6.310.0 — every element is centred on the SPAN, so the rings
        -- stay concentric on the pointer however far the outermost goes.
        local span = grid.locateSpan(r)
        -- Every knob is a settings override away from a typo: a bad one
        -- falls back to the default rather than drawing NaN or nothing.
        local secs, cycle = num(grid.locateSecs, 6), num(grid.locateCycle, 1.2)
        local rings = math.floor(num(grid.locateRings, 3))
        local stagger = tonumber(grid.locateStagger) or 0.22
        if t >= 0 and t < secs then
            local k = r / 60                        -- stroke and dot grow with the ring
            if k < 1 then k = 1 end
            local tc = t - math.floor(t / cycle) * cycle
            local life = cycle - stagger * (rings - 1)
            if life <= 0 then life = cycle end
            for i = 0, rings - 1 do
                local p = (tc - i * stagger) / life
                if p >= 0 and p <= 1 then
                    local ri = grid.locateRingR(i, r)      -- 6.310.0
                    local rc = grid.locateRingColor(i, grid.locateColors,
                                                     grid.locateColor)
                    els[#els + 1] = {
                        type = "circle", action = "stroke",
                        strokeColor = { red = rc.red, green = rc.green,
                                        blue = rc.blue, alpha = 0.95 * (1 - p) },
                        strokeWidth = (4 - 2 * p) * k,
                        center = { x = span, y = span },
                        radius = 4 * k + (ri - 8 * k) * p,
                    }
                end
            end
            local dc = grid.locateRingColor(0, grid.locateColors, grid.locateColor)
            els[#els + 1] = {
                type = "circle", action = "fill",
                fillColor = { red = dc.red, green = dc.green,
                              blue = dc.blue, alpha = 0.9 - 0.6 * (tc / cycle) },
                center = { x = span, y = span }, radius = 3 * k,
            }
        end
        if #els == 0 then els[1] = { action = "skip" } end
        return els
    end

    function grid.locate()
        -- Idempotent: a second press replaces the first ring rather than
        -- stacking canvases that each delete themselves on their own
        -- schedule, which is how this kind of thing leaks.
        if grid.locateTimer  then pcall(function() grid.locateTimer:stop() end) end
        if grid.locateAnim   then pcall(function() grid.locateAnim:stop() end) end
        if grid.locateCanvas then pcall(function() grid.locateCanvas:delete() end) end
        grid.locateCanvas, grid.locateTimer, grid.locateAnim = nil, nil, nil

        local okPos, pos = pcall(hs.mouse.absolutePosition)
        if not (okPos and pos) then return false end
        local s = grid.locateScaleFor()
        local r = math.floor(grid.locateRadius * s + 0.5)
        -- 6.310.0 — the canvas is the OUTERMOST ring's size.
        local span = grid.locateSpan(r)
        grid.locateLast = { scale = s, radius = r, span = span, at = os.time() }
        local okNew, c = pcall(hs.canvas.new,
                               { x = pos.x - span, y = pos.y - span,
                                 w = span * 2, h = span * 2 })
        if not (okNew and c) then return false end
        pcall(function()
            c:replaceElements(grid.locateFrame(0, r))
            -- 🚨 6.66.0 — MATCH THE GRID'S OWN LEVEL AND BEHAVIOUR.
            -- This ring was the odd one out: "overlay" level and
            -- "stationary" behaviour, while the grid itself uses
            -- screenSaver + fullScreenAuxiliary. The consequences were both
            -- real and both invisible until you hit them:
            --   · at "overlay" the ring hides behind the menu bar, so a
            --     pointer parked near the top of the screen was not found
            --     by the tool whose entire job is finding it;
            --   · WITHOUT fullScreenAuxiliary a canvas cannot draw over a
            --     FULL-SCREEN app at all — which is exactly when a pointer
            --     goes missing, because there is no window furniture left
            --     to locate it against.
            -- "stationary" only means "do not move me when Spaces change";
            -- it says nothing about full-screen, and it is not what was
            -- wanted here.
            c:level((hs.canvas.windowLevels or {}).screenSaver)
            c:behaviorAsLabels({ "canJoinAllSpaces", "fullScreenAuxiliary" })
            -- 🚨 CLICK-THROUGH. Without this the ring is a disc of glass
            -- over whatever you were about to click, for half a second —
            -- which is precisely when you are reaching for something.
            c:canvasMouseEvents(false, false, false, false)
        end)
        -- Same protection as every other canvas here — see showCanvas above.
        if _G.showCanvasSafely then _G.showCanvasSafely(c, "pointer ring")
        else pcall(function() c:show() end) end
        grid.locateCanvas = c
        local t0 = hs.timer.secondsSinceEpoch()
        local okA, anim = pcall(hs.timer.doEvery, 1 / grid.locateFps, function()
            if grid.locateCanvas ~= c then
                if grid.locateAnim then pcall(function() grid.locateAnim:stop() end) end
                grid.locateAnim = nil
                return
            end
            pcall(function() c:replaceElements(grid.locateFrame(hs.timer.secondsSinceEpoch() - t0, r)) end)
        end)
        grid.locateAnim = okA and anim or nil
        local okT, tmr = pcall(hs.timer.doAfter, num(grid.locateSecs, 6), function()
            if grid.locateAnim then pcall(function() grid.locateAnim:stop() end) end
            grid.locateAnim = nil
            pcall(function() c:delete() end)
            if grid.locateCanvas == c then grid.locateCanvas = nil end
        end)
        if not (okT and tmr) then
            -- No way to end it: take the ring down now rather than leave a
            -- canvas and a 30 fps timer running until the next press.
            if grid.locateAnim then pcall(function() grid.locateAnim:stop() end) end
            grid.locateAnim = nil
            pcall(function() c:delete() end)
            grid.locateCanvas = nil
            return false
        end
        grid.locateTimer = tmr
        return true
    end

    core.provide("mouseGrid.show",   function() return grid.show(false) end)
    core.provide("mouseGrid.hide",   function() return grid.hide("service") end)
    core.provide("mouseGrid.locate", function() return grid.locate()      end)
    core.provide("mouseGrid.report", function() return _G.mouseGridReport() end)

    _G.mouseGrid = grid
    M.grid   = grid
    M.config = grid   -- so a machine profile can retune it per Mac
end

function M.warm()
    if _G.mouseGrid and _G.mouseGrid.refreshCheatsheet then _G.mouseGrid.refreshCheatsheet() end
end

return M
