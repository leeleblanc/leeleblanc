-- =====================================================================
-- test_unified.lua — Unified Search's Lua half (⇪D since 6.196.0)
-- =====================================================================
--     lua5.4 test_unified.lua [/path/to/hammerspoon]
--
-- Executes modules/unified_search.lua against fixture STORES — a fake
-- clipboard cache, a commands service, a screenshot folder, notes files
-- with real ── stamps ──, an Asana history, OCR / document / file-move
-- CSVs, a pad queue — and checks that gather() reads every one of them
-- the way its own picker does, that the page JSON survives hostile
-- content ("</script>" included), and that the bridge's pick / path /
-- close / dragStart actions do exactly what the panel promises.
-- The page's JavaScript half is executed for real by test_unified_js.js.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail, failures = 0, 0, {}
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else fail = fail + 1
         failures[#failures + 1] = label .. (extra ~= nil and ("\n        got: " .. tostring(extra)) or "") end
end
local function out(s) io.write(s) end

local printed = {}
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    printed[#printed + 1] = table.concat(p, " ")
end

-- ---- a fake filesystem that honors the tail-read protocol --------------
-- tailRead opens "rb", seeks to the end for the size, seeks back, drops a
-- partial line with read("*l") and slurps read("*a") — the stub file
-- object supports exactly that.
local FILES = {}
local realOpen = io.open
local REAL_OPEN = io.open
io.open = function(path, mode)
    local body = FILES[path]
    if body == nil then return nil end
    local pos = 0
    return {
        seek = function(_, whence, offset)
            if whence == "end" then pos = #body
            elseif whence == "set" then pos = offset or 0 end
            return pos
        end,
        read = function(_, what)
            if what == "*l" or what == "l" then
                local nl = body:find("\n", pos + 1, true)
                if not nl then pos = #body return nil end
                local line = body:sub(pos + 1, nl - 1)
                pos = nl
                return line
            end
            local rest = body:sub(pos + 1)
            pos = #body
            return rest
        end,
        close = function() end,
    }
end

-- ---- the stub Mac -------------------------------------------------------
local ALERTS, PB, CLIPOBJ = {}, nil, nil
local OPENED = nil          -- 6.187.0 — what ⌥⏎ handed to /usr/bin/open
local TIMERS = {}
local function drain()
    local list = TIMERS
    TIMERS = {}
    for _, t in ipairs(list) do if not t.stopped then t.fn() end end
end
local LAST_HTML, BRIDGE, VIEW = nil, nil, nil
local EVALS = {}            -- 6.204.0 — every script Lua pushed into the page
local DRAGGED = {}
local KEYS = {}            -- 6.402.0 — every keystroke this panel posted
_G.beginPanelDrag = function(name) DRAGGED[#DRAGGED + 1] = name return true end

hs = {
    webview = {
        usercontent = {
            new = function(name)
                local uc = { name = name }
                function uc:setCallback(fn) BRIDGE = fn return self end
                return uc
            end,
        },
        new = function(rect, opts, uc)
            local v = { rect = rect, deleted = false, flags = {} }
            function v:html(s) LAST_HTML = s return self end
            function v:show() self.shown = true return self end
            function v:delete() self.deleted = true return self end
            function v:windowTitle(t) self.title = t return self end
            function v:allowTextEntry() self.flags.text = true return self end
            function v:closeOnEscape() self.flags.esc = true return self end
            function v:level(l) self.flags.level = l return self end
            function v:behaviorAsLabels() self.flags.spaces = true return self end
            function v:bringToFront() self.flags.front = true return self end
            function v:evaluateJavaScript(js) EVALS[#EVALS + 1] = js return self end
            function v:frame(f)
                if f then self.rect = f return self end
                return self.rect
            end
            VIEW = v
            return v
        end,
    },
    drawing = { windowLevels = { floating = 5 } },
    screen = {
        mainScreen = function()
            return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
        end,
        allScreens = function()
            return { { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end } }
        end,
    },
    image = {
        imageFromPath = function(p)
            return {
                __path = p,
                setSize = function(self, sz)
                    return {
                        encodeAsURLString = function()
                            return "data:image/png;base64,THUMB-" .. p
                        end,
                    }
                end,
            }
        end,
    },
    pasteboard = {
        setContents = function(t) PB = t return true end,
        writeObjects = function(o) CLIPOBJ = o return true end,
    },
    alert = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    -- 📋 6.402.0 — posting a ⌘V is how a pick is pasted. The stub records
    -- the keystroke AND can REFUSE it, because a refusal is a state the
    -- feature has to report rather than a branch nothing can reach
    -- (6.265.0 — MISSING is not REFUSING; 6.290.0 — a stub that always
    -- succeeds certifies the bug).
    eventtap = {
        keyStroke = function(mods, key)
            if _G.KEYSTROKE_REFUSES then error("macOS refused the keystroke", 0) end
            KEYS[#KEYS + 1] = table.concat(mods or {}, "+") .. "+" .. tostring(key)
        end,
    },
    timer = {
        secondsSinceEpoch = function() return 1000.4231 end,
        -- runTool defers by one run-loop turn so the panel is gone before
        -- the tool opens; the suite fires the queue by hand.
        doAfter = function(secs, fn)
            local t = { secs = secs, fn = fn }
            function t:stop() self.stopped = true end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
    },
    -- 6.187.0 — @images asks whether the file is still there (a stat, never
    -- a read). A stub that always says "gone" could never exercise the
    -- branch that draws a thumbnail.
    -- 6.187.0 — ⌥⏎ opens a file through a task, never a main-thread read
    task = {
        new = function(bin, cb, args)
            local t = { bin = bin, args = args }
            function t:start() if self.bin == "/usr/bin/open" then OPENED = self.args[1] end return true end
            return t
        end,
    },
    fs = { attributes = function(path, what)
        if FILES[path] == nil then return nil end
        if what == "modification" then return 1000 end
        return "file"
    end },
}
-- 🖐 6.107.0 — hs.settings, where the dragged position now survives a
-- reload. A plain table stands in for the plist; what is under test is
-- that the panel writes ONE key, debounces the write, and validates
-- whatever comes back.
local SETTINGS = {}
hs.settings = {
    set = function(k, v) SETTINGS[k] = v end,
    get = function(k) return SETTINGS[k] end,
}
_G.diag = { say = function() end, warn = function() end, err = function() end }
local CLAIMS = {}
_G.claimEscape = function(name, priority, active, handle)
    CLAIMS[name] = { priority = priority, active = active, handle = handle }
    return true
end

-- ---- the fixture stores ---------------------------------------------------
_G.clipboardCache = {
    { date = "Aug 15 10:00", text = "newest copy — receipt total" },
    { date = "Aug 14 09:00", text = "</script><b>hostile</b> copy" },
    { date = "Aug 13 08:00", text = ("long "):rep(200) },   -- 1000 chars
}
_G.screenshots = {
    list = function()
        return {
            { name = "Screenshot A.png", path = "/od/shots/Screenshot A.png",
              mtime = 100, size = 2 * 1024 * 1024 },
            { name = "receipt scan.png", path = "/od/shots/receipt scan.png",
              mtime = 90, size = 50 * 1024 },
        }
    end,
}
_G.quickAppend = {
    targets = { { name = "Inbox", file = "inbox.txt" } },
    pathFor = function(t) return "/logs/notes/" .. t.file end,
}
FILES["/logs/notes/inbox.txt"] =
    "── 2026-08-14 09:00 ──\nfirst note line\nsecond line\n\n"
    .. "── 2026-08-15 08:00 ──\nnewest note about receipts\n\n"
_G.asanaTaskHistory = {
    { title = "Old task",    timestamp = 100, desc = "",        assignee = "" },
    { title = "Newest task", timestamp = 200, desc = "the why", assignee = "Lee" },
}
-- 🖼 6.187.0 — DELIBERATELY MIXED, like the real file. Rows written before
-- 6.187.0 have two columns and no image; rows written since carry the file
-- the words were read from as a third, quoted column (quoted because a
-- screenshot name may contain a comma). Both shapes live in one file
-- forever — adoptLegacyFile folds an old machine's log into the new one —
-- so the parser is never allowed to assume which it is holding.
local OCRCSV =
    '2026-08-14 10:00:00,"Hello ""OCR"" line\\nsecond"\n'
    .. '2026-08-15 09:00:00,"Receipt total 42.50"\n'
    .. '2026-08-16 09:00:00,"Invoice from Acme","/shots/invoice.png"\n'
    .. '2026-08-17 09:00:00,"Bank statement, March","/shots/Screenshot 1, cropped.png"\n'
    .. '2026-08-18 09:00:00,"' .. ("filler word " .. ""):rep(40) .. 'buriedneedle at the end"'
    .. ',"/shots/long.png"\n'
    .. '2026-08-19 09:00:00,"a newer reading of the same file","/shots/invoice.png"\n'
    .. '2026-08-20 09:00:00,"words from a file that has since moved","/shots/gone.png"\n'
FILES["/logs/image_text-TestMac.csv"] = OCRCSV
FILES["/shots/invoice.png"] = "PNG"
FILES["/shots/Screenshot 1, cropped.png"] = "PNG"
FILES["/shots/long.png"] = "PNG"
FILES["/logs/doc_wather.csv"] =
    "Date,Time of day,File name,Working time\n"
    .. '2026-08-14,09:12,"Report.docx",1h 05m\n'
    .. '2026-08-15,10:00,"notes.md",12m\n'
-- 📅 6.115.0 — DELIBERATELY MIXED. The file tracker's CSV moved its date
-- to the first column, and this reader gets only the TAIL of the file
-- (256 KB), so it can never see a header to tell it which layout it is
-- holding. Row one is the new layout, row two is the pre-6.115.0 one, and
-- both must come out right — a real file genuinely contains both when the
-- upgrade lands mid-session.
FILES["/logs/file_changes-TestMac.csv"] =
    "timestamp,file_name,new_name,present_location,moved_location,event,epoch\n"
    .. '"2026-08-15 11:00","old.txt","new.txt","/a","/b","renamed",1000\n'
    .. '"solo.png","","/c","","2026-08-15 12:00","created",1001\n'
_G.capturePad = {
    queue  = { { text = "queued pad note", createdAt = 300 } },
    parked = { { text = "parked pad note", createdAt = 200 } },
    applyNonActivating = function(v) v.nonActivating = true return true end,
}

-- 🔧 the tools source reads the ASSEMBLED cheat sheet, exactly as the
-- standalone Tool Picker did before 6.104.0 folded it in here.
_G.cheatSheet = { groups = function()
    return {
        { title = "🎯 MOUSE GRID (⇪X — type 3 letters)", entries = {
            { "⇪X", "Jump the pointer anywhere" } } },
        { title = "🔗 URL CLEANER (⇪K)", entries = {
            { "⇪K",  "Clean the copied link of trackers" },
            { "⇪⇧K", "Undo the last clean" } } },
        { title = "❓ HELP", entries = {
            { "⇪/", "Toggle this cheat sheet" },
            { "⇪=", "Add your own entry" } } },
    }
end }

local RAN, REGISTRY = {}, {}
_G.service = {
    has  = function(n) return REGISTRY[n] ~= nil end,
    call = function(n, ...) 
        if REGISTRY[n] then return REGISTRY[n](...) end
        return nil                      -- PRINTS and returns in the real one
    end,
}
local function publish(n, fn) REGISTRY[n] = fn end
publish("mouseGrid.show", function() RAN[#RAN + 1] = "grid" return true end)

local PROVIDED, HYPER = {}, {}
local CORE = {
    logsDir = "/logs", hostTag = "TestMac",
    -- 📋 6.325.0 — THE ONE CLIPBOARD DOOR, in the stub too. The three
    -- callers that used to announce "📋 Copied" over a write macOS may
    -- have refused now ask core.copyText, so a core stub without it
    -- throws rather than silently taking a different path — and a stub
    -- that always SUCCEEDS could never drive the refusal (6.290.0).
    copyText = function(text, who)
        _G.COPIES = _G.COPIES or {}
        _G.COPIES[#_G.COPIES + 1] = { text = text, who = who }
        if _G.COPY_REFUSES then return false, "macOS refused the write" end
        if type(text) ~= "string" or text == "" then return false, "there was nothing to copy" end
        pcall(function() hs.pasteboard.setContents(text) end)
        return true
    end,
    provide = function(n, f) PROVIDED[n] = f end,
    call    = function(n, ...)
        if n == "commands.entries" then
            return {
                { cmd = "git status",          when = "2026-08-15 10:00" },
                { cmd = "grep receipt log.txt" },
            }
        end
    end,
    hyperAddShortcut = function(mods, key, fn)
        local ms = {}
        for _, x in ipairs(mods or {}) do ms[#ms + 1] = x end
        table.sort(ms)
        HYPER[table.concat(ms, "+") .. "|" .. key] = fn
    end,
    resolveBaseScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
    end,
}

-- =====================================================================
out("── Unified Search: every store, one picker ──\n")
out("\n1. contract & wiring\n")
-- =====================================================================
local M = dofile(HS .. "/modules/unified_search.lua")
check("module loads and has setup()", type(M.setup) == "function")
M.setup(CORE)
local U = _G.unifiedSearch
check("module table exported", type(U) == "table")
-- 6.196.0 — LL: "swap hyper+space as app launcher, hyper+d Unified
-- search." The PLAIN key moved to ⇪D; the shifted screenshot view did
-- NOT follow it, because ⇪⇧D must stay unclaimed so it forwards to the
-- diagnostic report's global chord. Both halves are asserted by name.
check("⇪D is claimed", type(HYPER["|d"]) == "function")
check("…and ⇪⇧space still opens the screenshot view", 
      type(HYPER["shift|space"]) == "function")
check("🚨 …and ⇪⇧D is NOT claimed — it forwards as ⌘⇧⌃⌥D to the diagnostic\n      report, and a bind here would take it silently (a forwarded chord\n      is not a bind, so the collision auditor cannot see one stolen)",
      HYPER["shift|d"] == nil)
check("…and the launcher's ⇪space is left alone", HYPER["|space"] == nil)
check("…and ⇪⇧/ — the Tool Picker's key still works, and lands where its "
      .. "content moved to (6.104.0)", type(HYPER["shift|/"]) == "function")
check("unified.show is provided", type(PROVIDED["unified.show"]) == "function")
check("listed for Window Move", (function()
    for _, e in ipairs(_G.movablePanels or {}) do
        if e.name == "unified search" then return true end
    end
    return false
end)())

-- =====================================================================
out("2. gather — every store, read like its own picker\n")
-- =====================================================================
U.gather()
local rows = U.rows
byTag = {}
for _, r in ipairs(rows) do
    byTag[r.tag] = byTag[r.tag] or {}
    table.insert(byTag[r.tag], r)
end
check("every store contributed", (function()
    for _, t in ipairs({ "clip", "cmd", "shots", "note", "asana",
                         "ocr", "doc", "file", "pad" }) do
        if not byTag[t] or #byTag[t] == 0 then return false, t end
    end
    return true
end)())
check("clipboard leads the list (it is the unified CLIPBOARD picker)",
      rows[1].tag == "clip" and rows[1].text:find("newest copy") == 1)
check("clipboard rows keep their FULL text for ⏎",
      byTag.clip[3].full:len() == 1000 and byTag.clip[3].text:len() <= U.preview,
      byTag.clip[3].full:len())
check("commands arrive through the ⇪H service",
      byTag.cmd[1].text == "git status" and byTag.cmd[2].full == "grep receipt log.txt")
-- 📅 6.115.0 — BOTH CSV LAYOUTS, READ FROM THE SAME FILE.
-- Getting this wrong does not raise: every field is a string, so a
-- 6.114.0 row read with 6.115.0 indices lists the folder as the file's
-- name and the word "renamed" as its date. Wrong, plausible, and silent
-- — which is exactly the kind of thing that needs asserting by value.
do
    local function fileRow(name)
        for _, r in ipairs(byTag.file or {}) do
            if (r.text or ""):find(name, 1, true) then return r end
        end
        return nil
    end
    local newRow, oldRow = fileRow("old.txt"), fileRow("solo.png")

    check("a NEW-layout row (date first) is read correctly",
          newRow ~= nil and newRow.text == "old.txt → new.txt"
          and newRow.path == "/b/new.txt",
          newRow and newRow.text)
    check("…with its event and date on the sub line, in that order",
          newRow ~= nil and newRow.sub == "renamed · 2026-08-15 11:00",
          newRow and newRow.sub)
    check("🚨 an OLD-layout row in the SAME file is still read correctly — "
          .. "this reader only ever sees the tail of the file, so it can "
          .. "never check a header to find out which layout it holds",
          oldRow ~= nil and oldRow.text == "solo.png"
          and oldRow.path == "/c/solo.png",
          oldRow and oldRow.text)
    check("🚨 …and its DATE is the date, not the word 'created' — reading "
          .. "an old row with new indices produces exactly that, without "
          .. "raising",
          oldRow ~= nil and oldRow.sub == "created · 2026-08-15 12:00",
          oldRow and oldRow.sub)
    check("neither CSV header row became a search result",
          fileRow("file_name") == nil and fileRow("File Name") == nil)
end
check("screenshots carry kind=image, a path and a thumbnail",
      byTag.shots[1].kind == "image"
      and byTag.shots[1].path == "/od/shots/Screenshot A.png"
      and (byTag.shots[1].img or ""):find("^data:image") ~= nil)
check("…and a human sub line (date · size)",
      (byTag.shots[1].sub or ""):find("MB") ~= nil
      and (byTag.shots[2].sub or ""):find("KB") ~= nil, byTag.shots[1].sub)

-- =====================================================================
-- 📸 6.431.0 — @shots BOUNDS DECODES, NOT ROWS
-- =====================================================================
-- LL: "Why do I only have 33 screenshots when I use @shots?" Because 30
-- were listed — maxPer.shots — and the other three rows were incidental
-- matches from other stores. He has 488 captures in that folder.
--
-- 🔑 AND 30 WAS BOUNDING THE WRONG COST. The comment it was written
-- under is about THUMBNAILS: every shots row asked uni.thumbFor(), and
-- a thumbnail is a full PNG decode on the main thread — which on a
-- OneDrive-evicted file means downloading it first (6.187.0 priced
-- exactly that, and 6.152.x is what it costs when nobody does). So the
-- number was a decode budget wearing a row cap's clothes, and the
-- source next door already keeps the two apart: @images lists
-- maxPer.images rows and decodes only uni.thumbMax of them.
--
-- The fixture has two shots; the budget is driven to ONE so the two
-- halves must differ (6.230.0 — at thumbMax >= 2 a row cap and a decode
-- budget agree, and the check would prove nothing).
do
    local U = _G.unifiedSearch
    -- 🚨 THE SHIPPED VALUE FIRST, BEFORE ANYTHING IS PINNED. The sweep
    -- found that putting maxPer.shots back to 30 survived every check
    -- below, because every one of them sets its own value first — which
    -- is 6.429.0's finding word for word, in a different file: a suite
    -- that pins its own configuration proves nothing about the one that
    -- ships (6.273.0). Asserted as a RULE, not as the literal 300
    -- (6.248.0): the number that bounds the LIST must be far larger than
    -- the one that bounds DECODES, or it is still bounding decodes —
    -- which is the whole defect — and it must not be the odd one out in
    -- a table where every other store is in the hundreds.
    check("📸 the SHIPPED shots cap bounds the list, not the decodes — it is "
          .. "many times the thumbnail budget",
          U.maxPer.shots >= U.thumbMax * 4,
          U.maxPer.shots .. " rows vs " .. U.thumbMax .. " decodes")
    check("📸 …and it is in the same class as every other store, which 30 "
          .. "never was (clip 400, web 300, images 150, note 120)",
          U.maxPer.shots >= 100, U.maxPer.shots)
    local savedThumb, savedMax = U.thumbMax, U.maxPer.shots
    U.thumbMax = 1
    U.gather()
    local shots = {}
    for _, r in ipairs(U.rows) do
        if r.tag == "shots" then shots[#shots + 1] = r end
    end
    check("📸 both captures are LISTED when only one may be decoded",
          #shots == 2, #shots)
    check("📸 …and exactly one carries a picture — the budget is spent on "
          .. "DECODES, which is the cost, not on rows, which are free",
          (shots[1].img or ""):find("^data:image") ~= nil
          and shots[2].img == nil,
          tostring(shots[2].img))
    check("…and the row with no picture still carries everything ⏎ and ⌘⏎ "
          .. "need — its name, its date, its size and its path",
          shots[2].path == "/od/shots/receipt scan.png"
          and (shots[2].sub or ""):find("KB") ~= nil
          and (shots[2].text or "") ~= "")
    check("🔎 …and the report says both numbers, which is what makes "
          .. "\"why only 33?\" answerable without reading the source",
          U.shotRows == 2 and U.shotThumbs == 1 and U.shotsOnDisk == 2,
          tostring(U.shotRows) .. "/" .. tostring(U.shotThumbs))

    -- The row cap still exists; it is simply not 30 any more, and it is
    -- the thing that bounds how much of the FOLDER reaches the page.
    U.maxPer.shots = 1
    U.gather()
    local one = 0
    for _, r in ipairs(U.rows) do if r.tag == "shots" then one = one + 1 end end
    check("📏 maxPer.shots still bounds the LIST — the page is never handed "
          .. "an unbounded folder, which is what lets a pinned @tag draw "
          .. "all of it", one == 1, one)
    check("…and the report NAMES what the cap left out, rather than leaving "
          .. "a short list to be discovered",
          U.shotsOnDisk == 2 and U.shotRows == 1)

    U.thumbMax, U.maxPer.shots = savedThumb, savedMax
    U.gather()
end
check("notes split on the ── stamp ── lines, newest first",
      byTag.note[1].full == "newest note about receipts"
      and byTag.note[2].full == "first note line\nsecond line",
      byTag.note[1].full)
check("…and say which file and when",
      (byTag.note[1].sub or ""):find("Inbox") ~= nil
      and (byTag.note[1].sub or ""):find("2026%-08%-15") ~= nil)
check("asana tasks newest first, description carried in full",
      byTag.asana[1].text == "Newest task"
      and byTag.asana[1].full == "Newest task\nthe why"
      and (byTag.asana[1].sub or ""):find("Lee") ~= nil)
check("OCR rows un-escape the CSV (quotes and newlines), newest first",
      byTag.ocr[1].full == "words from a file that has since moved"
      and byTag.ocr[#byTag.ocr].full == 'Hello "OCR" line\nsecond',
      byTag.ocr[1].full .. " / " .. byTag.ocr[#byTag.ocr].full)
-- 6.187.0 — the row that would have proved the old greedy parser wrong:
-- with `^([^,]+),(.*)$` this came out as `Invoice from Acme","/shots/invoice.png`
check("…and a row WITH an image keeps its text clean — no path glued on the end",
      (function()
          for _, r in ipairs(byTag.ocr) do
              if r.full == "Invoice from Acme" then return true end
          end
          return false, byTag.ocr[3] and byTag.ocr[3].full
      end)())
check("documents newest first, worked time in the sub line",
      byTag.doc[1].text == "notes.md"
      and (byTag.doc[1].sub or ""):find("worked 12m") ~= nil, byTag.doc[1].sub)
-- (The rename / created rows these two checks used to assert by INDEX are
--  now asserted by name in section 2, alongside the layout they arrived
--  in. Indexing byTag.file[2] CRASHED the whole suite the moment a reader
--  change dropped a row, which reports a bug as "attempt to index a nil
--  value" three hundred lines away from the cause.)
check("…and the two file rows are the only ones — a reader that accepted "
      .. "a CSV header row would silently add a third",
      #(byTag.file or {}) == 2, #(byTag.file or {}))
check("the CSV header rows were never mistaken for data",
      #byTag.doc == 2 and #byTag.file == 2)
check("pad queue AND parked notes are searchable",
      byTag.pad[1].full == "queued pad note"
      and byTag.pad[2].full == "parked pad note")

check("caps hold — a 400-row store cannot drown the page", (function()
    local old = U.maxPer.clip
    U.maxPer.clip = 2
    U.gather()
    local n = U.counts.clip
    U.maxPer.clip = old
    U.gather()
    return n == 2
end)())

-- =====================================================================
out("2b. 🔧 the tools source — the Tool Picker, folded in (6.104.0)\n")
-- =====================================================================
U.gather()
byTag = {}
for _, r in ipairs(U.rows) do
    byTag[r.tag] = byTag[r.tag] or {}
    table.insert(byTag[r.tag], r)
end
local tools = byTag.tool or {}
check("every cheat sheet entry in every group became a tool row",
      #tools == 5, #tools)
check("🔧 tools come LAST, so what you SAVED stays above what is always "
      .. "there", U.rows[#U.rows].tag == "tool" and U.rows[1].tag ~= "tool")
check("a tool row carries its key, its description and its group",
      (function()
    for _, r in ipairs(tools) do
        if r.keys == "⇪K" then
            return r.text:find("trackers", 1, true) ~= nil
               and r.sub == "⇪K"
               and r.src:find("URL CLEANER", 1, true) ~= nil
        end
    end
end)())
check("…and the group has lost its emoji and its (key) parenthetical — it "
      .. "is a label, not a title", (function()
    for _, r in ipairs(tools) do
        if r.keys == "⇪X" then
            return r.src == "MOUSE GRID" 
        end
    end
end)(), (function()
    for _, r in ipairs(tools) do if r.keys == "⇪X" then return r.src end end
end)())
check("the @tool tag rides in the haystack, so ⇪⇧/ can pin the source",
      U.rowsJson():find("@tool", 1, true) ~= nil)
check("a runnable key is joined to its service, an ordinary row is not",
      (function()
    local grid, help
    for _, r in ipairs(tools) do
        if r.keys == "⇪X" then grid = r end
        if r.keys == "⇪=" then help = r end
    end
    return grid and grid.service == "mouseGrid.show"
           and help and help.service == nil
end)())

out("   -- ⏎ on a 🔧 row RUNS it, or hands back the key --\n")
local gridRow, helpRow
for _, r in ipairs(tools) do
    if r.keys == "⇪X" then gridRow = r end
    if r.keys == "⇪=" then helpRow = r end
end
U.show()
ALERTS = {}
BRIDGE({ body = { a = "pick", id = gridRow.id } })
check("the panel is put away BEFORE the tool runs — two panels racing for "
      .. "the keyboard is how the first keystroke gets eaten",
      U.webview == nil and #RAN == 0)
drain()
check("…and then it runs", RAN[1] == "grid", RAN[1])

U.show()
PB = nil
BRIDGE({ body = { a = "pick", id = helpRow.id } })
check("a row with no runnable service copies its key instead — being told "
      .. "the key is the FALLBACK, not the failure",
      PB == "⇪=" and U.webview == nil, tostring(PB))

check("🚨 a row naming a service nothing publishes copies the key rather "
      .. "than reporting a run — service.call does not throw on a missing "
      .. "provider, so a pcall alone would call it a success", (function()
    PB = nil
    RAN = {}
    U.show()
    U.runTool({ keys = "⇪Z", service = "nope.missing" })
    drain()
    return PB == "⇪Z" and #RAN == 0 and U.webview == nil
end)(), tostring(PB))
check("a service that IS published but THROWS is reported as the real "
      .. "failure it is, not quietly downgraded to 'here is the key'",
      (function()
    publish("boom.now", function() error("kaboom") end)
    ALERTS, PB = {}, nil
    U.show()
    U.runTool({ keys = "⇪B", service = "boom.now" })
    drain()
    for _, a in ipairs(ALERTS) do
        if a:find("failed", 1, true) then return PB == nil end
    end
    return false
end)())

out("   -- the run map is checked against BOTH tables it joins --\n")
local recorded = {}
_G.notices = { record = function(_, _, c) recorded[#recorded + 1] = tostring(c) end }
U.toolsVerified = false
U.gather()
check("a run-map entry naming a service nothing publishes is REPORTED, "
      .. "not left to be found the day you rely on it",
      #recorded == 1 and recorded[1]:find("url.cleanClipboard", 1, true) ~= nil,
      recorded[1])
check("…and an entry whose KEY no cheat sheet row uses is reported too — "
      .. "checking one side of a join catches half the drift",
      recorded[1]:find("no cheat sheet entry uses that key", 1, true) ~= nil)
check("…once, not on every open", (function()
    U.gather(); return #recorded == 1
end)())
_G.notices = nil

-- =====================================================================
out("3. the page — JSON survives hostile content, rows are BIG\n")
-- =====================================================================
local json = U.rowsJson()
check("a copied </script> cannot end the page's script tag",
      json:find("</script>", 1, true) == nil
      and json:find("<\\/script>", 1, true) ~= nil)
check("quotes are escaped and no raw control character leaks",
      json:find('\\"OCR\\"', 1, true) ~= nil
      and json:find("\n", 1, true) == nil)
check("ids are stable and 1-based",
      json:find('{"id":1,', 1, true) == 2)   -- 2: right after the [

local html = U.buildHtml("@shots ")
check("one search field, autofocused prefill",
      html:find('id="q"', 1, true) ~= nil
      and html:find('PREFILL = "@shots ', 1, true) ~= nil)
check("the rows are the 50%-larger kind — 19px titles, 84px thumbs",
      html:find("font-size:19px", 1, true) ~= nil
      and html:find("height:84px", 1, true) ~= nil)
-- 6.92.0 — the tag list OUTGREW the input box ("I can't read all the
-- tool tips"): the placeholder now teaches the RULE and each section
-- header carries its own tag, where it can never be clipped.
-- 6.298.0 — and it teaches the DOOR as well as the rule. The literal it
-- used to assert ("a @tag pins one source") was the sentence, not the
-- rule (6.248.0): the rule is that the box says how to find the tags
-- without listing them, which is what outgrew it in 6.92.0.
check("the placeholder teaches the @ door, short enough to read whole",
      html:find("type @ to see all", 1, true) ~= nil
      and html:find('placeholder="[^"]*@clip') == nil)
check("...and every section header shows its own tag instead",
      html:find("<span class=\"tag\">@' + esc(SRCS[s].tag)", 1, true) ~= nil)
check("the header advertises drag · copy · path · Esc",
      html:find("drag here", 1, true) ~= nil
      and html:find("⌘⏎ path", 1, true) ~= nil)
check("🎨 6.90.0 — the shared card colors ride in when published, last "
   .. "in the stylesheet so the cascade lets them win", (function()
    _G.uiStyle = { cssOverride = function()
        return "body{background:#171a21;color:rgba(255,255,255,0.97)}"
    end }
    local themed = U.buildHtml("")
    _G.uiStyle = nil
    local at = themed:find("body{background:#171a21", 1, true)
    return at ~= nil and at < themed:find("</style>", 1, true)
           and html:find("#171a21", 1, true) == nil   -- absent when unset
end)())

-- =====================================================================
out("4. the window\n")
-- =====================================================================
check("show() returns true and builds the panel", U.show() == true)
check("the webview can take the keyboard and Esc closes it",
      VIEW.flags.text == true and VIEW.flags.esc == true)
check("floating, on every Space, brought forward",
      VIEW.flags.level == 5 and VIEW.flags.spaces == true
      and VIEW.flags.front == true)
check("the pad's non-activating plumbing was borrowed",
      VIEW.nonActivating == true)
check("toggle closes it", (function()
    U.toggle()
    return U.webview == nil and VIEW.deleted == true
end)())
check("⇪⇧space reopens pre-filtered to screenshots", (function()
    HYPER["shift|space"]()
    return (LAST_HTML or ""):find('PREFILL = "@shots ', 1, true) ~= nil
end)())

-- =====================================================================
out("5. the bridge — pick, path, close, dragStart\n")
-- =====================================================================
U.show()
local function rowWhere(fn)
    for _, r in ipairs(U.rows) do if fn(r) then return r end end
end

local noteRow = rowWhere(function(r) return r.tag == "note" end)
BRIDGE({ body = { a = "pick", id = noteRow.id } })
check("⏎ on a text row copies its FULL text and closes",
      PB == "newest note about receipts" and U.webview == nil
      and (ALERTS[#ALERTS] or ""):find("Copied") ~= nil, PB)

U.show()
local shotRow = rowWhere(function(r) return r.kind == "image" end)
BRIDGE({ body = { a = "pick", id = shotRow.id } })
check("⏎ on a screenshot copies the IMAGE itself",
      CLIPOBJ ~= nil and CLIPOBJ.__path == shotRow.path
      and (ALERTS[#ALERTS] or ""):find("clipboard") ~= nil)

U.show()
BRIDGE({ body = { a = "path", id = shotRow.id } })
check("⌘⏎ copies the file PATH instead (the ⇪⇧4 convention)",
      PB == shotRow.path
      and (ALERTS[#ALERTS] or ""):find("Path copied") ~= nil, PB)

U.show()
local clipRow = rowWhere(function(r) return r.tag == "clip" end)
BRIDGE({ body = { a = "path", id = clipRow.id } })
check("⌘⏎ on a row with no path degrades to the copy",
      PB == clipRow.full)

U.show()
BRIDGE({ body = { a = "close" } })
check("Escape's close message closes", U.webview == nil)

U.show()
BRIDGE({ body = { a = "dragStart" } })
check("the header grab is handed to Window Move by name",
      DRAGGED[#DRAGGED] == "unified search")
BRIDGE({ body = "not-a-table" })
check("a malformed message is shrugged off", U.webview ~= nil)
U.hide()

-- =====================================================================
out("5b. 6.93.0 — the remembered position, and the escape claim\n")
-- =====================================================================
U.pos = nil
U.show()
-- 6.204.0 — the pane is ADDED to the width, so "centred" is measured on
-- the whole window, pane included.
local function panelW() return U.width + (U.pane and U.paneW or 0) end
check("first open is centered", VIEW.rect.x == (1440 - panelW()) / 2)
local entry
for _, e in ipairs(_G.movablePanels or {}) do
    if e.name == "unified search" then entry = e end
end
entry.move(101, 77)
check("dragging writes the remembered position",
      U.pos and U.pos.x == 101 and U.pos.y == 77)
U.hide() ; U.show()
check("🖐 A REMEMBERED POSITION WINS — reopened where dragged",
      VIEW.rect.x == 101 and VIEW.rect.y == 77)
U.hide()
U.pos = { x = 9999, y = 9999 }
U.show()
check("an unplugged screen's memory re-centers instead",
      VIEW.rect.x == (1440 - panelW()) / 2)
-- ---- 6.107.0: and it survives a RELOAD, not just a reopen ------------
-- Same gap the cheat sheet had in 6.106.0: uni is rebuilt every reload,
-- so the position went with it and the box came back centred.
U.hide()
SETTINGS = {}
U.pos = nil
local function drainTimers()
    local queued = TIMERS ; TIMERS = {}
    for _, t in ipairs(queued) do
        if not t.stopped then pcall(t.fn) end
    end
end

entry.move(101, 77)
check("🚨 the write is DEBOUNCED — a drag tick does not touch settings yet",
      SETTINGS["unifiedSearch.pos"] == nil, SETTINGS["unifiedSearch.pos"])
-- The drag layer calls move() from a repeating timer for the whole drag,
-- so saving inline would write tens of times a second for as long as the
-- mouse is down. Only the last one should land.
entry.move(150, 90)
entry.move(202, 120)
drainTimers()
check("...and after you settle, exactly one key holds the LAST position",
      SETTINGS["unifiedSearch.pos"]
      and SETTINGS["unifiedSearch.pos"].x == 202
      and SETTINGS["unifiedSearch.pos"].y == 120
      and next(SETTINGS, next(SETTINGS)) == nil,
      SETTINGS["unifiedSearch.pos"] and SETTINGS["unifiedSearch.pos"].x)

-- A fresh setup() is what a reload is.
local function reload()
    _G.movablePanels = {}
    local M2 = dofile(HS .. "/modules/unified_search.lua")
    M2.setup(CORE)
    return _G.unifiedSearch
end
local R = reload()
check("🚨 a RELOAD picks the position back up",
      R.pos and R.pos.x == 202 and R.pos.y == 120, R.pos and R.pos.x)

-- Validated on the way in: a plist can hand back anything.
for _, j in ipairs({
    { "a string",            "202,120" },
    { "a number",            42 },
    { "no coordinates",      { w = 10 } },
    { "a NaN",               { x = 0/0, y = 10 } },
    { "an infinity",         { x = math.huge, y = 10 } },
    { "coordinates as text", { x = "left", y = "top" } },
}) do
    SETTINGS["unifiedSearch.pos"] = j[2]
    local r = reload()
    check("junk in settings — " .. j[1] .. " — reads as NO position",
          r.pos == nil, r.pos and tostring(r.pos.x))
end

SETTINGS["unifiedSearch.pos"] = { x = "202", y = "120" }
check("numeric strings still count as a position",
      (function() local r = reload() return r.pos and r.pos.x == 202 end)())

SETTINGS["unifiedSearch.pos"] = { x = 202, y = 120 }
local R2 = reload()
_G.unifiedCenter()
check("_G.unifiedCenter() forgets the stored position",
      SETTINGS["unifiedSearch.pos"] == nil and R2.pos == nil)

R2.rememberPos = false
SETTINGS["unifiedSearch.pos"] = nil
R2.savePos({ x = 1, y = 2 })
drainTimers()
check("rememberPos = false stops it being saved",
      SETTINGS["unifiedSearch.pos"] == nil)
check("...and stops it being read", R2.loadPos() == nil)

-- Back to the live module for the rest of the suite.
SETTINGS = {}
U = reload()
U.show()

check("the escape claim is 'unified' and live while open",
      CLAIMS.unified ~= nil and CLAIMS.unified.active() == true)
CLAIMS.unified.handle()
check("…its handle closes the panel — the sheet closes after",
      U.webview == nil and CLAIMS.unified.active() == false)

-- =====================================================================
out("6. a hostile Monday — stores missing, files gone\n")
-- =====================================================================
_G.clipboardCache, _G.screenshots, _G.quickAppend = nil, nil, nil
_G.asanaTaskHistory, _G.capturePad = nil, nil
for p in pairs(FILES) do FILES[p] = nil end
CORE.call = function() return nil end
U.gather()
-- 🧪 6.427.0 — THESE TWO ASSERTED A CONSTANT WHERE THE RULE IS A CLASS
-- (6.248.0, and this is why it keeps happening): "only tool rows" and
-- "zero rows" were true while the cheat sheet was the ONLY source that
-- does not read a store. @report is the second — it is read from _G,
-- which is there whatever the disk is doing — so the numbers moved and
-- the rule did not. Stated as the rule now: a dead disk costs the stores
-- and nothing else.
check("with every SAVED store gone, the sources that do not read a store "
      .. "are still listed — the cheat sheet's tools and the reports",
      (function()
    for _, r in ipairs(U.rows) do
        if r.tag ~= "tool" and r.tag ~= "report" then return false end
    end
    return #U.rows > 0
end)(), #U.rows)
check("…and @report is one of them — it is read from _G, so it survives a "
      .. "disk that answers nothing", (function()
    for _, r in ipairs(U.rows) do if r.tag == "report" then return true end end
    return false
end)())
local savedSheet = _G.cheatSheet
_G.cheatSheet = nil
U.gather()
check("no store and no cheat sheet at all is still not an error — what is "
      .. "left is reports and nothing else", (function()
    for _, r in ipairs(U.rows) do if r.tag ~= "report" then return false end end
    return true
end)(), #U.rows)
check("…and the panel still opens over it", U.show() == true and U.webview ~= nil)
U.hide()
_G.cheatSheet = savedSheet

-- =====================================================================
-- =====================================================================
out("\n7. 🖼 6.187.0 — @images: find the PICTURE by the words inside it\n")
-- =====================================================================
do
    -- Section 6 emptied every store on purpose. Put back ONLY the OCR log
    -- and the files it points at: @images must work with every other store
    -- missing, which is the degrade rule stated as a fixture.
    FILES["/logs/image_text-TestMac.csv"] = OCRCSV
    FILES["/shots/invoice.png"] = "PNG"
    FILES["/shots/Screenshot 1, cropped.png"] = "PNG"
    FILES["/shots/long.png"] = "PNG"
    U.gather()
    byTag = {}
    for _, r in ipairs(U.rows) do
        byTag[r.tag] = byTag[r.tag] or {}
        table.insert(byTag[r.tag], r)
    end
    local img = byTag.images or {}
    check("@images works with every other store gone — it needs only the log",
          #img > 0 and (byTag.clip == nil or #byTag.clip == 0))
    check("@images is a source, so it gets a section of its own and a @tag",
          (function()
              for _, sc in ipairs(U.sources) do if sc.tag == "images" then return true end end
              return false
          end)())
    check("…and it is capped like every other source (an unregistered tag kills the source)",
          type(U.maxPer.images) == "number" and U.maxPer.images > 0)
    check("only the rows that KNOW their image become an image row",
          #img == 4, #img)
    check("the newest reading of an image wins and the older one is not a second card",
          (function()
              local n = 0
              for _, r in ipairs(img) do if r.path == "/shots/invoice.png" then n = n + 1 end end
              return n == 1 and (img[2] and img[2].full) == "a newer reading of the same file", n
          end)())
    check("the row is named by the FILE and carries the words for ⏎",
          (function()
              for _, r in ipairs(img) do
                  if r.path == "/shots/invoice.png" then
                      return r.text == "invoice.png" and r.full == "a newer reading of the same file"
                             and r.kind == "image"
                  end
              end
              return false
          end)())
    check("a path with a comma in it survives — the column is quoted for exactly this",
          (function()
              for _, r in ipairs(img) do
                  if r.text == "Screenshot 1, cropped.png" then
                      return r.full == "Bank statement, March"
                  end
              end
              return false, (img[3] or {}).text
          end)())
    check("an image still on disk gets a thumbnail",
          (function()
              for _, r in ipairs(img) do
                  if r.path == "/shots/invoice.png" then
                      return (r.img or ""):find("THUMB-/shots/invoice.png", 1, true) ~= nil
                  end
              end
              return false
          end)())
    check("an image that has MOVED keeps its words, loses its picture, and SAYS so",
          (function()
              for _, r in ipairs(img) do
                  if r.path == "/shots/gone.png" then
                      return r.img == nil and (r.sub or ""):find("has moved") ~= nil
                             and r.full == "words from a file that has since moved"
                  end
              end
              return false
          end)())
    check("a two-column row from before 6.187.0 is NOT an image row — it never knew one",
          (function()
              for _, r in ipairs(img) do
                  if r.full == "Receipt total 42.50" then return false end
              end
              return true
          end)())
    check("@ocr still lists every reading, images and all — the two sources do not compete",
          #byTag.ocr == 7, #byTag.ocr)

    -- the haystack: this is what makes "find the picture by its words" true
    local json = U.rowsJson()
    check("a word buried deep in an OCR'd page is SEARCHABLE, not just stored",
          json:find("buriedneedle", 1, true) ~= nil)
    check("…and the haystack is bounded, so one enormous entry cannot bloat the page",
          type(U.hayFull) == "number" and U.hayFull > 0
          and (function()
              -- the fixture's long row is longer than the cap only if the cap bites;
              -- prove the cap by a text that exceeds it
              local hay = ("x"):rep(U.hayFull + 500)
              U.rows[#U.rows + 1] = { id = #U.rows + 1, tag = "images", icon = "🖼",
                                      src = "Images", text = "big.png", sub = "", full = hay }
              local j2 = U.rowsJson()
              U.rows[#U.rows] = nil
              return j2:find(("x"):rep(U.hayFull + 1), 1, true) == nil
          end)())

    -- 🖼 A THUMBNAIL IS A MAIN-THREAD DECODE, and on a cloud-evicted file
    -- that decode is a download. So the budget is not a preference, and
    -- these two checks prove it BITES rather than merely being declared.
    local savedMax = U.thumbMax
    U.thumbMax = 1
    U.thumbCache, U.thumbCount = {}, 0
    U.gather()
    local decoded, live = 0, 0
    for _, r in ipairs(U.rows) do
        if r.tag == "images" then
            if r.img then decoded = decoded + 1 end
            if (r.sub or ""):find("has moved") == nil then live = live + 1 end
        end
    end
    check("past the budget an image row is drawn WITHOUT a picture, not decoded anyway",
          decoded == 1 and live > 1, decoded .. " decoded of " .. live .. " still on disk")
    U.thumbMax = savedMax

    local savedCache = U.thumbCacheMax
    U.thumbCacheMax = 2
    U.thumbCache, U.thumbCount = {}, 0
    U.thumbFor({ path = "/shots/invoice.png", mtime = 1 })
    U.thumbFor({ path = "/shots/long.png", mtime = 1 })
    check("the cache fills to its ceiling", U.thumbCount == 2, U.thumbCount)
    U.thumbFor({ path = "/shots/Screenshot 1, cropped.png", mtime = 1 })
    check("…and at the ceiling it is EMPTIED — before 6.187.0 it grew all day",
          U.thumbCount == 1 and U.thumbCache["/shots/invoice.png"] == nil, U.thumbCount)
    U.thumbCacheMax = savedCache
    U.thumbCache, U.thumbCount = {}, 0
    U.gather()

    -- ⌥⏎ OPENS
    local before = #ALERTS
    BRIDGE({ body = { a = "open", id = (function()
        for _, r in ipairs(U.rows) do if r.path == "/shots/invoice.png" then return r.id end end
    end)() } })
    check("⌥⏎ hands the file to /usr/bin/open — never a decode on the main thread",
          OPENED == "/shots/invoice.png" and #ALERTS > before, tostring(OPENED))
    local pbBefore = PB
    local toolId
    for _, r in ipairs(U.rows) do if r.kind == "tool" then toolId = r.id break end end
    if toolId then
        BRIDGE({ body = { a = "open", id = toolId } })
        check("⌥⏎ on a row with no file falls through and does what ⏎ does",
              OPENED == "/shots/invoice.png", tostring(OPENED))
    end

    -- 🔗 THE PROMISE IN THE COMMENT: two modules read this CSV, so the gate
    -- runs BOTH parsers over the same rows and fails if they ever disagree.
    local function lift(file, name)
        local f = realOpen(HS .. "/" .. file)
        local src = f and f:read("a") or ""
        if f then f:close() end
        local body = src:match("(function " .. name .. "%(line%)\n.-\n    end)")
        return body
    end
    local twinA = lift("modules/ocr_engine.lua", "ocr%.parseRow")
    local twinB = lift("modules/unified_search.lua", "uni%.parseOcrRow")
    check("both parsers are still there to compare (a rename must not skip this check)",
          twinA ~= nil and twinB ~= nil)
    if twinA and twinB then
        local function mk(body, holder)
            local env = { core = { splitCSVLine = _G.__split }, csvSplit = _G.__split,
                          tostring = tostring, string = string }
            env[holder] = {}
            local chunk = load("local " .. holder .. " = ... " .. body .. " return " .. holder,
                               "twin", "t", setmetatable(env, { __index = _G }))
            return chunk({})
        end
        _G.__split = (function()
            -- the same splitter both modules are handed, so what is compared
            -- is the WRAPPER logic each one adds — which is where a drift lives
            return function(line)
                local out, i, n = {}, 1, #line
                while i <= n + 1 do
                    if line:sub(i, i) == '"' then
                        local j, buf = i + 1, {}
                        while j <= n do
                            local c = line:sub(j, j)
                            if c == '"' then
                                if line:sub(j + 1, j + 1) == '"' then buf[#buf + 1] = '"'; j = j + 2
                                else break end
                            else buf[#buf + 1] = c; j = j + 1 end
                        end
                        out[#out + 1] = table.concat(buf); i = j + 2
                    else
                        local j = line:find(",", i, true) or (n + 1)
                        out[#out + 1] = line:sub(i, j - 1); i = j + 1
                    end
                end
                return out
            end
        end)()
        local A, B = mk(twinA, "ocr"), mk(twinB, "uni")
        local FIX = {
            '2026-01-01 00:00:00,"plain"',
            '2026-01-01 00:00:00,"plain","/a/b.png"',
            '2026-01-01 00:00:00,"has ""quotes"", and a comma","/a/b,c.png"',
            '2026-01-01 00:00:00,"line one\\nline two"',
            '2026-01-01 00:00:00,"trailing empty",',
            '2026-01-01 00:00:00,unquoted text',
            '',
        }
        local agree, why = true, nil
        for _, line in ipairs(FIX) do
            local a1, a2, a3 = A.parseRow(line)
            local b1, b2, b3 = B.parseOcrRow(line)
            if a1 ~= b1 or a2 ~= b2 or a3 ~= b3 then
                agree, why = false, line .. " → " .. tostring(a2) .. "|" .. tostring(a3)
                              .. "  vs  " .. tostring(b2) .. "|" .. tostring(b3)
                break
            end
        end
        check("the two readers of the OCR log agree on every row shape, old and new", agree, why)
        local ts, text, path = A.parseRow('2026-01-01 00:00:00,"words","/a/b.png"')
        check("…and they really do split off the path (not swallow it into the text)",
              text == "words" and path == "/a/b.png", tostring(text) .. " | " .. tostring(path))
    end
end

-- ⌨️ 6.193.0 — THE ⇪ RELEASE HANDSHAKE, Lua half. Opening a text panel
-- shortens the hyper latch deadline; without it the hold sat the full
-- 8 s and LL's Console showed the watchdog releasing it. Every other
-- text panel has done this since 6.165.1.
do
    local asked = nil
    local realExpect = _G.hyperExpectRelease
    _G.hyperExpectRelease = function(secs, who) asked = { secs = secs, who = who } return true end
    U.hide()
    U.show()
    check("opening the panel shortens the ⇪ hold deadline and NAMES itself",
          type(asked) == "table" and asked.secs == 1.5
          and tostring(asked.who):find("unified", 1, true) ~= nil,
          asked and (tostring(asked.secs) .. " " .. tostring(asked.who)))
    -- 🚨 IT DEGRADES: an older init.lua has no such global, and a panel
    -- that throws on the way up is worse than one that never shortens.
    _G.hyperExpectRelease = nil
    U.hide()
    check("...and a Hammerspoon without that global still opens the panel",
          U.show() == true)
    _G.hyperExpectRelease = realExpect

    -- The page's F18 keyup arrives as a message; it must reach
    -- hyperReleaseSeen and must NOT be mistaken for anything else.
    local seen = nil
    local realSeen = _G.hyperReleaseSeen
    _G.hyperReleaseSeen = function(who) seen = who return true end
    U.handleMessage({ a = "f18up" })
    check("the page's ⇪ keyUp is passed straight to the release, named",
          tostring(seen):find("unified", 1, true) ~= nil, tostring(seen))
    check("...and it does NOT close the panel — a release is not a dismissal",
          U.webview ~= nil)
    _G.hyperReleaseSeen = nil
    local ok = pcall(U.handleMessage, { a = "f18up" })
    check("...and it degrades where that global is missing", ok)
    _G.hyperReleaseSeen = realSeen
    U.hide()
end

-- =====================================================================
out("5c. 👁 6.204.0 — the pointer, and the pane that shows the full entry\n")
-- =====================================================================
-- LL, bug (3) of the three against 6.201.0: "I can only use the arrow
-- keys. There also is no side window that shows the full entry." The
-- pane asks Lua for ONE row's full text and Lua answers through
-- evaluateJavaScript — so what is proven here is the Lua half of that
-- contract: the answer carries the FULL text (not the 240-char line),
-- it is bounded in CHARACTERS and never cut mid-glyph, the panel stays
-- up, nothing is copied, and a window that cannot be written to is
-- COUNTED rather than thrown at. The page half runs in test_unified_js.
do
    local U = _G.unifiedSearch
    -- Sections 6 and 7 emptied the stores on purpose; the pane needs a
    -- long clipboard entry and a screenshot back, and nothing else.
    _G.clipboardCache = {
        { date = "Aug 15 10:00", text = "newest copy — receipt total" },
        { date = "Aug 13 08:00", text = ("long "):rep(200) },   -- 1000 chars
    }
    _G.screenshots = {
        list = function()
            return { { name = "receipt scan.png", path = "/od/shots/receipt scan.png",
                       mtime = 90, size = 50 * 1024 } }
        end,
    }
    check("the pane is on by default, 400 px wide, and shows the chooser "
       .. "pane's 12,000 characters — one number LL already knows",
          U.pane == true and U.paneW == 400 and U.detailMax == 12000)

    -- the window grows BY the pane, so the list keeps its 840
    U.pos = nil
    U.show()
    check("the window is the list's width PLUS the pane's",
          VIEW.rect.w == U.width + U.paneW, VIEW.rect.w)
    local html = U.buildHtml("")
    check("the page carries the pane, told on by PANE, and the list stops "
       .. "where the pane starts",
          html:find('id="pane"', 1, true) ~= nil
          and html:find("var PANE = true;", 1, true) ~= nil
          and html:find("right:" .. U.paneW .. "px;overflow-y:auto}", 1, true) ~= nil)
    check("the header says the pointer works now",
          html:find("hover or ↑↓", 1, true) ~= nil)
    U.hide()

    -- ⏎ copies the FULL text (6.89.0); the pane must show the same thing
    local longRow = rowWhere(function(r)
        return r.tag == "clip" and #(r.full or "") > 240 end)
    check("fixture: a clipboard row longer than the 240-char line exists",
          longRow ~= nil and #longRow.full == 1000)
    U.show()
    local before, pbBefore, alertsBefore = #EVALS, PB, #ALERTS
    BRIDGE({ body = { a = "detail", id = longRow.id } })
    local js = EVALS[#EVALS] or ""
    check("🔑 a 'detail' ask is answered with uniDetail(id, …) pushed INTO the page",
          #EVALS == before + 1 and js:find("^uniDetail%(" .. longRow.id .. ",") ~= nil,
          js:sub(1, 60))
    check("🔑 …carrying the FULL 1,000-character entry, not the 240-char line",
          js:find(longRow.full, 1, true) ~= nil, #js)
    check("…with the total character count and 0 for 'nothing cut'",
          js:find(",\"\",1000,0)", 1, true) ~= nil, js:sub(-30))
    check("🚨 a detail ask is a READ: the panel stays up, nothing is copied, "
       .. "nothing is alerted",
          U.webview ~= nil and PB == pbBefore and #ALERTS == alertsBefore)
    check("…and it is counted: asked, drawn, and the last row named",
          U.detailAsked >= 1 and U.detailDrawn >= 1 and U.detailLast == longRow.id)

    -- the bound is in CHARACTERS, and the cut is said
    local saveMax = U.detailMax
    U.detailMax = 10
    BRIDGE({ body = { a = "detail", id = longRow.id } })
    js = EVALS[#EVALS] or ""
    check("🔑 past detailMax the answer is cut, the TOTAL still says 1000, "
       .. "and the fifth value is the 10 characters SHOWN — counted by Lua, "
       .. "so the pane's 'first N shown' is in the same unit as the cut",
          js:find("uniDetail(" .. longRow.id .. ",\"long long \",\"\",1000,10)", 1, true) ~= nil,
          js)
    U.detailMax = saveMax

    -- never mid-glyph: 20 × "é" (2 bytes each) cut to 5 CHARACTERS is 5
    -- glyphs, 10 bytes — a byte cut at 5 would leave half an "é" and a
    -- string WebKit refuses to receive at all
    local shown, total, cut = U.detailCut(("é"):rep(20), 5)
    check("🔑 the cut counts CHARACTERS, not bytes — 20 é cut to 5 is 5 é",
          shown == ("é"):rep(5) and total == 20 and cut == true,
          tostring(#shown) .. " bytes, total " .. tostring(total))
    -- and the count the page is HANDED is characters too: 8 × 🙂 (4 bytes
    -- each, two UTF-16 units each) cut to 5 must say 5, not 10, not 20
    do
        local emojiRow = { id = 4242, full = ("🙂"):rep(8), text = "x" }
        U.detailMax = 5
        U.answerDetail(emojiRow)          -- the panel is still up from above
        local ej = EVALS[#EVALS] or ""
        check("🔑 an emoji entry says 'first 5 shown' of 8 — characters, never "
           .. "UTF-16 units (10) or bytes (20)",
              ej:sub(-5) == ",8,5)" and ej:find(("🙂"):rep(5) .. '"', 1, true) ~= nil
              and ej:find(("🙂"):rep(6), 1, true) == nil, ej)
        U.detailMax = saveMax
    end
    shown, total, cut = U.detailCut("abc", 5)
    check("…a short entry comes back whole, uncut, with its own count",
          shown == "abc" and total == 3 and cut == false)
    shown, total, cut = U.detailCut("\xff\xfe" .. ("a"):rep(20), 5)
    check("…and a store that is not valid UTF-8 still answers (bytes, cut) "
       .. "rather than erroring the pane shut",
          type(shown) == "string" and #shown == 5 and total == 22 and cut == true,
          tostring(#shown) .. "/" .. tostring(total))

    -- a screenshot row answers with its PATH in the third slot
    local shot = rowWhere(function(r) return r.kind == "image" end)
    BRIDGE({ body = { a = "detail", id = shot.id } })
    js = EVALS[#EVALS] or ""
    check("an image row's answer names its path, so the pane can show it",
          js:find(shot.path, 1, true) ~= nil, js:sub(1, 120))

    -- an unknown id is nothing, not a crash and not a count
    local asked = U.detailAsked
    BRIDGE({ body = { a = "detail", id = 999999 } })
    check("a detail ask for a row that does not exist is ignored, uncounted",
          U.detailAsked == asked and U.webview ~= nil)

    -- 🚨 REFUSED IS A STATE. A webview that cannot be written to (this
    -- Hammerspoon lacks evaluateJavaScript), or a window gone before Lua
    -- replied, must not throw inside the bridge callback — the page keeps
    -- the preview it drew itself, and the report says how often.
    local refused = U.detailRefused
    local realEval = VIEW.evaluateJavaScript
    VIEW.evaluateJavaScript = nil
    local okCall = pcall(BRIDGE, { body = { a = "detail", id = longRow.id } })
    check("🚨 no evaluateJavaScript on this webview: no throw, counted as refused, "
       .. "panel still up",
          okCall and U.detailRefused == refused + 1 and U.webview ~= nil)
    VIEW.evaluateJavaScript = function(self, s) error("webview gone") end
    okCall = pcall(BRIDGE, { body = { a = "detail", id = longRow.id } })
    check("…a webview that THROWS on the push is refused the same way",
          okCall and U.detailRefused == refused + 2)
    VIEW.evaluateJavaScript = realEval
    U.hide()
    okCall = pcall(U.answerDetail, longRow)
    check("…and with the window already gone the answer is refused, not thrown",
          okCall and U.detailRefused == refused + 3)

    -- 🔎 THE REPORT — "never asked" and "0 drawn" must not read the same
    -- (6.196.1's rule): the first is a panel nobody has hovered, the
    -- second is a pane that asked and got nothing back.
    local function reportText()
        local said = {}
        local realPrint = print
        print = function(...) said[#said + 1] = table.concat({ ... }, "\t") end
        _G.unifiedSearchReport()
        print = realPrint
        return table.concat(said, "\n"), #said
    end
    local sA, sD, sR, sL = U.detailAsked, U.detailDrawn, U.detailRefused, U.detailLast
    U.detailAsked, U.detailDrawn, U.detailRefused, U.detailLast = 0, 0, 0, nil
    local rep, calls = reportText()
    check("the report has a pane line, still printed as ONE string",
          calls == 1 and rep:find("pane   : on", 1, true) ~= nil, rep)
    check("🔑 a pane nobody has hovered says 'never asked' — and NOT '0 drawn'",
          rep:find("never asked", 1, true) ~= nil
          and rep:find("0 drawn", 1, true) == nil, rep)
    U.detailAsked, U.detailDrawn, U.detailRefused, U.detailLast = 3, 0, 3, nil
    rep = reportText()
    check("🔑 a pane that asked and got nothing says so in numbers, with the ↳ "
       .. "line naming what a refusal is — and never 'never asked'",
          rep:find("3 asked", 1, true) and rep:find("0 drawn", 1, true)
          and rep:find("3 refused", 1, true)
          and rep:find("refused answer is the window gone", 1, true)
          and rep:find("never asked", 1, true) == nil, rep)
    U.detailAsked, U.detailDrawn, U.detailRefused, U.detailLast = 2, 2, 0, longRow.id
    rep = reportText()
    check("…a healthy pane names the last row it drew, by id and store",
          rep:find("last row " .. longRow.id .. " (📋 Clipboard)", 1, true) ~= nil
          and rep:find("↳ a refused", 1, true) == nil, rep)
    U.detailAsked, U.detailDrawn, U.detailRefused, U.detailLast = sA, sD, sR, sL

    -- 🔕 the rollback: settings = { unified_search = { pane = false } }
    U.pane = false
    U.pos = nil
    U.show()
    check("pane = false: the window is the list's width alone, as before 6.204.0",
          VIEW.rect.w == U.width, VIEW.rect.w)
    html = U.buildHtml("")
    check("…the page has no pane element, PANE is false, the list spans the width",
          html:find('id="pane"', 1, true) == nil
          and html:find("var PANE = false;", 1, true) ~= nil
          and html:find("right:0px;overflow-y:auto}", 1, true) ~= nil)
    rep = reportText()
    check("…and the report says off, with the line that brings it back",
          rep:find("pane   : off", 1, true) ~= nil
          and rep:find("pane = true", 1, true) ~= nil, rep)
    U.hide()
    U.pane = true

    -- the cheat sheet teaches both halves
    local sheet = ""
    for _, e in ipairs(M.cheatsheet.entries) do sheet = sheet .. e[1] .. " " .. e[2] .. "\n" end
    check("the cheat sheet names the hover and the pane, and the rollback line",
          sheet:find("hover", 1, true) and sheet:find("pane", 1, true)
          and sheet:find("pane = false", 1, true), sheet)

    -- 🔒 ASSERTED AGAINST THE SOURCE: the detail path reads and nothing
    -- else — no hide, no clipboard, no alert — and the page's hover
    -- handler rebuilds without scrolling (render() scrolls the highlight
    -- into view; under a pointer that would move a different row under it).
    local f = realOpen(HS .. "/modules/unified_search.lua", "r")
    local src = f and f:read("*a") or ""
    if f then f:close() end
    local body = src:match("function uni%.answerDetail%(row%)(.-)\n    end")
    check("source: answerDetail never hides, copies or alerts",
          body and not body:find("hide(", 1, true)
          and not body:find("setContents", 1, true)
          and not body:find("alert", 1, true), body and #body)
    local hover = src:match("list%.addEventListener%('mousemove'(.-)\n}%);")
    check("source: the hover handler rebuilds and never render()s — no "
       .. "scrollIntoView under the pointer",
          hover and hover:find("rebuild()", 1, true)
          and not hover:find("render()", 1, true), hover)
end

-- ---- 🔎 THE REPORT (6.196.1) ------------------------------------
-- ⇪space was the one tool in this config with no _G.<tool>Report(),
-- which is why "2372 items indexed — does this seem right?" had no
-- answer. The check that matters is NOT that it prints: it is that an
-- empty store and a BROKEN one read differently. Before this they were
-- the same absence inside a total that still looked large.
do
    local U = M.unified or _G.unifiedSearch
    check("🔎 _G.unifiedSearchReport() exists at all",
          type(_G.unifiedSearchReport) == "function")

    local said = {}
    local realPrint = print
    print = function(...) said[#said + 1] = table.concat({ ... }, "\t") end

    U.counts = { clip = 7 }
    U.failed = { ocr = "the log could not be read" }
    U.rows   = { {}, {}, {}, {}, {}, {}, {} }
    U.lastGather = os.time()
    _G.unifiedSearchReport()
    print = realPrint

    check("🚨 the report prints as ONE string — 6.179.1, the console gate "
          .. "swallows a report printed row by row",
          #said == 1, #said .. " print call(s)")
    local out = said[1] or ""
    check("...it names a store that HAS rows, with its count",
          out:find("@clip", 1, true) and out:find("7", 1, true))
    check("🚨 ...and a FAILED store says FAILED and carries the reason — a "
          .. "broken source that read as '0' is a store that has been "
          .. "quietly missing from every search",
          out:find("FAILED", 1, true)
          and out:find("could not be read", 1, true), out)
    check("🚨 ...and it is NOT the same text as an untouched store, which "
          .. "reads as empty",
          out:find("nothing in this store yet", 1, true), out)
    check("...the summary counts the failure separately from the empties",
          out:find("1 FAILED", 1, true), out)
    -- Counted as ROWS, not as occurrences of the word: the summary and the
    -- advisory footer both say FAILED, and a word count would have passed
    -- even if every store had been marked broken.
    local failRows = 0
    for line in out:gmatch("[^\n]+") do
        if line:find("@%w+%s+FAILED") then failRows = failRows + 1 end
    end
    check("...and exactly ONE store row is marked failed — the others are "
          .. "empty, which is a different thing and must stay one",
          failRows == 1, failRows .. " rows marked FAILED")

    -- gather() must RECORD a failure, not only print one: a line that has
    -- scrolled away cannot be reported on an hour later.
    check("🔎 gather() clears and records failures rather than only printing",
          type(U.gather) == "function")
    U.failed, U.counts, U.lastGather = nil, nil, nil
    local ok = pcall(_G.unifiedSearchReport)
    check("...and the report degrades where nothing has been gathered yet",
          ok)
end

-- =====================================================================
-- 🔎 6.298.0 — THE @ SEARCHES NAME THEMSELVES
-- =====================================================================
-- LL: "All @ searches should be listed so I know what I can use to
-- search." The page draws the directory (test_unified_js.js drives it);
-- what Lua owes is the DATA — every source able to say what it holds,
-- and the count in the placeholder coming off the table rather than
-- being typed in beside it.
do
    -- §6 above deliberately leaves the module with nothing gathered, so
    -- gather again: this section is about real sources and real counts.
    pcall(U.gather)
    -- 🔒 EVERY source, not most of them: a source with no `what` draws a
    -- row in the directory with nothing after its label, which is the
    -- one thing this release exists to stop.
    local missing = {}
    for _, src in ipairs(U.sources) do
        if type(src.what) ~= "string" or #src.what < 8 then
            missing[#missing + 1] = tostring(src.tag)
        end
    end
    check("every source says what it HOLDS — the directory can explain all "
          .. #U.sources, #missing == 0, table.concat(missing, ", "))

    -- ...and it reaches the page. A `what` nothing publishes is a
    -- comment (6.269.0: rows under the wrong key drew an empty card for
    -- eighty-nine releases).
    local js = U.sourcesJson()
    local withW = 0
    for _ in js:gmatch('"w":"') do withW = withW + 1 end
    check("...and every one of them rides into the page as `w`",
          withW == #U.sources, withW .. " of " .. #U.sources)

    -- 6.239.0 — MOVE THE CONFIG AND REQUIRE THE DRAWING TO FOLLOW.
    -- Asserting "14" passes just as happily when the number is typed
    -- into the placeholder by hand, which is exactly how a count printed
    -- to a human goes stale.
    local before = U.buildHtml("")
    check("the placeholder counts the sources it really has",
          before:find("type @ to see all " .. #U.sources .. " sources", 1, true) ~= nil,
          (before:match("type @ to see all %d+ sources")))
    U.sources[#U.sources + 1] = { tag = "zztest", icon = "🧪",
                                  label = "Test", what = "a fixture source",
                                  fn = function() end }
    local after = U.buildHtml("")
    check("...and a source added to the table moves it",
          after:find("type @ to see all " .. #U.sources .. " sources", 1, true) ~= nil
          and after:find('"tag":"zztest"', 1, true) ~= nil,
          (after:match("type @ to see all %d+ sources")))
    U.sources[#U.sources] = nil

    -- ...and it must not RAISE before the first gather, because the
    -- page can be built then (6.282.0: an instrument that throws is
    -- worse than one that lies — there is no line left to read).
    local saveC, saveR = U.counts, U.rows
    U.counts, U.rows = nil, {}
    local okJson = pcall(U.sourcesJson)
    U.counts, U.rows = saveC, saveR
    check("...and it answers rather than throwing before the first gather",
          okJson)

    -- 6.181.0 — the sheet is where he goes to find out what a tool can
    -- do, so a door that is not on it is a door he cannot find.
    local said = false
    for _, row in ipairs((M.cheatsheet and M.cheatsheet.entries) or {}) do
        if tostring(row[1]) == "@" and tostring(row[2]):find("every source is listed", 1, true) then
            said = true
        end
    end
    check("📋 the ⇪/ card names the @ door", said)
end

-- =======================================================================
io.write("\n6.325.0 — 📋 \"COPIED\" IS SAID ONLY IF IT HAPPENED\n")
-- =======================================================================
-- hs.pasteboard.setContents REFUSES BY RETURNING FALSE and never throws,
-- so `pcall(function() setContents(x) end)` is true either way. This
-- panel announced "📋 Copied" under exactly that shape: on a Mac where
-- macOS refuses the write he is told his text was copied, presses ⌘V,
-- and gets whatever was there before (6.198.0).
do
    local before = pass + fail
    U.show()
    if U.gather then pcall(U.gather) end
    -- 🚨 DELIBERATELY NOT A CLIPBOARD ROW. 6.402.0 made ⏎ on one of those
    -- PASTE rather than announce a copy, so this section — which is about
    -- "a refused write is never announced as a copy" — would otherwise be
    -- asserting a sentence that is false by design (6.248.0, and the
    -- refusal rule it exists for is unchanged on both paths).
    local row
    for _, r in ipairs(U.rows or {}) do
        if (r.full or r.text) and (r.full or r.text) ~= ""
           and r.kind ~= "image" and r.tag ~= "clip" then
            row = r break
        end
    end
    check("🧪 the section has a NON-clipboard row with text to copy "
          .. "(without one it proves nothing)", row ~= nil, #(U.rows or {}))
    if not row then row = { id = "none", full = "" } end

    PB, ALERTS = nil, {}
    BRIDGE({ body = { a = "pick", id = row.id } })
    check("📋 a write macOS TAKES is announced, as ever",
          PB == row.full and (ALERTS[#ALERTS] or ""):find("Copied", 1, true) ~= nil,
          tostring(PB))

    -- 🚨 and the refusal is the whole release
    U.show()
    PB, ALERTS = nil, {}
    _G.COPY_REFUSES = true
    BRIDGE({ body = { a = "pick", id = row.id } })
    _G.COPY_REFUSES = false
    check("🚨 a write macOS REFUSES is NOT announced as a copy — the "
          .. "sentence is conditional on the thing it describes",
          (ALERTS[#ALERTS] or ""):find("Copied", 1, true) == nil,
          ALERTS[#ALERTS] or "(no alert)")
    check("…and nothing reached the clipboard", PB == nil, tostring(PB))

    -- 🔒 THE CLASS, NOT THE INSTANCE
    local src = (function()
        local f = REAL_OPEN(HS .. "/modules/unified_search.lua", "r")
        local t = f and f:read("*a") or "" ; if f then f:close() end
        return t
    end)()
    check("🔒 SOURCE: the sentry read something", #src > 1000, #src)
    local code = src:gsub("[^\n]*", function(l)
        return l:match("^%s*%-%-") and "" or l
    end)
    check("🔒 SOURCE: nothing here calls hs.pasteboard.setContents any more "
          .. "— every text copy goes through core.copyText, which READS "
          .. "the answer",
          code:find("hs%.pasteboard%.setContents") == nil)
    check("…and the comment explaining the rule survives, so the sentry "
          .. "cannot be satisfied by deleting the reason (6.280.0)",
          src:find("refuses by RETURNING FALSE", 1, true) ~= nil)

    local ran = (pass + fail) - before
    check("§6.325.0 ran all of its checks (" .. ran .. " of 7)", ran >= 7, ran)
end


-- =====================================================================
-- =====================================================================
out("\n=== 9. 📋 6.402.0 — ⏎ ON A CLIPBOARD ROW PASTES IT ===\n")
-- =====================================================================
-- LL: "First result from history clipboard list is not pasted when
-- selected and it should be."
--
-- 🔎 AND THE FIRST ROW IS WHY IT READ AS BROKEN RATHER THAN MISSING. ⏎
-- has always COPIED, and the first row of the clipboard history IS
-- whatever is already on the clipboard — so ⏎ there wrote back what was
-- already there, pasted nothing, and changed nothing observable. Every
-- other row at least leaves ⌘V carrying something new; row one does
-- not, so the one row he would try first is the one that looks dead.
do
    local before = pass + fail
    local BORROWS, RETURNS = {}, {}
    local realBorrow, realReturn, realInject =
        _G.focusBorrow, _G.focusReturn, _G.withInjection
    local RETURN_ANSWER = true
    _G.focusBorrow = function(who) BORROWS[#BORROWS + 1] = who return true end
    _G.focusReturn = function(who) RETURNS[#RETURNS + 1] = who return RETURN_ANSWER end
    local INJECTED = 0
    _G.withInjection = function(fn) INJECTED = INJECTED + 1 return pcall(fn) end

    local function clipRow()
        U.show()
        if U.gather then pcall(U.gather) end
        for _, r in ipairs(U.rows or {}) do
            if r.tag == "clip" and (r.full or r.text) and (r.full or r.text) ~= "" then
                return r
            end
        end
    end
    local row = clipRow()
    check("🧪 the section has a clipboard row (without one it proves nothing)",
          row ~= nil, #(U.rows or {}))
    if not row then row = { id = "none", full = "", tag = "clip" } end

    -- 1. the happy path: copied, panel closed, focus back, ⌘V posted
    U.show()
    PB, ALERTS, KEYS, RETURNS, INJECTED = nil, {}, {}, {}, 0
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    RETURN_ANSWER = true
    BRIDGE({ body = { a = "pick", id = row.id } })
    check("📋 the row reaches the clipboard first — whatever happens next, "
          .. "⌘V carries it (6.325.0's door answers for the write)",
          PB == row.full, tostring(PB))
    check("📋 the panel is CLOSED before anything is posted — a ⌘V that "
          .. "arrives while this window has the keyboard goes nowhere",
          U.webview == nil)
    check("🎯 ...and the focus is handed back to the app he came from",
          #RETURNS == 1 and RETURNS[1] == "⇪D",
          #RETURNS .. " · " .. tostring(RETURNS[1]))
    check("📋 nothing is posted on THIS turn — macOS activates an app on "
          .. "its own turn, so a ⌘V on this line beats the app to the front",
          #KEYS == 0, #KEYS)
    drain()
    check("📋 a turn later the ⌘V is posted",
          #KEYS == 1 and KEYS[1] == "cmd+v", table.concat(KEYS, ","))
    check("🚨 ...THROUGH the shared injection guard, or our own taps read "
          .. "it as him typing and autocorrect reads the pasted text "
          .. "(6.218.0)", INJECTED == 1, INJECTED)
    check("📋 and it is counted as POSTED, never as pasted — nothing here "
          .. "can see where the keystroke landed (6.299.0)",
          U.pastes.posted == 1 and U.pastes.copiedOnly == 0,
          U.pastes.posted .. " posted · " .. U.pastes.copiedOnly .. " copied only")

    -- 2. 🚨 THE GUARD: the focus did NOT come back, so NOTHING is posted.
    U.show()
    PB, ALERTS, KEYS, RETURNS, INJECTED = nil, {}, {}, {}, 0
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    RETURN_ANSWER = false
    BRIDGE({ body = { a = "pick", id = row.id } })
    drain()
    check("🚨 with the focus NOT back, no ⌘V is posted at all — a blind one "
          .. "lands in whatever he moved to, which is worse than leaving "
          .. "the text on the clipboard",
          #KEYS == 0 and U.pastes.posted == 0, #KEYS)
    check("🚨 ...the text is still on the clipboard, so nothing is lost",
          PB == row.full, tostring(PB))
    check("🔎 ...and he is TOLD, with the way to use it — silence here is "
          .. "a key that looks dead, which is the bug being fixed",
          (ALERTS[#ALERTS] or ""):find("⌘V pastes it", 1, true) ~= nil,
          ALERTS[#ALERTS] or "(no alert)")
    check("🔎 ...and it is counted apart from a posted paste (6.196.1)",
          U.pastes.copiedOnly == 1, U.pastes.copiedOnly)

    -- 3. a refused clipboard write never claims a paste
    U.show()
    PB, ALERTS, KEYS = nil, {}, {}
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    RETURN_ANSWER = true
    _G.COPY_REFUSES = true
    BRIDGE({ body = { a = "pick", id = row.id } })
    _G.COPY_REFUSES = false
    drain()
    check("🚨 a clipboard write macOS REFUSES posts no ⌘V and claims "
          .. "nothing — there is nothing on the clipboard to paste",
          #KEYS == 0 and PB == nil and U.pastes.posted == 0,
          #KEYS .. " key(s) · " .. tostring(PB))

    -- 4. a macOS that refuses the keystroke itself
    U.show()
    PB, ALERTS, KEYS = nil, {}, {}
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    RETURN_ANSWER = true
    _G.KEYSTROKE_REFUSES = true
    BRIDGE({ body = { a = "pick", id = row.id } })
    drain()
    _G.KEYSTROKE_REFUSES = false
    check("🔑 a ⌘V macOS REFUSES is counted as clipboard-only and SAID — "
          .. "not announced as a paste that happened (6.265.0)",
          U.pastes.posted == 0 and U.pastes.copiedOnly == 1
          and (ALERTS[#ALERTS] or ""):find("⌘V pastes it", 1, true) ~= nil,
          U.pastes.posted .. "/" .. U.pastes.copiedOnly)

    -- 5. the switch is real in both directions
    U.show()
    PB, ALERTS, KEYS = nil, {}, {}
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    U.pasteOnPick = false
    BRIDGE({ body = { a = "pick", id = row.id } })
    drain()
    check("🔌 pasteOnPick = false copies and announces it, exactly as "
          .. "before 6.402.0, and posts nothing",
          #KEYS == 0 and PB == row.full
          and (ALERTS[#ALERTS] or ""):find("Copied", 1, true) ~= nil,
          ALERTS[#ALERTS] or "(no alert)")
    U.pasteOnPick = true

    -- 6. 🚨 EVERY OTHER SOURCE STILL COPIES. Pasting a file path or a
    --    shortcut's keys into whatever he was typing in is not what ⏎
    --    means there, and this is the check that keeps the change narrow.
    U.show()
    if U.gather then pcall(U.gather) end
    local other
    for _, r in ipairs(U.rows or {}) do
        if r.tag ~= "clip" and (r.full or r.text) and (r.full or r.text) ~= ""
           and r.kind ~= "image" and not r.service then other = r break end
    end
    if other then
        PB, ALERTS, KEYS = nil, {}, {}
        BRIDGE({ body = { a = "pick", id = other.id } })
        drain()
        check("🚨 a NON-clipboard row still only COPIES — no ⌘V is posted "
              .. "into the app he was in",
              #KEYS == 0 and (ALERTS[#ALERTS] or ""):find("Copied", 1, true) ~= nil,
              ALERTS[#ALERTS] or "(no alert)")
    else
        check("🧪 a non-clipboard row was available to prove the change "
              .. "stays narrow", false, "none found")
    end

    -- 7. opening the panel BORROWS the focus, so closing can give it back
    BORROWS = {}
    U.show()
    check("🎯 opening the panel borrows the focus, naming itself",
          #BORROWS == 1 and BORROWS[1] == "⇪D",
          #BORROWS .. " · " .. tostring(BORROWS[1]))
    RETURNS = {}
    U.hide()
    check("🎯 ...and an ordinary close gives it back, so Esc puts him back "
          .. "where he was too", #RETURNS == 1 and RETURNS[1] == "⇪D",
          #RETURNS)
    RETURNS = {}
    U.show()
    check("🚨 ...but show's own close does NOT, because it is about to take "
          .. "the keyboard again and the first loan names his app",
          #RETURNS == 0, #RETURNS)

    -- 8. the report's three states
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    printed = {}
    _G.unifiedSearchReport()
    check("🔎 the report says nothing has been picked rather than printing "
          .. "a row of zeros",
          (printed[1] or ""):find("no clipboard row has been picked", 1, true) ~= nil,
          printed[1])
    U.pastes = { asked = 2, posted = 1, copiedOnly = 1,
                 last = { ok = false, src = "Clipboard", why = "a reason" } }
    printed = {}
    _G.unifiedSearchReport()
    check("🔎 ...and names the clipboard-only picks as NOT a failure, "
          .. "because the text is on the clipboard either way",
          (printed[1] or ""):find("NOT A FAILURE", 1, true) ~= nil
          and (printed[1] or ""):find("1 ⌘V posted", 1, true) ~= nil,
          printed[1])

    -- 9. 🪜 THE TIMER IS HELD IN ITS OWN NAMED SLOT, and a second pick
    --    stops the first. The sweep found both halves: an unreferenced
    --    hs.timer is collected and never fires, so the ASSIGNMENT is the
    --    mechanism (6.196.1) — and no functional test can see that,
    --    because the suite's timer table holds every timer whether the
    --    module does or not (6.290.0). So the slot is asserted against
    --    the SOURCE, exactly as the Secure Input task slots are, and the
    --    re-arm is driven for real.
    local usrc = (function()
        local f = REAL_OPEN(HS .. "/modules/unified_search.lua", "r")
        local t = f and f:read("*a") or "" ; if f then f:close() end
        return t
    end)()
    check("🪜 SOURCE: the settle timer is held in its own named slot — an "
          .. "unreferenced hs.timer is collected and never fires, so the "
          .. "paste would simply never happen (6.196.1)",
          usrc:find("uni.pasteTimer = hs.timer.doAfter", 1, true) ~= nil)
    check("🪜 SOURCE: ...and the slot is cleared inside the callback, so a "
          .. "spent timer is not mistaken for one still in flight",
          usrc:find("uni.pasteTimer = nil", 1, true) ~= nil)

    U.show()
    PB, ALERTS, KEYS = nil, {}, {}
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    RETURN_ANSWER = true
    BRIDGE({ body = { a = "pick", id = row.id } })   -- arms one
    U.show()
    BRIDGE({ body = { a = "pick", id = row.id } })   -- must stop the first
    drain()
    check("🪜 two picks in a row post ONE ⌘V, not two — the second arms "
          .. "into the same slot and stops what was there",
          #KEYS == 1 and U.pastes.posted == 1,
          #KEYS .. " key(s) · " .. U.pastes.posted .. " posted")

    _G.focusBorrow, _G.focusReturn, _G.withInjection =
        realBorrow, realReturn, realInject
    U.pastes = { asked = 0, posted = 0, copiedOnly = 0, last = nil }
    local ran = (pass + fail) - before
    check("📋 the 6.402.0 section ran all of its checks", ran >= 24, ran)
end

out("\n8. 📓 6.383.0 — @logs: every tool that has failed, searchable\n")
-- =====================================================================
-- LL: "I don't have at @ search for Logs." He was right. 6.279.0 built
-- the ledger and named this gap in the same breath — "the log is not yet
-- a ⇪D source. One uni.sources row, its own release" — and then it sat
-- there for a hundred releases.
do
    local before = pass + fail

    check("@logs is a source, so it has a section, a @tag and a directory row",
          (function()
              for _, sc in ipairs(U.sources) do
                  if sc.tag == "logs" then
                      return type(sc.what) == "string" and #sc.what > 10
                  end
              end
              return false
          end)())

    -- a ledger with two failures in it, written the way notices writes
    local LOGCSV = table.concat({
        '"2026-10-29","08:14:02",1790000042,"Hamsidian save","the note Budget was NOT written"',
        '"2026-10-29","09:02:11",1790003731,"OneDrive watch","no folder to watch"',
    }, "\n") .. "\n"

    _G.notices = {
        logPath = "/logs/degrades-TestMac.csv",
        logTail = 64 * 1024,
        logRows = function(opts)
            local rows = {}
            for line in LOGCSV:gmatch("[^\n]+") do
                local d, clock, at, rest = line:match('^"([^"]*)","([^"]*)",(%d+),(.*)$')
                if d then
                    local tool, why = rest:match('^"(.-)",?"?(.*)"?$')
                    rows[#rows + 1] = { date = d, clock = clock, at = tonumber(at),
                                        tool = tool, why = (why or ""):gsub('"$', "") }
                end
            end
            local out = {}
            for i = #rows, 1, -1 do out[#out + 1] = rows[i] end
            return out
        end,
    }
    U.gather()
    local logs = {}
    for _, r in ipairs(U.rows) do if r.tag == "logs" then logs[#logs + 1] = r end end
    check("every failure in the ledger becomes a row", #logs == 2, #logs)
    check("…newest first, the way every other store here reads",
          (logs[1].text or ""):find("OneDrive watch", 1, true) ~= nil,
          logs[1] and logs[1].text)
    check("…and a row carries the TOOL and macOS's own words, so it is searchable",
          (logs[2].text or ""):find("Hamsidian save", 1, true) ~= nil
          and (logs[2].text or ""):find("NOT written", 1, true) ~= nil,
          logs[2] and logs[2].text)
    check("…with the day and the clock beside it",
          (logs[2].sub or ""):find("2026%-10%-29") ~= nil
          and (logs[2].sub or ""):find("08:14:02", 1, true) ~= nil, logs[2].sub)

    -- 🚨 THE ONE THAT MATTERS MOST, and it is the fixture where a lazier
    -- build and this one must differ: a log that could NOT be read must
    -- not arrive as an empty store. "nothing has failed" is the most
    -- reassuring line this config can print and would be a lie on
    -- exactly the day the disk is full (6.196.1 · 6.279.0).
    _G.notices.logRows = function() return nil, "the log is there and could not be read" end
    U.gather()
    local bad = {}
    for _, r in ipairs(U.rows) do if r.tag == "logs" then bad[#bad + 1] = r end end
    -- 🚨 A HELPER THAT ANSWERS FALSELY, NEVER ONE THAT INDEXES A NIL
    -- (6.186.0). The mutation that drops this row leaves `bad` empty, and
    -- `bad[1].text` then ENDS THE RUN with "0 failed" never printed —
    -- which in a gate that reads the tail looks exactly like a pass. It
    -- DID, on the first sweep of this release.
    local function badField(i, k)
        local r = bad[i]
        return (type(r) == "table" and tostring(r[k] or "")) or ""
    end
    check("🚨 an UNREADABLE log is a row, not an empty store",
          #bad == 1 and badField(1, "text"):find("could not be read", 1, true) ~= nil,
          #bad .. " / " .. badField(1, "text"))
    check("…and it says so in as many words, rather than reading as 'all clear'",
          badField(1, "sub"):find("NOT", 1, true) ~= nil, badField(1, "sub"))

    -- a Mac where notices never loaded: no rows, no crash, no claim
    _G.notices = nil
    U.gather()
    local none = 0
    for _, r in ipairs(U.rows) do if r.tag == "logs" then none = none + 1 end end
    check("no ledger at all → no rows and nothing thrown (it degrades)", none == 0, none)

    -- 🔁 ONE PARSER. A second copy of the CSV parsing in this module is
    -- how two readers over one file drift; the gate asserts the module
    -- asks for the rows rather than parsing them itself.
    -- 🔌 realOpen — io.open is a virtual disk in this suite, so the plain
    -- one reads NOTHING and the sentry is green over an empty haystack
    -- (6.313.0). The size is asserted for the same reason.
    local SRC = realOpen(HS .. "/modules/unified_search.lua", "r")
    local TXT = SRC and SRC:read("*a") or ""
    if SRC then SRC:close() end
    check("the sentry below really read the module", #TXT > 40000, #TXT)
    -- 🚨 THE WINDOW ENDS AT THE FUNCTION'S OWN BOUNDARY (6.263.0). The
    -- first version searched the WHOLE file for "logs" followed by
    -- "gmatch", which spans half the module and matches a neighbour —
    -- it went red on correct code. The body is cut out first.
    local body = TXT:match("local function srcLogs%(add%).-\n    local function ") or ""
    check("the srcLogs body was found to read", #body > 400, #body)
    check("@logs asks notices for the rows and parses no CSV of its own",
          body:find("logRows", 1, true) ~= nil
          and body:find("gmatch", 1, true) == nil,
          tostring(body:match("[^\n]*gmatch[^\n]*")))

    local ran = (pass + fail) - before
    check("§8 ran all of its checks (" .. ran .. " of 11)", ran >= 11, ran)
end

-- =====================================================================
out("\n9. 📋 6.427.0 — @report: every report, what it answers, and ⏎ runs it\n")
-- =====================================================================
do
    local n9 = pass + fail
    -- the source is listed with the rest, and says what it holds
    local src9
    for _, so in ipairs(U.sources) do if so.tag == "report" then src9 = so end end
    check("§9 @report is a source, with a sentence of its own (6.298.0)",
          src9 ~= nil and type(src9.what) == "string" and #src9.what > 20,
          src9 and src9.what)

    -- 🔎 6.431.0 — THE DIAGNOSTICS THE EXTRAS SWEEP CANNOT SEE. That
    -- sweep walks _G for names ending in "Report", which is what makes a
    -- report added next year appear here on the day it ships. A probe
    -- called `…Probe` or `…CheckNow` ends in neither, so however long it
    -- had existed it was invisible to the one list that exists to name
    -- every diagnostic. Four of them, every one read-only.
    for _, name in ipairs({ "begoneProbe", "padProbe", "oneDriveProbe",
                            "healthCheckNow" }) do
        check("§9 🔎 @report names _G." .. name .. "(), which no name ending "
              .. "in 'Report' could ever have found",
              type(U.reportDocs[name]) == "string"
              and #U.reportDocs[name] > 10, U.reportDocs[name])
    end
    -- 🚨 AND THE OTHER HALF, which is the one that matters: ⏎ on a row
    -- RUNS it. A list whose Enter key runs things may only ever hold
    -- things that READ (6.335.0 — a purge control one pixel from a
    -- restore control is the wrong button to add). These three are
    -- published, diagnostics-shaped, and deliberately absent.
    for _, name in ipairs({ "vaultPurgeTrash",      -- erases notes
                            "hyperSelfTest",        -- acts on the keyboard
                            "hyperWakeProbeRun" }) do
        check("§9 🚨 …and _G." .. name .. "() is NOT in it — it acts, and "
              .. "⏎ on a row runs what it names",
              U.reportDocs[name] == nil)
    end

    -- 🚨 NOTHING PUBLISHED: every documented report is a ⚠️ row, and NOT
    -- ONE of them is runnable. A list that offered to run a report that
    -- does not exist would be worse than no list (6.276.0).
    for name in pairs(U.reportDocs) do rawset(_G, name, nil) end
    U.gather()
    local rows9, runnable9 = {}, 0
    for _, r in ipairs(U.rows) do
        if r.tag == "report" then
            rows9[#rows9 + 1] = r
            if r.kind == "report" then runnable9 = runnable9 + 1 end
        end
    end
    check("§9 with nothing published, every report row is a ⚠️ row",
          #rows9 > 50 and (function()
              for _, r in ipairs(rows9) do
                  if not tostring(r.text):find("NOT published", 1, true) then
                      return false
                  end
              end
              return true
          end)(), #rows9)
    check("§9 …and none of them is runnable", runnable9 == 0, runnable9)

    -- …now publish two: one described, one not.
    local RANR = {}
    rawset(_G, "draftKeeperReport", function() RANR[#RANR + 1] = "draft" end)
    rawset(_G, "zzzMadeUpReport",   function() RANR[#RANR + 1] = "madeup" end)
    U.gather()
    local described, undescribed, order = nil, nil, {}
    for _, r in ipairs(U.rows) do
        if r.tag == "report" then
            order[#order + 1] = tostring(r.report)
            if r.report == "draftKeeperReport" then described = r end
            if r.report == "zzzMadeUpReport"   then undescribed = r end
        end
    end
    check("§9 a published report is a plain row carrying its own sentence",
          described ~= nil and described.kind == "report"
          and described.text == U.reportDocs.draftKeeperReport,
          described and described.text)
    check("§9 …and the command is the row's second line, so it can be read"
          .. " without running anything",
          described and described.sub == "_G.draftKeeperReport()",
          described and described.sub)
    -- 🚨 THE OTHER DIRECTION, and it is the half that keeps the hand-kept
    -- table honest: a report added next year with no sentence here shows
    -- up on the day it ships rather than being quietly absent for a year.
    check("§9 a PUBLISHED report nobody described is a ⚠️ row — forgetting"
          .. " is loud in both directions (6.276.0 · 6.317.0)",
          undescribed ~= nil
          and tostring(undescribed.text):find("no description", 1, true) ~= nil,
          undescribed and undescribed.text)
    check("§9 …and it still RUNS, because it exists",
          undescribed and undescribed.kind == "report"
          and undescribed.report == "zzzMadeUpReport")
    -- 🔤 sorted, or the picker reshuffles under his hand between opens
    check("§9 the documented rows are in a stable, sorted order", (function()
        local last = nil
        for _, sub in ipairs(order) do
            if sub == "zzzMadeUpReport" then break end       -- the extras tail
            if last and sub < last then return false end
            last = sub
        end
        return #order > 50
    end)(), #order)

    -- ⏎ RUNS IT. Same shape as a tool row: the panel first, the call a
    -- turn later, because a report can open a window of its own.
    U.show()
    ALERTS, RANR = {}, {}
    BRIDGE({ body = { a = "pick", id = described.id } })
    check("§9 the panel is put away BEFORE the report runs",
          U.webview == nil and #RANR == 0)
    drain()
    check("§9 …and then it runs", RANR[1] == "draft", RANR[1])
    check("§9 …and says where the answer went",
          (ALERTS[#ALERTS] or ""):find("Console", 1, true) ~= nil,
          ALERTS[#ALERTS])

    -- ⌘⏎ copies the command instead of running it.
    U.show() ; PB, ALERTS, RANR = nil, {}, {}
    BRIDGE({ body = { a = "path", id = described.id } })
    check("§9 ⌘⏎ copies the command and runs nothing",
          PB == "_G.draftKeeperReport()" and #RANR == 0, tostring(PB))

    -- 🚨 A REPORT THAT RAISES IS WORSE THAN ONE THAT LIES (6.282.0) — it
    -- takes itself down silently in the one place you go to find out
    -- what is wrong. So a throw is NAMED.
    rawset(_G, "draftKeeperReport", function() error("this report is broken", 0) end)
    U.gather()
    local broken
    for _, r in ipairs(U.rows) do
        if r.report == "draftKeeperReport" then broken = r end
    end
    U.show() ; ALERTS = {}
    BRIDGE({ body = { a = "pick", id = broken.id } })
    drain()
    check("§9 a report that THROWS is named on screen, not swallowed",
          (ALERTS[#ALERTS] or ""):find("threw", 1, true) ~= nil,
          ALERTS[#ALERTS])

    -- …and a row whose report vanished between the gather and the press
    -- hands over the command rather than claiming it ran.
    U.gather()
    local live
    for _, r in ipairs(U.rows) do
        if r.report == "zzzMadeUpReport" then live = r end
    end
    rawset(_G, "zzzMadeUpReport", nil)
    U.show() ; PB, ALERTS = nil, {}
    U.runReport(live)
    check("§9 a report that went away before ⏎ hands over the command and"
          .. " does not pretend it ran",
          PB == "_G.zzzMadeUpReport()"
          and (ALERTS[#ALERTS] or ""):find("not published", 1, true) ~= nil,
          tostring(PB))

    check("§9 ran all of its checks", (pass + fail) - n9 == 21,
          (pass + fail) - n9)
end

io.write(("\n%d passed, %d failed\n"):format(pass, fail))

if fail > 0 then
    io.write("FAILURES:\n")
    for _, f in ipairs(failures) do io.write("   ❌ " .. f .. "\n") end
    os.exit(1)
end
