-- =====================================================================
-- test_editor.lua — the blur editor's Lua half
-- =====================================================================
--     lua5.4 test_editor.lua [/path/to/hammerspoon]
--
-- Executes modules/screenshot_editor.lua against a stubbed hs (webview
-- records HTML, io.open serves a fake PNG) and drives the real message
-- handler: open → save / cancel. The page's JavaScript half — the blur
-- itself — is executed for real by tests/test_editor_js.js under node;
-- this suite covers everything on the Lua side of the bridge.
--
-- THE RULES THIS SUITE ENFORCES ABOVE ALL OTHERS:
--   · The ORIGINAL FILE IS NEVER TOUCHED. Saving writes "… (edited).png"
--     next to it; cancelling writes nothing at all.
--   · A save that cannot be decoded alerts and keeps the editor open —
--     it never half-writes a file.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail, failures = 0, 0, {}
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else fail = fail + 1
         failures[#failures + 1] = label .. (extra and ("\n        got: " .. tostring(extra)) or "") end
end
local function out(s) io.write(s) end

local printed = {}
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    printed[#printed + 1] = table.concat(p, " ")
end

-- ---- fake filesystem: readable sources, recorded writes ---------------
local SRC = "/od/2026 Screenshots/Screenshot demo.png"
local READABLE = { [SRC] = "FAKE-PNG-BYTES" }
local WRITTEN  = {}     -- path -> bytes
local realOpen = io.open
io.open = function(path, mode)
    if mode == "rb" then
        local bytes = READABLE[path]
        if not bytes then return nil end
        return { read = function() return bytes end, close = function() end }
    elseif mode == "wb" then
        local buf = {}
        return {
            write = function(_, s) buf[#buf + 1] = s end,
            close = function() WRITTEN[path] = table.concat(buf) end,
        }
    end
    return realOpen(path, mode)
end

local ALERTS = {}
local LAST_HTML, BRIDGE, VIEW = nil, nil, nil
local CLIP = { kind = "empty" }
JS = {}                 -- 6.213.0: every evaluateJavaScript the module pushes
PB_IMAGE = nil          -- what hs.pasteboard.readImage answers
EVENTS = {}             -- 6.255.0: hide / show / timer, IN ORDER
TIMERS = {}             -- 6.255.0: every hs.timer.doAfter the module holds
DEGRADES = {}           -- 6.255.0: every core.degrade the module takes
FOCUSED = false
NO_HSWINDOW = false
NO_TIMER = false
-- 🔬 6.424.0 — THE STUB MUST BE ABLE TO REFUSE, BOTH WAYS. 6.290.0's
-- ratchet: a show that always succeeds cannot see a caller that ignores
-- the answer, which is exactly what let a refused window be dragged on
-- screen by the bringToFront below it. "throw" is the shape LL's Mac
-- produced ("macOS raised while ordering the window on screen");
-- "false" is the other one macOS uses, and 6.265.0 is the release that
-- learned they are different facts.
SHOW_MODE  = "ok"       -- "ok" · "throw" · "false"
HTML_THROW = false      -- the page builder raising (6.406.0's white box)

hs = {
    webview = {
        usercontent = {
            new = function(name)
                local uc = { name = name }
                function uc:setCallback(fn) BRIDGE = fn; return self end
                return uc
            end,
        },
        new = function(rect, opts, uc)
            local v = { rect = rect, deleted = false, shown = false }
            function v:html(s)
                if HTML_THROW then error("the page could not be built", 0) end
                LAST_HTML = s; return self
            end
            function v:show()
                EVENTS[#EVENTS + 1] = "show"
                if SHOW_MODE == "throw" then
                    error("macOS raised while ordering the window on screen", 0)
                end
                if SHOW_MODE == "false" then return false end
                self.shown = true; self.hidden = false
                return self
            end
            -- 🧪 6.255.0 — a hide() that only returns self would let every
            -- "it got out of the way" check pass over a window that never
            -- moved: the getter-only stub, SIXTH time (6.193.0). It really
            -- hides, and the order it happens in is recorded, because the
            -- belt must be armed BEFORE the window goes.
            function v:hide() self.shown = false; self.hidden = true
                              EVENTS[#EVENTS + 1] = "hide"; return self end
            function v:hswindow()
                if NO_HSWINDOW then return nil end
                return { focus = function() FOCUSED = true; return true end }
            end
            function v:delete() self.deleted = true; return self end
            function v:windowTitle(t) self.title = t; return self end
            function v:allowTextEntry() return self end
            function v:closeOnEscape() return self end
            function v:level() return self end
            function v:behaviorAsLabels() return self end
            -- 🚨 RECORDED (6.424.0): "it was not shown" and "it was not
            -- shown AND NOT dragged to the front anyway" are different
            -- facts, and only the second is the white box being prevented.
            function v:bringToFront()
                EVENTS[#EVENTS + 1] = "front"; return self
            end
            -- 6.286.0 — recorded in EVENTS too, so a check can assert that
            -- the close belt is armed BEFORE the page is asked. Ordering is
            -- the rule; a check that only counts cannot see it.
            function v:evaluateJavaScript(js)
                JS[#JS + 1] = js; EVENTS[#EVENTS + 1] = "js"; return self
            end
            -- 6.221.0 — the REAL webview answers :frame() and takes one;
            -- a stub without it hid a ⌘-drag strip that could not be read
            function v:frame(f) if f then self.rect = f end return self.rect end
            VIEW = v
            return v
        end,
    },
    drawing = { windowLevels = { floating = 5 } },
    screen = { mainScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
    end },
    base64 = {
        -- visible transformations, so the suite can PROVE they ran.
        -- encode wraps lines the way the real one does — the module must
        -- strip that or the data: URI dies inside WKWebView.
        encode = function(s) return "B64<" .. s:sub(1, 8) .. "\n" .. s:sub(9) .. ">" end,
        decode = function(s) return "DECODED<" .. s .. ">" end,
    },
    image = {
        imageFromPath = function(p)
            if not (READABLE[p] or WRITTEN[p]) then return nil end
            return { __path = p,
                     size = function() return { w = 800, h = 600 } end }
        end,
    },
    pasteboard = {
        writeObjects = function(o) CLIP = { kind = "image", v = o }; return true end,
        readImage = function() return PB_IMAGE end,
    },
    fs = { attributes = function(p, k)
        if WRITTEN[p] then return k and #WRITTEN[p] or { size = #WRITTEN[p] } end
        return nil
    end },
    alert = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    -- 6.258.0 — ⌘O's picker. It REMEMBERS its rows and its callback so the
    -- suite can choose a row for real rather than calling the grow by hand
    -- (6.203.0: a harness that builds the message cannot see a bug in the
    -- sending).
    chooser = { new = function(cb)
        local c = { _cb = cb, rows = {}, shown = false, hidden = false }
        function c:choices(x) if x then self.rows = x end return self.rows end
        function c:placeholderText() return self end
        function c:show() self.shown = true; return self end
        function c:hide() self.hidden = true; self.shown = false; return self end
        function c:pick(i) self._cb(self.rows[i]) end
        CHOOSER = c
        return c
    end },
    timer = {
        secondsSinceEpoch = function() return 1000.4231 end,
        -- 6.255.0 — timers are HELD, not fired: the suite fires them by
        -- hand so the belt can be proven without waiting eight seconds.
        doAfter = function(secs, fn)
            if NO_TIMER then return nil end
            EVENTS[#EVENTS + 1] = "timer"
            local t = { secs = secs, fn = fn, stopped = false }
            function t:stop() self.stopped = true; return self end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
    },
}
_G.diag = { say = function() end, warn = function() end, err = function() end }

CHOOSER = nil           -- 6.258.0: the last hs.chooser the module made
SERVICES = {}           -- 6.258.0: what core.has / core.call answer
_G.choosers = {}

local PROVIDED = {}
local CORE = {
    provide = function(n, f) PROVIDED[n] = f end,
    has  = function(n) return SERVICES[n] ~= nil end,
    call = function(n, ...) local f = SERVICES[n]; if f then return f(...) end end,
    showPopup = function(c) POPPED = c; pcall(function() c:show() end) end,
    degrade = function(tool, why)
        DEGRADES[#DEGRADES + 1] = { tool = tool, why = tostring(why) }
        return false, why
    end,
    resolveBaseScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
    end,
}

local M = dofile(HS .. "/modules/screenshot_editor.lua")
M.setup(CORE)
local E = _G.screenshotEditor

-- =====================================================================
out("\n1. contract & wiring\n")
-- =====================================================================
check("module loads and has setup()", type(M.setup) == "function")
check("screenshotEditor.open is a service", type(PROVIDED["screenshotEditor.open"]) == "function")
check("cheat sheet group present with a title", type(M.cheatsheet) == "table"
      and type(M.cheatsheet.title) == "string")
check("edited files land NEXT TO the original",
      E.editedPathFor("/x/Shot.png") == "/x/Shot (edited).png",
      E.editedPathFor("/x/Shot.png"))
check("…as .jpg when the small-JPEG save asks for it",
      E.editedPathFor("/x/Shot.png", "jpg") == "/x/Shot (edited).jpg",
      E.editedPathFor("/x/Shot.png", "jpg"))

-- =====================================================================
out("2. open — the image travels INTO the page\n")
-- =====================================================================
check("open() on a readable file succeeds", E.open(SRC) == true)
check("a webview came up", VIEW ~= nil and VIEW.shown)
check("the window is named after the file",
      (VIEW.title or ""):find("Screenshot demo.png", 1, true) ~= nil, VIEW.title)
check("the page embeds the image as a base64 data: URI",
      LAST_HTML:find("data:image/png;base64,B64&lt;", 1, true) == nil
      and LAST_HTML:find("data:image/png;base64,B64<", 1, true) ~= nil)
check("🚨 the base64 is ONE UNBROKEN RUN — hs.base64.encode line-wraps, "
      .. "and a wrapped data: URI dies inside WKWebView without a word",
      LAST_HTML:find("base64,B64<FAKE%-PNG\n") == nil)
check("the page carries the blur core the node suite executes",
      LAST_HTML:find("function boxBlurRGBA", 1, true) ~= nil)
check("…and the undo stack", LAST_HTML:find("undoStack", 1, true) ~= nil)
check("…and the ⌘Z / ⌘⏎ / esc key handlers", LAST_HTML:find("'Escape'", 1, true) ~= nil
      and LAST_HTML:find("'Enter'", 1, true) ~= nil)
check("…and the text/arrow tools the node suite drives (6.88.0)",
      LAST_HTML:find("function drawNote", 1, true) ~= nil
      and LAST_HTML:find("function setTool", 1, true) ~= nil
      and LAST_HTML:find("'arrow'", 1, true) ~= nil)

-- =====================================================================
out("3. save — an edited copy, never the original\n")
-- =====================================================================
BRIDGE({ body = { a = "save", data = "data:image/png;base64,EDITEDPNG" } })
local outPath = "/od/2026 Screenshots/Screenshot demo (edited).png"
check("the edited file is written next to the original",
      WRITTEN[outPath] ~= nil, next(WRITTEN))
check("…containing the DECODED bytes from the page",
      WRITTEN[outPath] == "DECODED<EDITEDPNG>", WRITTEN[outPath])
check("🚨 the ORIGINAL was not touched", WRITTEN[SRC] == nil)
check("the edited image went onto the clipboard", CLIP.kind == "image"
      and CLIP.v.__path == outPath)
check("…with an alert that says so", (ALERTS[#ALERTS] or ""):find("Saved") ~= nil,
      ALERTS[#ALERTS])
check("and the editor closed", E.webview == nil and VIEW.deleted)

-- a second save of the same screenshot numbers itself instead of
-- overwriting the first edit
E.open(SRC)
BRIDGE({ body = { a = "save", data = "data:image/png;base64,EDIT2" } })
check("a second edit becomes “… (edited 2).png”",
      WRITTEN["/od/2026 Screenshots/Screenshot demo (edited 2).png"] ~= nil)

-- the "Small JPEG" path (6.88.0): same rules, .jpg extension
E.open(SRC)
BRIDGE({ body = { a = "save", data = "data:image/jpeg;base64,EDITJPG", ext = "jpg" } })
check("a JPEG save writes “… (edited).jpg” next to the original",
      WRITTEN["/od/2026 Screenshots/Screenshot demo (edited).jpg"]
      == "DECODED<EDITJPG>",
      WRITTEN["/od/2026 Screenshots/Screenshot demo (edited).jpg"])
check("🚨 …and the ORIGINAL is still untouched", WRITTEN[SRC] == nil)

-- =====================================================================
out("4. cancel & bad input\n")
-- =====================================================================
local writesBefore = 0
for _ in pairs(WRITTEN) do writesBefore = writesBefore + 1 end
E.open(SRC)
BRIDGE({ body = { a = "cancel" } })
local writesAfter = 0
for _ in pairs(WRITTEN) do writesAfter = writesAfter + 1 end
check("cancel writes NOTHING", writesAfter == writesBefore)
check("…and closes the editor", E.webview == nil)

E.open(SRC)
local alertsBefore = #ALERTS
BRIDGE({ body = { a = "save", data = "data:text/html;base64,NOTPNG" } })
check("a non-png save payload alerts instead of writing",
      #ALERTS == alertsBefore + 1 and (ALERTS[#ALERTS] or ""):find("failed") ~= nil,
      ALERTS[#ALERTS])
check("…and the editor STAYS OPEN so the work is not lost", E.webview ~= nil)
BRIDGE({ body = { a = "cancel" } })

check("open() on an unreadable file fails with an alert, no window",
      E.open("/nowhere/gone.png") == false
      and (ALERTS[#ALERTS] or ""):find("Could not read") ~= nil)

-- =====================================================================
out("5. the work survives an accidental Esc (6.189.0)\n")
-- =====================================================================
-- LL: "I hit escape 2 times and all my screenshot work wasn't saved as I
-- accidentally hit escape." The page hands its state back on the way out
-- and it is held in ONE slot, keyed by the image path.
local KEEPIMG = "data:image/png;base64,BLURREDPIXELS+/="
local NOTES   = '[{"kind":"text","x":1,"y":2,"text":"hi"}]'
local keptSection0 = 0
for _ in pairs(WRITTEN) do keptSection0 = keptSection0 + 1 end

E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
check("Esc still writes NOTHING, even carrying the work out", (function()
          local n = 0; for _ in pairs(WRITTEN) do n = n + 1 end
          return n == keptSection0
      end)())
check("…and the work is held against the image path",
      E.kept ~= nil and E.kept.path == SRC and E.kept.img == KEEPIMG,
      E.kept and E.kept.path)

E.open(SRC)
check("reopening the SAME shot hands the kept image back to the page",
      LAST_HTML:find("RESTOREIMG   = '" .. KEEPIMG .. "'", 1, true) ~= nil)
check("…and the notes with it",
      LAST_HTML:find("RESTORENOTES = ''", 1, true) == nil
      and LAST_HTML:find("RESTORENOTES = 'B64<", 1, true) ~= nil)
check("…and LL is told his edits came back",
      (ALERTS[#ALERTS] or ""):find("back") ~= nil, ALERTS[#ALERTS])
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })

-- 🚨 THE INJECTION RULE. A note's text is LL's typing and rides into a
-- <script> block; it must never arrive as markup. The notes go as base64
-- for exactly this reason, so the raw string must be absent from the page.
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG,
                  notes = '[{"kind":"text","text":"</script><b>x"}]' } })
E.open(SRC)
-- The stub encoder is deliberately VISIBLE (B64<…>), so the payload can
-- still be read inside its own literal. What must be true is that it went
-- THROUGH the encoder and that no second, unencoded copy was injected —
-- with the real hs.base64 that is exactly "arrives inert".
local restLit = LAST_HTML:match("RESTORENOTES = '([^']*)'") or ""
local restOf  = LAST_HTML:gsub("RESTORENOTES = '[^']*'", "", 1)
check("🚨 a note carrying </script> is ENCODED on the way into the page",
      restLit:sub(1, 4) == "B64<" and restLit:find("</script>", 1, true) ~= nil,
      restLit:sub(1, 40))
check("🚨 …and no unencoded copy of it is injected anywhere else",
      restOf:find("</script><b>x", 1, true) == nil)

-- keyed by PATH: a second screenshot opens clean (LL: "that's fine")
local OTHER = "/od/2026 Screenshots/Another shot.png"
READABLE[OTHER] = "FAKE-PNG-TWO"
E.open(OTHER)
check("a DIFFERENT shot opens clean — the slot does not follow it",
      LAST_HTML:find("RESTOREIMG   = ''", 1, true) ~= nil)
BRIDGE({ body = { a = "cancel" } })

-- a cancel with nothing usable keeps NOTHING rather than half a session
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = "data:text/html;base64,NOPE", notes = NOTES } })
check("a cancel without a usable png keeps nothing at all", E.kept == nil)
E.open(SRC)
check("…so the next open restores the FILE, not a fragment",
      LAST_HTML:find("RESTOREIMG   = ''", 1, true) ~= nil)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })

-- the notes budget costs the annotations, never the whole rescue
E.keepMaxNoteBytes = 8
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
check("oversized notes are dropped but the image is still kept",
      E.kept ~= nil and E.kept.img == KEEPIMG and E.kept.notes == "[]",
      E.kept and E.kept.notes)
E.keepMaxNoteBytes = 256 * 1024

-- and the image budget refuses the lot rather than keeping a fragment
E.keepMaxBytes = 4
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
check("an image over the keep budget is refused outright", E.kept == nil)
E.keepMaxBytes = 40 * 1024 * 1024

-- SAVED work is not lost work — a slot left standing would restore a
-- stale state over the next open of the same shot
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
E.open(SRC)
BRIDGE({ body = { a = "save", data = "data:image/png;base64,SAVEDPNG" } })
check("a save clears the slot", E.kept == nil)
E.open(SRC)
check("…so reopening after a save shows the file, not the old session",
      LAST_HTML:find("RESTOREIMG   = ''", 1, true) ~= nil)
BRIDGE({ body = { a = "cancel" } })

-- the switch LL can throw if any of this ever misbehaves
E.keepOnClose = false
E.open(SRC)
BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
check("settings { screenshot_editor = { keepOnClose = false } } keeps nothing",
      E.kept == nil)
E.keepOnClose = true

-- =====================================================================
-- =====================================================================
out("\n9. 6.213.0 — ⌘V and ⌘A: an image INTO the page, through Lua\n")
-- =====================================================================
do
    local function open()
        JS, ALERTS = {}, {}
        READABLE["/x/Shot.png"] = "PNGBYTES"
        E.open("/x/Shot.png")
    end
    open()
    -- ⌘V with nothing usable on the clipboard
    PB_IMAGE = nil
    BRIDGE({ body = { a = "paste" } })
    check("⌘V with no image on the clipboard: an alert, nothing pushed",
          #JS == 0 and ALERTS[#ALERTS] and ALERTS[#ALERTS]:find("Nothing to paste", 1, true) ~= nil, ALERTS[#ALERTS])
    -- ⌘V with an image
    PB_IMAGE = { encodeAsURLString = function() return "data:image/png;base64,PASTEDB64==" end,
                 size = function() return { w = 800, h = 600 } end }
    BRIDGE({ body = { a = "paste" } })
    check("🚨 ⌘V with an image: the page gets addImage(<data URI>, w, h) through evaluateJavaScript",
          JS[#JS] == "addImage('data:image/png;base64,PASTEDB64==', 800, 600)", JS[#JS])
    -- a URI the page could not parse never reaches WebKit
    PB_IMAGE = { encodeAsURLString = function() return "data:image/png;base64,bad'; alert(1); //" end,
                 size = function() return { w = 8, h = 8 } end }
    local before = #JS
    BRIDGE({ body = { a = "paste" } })
    check("a URI that is not pure base64 is REFUSED, never pushed into a script",
          #JS == before and ALERTS[#ALERTS]:find("not a usable image", 1, true) ~= nil, ALERTS[#ALERTS])
    PB_IMAGE = { encodeAsURLString = function() return "data:image/png;base64,AAAA" end,
                 size = function() return { w = 0, h = 0 } end }
    BRIDGE({ body = { a = "paste" } })
    check("an image with no size is refused, named", ALERTS[#ALERTS]:find("no size", 1, true) ~= nil)
    check("pushImage returns ok, why and never throws", (function()
        local ok, why = E.pushImage("junk", 1, 1)
        return ok == false and why == "not a usable image"
    end)())

    -- ⌘A with no screenshots module
    CORE.has  = function(n) return PROVIDED[n] ~= nil end
    CORE.call = function(n, ...) return PROVIDED[n](...) end
    PROVIDED["screenshots.captureAreaTo"] = nil
    BRIDGE({ body = { a = "capture" } })
    check("⌘A without the screenshots module: says so, pushes nothing",
          ALERTS[#ALERTS]:find("screenshots module", 1, true) ~= nil and #JS == before, ALERTS[#ALERTS])
    -- ⌘A with the service: the callback with a path reads the file and pushes it
    local CAPTURE_CB
    PROVIDED["screenshots.captureAreaTo"] = function(cb) CAPTURE_CB = cb return true end
    BRIDGE({ body = { a = "capture" } })
    check("⌘A asks screenshots.captureAreaTo and waits", type(CAPTURE_CB) == "function" and #JS == before)
    READABLE["/x/Cap.png"] = "CAPTUREBYTES"
    -- this suite's base64 stub writes visible markers (B64<…>), which a
    -- data URI can never carry; for the door that pushes a URI the stub
    -- answers the REAL shape — base64 characters, line-wrapped at 76 as
    -- hs.base64.encode does
    local markerEncode = hs.base64.encode
    hs.base64.encode = function() return "Q0FQVFVSRUJZVEVT\nQkFTRTY0" end
    CAPTURE_CB("/x/Cap.png")
    hs.base64.encode = markerEncode
    check("🚨 …the capture that lands is read, encoded and pushed as addImage(...) with its size",
          JS[#JS] == "addImage('data:image/png;base64,Q0FQVFVSRUJZVEVTQkFTRTY0', 800, 600)", JS[#JS])
    check("…with hs.base64's line-wrap stripped (a broken data URI is a silent nothing in WebKit)",
          JS[#JS] and not JS[#JS]:find("\n", 1, true))
    check("…and a wrap that survived would have been REFUSED, not pushed (the shape is checked at the door)",
          select(2, E.pushImage("data:image/png;base64,QUJD\nREVG", 8, 8)) == "not a usable image")
    before = #JS
    CAPTURE_CB(nil, "screencapture exit 1 — could not create image")
    check("a capture that did not land: the reason is alerted, nothing pushed",
          #JS == before and ALERTS[#ALERTS]:find("Capture did not land — screencapture exit 1", 1, true) ~= nil, ALERTS[#ALERTS])
    CAPTURE_CB("/x/missing.png")
    check("a path that cannot be read: alerted, nothing pushed",
          #JS == before and ALERTS[#ALERTS]:find("could not be read", 1, true) ~= nil, ALERTS[#ALERTS])
    -- the buttons and keys are in the page
    check("the page has the Spotlight and Magnifier tools and the two doors",
          LAST_HTML:find("id=\"tool-spot\"", 1, true) ~= nil and LAST_HTML:find("id=\"tool-mag\"", 1, true) ~= nil
          and LAST_HTML:find("say({a:'paste'})", 1, true) ~= nil and LAST_HTML:find("say({a:'capture'})", 1, true) ~= nil
          and LAST_HTML:find("function addImage(", 1, true) ~= nil)
    check("…and the zoom / veil knobs reach it", LAST_HTML:find("var MAGZOOM = 2;", 1, true) ~= nil
          and LAST_HTML:find("var VEIL = 0.55;", 1, true) ~= nil)
    E.close()
end

-- =====================================================================
out("\n10. 6.221.0 — ⌘ belongs to the PAGE below the title bar\n")
-- =====================================================================
-- window_move's tap takes a bare-⌘ left-mouse-down anywhere inside a
-- listed panel's frame and begins a window drag, consuming the click. So
-- for LL's ⌘-click to reach a mark at all, this module must list only
-- the strip it is happy to be dragged by — its header.
local mine = 0
local function ck(label, cond, extra) mine = mine + 1; check(label, cond, extra) end

local F = { x = 100, y = 50, w = 900, h = 700 }
local strip = E.stripOf(F, 54)
ck("stripOf keeps the panel's x, y and WIDTH", strip and strip.x == 100
   and strip.y == 50 and strip.w == 900)
ck("🚨 …and only the header's height, so ⌘ below it reaches the canvas",
   strip and strip.h == 54, strip and strip.h)
ck("a strip taller than the window is CLAMPED to the window",
   (E.stripOf({ x = 0, y = 0, w = 10, h = 20 }, 54) or {}).h == 20)
ck("no frame → no strip (never a rectangle at 0,0)", E.stripOf(nil, 54) == nil
   and E.stripOf({ x = 1 }, 54) == nil)
ck("a zero or negative height → no strip, never the whole window",
   E.stripOf(F, 0) == nil and E.stripOf(F, -10) == nil)

local entry
for _, e in ipairs(_G.movablePanels or {}) do
    if e.name == "screenshot editor" then entry = e end
end
ck("the editor is still listed for Window Move", entry ~= nil)
E.open(SRC)
local listed = entry and entry.frame()
local win = E.webview and E.webview:frame()
ck("🚨 THE LISTED FRAME IS THE HEADER, NOT THE WINDOW — ⌘ inside the "
   .. "drawing area is the page's now, which is the whole of this fix",
   listed and win and listed.h == 54 and win.h > 54
   and listed.w == win.w and listed.y == win.y,
   listed and (listed.w .. "x" .. listed.h) or "nil")
ck("…and it still MOVES the whole window, not the strip",
   (function()
        entry.move(win.x + 40, win.y + 30)
        local f = E.webview:frame()
        return f.x == win.x + 40 and f.y == win.y + 30
               and f.w == win.w and f.h == win.h
    end)())
E.close()
ck("with the editor closed the strip is nil — nothing to ⌘-drag",
   entry.frame() == nil)

-- 🔒 the strip height and the page's own header height are ONE number.
-- If the header's CSS grows and this does not, ⌘-drag grabs part of the
-- canvas again — silently, and only on his Mac.
E.open(SRC)
ck("the page's #stage height is measured from the SAME header height the "
   .. "⌘-drag strip uses — the two cannot drift apart",
   LAST_HTML:find("height:calc(100vh - " .. E.dragStripH .. "px)", 1, true) ~= nil,
   E.dragStripH)
E.close()

-- 🖼 6.270.0 — THE RAILS EXIST, AND THEY ARE SIZED FROM THE CONFIG.
-- LL, three times: the editor "has not had the tools that run across the
-- top of the editor and a column on the left-hand side and the right hand
-- side". It never had them — all eighteen buttons were in ONE wrapping
-- strip. These checks are about the STRUCTURE, because a rail that is
-- present but empty, or present but sized by a literal, is the same
-- complaint again next month.
E.open(SRC)
ck("🖼 there is a rail on the LEFT and a rail on the RIGHT",
   LAST_HTML:find('id="railL"', 1, true) ~= nil
   and LAST_HTML:find('id="railR"', 1, true) ~= nil)
-- 🚨 MATCHED WITH ITS CLOSING QUOTE, and that is not fussiness: the first
-- version of this check searched for the bare id, and `tool-blur` is a
-- PREFIX of `tool-blur-moved`, so a renamed button satisfied it and the
-- mutation that renames one passed the gate. 6.236.0's rule — a name
-- sentry matches the delimiter — in a check written to catch exactly this
-- shape of silent regression.
ck("🖼 the drawing TOOLS are in the left rail, not the top strip",
   (function()
       local l = LAST_HTML:match('<nav id="railL".-</nav>') or ""
       for _, id in ipairs({ "tool-blur", "tool-text", "tool-arrow", "tool-line",
                             "tool-oval", "tool-hl", "tool-count", "tool-spot",
                             "tool-mag" }) do
           if not l:find('id="' .. id .. '"', 1, true) then
               return false, id .. " is not in the left rail"
           end
       end
       return true
   end)())
ck("🖼 the capture and edit ACTIONS are in the right rail",
   (function()
       local r = LAST_HTML:match('<nav id="railR".-</nav>') or ""
       for _, w in ipairs({ "a:'paste'", "a:'capture'", "a:'delay'", "a:'full'",
                            "a:'loadshot'", "undoLast()" }) do
           if not r:find(w, 1, true) then return false, w .. " is not in the right rail" end
       end
       return true
   end)())
-- 🚨 THE CHECK THAT STOPS IT SILENTLY REGRESSING: a button left behind in
-- the header is a rail that only LOOKS built. The top strip keeps the
-- title, the three finish actions and the hint — and nothing else.
ck("🖼 the top strip carries ONLY the title, the finish actions and the "
   .. "hint — a tool left behind there is a rail that only looks built",
   (function()
       local h = LAST_HTML:match("<header>.-</header>") or ""
       for _, w in ipairs({ "setTool(", "a:'paste'", "a:'capture'", "a:'delay'",
                            "a:'full'", "a:'loadshot'", "undoLast()" }) do
           if h:find(w, 1, true) then return false, w .. " is still in the header" end
       end
       return h:find("saveIt('png')", 1, true) ~= nil
          and h:find("stashAndCancel()", 1, true) ~= nil
   end)())
-- 6.239.0 — the rail width is ONE number, read by the CSS and by
-- ed.windowSizeFor. Move it and the page must move with it, or the window
-- reserves 136 points for a rail drawn 200 wide.
ck("🖼 the rail's CSS width is written from ed.railW, not typed in",
   LAST_HTML:find("width:" .. E.railW .. "px", 1, true) ~= nil, E.railW)
ck("🖼 …and the canvas leaves room for BOTH rails, which is his "
   .. "'big enough to accommodate the tool buttons on each side'",
   LAST_HTML:find("max-width:calc(100vw - " .. (E.railW * 2 + 24) .. "px)", 1, true) ~= nil,
   E.railW * 2 + 24)
E.close()

-- Now MOVE it, and require the drawing to follow.
local savedRail = E.railW
E.railW = 210
E.open(SRC)
ck("🖼 moving ed.railW moves the rail AND the canvas budget together",
   LAST_HTML:find("width:210px", 1, true) ~= nil
   and LAST_HTML:find("max-width:calc(100vw - " .. (210 * 2 + 24) .. "px)", 1, true) ~= nil)
E.close()
E.railW = savedRail

check("§10 ran every one of its checks", mine == 17, mine)

-- =====================================================================
out("\n11. 6.342.0 — ⌘D: drag an AREA, then count down, then shoot it\n")
-- =====================================================================
-- LL, on 6.255.0's ⌘D: "⌘D says I have five seconds to setup, shows no
-- crosshairs, and then in the screenshot of the editor, a screenshot of
-- the desktop is placed on it." That IS what 6.255.0 built — and his
-- expectation is macOS's own ⇧⌘5 order, which he then asked for by
-- name. So the shape is: hide · settle · OUR selector (crosshairs since
-- 6.318.0, live W × H since 6.260.0, and the only selector that can
-- report the rectangle — 6.337.0) · countdown · shoot THAT rect.
-- 🪜 The risk is the belt. ⌘F and the old ⌘D knew how long they would be
-- hidden; this one waits on a hand, so there are TWO legs and most of
-- this section is spent on them.
do
    local n11 = 0
    local function c11(label, cond, extra) n11 = n11 + 1; check(label, cond, extra) end

    -- ---- the PURE plan ------------------------------------------------
    c11("grabPlan: open, service there, idle, 5 s → go, with the reason",
        (function()
            local ok, why = E.grabPlan(true, true, false, 5, true, "the area you drag")
            return ok == true and tostring(why):find("5 second", 1, true) ~= nil
        end)())
    c11("grabPlan: the editor is not open → refused, named",
        select(2, E.grabPlan(false, true, false, 5, true)) == "the editor is not open")
    c11("grabPlan: no screenshots module → refused, and it names the module",
        tostring(select(2, E.grabPlan(true, false, false, 5, true)))
            :find("screenshots module", 1, true) ~= nil)
    c11("grabPlan: one already running → refused, NOT a second countdown",
        tostring(select(2, E.grabPlan(true, true, true, 5, true)))
            :find("already running", 1, true) ~= nil)
    c11("grabPlan: a ⌘D with no delay is refused and points at ⌘F — but the "
        .. "SAME zero is a perfectly good ⌘F, which is why it is one function",
        tostring(select(2, E.grabPlan(true, true, false, 0, true)))
            :find("Full screen", 1, true) ~= nil
        and E.grabPlan(true, true, false, 0, false) == true)
    -- 📐 6.342.0 — `what` EARNS ITS PLACE: the two callers capture two
    -- different surfaces, and a plan that said "the whole screen" about
    -- ⌘D would be a reason that lies on one of its callers. The check
    -- that bites asserts BOTH halves — asserting only ⌘D's passes with
    -- the parameter ignored and the default rewritten.
    c11("🚨 grabPlan names the SURFACE: ⌘D's reason says the area he drags, "
        .. "⌘F's still says the whole screen",
        (function()
            local _, area  = E.grabPlan(true, true, false, 5, true, "the area you drag")
            local _, whole = E.grabPlan(true, true, false, 0, false)
            return tostring(area):find("area you drag", 1, true) ~= nil
               and tostring(area):find("whole screen", 1, true) == nil
               and tostring(whole):find("whole screen", 1, true) ~= nil
        end)())

    -- ---- the page -----------------------------------------------------
    READABLE["/x/D.png"] = "PNGBYTES"
    E.close(); JS, ALERTS, EVENTS, TIMERS, DEGRADES = {}, {}, {}, {}, {}
    E.open("/x/D.png")
    c11("the page carries the ⏲ button, the ⌘D key and the door",
        LAST_HTML:find("say({a:'delay'})", 1, true) ~= nil
        and LAST_HTML:find("id=\"btn-delay\"", 1, true) ~= nil
        and LAST_HTML:find("e.key === 'd'", 1, true) ~= nil)
    c11("…and the button's LABEL says the configured number of seconds",
        LAST_HTML:find("⏲ Area +5s", 1, true) ~= nil)
    -- 6.203.0 — say it where he is looking. The label is a NAME; the
    -- hover is where the order of the two steps is spelled out, and
    -- the old label ("Delayed 5s") described a shape this release
    -- replaced, so leaving it would be 6.181.0's stale promise.
    c11("🏷 …and the hover names the ORDER — drag first, then the seconds",
        LAST_HTML:find("drag an area, then 5 seconds", 1, true) ~= nil
        and LAST_HTML:find("⏲ Delayed", 1, true) == nil, LAST_HTML:sub(1, 0))
    -- 6.239.0: assert the shipped default and the check passes when the
    -- number is typed in twice. Move the config; the page must follow.
    E.close(); E.delaySecs = 9; E.open("/x/D.png")
    c11("🚨 the label, the hover and the page's own DELAYSECS all come from "
        .. "the config — move it and all three move, or they were three numbers",
        LAST_HTML:find("⏲ Area +9s", 1, true) ~= nil
        and LAST_HTML:find("then 9 seconds", 1, true) ~= nil
        and LAST_HTML:find("var DELAYSECS = 9;", 1, true) ~= nil)
    E.delaySecs = 5

    -- ---- no service ----------------------------------------------------
    CORE.has  = function(n) return PROVIDED[n] ~= nil end
    CORE.call = function(n, ...) return PROVIDED[n](...) end
    PROVIDED["screenshots.captureRegionTo"] = nil
    E.close(); JS, ALERTS, EVENTS, TIMERS, DEGRADES = {}, {}, {}, {}, {}
    E.open("/x/D.png")
    EVENTS = {}          -- opening the window is a "show"; this is about ⌘D
    BRIDGE({ body = { a = "delay" } })
    c11("⌘D without the screenshots module: says so, and the window NEVER hides",
        (ALERTS[#ALERTS] or ""):find("screenshots module", 1, true) ~= nil
        and E.hidden == false and #EVENTS == 0, ALERTS[#ALERTS])

    -- ---- the happy path -------------------------------------------------
    local ASKED, CB, PICK, CANCELLED = nil, nil, nil, 0
    PROVIDED["screenshots.captureRegionTo"] = function(secs, cb, onPicked)
        ASKED = secs; CB = cb; PICK = onPicked; return true
    end
    PROVIDED["screenshots.cancelSelect"] = function() CANCELLED = CANCELLED + 1 end
    JS, ALERTS, EVENTS, TIMERS, DEGRADES = {}, {}, {}, {}, {}
    BRIDGE({ body = { a = "delay" } })
    c11("🪟 the editor HIDES — an area dragged around a window that is still "
        .. "there is an area containing the editor",
        E.hidden == true)
    c11("🚨 THE BELT IS ARMED BEFORE THE WINDOW GOES (6.246.0's ordering): "
        .. "a hide with no way back is the failure this release could cause",
        EVENTS[1] == "timer" and EVENTS[2] == "hide",
        table.concat(EVENTS, ","))
    -- 🚨 THE SETTLE BEAT IS NEW TO ⌘D, and it is the 6.256.0 finding one
    -- surface on: the old ⌘D hid behind screencapture's own -T, so
    -- nothing of ours had to wait for the window to leave. Now the
    -- SELECTOR draws next, and :hide() is not instant.
    c11("🚨 …and the SELECTOR is not asked for until the window has had a "
        .. "beat to leave the screen",
        EVENTS[3] == "timer" and ASKED == nil, table.concat(EVENTS, ","))
    -- 🪜 LEG 1 IS THE LONG ONE, and this is the whole difference from
    -- 6.255.0: asserting `secs + grace` here passes with the long leg
    -- deleted, and then a belt fires five seconds into a drag he has not
    -- finished — the window comes back INTO the area he is choosing.
    c11("🪜 LEG 1 waits regionGraceSecs, not the countdown — the selector "
        .. "waits on a hand and nothing can say how long that is",
        #TIMERS >= 1 and TIMERS[1].secs == E.regionGraceSecs + E.delayGraceSecs
        and E.regionGraceSecs > E.delaySecs, TIMERS[1] and TIMERS[1].secs)
    TIMERS[2].fn()       -- the settle beat passes
    c11("⌘D asks screenshots.captureRegionTo for the CONFIGURED seconds, "
        .. "with a callback AND a picked-the-rectangle hook",
        ASKED == 5 and type(CB) == "function" and type(PICK) == "function", ASKED)
    -- a second ⌘D while one is open
    local before = #TIMERS
    BRIDGE({ body = { a = "delay" } })
    c11("a second ⌘D mid-selection is refused — one selector, one shot",
        #TIMERS == before
        and (ALERTS[#ALERTS] or ""):find("already running", 1, true) ~= nil,
        ALERTS[#ALERTS])

    -- ---- the rectangle is picked ---------------------------------------
    ALERTS, EVENTS, TIMERS = {}, {}, {}
    PICK({ x = 10, y = 20, w = 1280, h = 720 })
    c11("📐 the countdown alert names the RECTANGLE and the seconds — the "
        .. "whole point is that he can see what will be shot",
        (ALERTS[#ALERTS] or ""):find("1280 × 720", 1, true) ~= nil
        and (ALERTS[#ALERTS] or ""):find("5 seconds", 1, true) ~= nil,
        ALERTS[#ALERTS])
    c11("🪜 LEG 2 RE-ARMS SHORT: the drag is over, so a 93-second last "
        .. "resort would leave the window hidden long after a dead capture",
        #TIMERS == 1 and TIMERS[1].secs == 5 + E.hideSettleSecs + E.delayGraceSecs,
        TIMERS[1] and TIMERS[1].secs)

    -- the capture lands
    local markerEncode = hs.base64.encode
    hs.base64.encode = function() return "UkVHSU9O" end
    READABLE["/x/Region.png"] = "REGION"
    FOCUSED = false
    CB("/x/Region.png", nil, "region")
    hs.base64.encode = markerEncode
    c11("🚨 the window comes BACK the moment the capture answers",
        E.hidden == false and VIEW.shown == true)
    c11("…and it asks for the keyboard once, rather than leaving a window "
        .. "that is up but not key (6.251.0)", FOCUSED == true)
    c11("…and the rectangle lands on the canvas as addImage(<data URI>, w, h)",
        JS[#JS] == "addImage('data:image/png;base64,UkVHSU9O', 800, 600)",
        JS[#JS])
    c11("…counted as LANDED, and nothing degraded",
        E.delays.landed == 1 and E.delays.failed == 0 and #DEGRADES == 0)
    c11("…and the run is over, so ⌘D works again", E.delayBusy == false)

    -- ---- Esc on the selector -------------------------------------------
    -- 🚨 A CANCEL IS NOT A FAILURE. He pressed Esc, or his drag was too
    -- small to capture; a tool that takes the 🔔 door over a decision he
    -- made is a tool he stops reading (6.269.0).
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    BRIDGE({ body = { a = "delay" } })
    TIMERS[2].fn()
    local pushedBefore = #JS
    CB(nil, "the selection was cancelled", "cancelled")
    c11("Esc on the selector: the editor is BACK and nothing was pushed",
        E.hidden == false and VIEW.shown == true and #JS == pushedBefore)
    c11("🚨 …counted as CANCELLED, never as a capture that failed",
        E.delays.cancelled == 1 and E.delays.failed == 0, E.delays.failed)
    c11("🔕 …and it does NOT take the 🔔 door — he cancelled on purpose",
        #DEGRADES == 0, DEGRADES[1] and DEGRADES[1].why)
    c11("…but it SAYS so, quietly: a window that reappears with no "
        .. "explanation is 6.320.0's refusal nobody can act on",
        (ALERTS[#ALERTS] or ""):find("Nothing captured", 1, true) ~= nil,
        ALERTS[#ALERTS])

    -- ---- the capture fails ---------------------------------------------
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    BRIDGE({ body = { a = "delay" } })
    TIMERS[2].fn()
    pushedBefore = #JS
    CB(nil, "screencapture exit 1 — could not create image", "region")
    c11("a capture that did not land: the window is back, nothing pushed",
        E.hidden == false and #JS == pushedBefore)
    c11("🔔 …and it takes the DOOR with screencapture's own words — a "
        .. "silence here is a shot he thinks he took",
        #DEGRADES == 1
        and DEGRADES[1].why:find("could not create image", 1, true) ~= nil,
        DEGRADES[1] and DEGRADES[1].why)
    c11("…counted as FAILED, apart from the ones that landed and the ones "
        .. "he cancelled",
        E.delays.failed == 1 and E.delays.landed == 1 and E.delays.cancelled == 1)

    -- ---- the belt, leg 2 ------------------------------------------------
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    BRIDGE({ body = { a = "delay" } })
    TIMERS[2].fn()
    PICK({ x = 0, y = 0, w = 400, h = 300 })
    local leg2 = TIMERS[#TIMERS]
    c11("the window is hidden and the countdown leg is armed",
        E.hidden == true and leg2.secs == 5 + E.hideSettleSecs + E.delayGraceSecs)
    leg2.fn()           -- the countdown passed and NOTHING ever answered
    c11("🚨 THE BELT BRINGS THE WINDOW BACK when the capture never answers "
        .. "— his work is in a live page he cannot see otherwise",
        E.hidden == false and VIEW.shown == true)
    c11("…and it says so rather than reading as health",
        #DEGRADES == 1 and DEGRADES[1].why:find("never answered", 1, true) ~= nil,
        DEGRADES[1] and DEGRADES[1].why)
    c11("…counted apart: a belt return means the capture answered NEVER, "
        .. "which is not the same fact as a capture that failed",
        E.delays.late == 1)
    c11("…and the busy flag is cleared, so ⌘D is not dead for the session",
        E.delayBusy == false)
    CB(nil, "too late", "region")
    c11("a callback that arrives after the belt cannot re-hide the window",
        E.hidden == false)

    -- ---- the belt, LEG 1, with the selector still open ------------------
    -- 📐 6.342.0's own hazard, and it is new: the belt can now fire while
    -- a selector is STILL UP, because the selector waits on a hand.
    -- Bringing the editor back under a live selector would put it in the
    -- very area he is dragging — so the belt ENDS the selector, and the
    -- ordinary cancel path then resolves the run.
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    E.delays = { asked = 0, landed = 0, failed = 0, late = 0, cancelled = 0 }
    CANCELLED = 0
    BRIDGE({ body = { a = "delay" } })
    local leg1 = TIMERS[1]
    TIMERS[2].fn()                 -- settle; the selector is now open
    c11("the selector is open and the editor is hidden",
        E.hidden == true and E.regionRunning == true and type(CB) == "function")
    -- the real module cancels the selector, which answers through cb
    PROVIDED["screenshots.cancelSelect"] = function()
        CANCELLED = CANCELLED + 1
        CB(nil, "the selection was cancelled", "cancelled")
    end
    leg1.fn()
    c11("🚨 LEG 1 ENDS THE SELECTOR rather than reappearing underneath it "
        .. "— a window brought back under a live selector is a window in "
        .. "the area he is choosing",
        CANCELLED == 1 and E.hidden == false and E.regionRunning == false)
    c11("🚨 …and the belt does NOT also count a late return: the cancel "
        .. "resolved the run, so one event is reported once",
        E.delays.cancelled == 1 and E.delays.late == 0,
        tostring(E.delays.cancelled) .. "/" .. tostring(E.delays.late))
    PROVIDED["screenshots.cancelSelect"] = function() CANCELLED = CANCELLED + 1 end

    -- ---- 🚨 LEG 1 GAVE UP AND THE SELECTOR IS STILL THERE --------------
    -- 6.273.0 — the sweep found this check missing, and the reason is the
    -- finding: `picked`'s guard was `state.answered`, which the BELT
    -- never sets, so the one case it was written for walked past it. On a
    -- Mac with no `screenshots.cancelSelect` provider stopRegion cannot
    -- end the overlay, so he can still drag a rectangle a minute after
    -- being told the capture never answered — and re-arming a belt and
    -- shouting a countdown for a run that is over is 6.304.0's
    -- generation problem in its simplest form.
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    E.delays = { asked = 0, landed = 0, failed = 0, late = 0, cancelled = 0 }
    PROVIDED["screenshots.cancelSelect"] = nil     -- this Mac has no door
    BRIDGE({ body = { a = "delay" } })
    local leg1b = TIMERS[1]
    TIMERS[2].fn()
    leg1b.fn()          -- the belt gives up with the overlay still open
    c11("with no cancel door the belt still brings the window back, and "
        .. "says the capture never answered",
        E.hidden == false and E.delays.late == 1)
    local timersThen, alertsThen = #TIMERS, #ALERTS
    PICK({ x = 0, y = 0, w = 900, h = 700 })
    c11("🚨 …and a rectangle dragged AFTER that does not re-arm a belt or "
        .. "shout a countdown for a run he has already been told died",
        #TIMERS == timersThen and #ALERTS == alertsThen,
        tostring(#TIMERS - timersThen) .. "/" .. tostring(#ALERTS - alertsThen))
    PROVIDED["screenshots.cancelSelect"] = function() CANCELLED = CANCELLED + 1 end

    -- ---- a Mac that cannot arm a timer ---------------------------------
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    NO_TIMER = true
    BRIDGE({ body = { a = "delay" } })
    c11("🚨 NO TIMER, NO HIDE: an area that contains the editor is a bad "
        .. "picture; a window that cannot come back is lost work",
        E.hidden == false and #EVENTS == 0, table.concat(EVENTS, ","))
    NO_TIMER = false
    CB("/x/Region.png", nil, "region")

    -- ---- no hswindow ----------------------------------------------------
    JS, ALERTS, EVENTS, DEGRADES, TIMERS = {}, {}, {}, {}, {}
    NO_HSWINDOW, FOCUSED = true, false
    BRIDGE({ body = { a = "delay" } })
    TIMERS[2].fn()
    CB(nil, "no", "region")
    c11("a Mac whose window cannot be named still gets its editor back",
        E.hidden == false and FOCUSED == false)
    NO_HSWINDOW = false

    -- ---- the report ------------------------------------------------------
    local rpt = _G.screenshotEditorReport()
    c11("the report is ONE string (6.179.1) and it is returned",
        type(rpt) == "string" and rpt:find("\n", 1, true) ~= nil)
    c11("…it counts asked / landed / failed apart",
        rpt:find("capture :", 1, true) ~= nil
        and rpt:find("landed", 1, true) ~= nil
        and rpt:find("failed", 1, true) ~= nil, rpt)
    -- 📐 6.342.0 — the report NAMES THE SHAPE, because a build that still
    -- hides and shoots the whole screen reads identically otherwise.
    c11("📐 …and it says what ⌘D does now — drag an area, then the seconds, "
        .. "then that rectangle",
        rpt:find("drag an area", 1, true) ~= nil
        and rpt:find("that rectangle", 1, true) ~= nil, rpt)
    -- the belt line is about WORDING: a return the belt made must be
    -- named, never folded into the ordinary counts (6.196.1). The run
    -- above deliberately left `late` at 0 to prove leg 1 does not
    -- double-report, so the state is set here rather than borrowed.
    E.delays.late = 1
    c11("…it names the belt's returns rather than printing health",
        _G.screenshotEditorReport():find("brought back by the belt", 1, true) ~= nil)
    c11("…and it carries the settings line that turns the hiding off",
        rpt:find("hideForDelay", 1, true) ~= nil
        and rpt:find("delaySecs = 5", 1, true) ~= nil, rpt)
    -- a cancel has to be visible in the report, or Esc is a silent number
    E.delays.cancelled = 3
    c11("🔎 …and a cancelled selection is in the report, not only in a counter",
        _G.screenshotEditorReport():find("3 cancelled", 1, true) ~= nil)
    -- 6.196.1 — never asked must not read like asked-and-nothing-happened
    E.delays = { asked = 0, landed = 0, failed = 0, late = 0, cancelled = 0 }
    local fresh = _G.screenshotEditorReport()
    c11("🔎 never asked reads differently from asked and failed",
        fresh:find("never asked", 1, true) ~= nil
        and fresh:find("0 asked", 1, true) == nil, fresh)

    E.close()
    check("§11 ran every one of its checks", n11 == 51, n11)
end

-- =====================================================================
out("\n12. 6.256.0 — ⌘F: the whole screen, NOW, with this window out of it\n")
-- =====================================================================
-- LL: "Add full screen snapshot tool." One body with ⌘D, one argument
-- apart: with a countdown screencapture's own -T covers the time the
-- window needs to leave the screen, and without one NOTHING does — so
-- the settle beat between the hide and the shutter IS this release.
do
    local n12 = 0
    local ASKED, CB    -- declared BEFORE the helpers, or `answer` closes
                       -- over a nil GLOBAL and every CB call is a no-op
    local function c12(label, cond, extra) n12 = n12 + 1; check(label, cond, extra) end
    -- 6.186.0 — a helper ANSWERS FALSELY rather than indexing a nil, or a
    -- mutation that removes a timer kills this section instead of failing
    -- a check in it.
    local function fire(i)
        local t = TIMERS[i]
        if not (t and type(t.fn) == "function") then return false end
        t.fn(); return true
    end
    local function answer(...)
        if type(CB) ~= "function" then return false end
        CB(...); return true
    end

    READABLE["/x/F.png"] = "PNGBYTES"
    CORE.has  = function(n) return PROVIDED[n] ~= nil end
    CORE.call = function(n, ...) return PROVIDED[n](...) end
    PROVIDED["screenshots.captureScreenTo"] = function(secs, cb)
        EVENTS[#EVENTS + 1] = "ask"; ASKED = secs; CB = cb; return true
    end

    E.close(); JS, ALERTS, EVENTS, TIMERS, DEGRADES = {}, {}, {}, {}, {}
    E.open("/x/F.png")
    c12("the page carries the 🖥 button, the ⌘F key and its door",
        LAST_HTML:find("say({a:'full'})", 1, true) ~= nil
        and LAST_HTML:find("id=\"btn-full\"", 1, true) ~= nil
        and LAST_HTML:find("e.key === 'f'", 1, true) ~= nil)

    EVENTS, TIMERS, ALERTS = {}, {}, {}
    BRIDGE({ body = { a = "full" } })
    c12("⌘F hides the editor and does NOT alert a countdown — there isn't one",
        E.hidden == true and #ALERTS == 0, ALERTS[1])
    c12("🚨 THE SHUTTER WAITS FOR THE WINDOW TO GO: belt, hide, settle — "
        .. "and NO ask yet. :hide() is not instant, and a screencapture on "
        .. "the next line photographs the editor",
        EVENTS[1] == "timer" and EVENTS[2] == "hide" and EVENTS[3] == "timer"
        and ASKED == nil, table.concat(EVENTS, ","))
    c12("…and the belt covers the settle as well as the countdown",
        TIMERS[1] and TIMERS[1].secs == 0 + E.hideSettleSecs + E.delayGraceSecs,
        TIMERS[1] and TIMERS[1].secs)
    c12("…the settle is its OWN held slot, never the belt's (6.196.1)",
        E.settleTimer ~= nil and E.delayTimer ~= nil
        and E.settleTimer ~= E.delayTimer)
    local beat = fire(2)   -- the window has gone; now the shutter
    c12("once the beat has passed the whole screen is asked for, no delay",
        beat and ASKED == 0 and type(CB) == "function", ASKED)

    local markerEncode = hs.base64.encode
    hs.base64.encode = function() return "V0hPTEVTQ1JFRU4=" end
    READABLE["/x/Whole.png"] = "WHOLESCREEN"
    answer("/x/Whole.png")
    hs.base64.encode = markerEncode
    c12("…and it lands on the shot as an image note, window back",
        E.hidden == false
        and JS[#JS] == "addImage('data:image/png;base64,V0hPTEVTQ1JFRU4=', 800, 600)",
        JS[#JS])

    -- a Mac that cannot arm the settle beat
    EVENTS, TIMERS, ASKED = {}, {}, nil
    NO_TIMER = true
    BRIDGE({ body = { a = "full" } })
    c12("🚨 no timer at all: it does NOT hide, and it still takes the shot — "
        .. "a picture with the editor in it beats no picture",
        E.hidden == false and ASKED == 0, table.concat(EVENTS, ","))
    NO_TIMER = false
    answer("/x/Whole.png")

    -- 🚨 6.255.0's wart, found building this one
    EVENTS, TIMERS, DEGRADES, ALERTS = {}, {}, {}, {}
    BRIDGE({ body = { a = "full" } })
    c12("a capture is running and the window is hidden",
        E.delayBusy == true and E.hidden == true)
    local belt = TIMERS[1]
    E.close()
    c12("🚨 CLOSING THE EDITOR MID-CAPTURE TEARS IT DOWN — the flags and "
        .. "BOTH timers, or the belt wakes to an editor HE closed",
        E.delayBusy == false and E.hidden == false
        and E.delayTimer == nil and E.settleTimer == nil
        and belt ~= nil and belt.stopped == true)
    fire(1)   -- even if it fires anyway, it must say nothing
    c12("…and a belt that fires anyway alerts nothing over a closed editor",
        #DEGRADES == 0, DEGRADES[1] and DEGRADES[1].why)

    check("§12 ran every one of its checks", n12 == 11, n12)
end

-- =====================================================================
out("13. 6.258.0 — ⌘O: a prior shot onto this one, and the canvas grows\n")
-- =====================================================================
-- LL: "Allow me to load a prior screenshot on to the current screenshot
-- and grow the canvas so that I can see both." The geometry is PURE and
-- lives in Lua, so all of it is proven here with no Mac and no WebKit;
-- the page is given the numbers and does them (its own section is in
-- test_editor_js.js).
do
    local n13 = 0
    local function c13(label, cond, extra) n13 = n13 + 1; check(label, cond, extra) end

    -- ---- which way it grows -------------------------------------------
    local ax, why = E.growAxis(2560, 1440)
    c13("🧭 a WIDE shot grows downwards — two of them stacked is nearly "
        .. "square, side by side is a 5120-pixel strip", ax == "down", ax)
    c13("...and says why", why == "a wide shot grows downwards", why)
    c13("🧭 a TALL shot grows sideways", E.growAxis(900, 1600) == "right")
    c13("a square canvas grows sideways — the tie has to go somewhere and "
        .. "it is stated rather than accidental", E.growAxis(800, 800) == "right")
    c13("a canvas with no size is not an axis", E.growAxis(0, 100) == nil)
    c13("...and says so", select(2, E.growAxis(nil, nil)) == "the canvas has no size")

    -- ---- the plan ------------------------------------------------------
    local p = E.growPlan(2560, 1440, 2560, 1440, nil, 12)
    c13("📐 two equal wide shots: the canvas keeps its width…",
        p and p.w == 2560, p and p.w)
    c13("…and grows by the second shot plus the gap",
        p and p.h == 1440 + 12 + 1440, p and p.h)
    c13("📏 THE ORIGINAL NEVER MOVES — it keeps 0,0, because every note, "
        .. "blur and arrow on this canvas is in canvas coordinates and "
        .. "would otherwise move with it", p and p.x == 0)
    c13("…and the loaded shot lands under it, past the gap",
        p and p.y == 1440 + 12, p and p.y)

    local wide = E.growPlan(1000, 800, 1600, 400, nil, 10)
    c13("📐 a WIDER shot widens the canvas rather than being cropped",
        wide and wide.w == 1600, wide and wide.w)
    c13("…and the original is STILL at 0,0 — centring it would be tidier "
        .. "and would move every mark he has already drawn",
        wide and wide.x == 0 and wide and wide.y == 810, wide and wide.y)

    local tall = E.growPlan(600, 1600, 500, 900, nil, 12)
    c13("📐 a tall canvas puts the loaded shot BESIDE it",
        tall and tall.axis == "right" and tall.x == 612 and tall.y == 0,
        tall and (tall.axis .. " " .. tall.x .. "," .. tall.y))
    c13("…and the canvas keeps the taller of the two",
        tall and tall.h == 1600 and tall.w == 600 + 12 + 500,
        tall and (tall.w .. "x" .. tall.h))

    c13("🔌 an axis given by name WINS over the computed one",
        (E.growPlan(2560, 1440, 100, 100, "right", 0) or {}).axis == "right")
    c13("…and an axis that is not one of the two falls back to the rule",
        (E.growPlan(2560, 1440, 100, 100, "sideways-ish", 0) or {}).axis == "down")
    c13("the gap is honoured", (E.growPlan(100, 100, 50, 50, "down", 30) or {}).y == 130)
    c13("a NEGATIVE gap is clamped to nothing — it would overlap the two "
        .. "shots, which is the one thing this feature must not do",
        (E.growPlan(100, 100, 50, 50, "down", -40) or {}).y == 100)
    c13("no gap at all is 0, never an error",
        (E.growPlan(100, 100, 50, 50, "down", nil) or {}).y == 100)
    c13("a shot with no size is refused", E.growPlan(100, 100, 0, 50) == nil)
    c13("…by name", select(2, E.growPlan(100, 100, 0, 50)) == "that shot has no size")
    c13("a canvas with no size is refused, and differently",
        select(2, E.growPlan(0, 0, 50, 50)) == "the canvas has no size")
    c13("the reason names both shots, so the report reads as a measurement",
        (select(2, E.growPlan(2560, 1440, 800, 600)) or ""):find("800x600", 1, true) ~= nil)

    -- ---- the window follows -------------------------------------------
    -- 🖼 6.270.0 — THE RAILS ARE ROOM, NOT PADDING. These checks used to
    -- assert 828 and 320, which were the numbers before there was a rail
    -- to fit; asserting a constant is how a check ends up with nothing to
    -- say about the change it should be proving (6.248.0). They ask the
    -- RULE now, in terms of the config, so moving a rail moves the check.
    local SCR = { x = 0, y = 0, w = 1440, h = 900 }
    local w1, h1 = E.windowSizeFor(800, 600, SCR)
    c13("🪟 a small shot gets its own size, the chrome, AND BOTH RAILS — "
        .. "the window grows; the picture is not squeezed to make room",
        w1 == 800 + 28 + E.railW * 2 and h1 == 600 + E.dragStripH + 28,
        w1 .. "x" .. h1 .. " (railW " .. tostring(E.railW) .. ")")
    c13("🪟 …which is strictly wider than the pre-rail window, or the "
        .. "buttons would be sitting on the screenshot",
        w1 > 828, w1)
    local w2, h2 = E.windowSizeFor(3840, 2160, SCR)
    c13("🪟 a 4K shot is CLAMPED to the screen rather than opening off it, "
        .. "rails included",
        w2 <= 1440 * 0.85 + 28 and h2 <= 900 * 0.85 + 82, w2 .. "x" .. h2)
    local w3, h3 = E.windowSizeFor(10, 10, SCR)
    c13("🪟 …and the floor now fits the TOOLBAR, not just a usable window: "
        .. "a tiny shot no longer opens too short to show its own tools",
        w3 == 720 and h3 == E.railMinH + E.dragStripH, w3 .. "x" .. h3)

    -- 6.239.0 — move the config and the arithmetic must follow. Asserting
    -- the shipped 136 passes on a build where the number is typed twice.
    -- 📐 6.407.0 — AND THIS CHECK HAD TO MOVE OFF AN 800x600 SHOT. The
    -- ceiling is 80% of the screen now, and 800 + 28 + two 200-pt rails is
    -- 1228 against a 1152-pt budget on this fixture — so the rule it is
    -- proving (the rails are RESERVED, so the window grows by twice the
    -- rail) only holds below the ceiling, and asserting it at the ceiling
    -- was asserting the old 85% in disguise (6.248.0, eighth time). The
    -- shot is 600x400 and the DIFFERENCE is asserted rather than the sum.
    local wNarrow = E.windowSizeFor(600, 400, SCR, { railW = 136, headerH = 54,
                                                     railMinH = 344 })
    local wWide = E.windowSizeFor(600, 400, SCR, { railW = 200, headerH = 54,
                                                   railMinH = 344 })
    c13("🪟 a WIDER rail makes a wider window, by exactly twice the "
        .. "difference — the reservation is real arithmetic, not a constant",
        wWide == 600 + 28 + 400 and (wWide - wNarrow) == 2 * (200 - 136),
        wNarrow .. " → " .. wWide)
    local wNone = E.windowSizeFor(800, 600, SCR, { railW = 0, headerH = 54,
                                                   railMinH = 0 })
    c13("🪟 …and with no rails at all it is the old window exactly, which "
        .. "is what proves the rails are the whole difference",
        wNone == 828, wNone)

    -- The picture must keep the size it would have had. A screen with room
    -- to spare must not shrink the shot just because rails now exist.
    local _, hPlain = E.windowSizeFor(800, 600, SCR, { railW = 0, headerH = 54,
                                                       railMinH = 0 })
    c13("🪟 the SHOT is unchanged by the rails on a screen with room — the "
        .. "height is the picture plus chrome either way",
        h1 == hPlain, h1 .. " vs " .. hPlain)

    -- A screen narrower than its own rails must not invert the arithmetic.
    local wTiny, hTiny = E.windowSizeFor(800, 600, { x = 0, y = 0, w = 200, h = 200 },
                                         { railW = 300, headerH = 54, railMinH = 344 })
    c13("🪟 a screen narrower than the rails themselves still answers a "
        .. "positive window rather than a negative one",
        type(wTiny) == "number" and wTiny > 0 and hTiny > 0, wTiny .. "x" .. hTiny)
    local w4 = E.windowSizeFor(nil, nil, nil)
    c13("🪟 garbage in does not throw — it sizes for a default shot",
        type(w4) == "number" and w4 > 0, w4)

    -- ---- the one door --------------------------------------------------
    c13("🔒 a png data URI is usable", E.imageURIok("data:image/png;base64,AAAB") == true)
    c13("🔒 a QUOTE is not — it would end the JavaScript string literal "
        .. "this URI is pushed inside, and a script WebKit cannot parse is "
        .. "dropped in SILENCE",
        E.imageURIok("data:image/png;base64,AA'+alert(1)+'") == false)
    c13("🔒 a plain path is not an image", E.imageURIok("/x/shot.png") == false)
    c13("🔒 nil is not an image, and does not throw", E.imageURIok(nil) == false)

    -- ---- the canvas size, and WHO says so ------------------------------
    JS = {}
    check("(the editor is open for this section)", E.open(SRC) == true)
    local cw, ch, who = E.canvasSize()
    c13("📏 before the page speaks, Lua uses the size it read off the FILE",
        cw == 800 and ch == 600, tostring(cw) .. "x" .. tostring(ch))
    c13("…and says that is where the number came from — a ⌘O this early "
        .. "still works, and the report does not pretend the page answered",
        who == "read off the file at open", who)
    BRIDGE({ body = { a = "size", w = 2560, h = 1440 } })
    local cw2, _, who2 = E.canvasSize()
    c13("📏 once the page says its size, THAT is the canvas", cw2 == 2560, cw2)
    c13("…and the report can tell the two apart (6.196.1)",
        who2 == "the page said so", who2)
    BRIDGE({ body = { a = "size", w = 0, h = 0 } })
    local cw3, _, who3 = E.canvasSize()
    c13("🚨 a size of zero is not an answer — it is ignored rather than "
        .. "believed, or the next grow plans against nothing",
        cw3 == 2560 and who3 == "the page said so", tostring(cw3))

    -- ---- the grow itself ------------------------------------------------
    JS = {}
    local okG, whyG = E.growWith("data:image/png;base64,SECOND", 2560, 1440)
    c13("🖼 the grow lands", okG == true, whyG)
    local grew = JS[#JS] or ""
    c13("…and the page is GIVEN the numbers rather than working them out",
        grew:find("growTo('data:image/png;base64,SECOND', 2560, 2892, 0, 1452", 1, true) ~= nil,
        grew)
    c13("…the fill colour rides with them", grew:find("#202127", 1, true) ~= nil)
    c13("🪟 the window grew with the canvas",
        VIEW.rect.w == E.windowSizeFor(2560, 2892, { w = 1440, h = 900 }),
        VIEW.rect.w)
    -- 🚨 THE BELT, ASSERTED WHERE IT BITES. "canvasSize now reads 2892"
    -- passes with the belt deleted too, because the old number is still a
    -- number — so the check is a SECOND ⌘O with no word from the page in
    -- between, which must plan against the canvas the first one made.
    JS = {}
    local okTwice = E.growWith("data:image/png;base64,THIRD", 2560, 1440)
    local twice = JS[#JS] or ""
    c13("🚨 a second ⌘O before the page has spoken again plans against the "
        .. "canvas the FIRST one made, not the one before it — and the "
        .. "axis is recomputed, so the now-TALL canvas grows sideways",
        okTwice == true
        and twice:find("2560x1440 beside", 1, true) == nil
        and twice:find("', 5132, 2892, 2572, 0", 1, true) ~= nil, twice:sub(1, 70))

    JS = {}
    local okBad, whyBad = E.growWith("/not/a/uri.png", 100, 100)
    c13("🔒 a refused URI never reaches WebKit", okBad == false and #JS == 0, #JS)
    c13("…and says why", whyBad == "not a usable image", whyBad)

    E.close()
    local okShut = E.growWith("data:image/png;base64,X", 10, 10)
    c13("a closed editor cannot grow", okShut == false)
    local _, _, whoShut = E.canvasSize()
    c13("🚨 and closing FORGETS the canvas — a size left behind is a grow "
        .. "planned against a page that no longer exists",
        whoShut == "not known", whoShut)

    -- ---- ⌘O's picker ----------------------------------------------------
    -- Earlier sections repoint CORE.has at their own registry, so this one
    -- claims it back rather than assuming what a section three hundred
    -- lines up left behind.
    SERVICES = {}
    CORE.has  = function(n) return SERVICES[n] ~= nil end
    CORE.call = function(n, ...) local f = SERVICES[n]; if f then return f(...) end end
    E.open(SRC)
    local okNo, whyNo = E.loadPrior()
    c13("🔌 with the screenshots module absent, ⌘O says so and changes "
        .. "nothing", okNo == false and (whyNo or ""):find("screenshots module", 1, true),
        whyNo)

    SERVICES["screenshots.list"] = function()
        return {
            { name = "Later.png",  path = "/od/2026 Screenshots/Later.png",
              mtime = 200, size = 2048 },
            { name = "Screenshot demo.png", path = SRC, mtime = 150, size = 1024 },
            { name = "Older.png",  path = "/od/2026 Screenshots/Older.png",
              mtime = 100, size = 512 },
        }
    end
    READABLE["/od/2026 Screenshots/Later.png"] = "FAKE-SECOND-PNG"
    CHOOSER = nil
    local okPick, whyPick = E.loadPrior()
    c13("🖼 ⌘O opens a picker of the folder's other shots", okPick == true
        and CHOOSER ~= nil and CHOOSER.shown == true, whyPick)
    -- 6.186.0 — every read of the picker below goes through these, so a
    -- mutation that stops it being made FAILS a check rather than ending
    -- the run at an index of nil.
    local function rowCount() return CHOOSER and #CHOOSER.rows or -1 end
    local function row(i)
        return (CHOOSER and CHOOSER.rows[i]) or { text = "(no picker)", path = "" }
    end
    c13("🚨 the shot he is ALREADY editing is not offered — loading a shot "
        .. "onto itself is the one row that can only be a mistake",
        rowCount() == 2 and row(1).text == "Later.png"
        and row(2).text == "Older.png", rowCount())
    c13("…each row carries its path and when it was taken",
        row(1).path == "/od/2026 Screenshots/Later.png"
        and (row(1).subText or ""):find("KB", 1, true) ~= nil,
        row(1).subText)
    c13("…and the picker is in the Esc registry like every other chooser "
        .. "here", _G.choosers.editorLoadShot == CHOOSER)

    JS = {}
    BRIDGE({ body = { a = "size", w = 800, h = 600 } })
    -- 🔒 THE DOOR BITES ON THE REAL ROUTE, and this suite's own encoder
    -- proves it: hs.base64.encode is stubbed here to a VISIBLE transform
    -- ("B64<…>") so other sections can see it ran — and those angle
    -- brackets are exactly what `ed.imageURIok` refuses, so a shot read
    -- off disk and encoded that way never reaches WebKit.
    if CHOOSER then CHOOSER:pick(1) end
    c13("🔒 a file whose encoding is not base64 is refused on the way in, "
        .. "on the path from DISK rather than only in a unit check",
        #JS == 0, JS[1])
    c13("…and the refusal is remembered for the report",
        (E.lastGrowWhy or "") == "not a usable image", E.lastGrowWhy)

    local realEncode = hs.base64.encode
    hs.base64.encode = function(bytes) return "SEC" .. #bytes end
    JS = {}
    _G.choosers.editorLoadShot = nil
    E.loadPrior()
    if CHOOSER then CHOOSER:pick(1) end
    hs.base64.encode = realEncode
    local pushed = JS[#JS] or ""
    c13("🖼 picking a row reads that file and grows the canvas — driven "
        .. "through the chooser's own callback, not by calling the grow "
        .. "by hand (6.203.0)",
        pushed:find("growTo(", 1, true) == 1, pushed:sub(1, 40))
    c13("…with the SECOND file's bytes, not the open one's",
        pushed:find("SEC15", 1, true) ~= nil, pushed:sub(1, 60))
    c13("…and the picker lets go of the registry when it answers",
        _G.choosers.editorLoadShot == nil)

    SERVICES["screenshots.list"] = function()
        return { { name = "Screenshot demo.png", path = SRC, mtime = 1, size = 1 } }
    end
    local okEmpty, whyEmpty = E.loadPrior()
    c13("a folder holding only this shot says so rather than opening an "
        .. "empty picker", okEmpty == false
        and (whyEmpty or ""):find("no other screenshots", 1, true) ~= nil, whyEmpty)

    -- ---- the report ------------------------------------------------------
    printed = {}
    local rep = _G.screenshotEditorReport()
    c13("🔎 the report prints as ONE string (6.179.1)", #printed == 1, #printed)
    c13("…it names the canvas and who said so",
        rep:find("canvas  :", 1, true) ~= nil
        and rep:find("the page said so", 1, true) ~= nil)
    c13("…and counts the grows", rep:find("grow    :", 1, true) ~= nil
        and rep:find("asked", 1, true) ~= nil, rep)

    E.close()
    E.open(SRC)
    printed = {}
    local rep2 = _G.screenshotEditorReport()
    local function line(rep, head)
        return rep:match("\n%s*" .. head .. "%s*:[^\n]*") or ""
    end
    c13("🔎 the counts are per SESSION, not per window — closing and "
        .. "reopening the editor does not forget what this session did",
        line(rep2, "grow") ~= ""
        and line(rep2, "grow"):find("never asked", 1, true) == nil,
        line(rep2, "grow"))
    E.grows.asked, E.grows.landed, E.grows.failed = 0, 0, 0
    printed = {}
    local rep3 = _G.screenshotEditorReport()
    c13("🔎 …and a session with no ⌘O in it reads DIFFERENTLY from one "
        .. "where every grow failed (6.196.1)",
        rep3:find("never asked this session", 1, true) ~= nil)
    E.close()

    check("§13 ran every one of its checks", n13 == 66, n13)
end

-- =====================================================================
out("\n14. 🚪 6.286.0 — the work survives EVERY door out, not just Cancel\n")
-- =====================================================================
-- LL, with an annotated screenshot: "Closing the screenshot editor dumps
-- the most recent edits so I lose any changes." 6.189.0 promises the
-- opposite and was telling the truth about exactly ONE way out — the
-- Cancel button, which is the only thing that called the page's
-- stashAndCancel(). The Esc router called ed.close() straight out, and
-- ed.open() calls ed.close() as its first line, so opening a second shot
-- threw the first one's marks away in silence.
do
    local n14 = pass + fail
    local function c14(l, cond, extra) check(l, cond, extra) end

    -- ---- the plan is PURE ------------------------------------------------
    c14("ed.closePlan is pure and reachable", type(E.closePlan) == "function")
    local p1 = E.closePlan(false, true, true)
    c14("no editor open → close now", p1 == "now", p1)
    local p2 = E.closePlan(true, false, true)
    c14("a page that cannot be asked → close now, rather than waiting on an "
        .. "answer nothing would send", p2 == "now", p2)
    local p3 = E.closePlan(true, true, false)
    c14("🚨 no timer → ASK and close anyway. A window that will not close is "
        .. "worse than marks that were not kept", p3 == "askThenNow", p3)
    local p4 = E.closePlan(true, true, true)
    c14("otherwise: ask the page first", p4 == "ask", p4)
    c14("…and every answer carries its reason",
        select(2, E.closePlan(true, true, true)) ~= nil
        and select(2, E.closePlan(false, true, true)) ~= nil)

    -- ---- Esc through the router -----------------------------------------
    E.close()
    E.closes = { asked = 0, stashed = 0, belt = 0, atOnce = 0, last = nil }
    E.kept = nil
    TIMERS = {}
    JS = {}
    E.open(SRC)
    c14("the editor is open", E.webview ~= nil)
    EVENTS = {}          -- the ordering below is about THIS close alone
    E.requestClose("Esc")
    c14("🚨 Esc ASKS THE PAGE for its work instead of deleting the window — "
        .. "this is the whole release", JS[#JS] == "stashAndCancel()", JS[#JS])
    c14("…and the window is still open while it waits", E.webview ~= nil)
    c14("…with a belt armed BEFORE the ask (6.246.0's ordering), so a page "
        .. "that throws cannot leave a window nobody can close",
        E.closeTimer ~= nil and E.closeTimer.secs == E.closeGraceSecs)
    -- 🚨 AND THE ORDER IS THE RULE, not the presence. A check that only
    -- asserts both happened passes with the belt armed second, which is
    -- the arrangement the ordering exists to forbid (6.220.0).
    c14("🚨 …and the ORDER is asserted, not just that both happened", (function()
        local lastTimer, firstJs
        for i, e in ipairs(EVENTS) do
            if e == "timer" then lastTimer = i end
            if e == "js" and not firstJs then firstJs = i end
        end
        return lastTimer ~= nil and firstJs ~= nil and lastTimer < firstJs
    end)(), table.concat(EVENTS, ","))
    -- the page answers
    BRIDGE({ body = { a = "cancel", img = KEEPIMG, notes = NOTES } })
    c14("…the page answers, the work is kept", E.kept ~= nil and E.kept.path == SRC)
    c14("…the window closes", E.webview == nil)
    c14("…and the belt is torn down, not left to fire over the next editor",
        E.closeTimer == nil)
    c14("…counted: one ask, one stash, no belt close",
        E.closes.asked == 1 and E.closes.stashed == 1 and E.closes.belt == 0,
        E.closes.asked .. "/" .. E.closes.stashed .. "/" .. E.closes.belt)

    -- ---- the belt --------------------------------------------------------
    E.kept = nil
    TIMERS = {}
    E.open(SRC)
    E.requestClose("Esc")
    local belt = TIMERS[#TIMERS]
    c14("a page that never answers still gets closed — by the belt",
        belt ~= nil and E.webview ~= nil)
    belt.fn()
    c14("…the window really goes", E.webview == nil)
    c14("…nothing was kept, because nothing was handed back", E.kept == nil)
    c14("🔎 …and it is COUNTED APART: a belt close is the bug to report, and "
        .. "it must not read like a clean one", E.closes.belt == 1)

    -- 🚨 AND close() ITSELF TEARS THE BELT DOWN. The cancel branch cannot
    -- prove this — it calls close() on every path — so the check has to
    -- drive the door that reaches close() with a belt still running: ⌘⏎,
    -- or any direct close. A belt left armed fires over the NEXT editor,
    -- which is 6.266.0's orphan class in a timer.
    E.kept = nil
    TIMERS = {}
    E.open(SRC)
    E.requestClose("Esc")
    c14("a belt is running", E.closeTimer ~= nil)
    E.close()
    c14("🚨 …and a direct close tears it down, so it cannot fire over the "
        .. "NEXT editor", E.closeTimer == nil)

    -- ---- ⇪⇧1 on another shot --------------------------------------------
    -- 🚨 THE DOOR HE IS MOST LIKELY PRESSING. ed.open()'s first line has
    -- always been ed.close(); the slot is keyed by path, so his marks would
    -- have come back — if anything had ever put them in it.
    E.kept = nil
    JS = {}
    E.open(SRC)
    E.open(OTHER)
    c14("🚨 opening ANOTHER shot asks the first one's page for its work "
        .. "before the window goes", JS[#JS] == "stashAndCancel()", JS[#JS])
    c14("…and the new editor really opened", E.webview ~= nil
        and E.currentPath == OTHER, tostring(E.currentPath))

    -- ---- the degrades ----------------------------------------------------
    E.close()
    E.closes = { asked = 0, stashed = 0, belt = 0, atOnce = 0, last = nil }
    NO_TIMER = true
    TIMERS = {}
    JS = {}
    E.open(SRC)
    E.requestClose("Esc")
    c14("🛟 a Mac that cannot arm a timer STILL asks the page…",
        JS[#JS] == "stashAndCancel()")
    c14("🛟 …and still closes, rather than waiting on an answer nothing "
        .. "would end", E.webview == nil)
    NO_TIMER = false
    -- nothing open at all
    local before = E.closes.asked
    E.requestClose("Esc")
    c14("closing when nothing is open asks nobody and throws nothing",
        E.closes.asked == before and E.webview == nil)

    -- ---- the report ------------------------------------------------------
    local rep = E.report and E.report() or nil
    if not rep then
        local printed = {}
        local rp = print
        print = function(...) local t = {}
            for i = 1, select("#", ...) do t[#t+1] = tostring((select(i, ...))) end
            printed[#printed+1] = table.concat(t, " ") end
        _G.screenshotEditorReport()
        print = rp
        rep = table.concat(printed, "\n")
    end
    c14("🔎 the report names WHICH door and whether the work survived it — "
        .. "'closed' used to be one fact and it was four",
        rep:find("closing :", 1, true) ~= nil, rep)
    c14("…and the last close is named", rep:find("↳ last  :", 1, true) ~= nil)

    -- ---- 🚨 SOURCE: no door may call ed.close() behind the page's back ---
    do
        local fh = assert(io.open(HS .. "/modules/screenshot_editor.lua"))
        local src = fh:read("a"); fh:close()
        local code = {}
        for line in (src .. "\n"):gmatch("([^\n]*)\n") do
            code[#code + 1] = (line:gsub("%-%-.*$", ""))
        end
        code = table.concat(code, "\n")
        -- 🚨 `closeOnEscape` let WebKit close the window itself, racing the
        -- page's own Escape handler — so even the path 6.189.0 built was a
        -- coin toss. Comments stripped (6.262.0), because the comment
        -- explaining the rule quotes the call it forbids.
        c14("🚨 SOURCE: the window no longer closes itself on Escape behind "
            .. "Lua's back", code:find("closeOnEscape") == nil)
        c14("🚨 SOURCE: the Esc router asks before it closes", (function()
            local at = code:find('claimEscape%("shoteditor"')
            if not at then return false end
            local blk = code:sub(at, at + 400)
            return blk:find("requestClose", 1, true) ~= nil
                   and blk:find("function() ed.close() end", 1, true) == nil
        end)())
        c14("🚨 SOURCE: opening another shot asks first too", (function()
            local blk = code:match("function ed%.open%(path%).-ed%.close%(%)")
            return blk ~= nil and blk:find("requestClose", 1, true) ~= nil
        end)())
    end

    c14("§14 ran every one of its checks", (pass + fail) - n14 == 31,
        (pass + fail) - n14)
end

-- =======================================================================
-- 15. 📐 6.407.0 — THE CEILING, AND WHAT HAPPENS WHEN IT MEETS THE FLOOR
-- =======================================================================
-- LL: "the editor window is growing too big … 80% of the largest
-- screenshot size … but not shrink down so much that the tools are not
-- usable." The FLOOR half is 6.270.0's and is checked above. What was
-- missing is a ceiling that is not only a fraction — 0.85 of a screen is
-- sensible on a laptop and absurd on his LG at full points — and a rule
-- for the case where the two contradict each other.
do
    local n15 = pass + fail
    local function c15(what, ok, got) check(what, ok, got) end
    local E = _G.screenshotEditor
    local AIR = { x = 0, y = 0, w = 1440, h = 900 }
    local LG  = { x = 0, y = 0, w = 3840, h = 2160 }

    -- ---- his number, and it binds on a laptop ------------------------
    local w, h, why = E.windowSizeFor(3840, 2160, AIR)
    c15("📐 a 4K shot on the laptop is capped at 80% of the screen — HIS"
        .. " number, not the 85% it shipped with",
        w <= math.floor(AIR.w * 0.80) and h <= math.floor(AIR.h * 0.80),
        w .. "x" .. h .. " of " .. math.floor(AIR.w * 0.80) .. "x" .. math.floor(AIR.h * 0.80))
    c15("...and it SAYS which bound decided, because 'too big' and 'too"
        .. " small' are opposite complaints about one function",
        tostring(why):find("80%% of the screen") ~= nil, why)

    -- ---- 🔑 AND A FRACTION ALONE IS WRONG ON A BIG DISPLAY -----------
    -- This is the half that answers him: on his LG at full points, 80% is
    -- 3072 × 1728, which is not a window anybody wants. The absolute cap
    -- is what makes the ceiling mean something there.
    local wl, hl, whyl = E.windowSizeFor(3840, 2160, LG)
    c15("📐 the same 4K shot on a 4K display is capped ABSOLUTELY, not at"
        .. " 80% of an enormous screen — 0.80 × 3840 is 3072 points, and a"
        .. " window that wide is the complaint, not the fix",
        wl <= E.maxW and hl <= E.maxH, wl .. "x" .. hl
        .. " (caps " .. E.maxW .. "x" .. E.maxH .. ")")
    c15("...and the smaller of the two ceilings wins, so the fraction is"
        .. " what binds on the laptop and the cap is what binds on the LG",
        w < wl and tostring(whyl):find("maximum window", 1, true) ~= nil,
        tostring(whyl))
    c15("...and the shot is SCALED to fit rather than the window being"
        .. " allowed past it — the canvas has always scaled, so capping"
        .. " the window costs nothing but reading distance",
        wl < 3840)

    -- ---- the config moves and the arithmetic follows (6.239.0) --------
    local wNar = E.windowSizeFor(3840, 2160, LG, { maxW = 900, maxH = 700 })
    c15("📐 moving the cap moves the window, so the number is read and not"
        .. " typed in twice", wNar <= 900, wNar)
    local wFrac = E.windowSizeFor(3840, 2160, AIR, { maxFrac = 0.5 })
    c15("...and so does the fraction", wFrac <= math.floor(AIR.w * 0.5), wFrac)

    -- 🚨 a settings typo must not produce a window of nothing
    local wBad = E.windowSizeFor(800, 600, AIR, { maxFrac = 0 })
    c15("📐 a fraction of 0 from a settings typo falls back to the default"
        .. " rather than opening a window with no room in it",
        wBad >= E.minW, wBad)
    local wBad2 = E.windowSizeFor(800, 600, AIR, { maxFrac = 9 })
    c15("...and a fraction over 1 does too", wBad2 <= AIR.w, wBad2)

    -- ---- 🚨 THE FLOOR AND THE CEILING CAN CONTRADICT, AND NOTHING -----
    -- DECIDED WHICH WON. On a short screen the tool rails need more height
    -- than the whole display has, and `math.max` let the floor win in
    -- silence: a window taller than the screen, whose buttons cannot be
    -- clicked. The rails SCROLL (6.270.0 built that); a window you cannot
    -- reach does not.
    local TINY = { x = 0, y = 0, w = 500, h = 360 }
    local wt, ht, whyt = E.windowSizeFor(1200, 900, TINY)
    c15("📐 a screen too short for the tool rails gets a window that FITS"
        .. " THE SCREEN — the rails scroll, and a window off the screen"
        .. " does not", ht <= TINY.h and wt <= TINY.w, wt .. "x" .. ht
        .. " on " .. TINY.w .. "x" .. TINY.h)
    c15("...and it says so, so a scrolling rail is a decision he was told"
        .. " about rather than a surprise",
        tostring(whyt):find("clamped to the screen", 1, true) ~= nil, whyt)
    c15("...and the floor still wins wherever the screen can hold it",
        select(2, E.windowSizeFor(10, 10, AIR)) == E.railMinH + E.dragStripH,
        select(2, E.windowSizeFor(10, 10, AIR)))
    c15("...which is the one input where the two rules must differ — on a"
        .. " roomy screen they agree and the clamp proves nothing (6.230.0)",
        tostring(select(3, E.windowSizeFor(10, 10, AIR))):find("floored", 1, true) ~= nil,
        select(3, E.windowSizeFor(10, 10, AIR)))

    -- ---- the window never exceeds the screen, whatever it is asked ----
    for _, scr in ipairs({ AIR, LG, TINY, { x = 0, y = 0, w = 200, h = 150 } }) do
        for _, shot in ipairs({ { 1, 1 }, { 10, 10 }, { 800, 600 }, { 3840, 2160 },
                                { 8000, 100 }, { 100, 8000 } }) do
            local ww, hh = E.windowSizeFor(shot[1], shot[2], scr)
            if ww > scr.w or hh > scr.h or ww < 1 or hh < 1 then
                c15("📐 a window is never bigger than its screen nor smaller"
                    .. " than nothing — " .. shot[1] .. "x" .. shot[2]
                    .. " on " .. scr.w .. "x" .. scr.h, false, ww .. "x" .. hh)
                goto done
            end
        end
    end
    c15("📐 a window is never bigger than its screen nor smaller than"
        .. " nothing, over every shot and screen in the sweep", true)
    ::done::

    -- ---- the report says which rule produced this window --------------
    local r = tostring(_G.screenshotEditorReport() or "")
    c15("the report names the ceiling in both forms, so 'too big' is a"
        .. " number he can argue with", r:find("ceiling :") ~= nil, r)
    c15("...and names which rule sized the window that is open",
        r:find("sized   :") ~= nil, r)

    c15("§15 ran every one of its checks", (pass + fail) - n15 == 16,
        (pass + fail) - n15)
end


-- =======================================================================
-- 16. ✂️ 6.414.0 — THE CROP TOOL (D7's second half)
-- =======================================================================
-- "I needed a tool that allows me to crop it." The rectangle is an
-- ordinary box note, so the hit test, the move, the size handle and ⌘Z
-- serve it with no new code — what is new is the PLAN (Lua's, so the gate
-- can drive it), the refusals, and the window following the new shape.
do
    local n16 = pass + fail
    local function c16(what, ok, got) check(what, ok, got) end
    local E = _G.screenshotEditor

    -- ---- the PURE plan ------------------------------------------------
    local r, why = E.cropPlan(800, 600, 100, 50, 400, 300)
    c16("✂️ an ordinary rectangle is kept as drawn",
        r and r.x == 100 and r.y == 50 and r.w == 400 and r.h == 300, why)
    c16("…and the reason names what is kept out of what",
        tostring(why):find("400 × 300 kept out of 800 × 600", 1, true) ~= nil, why)

    -- 🚨 THE PAGE'S NORMALISATION IS NOT TRUSTED. The corner drag answers
    -- a positive w/h today; a service caller, a restored session or a
    -- later edit need not, and the weaker guard is the one nobody can see
    -- (6.273.0).
    local rNeg = E.cropPlan(800, 600, 500, 350, -400, -300)
    c16("✂️ a side dragged the other way is the SAME rectangle",
        rNeg and rNeg.x == 100 and rNeg.y == 50 and rNeg.w == 400 and rNeg.h == 300,
        rNeg and (rNeg.x .. "," .. rNeg.y .. " " .. rNeg.w .. "x" .. rNeg.h))

    local rOff = E.cropPlan(800, 600, -50, -50, 400, 300)
    c16("✂️ a rectangle dragged off the top-left is clamped INTO the shot,"
        .. " because asking for pixels that are not there is a blank strip",
        rOff and rOff.x == 0 and rOff.y == 0 and rOff.w == 350 and rOff.h == 250,
        rOff and (rOff.x .. "," .. rOff.y .. " " .. rOff.w .. "x" .. rOff.h))
    local rOff2 = E.cropPlan(800, 600, 600, 400, 400, 400)
    c16("…and off the bottom-right the same way",
        rOff2 and rOff2.w == 200 and rOff2.h == 200,
        rOff2 and (rOff2.w .. "x" .. rOff2.h))

    -- 🔒 THE FIXTURE A NAIVE IMPLEMENTATION AGREES WITH EVERYWHERE ELSE
    -- (6.230.0): cropping to the WHOLE shot spends an undo row, resizes
    -- nothing, and reads as a key that did not work.
    local rAll, whyAll = E.cropPlan(800, 600, 0, 0, 800, 600)
    c16("✂️ a rectangle that IS the whole shot is refused, not obeyed",
        rAll == nil and tostring(whyAll):find("nothing to crop away", 1, true) ~= nil,
        tostring(whyAll))
    local rBig = E.cropPlan(800, 600, 0, 0, 9000, 9000)
    c16("…and so is one bigger than the shot, which clamps to the whole of it",
        rBig == nil, rBig and "a plan")

    -- the floor, and it NAMES THE SIZE: "6 × 4" is the whole diagnosis of
    -- a mis-drag, where "refused" sends a reader nowhere (6.336.0)
    local rTiny, whyTiny = E.cropPlan(800, 600, 10, 10, 6, 4)
    c16("✂️ a mis-drag is refused AND the size is in the sentence",
        rTiny == nil and tostring(whyTiny):find("6 × 4", 1, true) ~= nil,
        tostring(whyTiny))

    local rNil, whyNil = E.cropPlan(800, 600)
    c16("✂️ no rectangle at all says what to do, and names the key",
        rNil == nil and tostring(whyNil):find("Crop tool (K)", 1, true) ~= nil,
        tostring(whyNil))
    c16("✂️ a canvas with no size is refused before anything else",
        E.cropPlan(0, 0, 1, 1, 100, 100) == nil)
    local _, whyGone = E.cropPlan(800, 600, 2000, 2000, 100, 100)
    c16("✂️ a rectangle entirely off the shot says so rather than clamping"
        .. " to a strip",
        tostring(whyGone):find("off the shot", 1, true) ~= nil, tostring(whyGone))

    -- 6.239.0 — MOVE the config and require the rule to follow, rather
    -- than asserting the shipped 32 (which passes when it is typed twice)
    local savedMin = E.cropMin
    E.cropMin = 200
    local rMid, whyMid = E.cropPlan(800, 600, 0, 0, 100, 100)
    c16("✂️ the floor is read off ed.cropMin, not typed into the rule",
        rMid == nil and tostring(whyMid):find("200 × 200", 1, true) ~= nil,
        tostring(whyMid))
    E.cropMin = 1
    c16("…and a floor of 1 lets a tiny rectangle through, so the refusal"
        .. " really is the config and not a second constant",
        E.cropPlan(800, 600, 0, 0, 2, 2) ~= nil)
    E.cropMin = savedMin

    -- ---- the DOOR: the page asks, Lua decides, the page is given the
    --      numbers, and the WINDOW follows the new shape ---------------
    E.open(SRC)
    BRIDGE({ body = { a = "size", w = 800, h = 600 } })
    local wideRect = VIEW:frame()
    JS = {}; ALERTS = {}
    E.crops = { asked = 0, landed = 0, refused = 0 }
    BRIDGE({ body = { a = "crop", x = 100, y = 50, w = 400, h = 300 } })
    local pushed = table.concat(JS, "\n")
    c16("✂️ the page's ask reaches cropTo with the PLANNED numbers",
        pushed:find("cropTo(100, 50, 400, 300)", 1, true) ~= nil, pushed)
    c16("…and it is counted as cropped, not as refused",
        E.crops.asked == 1 and E.crops.landed == 1 and E.crops.refused == 0,
        E.crops.asked .. "/" .. E.crops.landed .. "/" .. E.crops.refused)
    c16("…nothing was alerted, because nothing was refused",
        #ALERTS == 0, table.concat(ALERTS, " | "))
    -- 🔑 ONLY LUA CAN RESIZE THE WINDOW, and a crop needs it: the canvas
    -- is scaled to fit, so a cropped shot in the old window is drawn
    -- BIGGER and blurrier than it was.
    local narrow = VIEW:frame()
    c16("✂️ the WINDOW follows the crop — a smaller shot gets a smaller"
        .. " window, or the canvas is scaled up and goes blurry",
        narrow.w < wideRect.w, wideRect.w .. " → " .. narrow.w)

    -- a refusal: nothing pushed, counted apart, and SEEN (6.214.0)
    JS = {}; ALERTS = {}
    BRIDGE({ body = { a = "crop", x = 0, y = 0, w = 4, h = 4 } })
    c16("✂️ a refused crop pushes NOTHING into the page",
        table.concat(JS, "\n"):find("cropTo", 1, true) == nil,
        table.concat(JS, "\n"))
    c16("…is counted as refused rather than cropped",
        E.crops.refused == 1 and E.crops.landed == 1,
        E.crops.landed .. "/" .. E.crops.refused)
    c16("…and is SEEN on screen at the moment it happens, with the size"
        .. " in it (6.214.0 — a break is seen, never only logged)",
        #ALERTS == 1 and ALERTS[1]:find("4 × 4", 1, true) ~= nil,
        table.concat(ALERTS, " | "))

    -- the button with no rectangle at all
    JS = {}; ALERTS = {}
    BRIDGE({ body = { a = "crop" } })
    c16("✂️ ✂︎ Crop to it with no rectangle drawn answers in one sentence"
        .. " rather than doing nothing",
        #ALERTS == 1 and ALERTS[1]:find("Crop tool (K)", 1, true) ~= nil,
        table.concat(ALERTS, " | "))

    -- ---- `fit` is ADDITIVE: the fixture where right and wrong differ --
    -- Every sender before 6.414.0 passes nothing and must be unaffected;
    -- the undo of a crop passes fit and must move the window.
    BRIDGE({ body = { a = "size", w = 800, h = 600, fit = true } })
    local back = VIEW:frame()
    c16("✂️ the undo of a crop asks for the window too, and gets it",
        back.w > narrow.w, narrow.w .. " → " .. back.w)
    local before = VIEW:frame()
    BRIDGE({ body = { a = "size", w = 200, h = 150 } })
    c16("…while a plain size message only RECORDS, as it has since"
        .. " 6.258.0 — the one input where additive and intrusive differ",
        VIEW:frame().w == before.w and E.canvasW == 200,
        VIEW:frame().w .. " (canvas " .. tostring(E.canvasW) .. ")")

    -- ---- the report ---------------------------------------------------
    local function line(rep, head)
        return rep:match("\n%s*" .. head .. "%s*:[^\n]*") or ""
    end
    local rep = tostring(_G.screenshotEditorReport() or "")
    c16("✂️ the report counts the crops APART from the grows",
        line(rep, "crop"):find("asked", 1, true) ~= nil
        and line(rep, "crop"):find("refused", 1, true) ~= nil, line(rep, "crop"))
    c16("…and names the floor, so 'it refused' is a number he can argue with",
        rep:find("a crop is at least " .. math.floor(E.cropMin), 1, true) ~= nil, rep)
    E.crops = { asked = 0, landed = 0, refused = 0 }
    E.lastCrop, E.lastCropWhy = nil, nil
    local rep2 = tostring(_G.screenshotEditorReport() or "")
    c16("✂️ a session with no crop in it reads DIFFERENTLY from one with"
        .. " a crop that failed (6.196.1)",
        line(rep2, "crop"):find("never asked", 1, true) ~= nil, line(rep2, "crop"))
    E.close()

    -- ---- the page ------------------------------------------------------
    E.open(SRC)
    local l = LAST_HTML:match('<nav id="railL".-</nav>') or ""
    c16("✂️ ✂︎ Crop is a TOOL, in the left rail with the other nine",
        l:find('id="tool-crop"', 1, true) ~= nil)
    local rr = LAST_HTML:match('<nav id="railR".-</nav>') or ""
    c16("…and the commit has a clickable door too, not only a key"
        .. " (6.317.0 — the instrument was not the gap, the door was)",
        rr:find("cropAsk()", 1, true) ~= nil)
    local hdr = LAST_HTML:match("<header>.-</header>") or ""
    c16("…and NOTHING of it was left behind in the top strip",
        hdr:find("setTool(", 1, true) == nil
        and hdr:find("cropAsk", 1, true) == nil)
    c16("✂️ K arms it from the keyboard", LAST_HTML:find("setTool('crop')", 1, true) ~= nil
        and LAST_HTML:find("e.key === 'k'", 1, true) ~= nil)
    c16("✂️ ⏎ commits it, and AFTER the text branch so a selected text box"
        .. " keeps the key it has had since 6.207.0",
        (function()
            local iText = LAST_HTML:find("startText(sel)", 1, true)
            local iCrop = LAST_HTML:find("cropAsk();", 1, true)
            return iText and iCrop and iCrop > iText
        end)())
    -- 🔒 THE RULE THAT STOPS A DIM OVERLAY BEING BURNED INTO A SAVED SHOT
    c16("✂️ the dim is drawn only for the SCREEN — saveIt bakes with"
        .. " withSel false, so the mask is behind that flag",
        LAST_HTML:find("if (withSel) drawCropMask(g);", 1, true) ~= nil
        and LAST_HTML:find("drawAll(ctx, false)", 1, true) ~= nil)
    c16("✂️ …and drawNote draws nothing at all for the kind, which is the"
        .. " belt on the same promise",
        LAST_HTML:find("n.kind === 'spot' || n.kind === 'crop'", 1, true) ~= nil)
    c16("✂️ the dim is written from ed.cropDim, not typed into the page",
        LAST_HTML:find("var CROPDIM = " .. tostring(E.cropDim), 1, true) ~= nil,
        tostring(E.cropDim))
    E.close()
    local savedDim = E.cropDim
    E.cropDim = 0.41
    E.open(SRC)
    c16("…and MOVING it moves the drawing (6.239.0)",
        LAST_HTML:find("var CROPDIM = 0.41", 1, true) ~= nil)
    E.close()
    E.cropDim = savedDim

    c16("§16 ran every one of its checks", (pass + fail) - n16 == 35,
        (pass + fail) - n16)
end

-- =====================================================================
-- 🖼 §17 — 6.415.0: THE LOADED SHOT IS A MARK, NOT PIXELS
-- =====================================================================
-- ⌘O used to draw the prior shot straight into the canvas, so where it
-- landed was where it stayed for ever — LL: "I should be able to position
-- the second screenshot on top of the second or where I want." It is an
-- ordinary `img` note now, at its OWN measured size, at the offset the
-- grow planned. This section proves the three things Lua owns: the size
-- really is handed over, it is the SHOT's and not the canvas's, and the
-- one-line explanation is said once rather than on every load.
do
    local n17 = pass + fail
    local function c17(name, ok, got) check("§17 " .. name, ok, got) end

    E.open(SRC)
    BRIDGE({ body = { a = "size", w = 800, h = 600 } })
    JS = {}; ALERTS = {}
    E.growSaid = false
    E.grows = { asked = 0, landed = 0, failed = 0 }

    local okG = E.growWith("data:image/png;base64,SECOND", 158, 65)
    local pushed = JS[#JS] or ""
    c17("🖼 the shot's own size reaches the page", okG == true
        and pushed:find(", 158, 65)", 1, true) ~= nil, pushed)
    -- 🔑 THE FIXTURE WHERE RIGHT AND WRONG MUST DIFFER (6.230.0): a page
    -- that drew the mark at the CANVAS size would look right on a shot
    -- the same size as the room. 158x65 under 800x600 can only come from
    -- the measured file.
    c17("…and it is the SHOT's size, never the new canvas's",
        pushed:find(", 800, 677, 0, 612, ", 1, true) ~= nil
        and pushed:find(", 800, 677)", 1, true) == nil, pushed)
    c17("…at the offset the grow planned, so it lands in the new room",
        pushed:find(", 0, 612, ", 1, true) ~= nil, pushed)

    -- 6.239.0 — move the input and require the push to follow, rather
    -- than asserting a number that passes when it is typed twice
    JS = {}
    E.growWith("data:image/png;base64,THIRD", 90, 40)
    c17("…and MOVING the measured size moves what is pushed",
        (JS[#JS] or ""):find(", 90, 40)", 1, true) ~= nil, JS[#JS])

    -- 🖼 SAID ONCE. The line answers a question he has on his first
    -- load; one on every load is one he stops reading (6.269.0).
    c17("🖼 the first load SAYS it is a mark he can drag (6.203.0)",
        #ALERTS == 1 and ALERTS[1]:find("mark now", 1, true) ~= nil,
        table.concat(ALERTS, " | "))
    c17("…and names the way back in the same breath",
        #ALERTS == 1 and ALERTS[1]:find("⌘Z", 1, true) ~= nil,
        table.concat(ALERTS, " | "))
    c17("…and the SECOND load is silent, while still landing",
        E.grows.landed == 2 and #ALERTS == 1,
        E.grows.landed .. " landed, " .. #ALERTS .. " alert(s)")

    -- 🚨 A REFUSAL MUST NOT SPEND THE ONE LINE. If it did, the first
    -- load that really worked would be the silent one — which is the
    -- whole release going unexplained on exactly the Mac that needed it.
    E.growSaid = false
    ALERTS = {}; JS = {}
    local okBad = E.growWith("/not/a/uri.png", 100, 100)
    c17("🔒 a refused grow neither pushes nor speaks",
        okBad == false and #JS == 0 and #ALERTS == 0,
        #JS .. " pushed, " .. #ALERTS .. " alert(s)")
    ALERTS = {}
    E.growWith("data:image/png;base64,FOURTH", 50, 50)
    c17("…so the next real load is the one that explains itself",
        #ALERTS == 1, table.concat(ALERTS, " | "))

    -- the report NAMES THE SHAPE, as 6.342.0's ⌘D line does: a build that
    -- still bakes the pixels in looks identical in every count above
    local rep = _G.screenshotEditorReport()
    c17("🖼 the report says what a loaded shot IS",
        rep:find("the loaded shot is a MARK", 1, true) ~= nil, "no ⌘O line")
    c17("…and that it may go over the first, which is what he asked for",
        rep:find("even over the first", 1, true) ~= nil)
    E.close()
    local repShut = _G.screenshotEditorReport()
    c17("…and the line is there before a single ⌘O, because it describes"
        .. " the tool rather than a count",
        repShut:find("the loaded shot is a MARK", 1, true) ~= nil)

    -- the cheat sheet is part of the surface (6.181.0: a sheet that
    -- promises the old behaviour IS a broken feature)
    local sheetSaysMark = false
    for _, row in ipairs(M.cheatsheet.entries or {}) do
        if row[1] == "⌘O" and tostring(row[2]):find("MARK", 1, true) then
            sheetSaysMark = true
        end
    end
    c17("📋 ⌘O's card row says the shot is a mark you can drag",
        sheetSaysMark)

    c17("§17 ran every one of its checks", (pass + fail) - n17 == 13,
        (pass + fail) - n17)
end

-- =====================================================================
out("\n18. 🪟 6.424.0 — a window macOS refuses is never left on screen\n")
-- =====================================================================
-- LL: "I was taking a screenshot that went fine. Then, after I brought
-- up the editor I now have a white box that won't go away." His Console
-- at 08:44:18 carried the diagnosis — "Screenshot editor: macOS raised
-- while ordering the window on screen" — and everything after that line
-- carried on as though the show had worked.
do
    local n18 = pass + fail
    local function c18(l, ok, x) check(l, ok, x) end

    E.close()
    -- ---- 1. macOS RAISES, with the shared door in place ---------------
    _G.showWebviewSafely = function(view, label)
        local answer
        local ok = pcall(function() answer = view:show() end)
        if ok and answer ~= false then return true, "shown" end
        return false, ok and "macOS would not put the window on screen"
                          or "macOS raised while ordering the window on screen"
    end
    SHOW_MODE = "throw"
    EVENTS, DEGRADES = {}, {}
    local opened = E.open(SRC)
    c18("a refused show makes open() answer FALSE, not true", opened == false,
        tostring(opened))
    c18("…and NOTHING is published — the handle is a claim about the world"
        .. " and the world said no (6.326.0)", E.webview == nil)
    c18("…and the window is torn down rather than abandoned",
        VIEW ~= nil and VIEW.deleted == true)
    -- 🚨 THE ONE THAT IS THE BUG. bringToFront ran unconditionally, on
    -- the very window macOS had just refused — which is how a window
    -- that never finished being shown ends up on screen with nothing
    -- drawn in it.
    c18("…and it is NOT dragged to the front anyway — that is the white box",
        (function()
            for _, e in ipairs(EVENTS) do if e == "front" then return false end end
            return true
        end)(), table.concat(EVENTS, ","))
    c18("…and it takes the 🔔 door, naming macOS's own words",
        #DEGRADES > 0 and DEGRADES[#DEGRADES].why:find("raised", 1, true) ~= nil,
        #DEGRADES > 0 and DEGRADES[#DEGRADES].why)

    -- ---- 2. macOS REFUSES BY RETURNING FALSE --------------------------
    -- 6.265.0, for the seventh time: ABSENT is not REFUSING, and a show
    -- that returns false is not a show that throws.
    SHOW_MODE = "false"
    EVENTS, DEGRADES = {}, {}
    c18("a show that RETURNS FALSE is refused too, not just a throw",
        E.open(SRC) == false and E.webview == nil and VIEW.deleted == true)

    -- ---- 3. no shared door at all -------------------------------------
    _G.showWebviewSafely = nil
    SHOW_MODE = "throw"
    EVENTS, DEGRADES = {}, {}
    c18("with no shared door, the fallback reads its own answer as well",
        E.open(SRC) == false and E.webview == nil and VIEW.deleted == true)
    c18("…and still does not drag the refused window to the front",
        (function()
            for _, e in ipairs(EVENTS) do if e == "front" then return false end end
            return true
        end)(), table.concat(EVENTS, ","))

    -- ---- 4. the page that could not be built (6.406.0's white box) ----
    SHOW_MODE, HTML_THROW = "ok", true
    EVENTS, DEGRADES = {}, {}
    c18("a page that cannot be built means the window is never SHOWN at"
        .. " all — an empty webview draws blank",
        E.open(SRC) == false and (function()
            for _, e in ipairs(EVENTS) do if e == "show" then return false end end
            return true
        end)(), table.concat(EVENTS, ","))
    c18("…and that window is deleted too", VIEW.deleted == true)
    c18("…and it is a named failure, not a silence",
        #DEGRADES > 0 and DEGRADES[#DEGRADES].why:find("page", 1, true) ~= nil,
        #DEGRADES > 0 and DEGRADES[#DEGRADES].why)

    -- ---- 5. and a healthy Mac is untouched ----------------------------
    SHOW_MODE, HTML_THROW = "ok", false
    EVENTS, DEGRADES = {}, {}
    c18("a show that works still opens, publishes and comes to the front",
        E.open(SRC) == true and E.webview ~= nil and VIEW.shown == true)
    c18("…in that order: shown BEFORE it is brought to the front",
        (function()
            local si, fi
            for i, e in ipairs(EVENTS) do
                if e == "show"  and not si then si = i end
                if e == "front" and not fi then fi = i end
            end
            return si and fi and si < fi
        end)(), table.concat(EVENTS, ","))
    c18("…and nothing degraded on the healthy path (6.269.0)", #DEGRADES == 0,
        #DEGRADES)

    -- ---- 6. the report names it ---------------------------------------
    local blk = {}
    local realPrint = print
    print = function(...) blk[#blk + 1] = table.concat({ ... }, " ") end
    pcall(_G.screenshotEditorReport)
    print = realPrint
    local txt = table.concat(blk, "\n")
    c18("the report counts the refusals apart from the pages that could"
        .. " not be built — two faults, two fixes",
        txt:find("refused by macOS", 1, true) ~= nil
        and txt:find("could not be built", 1, true) ~= nil, txt:sub(1, 400))
    c18("…and says nothing was left on screen either way",
        txt:find("left on screen", 1, true) ~= nil, txt:sub(1, 400))

    -- ---- 7. the panic chord's second argument -------------------------
    -- 🚨 It must ASK the page (so his marks are not thrown away) and
    -- close in the same breath, never wait out the belt.
    E.close() ; E.open(SRC)
    JS = {}
    local okP = E.requestClose("panic chord", true)
    c18("requestClose(why, true) asks the page for the work first",
        okP == true and (function()
            for _, j in ipairs(JS) do
                if tostring(j):find("stashAndCancel", 1, true) then return true end
            end
            return false
        end)(), table.concat(JS, " | "))
    c18("…and the window is gone AT ONCE — a panic chord cannot have a"
        .. " grace period in it", E.webview == nil)

    c18("§18 ran every one of its checks", (pass + fail) - n18 == 18,
        (pass + fail) - n18)
end

out(("\n%d passed, %d failed\n"):format(pass, fail))
for _, f in ipairs(failures) do out("    ❌ " .. f .. "\n") end
out("\n")
os.exit(fail == 0 and 0 or 1)
