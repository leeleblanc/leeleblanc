-- =====================================================================
-- test_features.lua — the five modules added in 6.44.0
-- =====================================================================
--   Capture Pad · Mini Calendar · Quick Append · Screen Veil · Numpad Layer
--
-- Runs under plain lua5.4 with no Mac and no Hammerspoon: the whole hs
-- API used by these modules is stubbed below, and the stubs record what
-- was asked of them so the tests can assert on behaviour rather than on
-- the absence of a crash.
--
--     lua5.4 test_features.lua                     # uses ~/.hammerspoon/modules
--     lua5.4 test_features.lua /path/to/modules    # or point it somewhere
--
-- ⏰ RUN IT UNDER A TIMEZONE WITH DST if you want the calendar's
-- daylight-saving tests to mean anything:
--     TZ=America/New_York lua5.4 test_features.lua
-- Under UTC those three checks still pass, but they pass trivially —
-- there is no clock change to survive.

-- Every other suite here takes the HAMMERSPOON DIRECTORY; this one took the
-- MODULES directory, so passing the same argument to all of them failed only
-- on this file, with a "cannot open ./capture_pad.lua" that pointed at the
-- module rather than at the argument. It now accepts either: if what it is
-- given contains a modules/ subdirectory, that is what was meant.
local MODDIR = arg and arg[1]
    or os.getenv("HAMMERSPOON_MODULES")
    or ((os.getenv("HOME") or ".") .. "/.hammerspoon/modules")
if io.open(MODDIR .. "/modules/capture_pad.lua", "r") then
    MODDIR = MODDIR .. "/modules"
end

local pass, fail, failures = 0, 0, {}
local function check(label, cond)
    if cond then pass = pass + 1
    else fail = fail + 1; table.insert(failures, label) end
end

-- =====================================================================
-- STUBS
-- =====================================================================
local printed = {}
local realPrint = print
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    table.insert(printed, table.concat(p, " "))
end
local function logged(needle)
    for _, line in ipairs(printed) do
        if line:find(needle, 1, true) then return true end
    end
    return false
end

local ALERTS, TIMERS, BOUND, SETTINGS = {}, {}, {}, {}
local CANVASES, DELETED_CANVASES = {}, {}
local HTTP_POSTS, TASKS = {}, {}
local SCREENS, FOCUSED = {}, nil
local NOW = 1000

local function newScreen(id, x, y, w, h, menuH)
    menuH = menuH or 25
    return {
        _id = id,
        id        = function(s) return s._id end,
        fullFrame = function() return { x = x, y = y, w = w, h = h } end,
        frame     = function() return { x = x, y = y + menuH, w = w, h = h - menuH } end,
        next      = function(s) return SCREENS[2] or s end,
        previous  = function(s) return SCREENS[1] or s end,
    }
end
SCREENS = { newScreen(1, 0, 0, 1440, 900) }

local function fakeCanvas(rect)
    local c = {
        _frame = rect, _elements = nil, _shown = false, _deleted = false,
        _mouseEvents = nil, _clickActivating = nil, _level = nil, _behaviors = nil,
    }
    function c:replaceElements(e) self._elements = e; return self end
    function c:show() self._shown = true; return self end
    function c:hide() self._shown = false; return self end
    function c:delete() self._deleted = true; table.insert(DELETED_CANVASES, self) end
    function c:level(l) self._level = l; return self end
    function c:behaviorAsLabels(b) self._behaviors = b; return self end
    function c:canvasMouseEvents(a, b, d, e) self._mouseEvents = { a, b, d, e }; return self end
    function c:clickActivating(v) self._clickActivating = v; return self end
    function c:frame(f) if f then self._frame = f end return self._frame end
    function c:mouseCallback(fn) self._mouseCallback = fn; return self end
    table.insert(CANVASES, c)
    return c
end

local function fakeHotkey(mods, key)
    local hk = { mods = mods, key = key, on = false }
    function hk:enable() self.on = true; return self end
    function hk:disable() self.on = false; return self end
    return hk
end

CLIPBOARD_IMAGE = nil
CLIPBOARD_TEXT  = ""
PROMPT_ANSWER   = { "Cancel", "" }
MOUSE           = { x = 0, y = 0 }
MOUSE_DOWN      = false

hs = {
    configdir = MODDIR:gsub("/modules$", ""),
    timer = {
        secondsSinceEpoch = function() NOW = NOW + 0.001; return NOW end,
        doAfter = function(_, fn)
            local t = { fn = fn, kind = "after" }
            function t:stop() self.stopped = true end
            table.insert(TIMERS, t); return t
        end,
        doEvery = function(iv, fn)
            local t = { fn = fn, kind = "every", interval = iv }
            function t:stop() self.stopped = true end
            function t:start() return self end
            table.insert(TIMERS, t); return t
        end,
        doAt = function(at, rep, fn)
            local t = { fn = fn, kind = "at", at = at, repeats = rep }
            function t:stop() self.stopped = true end
            table.insert(TIMERS, t); return t
        end,
        new = function() return { start = function(s) return s end,
                                  stop = function(s) return s end } end,
        usleep = function() end,
    },
    hotkey = {
        bind = function(mods, key, fn)
            local b = { mods = mods, key = key, fn = fn }
            table.insert(BOUND, b); return b
        end,
        new = function(mods, key, fn, rel, rep)
            local hk = fakeHotkey(mods, key)
            hk.fn, hk.releasedFn, hk.repeatFn = fn, rel, rep
            return hk
        end,
        modal = { new = function()
            local m = { bindings = {}, entered = false }
            function m:bind(mods, key, fn, rel, rep)
                table.insert(self.bindings, { mods = mods, key = key, fn = fn, repeatFn = rep })
                return self
            end
            function m:enter() self.entered = true; return self end
            function m:exit()  self.entered = false; return self end
            return m
        end },
    },
    alert = { show = function(m) table.insert(ALERTS, tostring(m)) end },
    canvas = {
        new = function(rect) return fakeCanvas(rect) end,
        windowLevels = { overlay = 25, screenSaver = 1000, floating = 5 },
    },
    drawing = { windowLevels = { floating = 5 } },
    screen = {
        allScreens  = function() return SCREENS end,
        mainScreen  = function() return SCREENS[1] end,
        primaryScreen = function() return SCREENS[1] end,
        watcher = { new = function(fn)
            local w = { fn = fn }
            function w:start() self.started = true; return self end
            function w:stop() self.started = false; return self end
            SCREEN_WATCHER = w
            return w
        end },
    },
    fs = {
        attributes = function(path)
            local f = io.open(path, "r")
            if f then f:close(); return { mode = "file", size = 1 } end
            -- A directory opens for read on Linux but reads as nil; good
            -- enough to answer "does this exist".
            local ok = os.rename(path, path)
            return ok and { mode = "directory" } or nil
        end,
        mkdir = function(d) os.execute('mkdir -p "' .. d .. '"'); return true end,
        dir = function() return function() return nil end end,
    },
    settings = {
        get = function(k) return SETTINGS[k] end,
        set = function(k, v) SETTINGS[k] = v end,
    },
    json = {
        encode = function(t)
            -- Enough of a JSON writer for the round-trip the queue does.
            local function enc(v)
                if type(v) == "table" then
                    if #v > 0 or next(v) == nil then
                        local out = {}
                        for _, x in ipairs(v) do table.insert(out, enc(x)) end
                        return "[" .. table.concat(out, ",") .. "]"
                    end
                    local out = {}
                    for k, x in pairs(v) do
                        table.insert(out, string.format("%q", tostring(k)) .. ":" .. enc(x))
                    end
                    return "{" .. table.concat(out, ",") .. "}"
                elseif type(v) == "string" then return string.format("%q", v)
                elseif type(v) == "number" or type(v) == "boolean" then return tostring(v)
                end
                return "null"
            end
            return enc(t)
        end,
        decode = function() error("hs.json.decode must go through _G.safeJson") end,
    },
    pasteboard = {
        getContents = function() return CLIPBOARD_TEXT end,
        setContents = function(s) CLIPBOARD_TEXT = s; return true end,
        readImage   = function() return CLIPBOARD_IMAGE end,
    },
    image = {
        imageFromPath = function(p)
            local f = io.open(p, "r"); if not f then return nil end; f:close()
            local img = {}
            function img:setSize() return self end
            function img:encodeAsURLString() return "data:image/png;base64,AAAA" end
            return img
        end,
        imageFromAppBundle = function() return nil end,
    },
    chooser = { new = function(fn)
        local c = { callback = fn }
        for _, m in ipairs({ "choices", "placeholderText", "query", "show", "hide",
                             "searchSubText", "rows", "width", "bgDark",
                             "selectedRow", "refreshChoicesCallback" }) do
            c[m] = function(self, v) if m == "choices" then self._choices = v end return self end
        end
        -- Captured, not swallowed: the search tests drive the picker
        -- through this exactly as typing a character would.
        c.queryChangedCallback = function(self, fn) self._onQuery = fn; return self end
        LAST_CHOOSER = c
        return c
    end },
    dialog = { textPrompt = function() return PROMPT_ANSWER[1], PROMPT_ANSWER[2] end },
    http = { asyncPost = function(url, body, headers, cb)
        table.insert(HTTP_POSTS, { url = url, body = body, headers = headers, cb = cb })
    end },
    task = { new = function(bin, cb, args)
        -- callOrder records method names in the sequence they were called,
        -- so a test can assert setInput happened BEFORE start — the exact
        -- ordering bug that made every 6.44.0 attachment silently fail.
        local t = { bin = bin, cb = cb, args = args, input = nil, callOrder = {} }
        function t:start() self.started = true
            table.insert(self.callOrder, "start"); return true end
        function t:setInput(s) self.input = s
            table.insert(self.callOrder, "setInput"); return self end
        function t:closeInput() self.inputClosed = true
            table.insert(self.callOrder, "closeInput"); return self end
        function t:terminate() self.terminated = true; return self end
        table.insert(TASKS, t)
        return t
    end },
    menubar = { new = function()
        local m = {}
        function m:setTitle(t) self.title = t; return self end
        function m:setTooltip(t) self.tooltip = t; return self end
        function m:setClickCallback(fn) self.click = fn; return self end
        MENUBAR = m
        return m
    end },
    webview = nil,   -- absent on purpose; see the fallback test
    window = { focusedWindow = function() return FOCUSED end },
    application = { launchOrFocus = function() end },
    mouse = { absolutePosition = function() return MOUSE end },
    pathwatcher = { new = function()
        return { start = function(s) return s end, stop = function(s) return s end }
    end },
    axuielement = { applicationElement = function() return nil end,
                    observer = { new = function() return nil end } },
    uielement   = { watcher = { new = function() return nil end } },
    caffeinate  = { watcher = { new = function()
        return { start = function(s) return s end, stop = function(s) return s end }
    end, screensDidLock = 1, screensDidUnlock = 2,
         systemDidWake = 3, systemWillSleep = 4 } },
    eventtap = { checkMouseButtons = function() return { left = MOUSE_DOWN } end },
    keycodes = { map = {
        pad0 = 82, pad1 = 83, pad2 = 84, pad3 = 85, pad4 = 86, pad5 = 87,
        pad6 = 88, pad7 = 89, pad8 = 91, pad9 = 92,
        ["pad."] = 65, ["pad+"] = 69, ["pad-"] = 78, ["pad*"] = 67, ["pad/"] = 75,
        padenter = 76, padclear = 71,
        ["0"] = 29, ["7"] = 26, g = 5, j = 38, n = 45,
        -- 💻 6.114.0 — THE REAL NUMBER-ROW AND PUNCTUATION CODES, from a
        -- live Mac. The laptop layer binds these, and bindAll SKIPS any key
        -- hs.keycodes.map has no code for — so a stub missing them would
        -- make the layer look correctly bound while binding one key in ten,
        -- and the count assertion would be measuring the stub.
        ["1"] = 18, ["2"] = 19, ["3"] = 20, ["4"] = 21, ["5"] = 23,
        ["6"] = 22, ["8"] = 28, ["9"] = 25,
        [","] = 43, ["."] = 47, ["return"] = 36,
    } },
}

_G.diag = { verbose = false, trail = {}, errors = {}, marks = {},
            say = function() end, warn = function() end,
            err = function() end, mark = function() end }
_G.safeJson = function(blob, label)
    -- The real one pcalls hs.json.decode. Here: a tiny reader that handles
    -- exactly what hs.json.encode above produces.
    local ok, res = pcall(function()
        local pos = 1
        local function skip() pos = blob:find("[^%s]", pos) or pos end
        local parse
        local function parseString()
            local out, i = {}, pos + 1
            while i <= #blob do
                local ch = blob:sub(i, i)
                if ch == "\\" then
                    local nx = blob:sub(i + 1, i + 1)
                    if nx == "n" then out[#out+1] = "\n"
                    elseif nx == "t" then out[#out+1] = "\t"
                    elseif nx == "r" then out[#out+1] = "\r"
                    else out[#out+1] = nx end
                    i = i + 2
                elseif ch == '"' then pos = i + 1; return table.concat(out)
                else out[#out+1] = ch; i = i + 1 end
            end
            error("unterminated string")
        end
        parse = function()
            skip()
            local ch = blob:sub(pos, pos)
            if ch == '"' then return parseString() end
            if ch == "{" then
                pos = pos + 1; local t = {}
                skip()
                if blob:sub(pos, pos) == "}" then pos = pos + 1; return t end
                while true do
                    skip(); local k = parseString()
                    skip(); pos = pos + 1            -- ':'
                    t[k] = parse()
                    skip()
                    local c = blob:sub(pos, pos); pos = pos + 1
                    if c == "}" then return t end
                end
            end
            if ch == "[" then
                pos = pos + 1; local t = {}
                skip()
                if blob:sub(pos, pos) == "]" then pos = pos + 1; return t end
                while true do
                    table.insert(t, parse())
                    skip()
                    local c = blob:sub(pos, pos); pos = pos + 1
                    if c == "]" then return t end
                end
            end
            local lit = blob:match("^[%w%.%-%+eE]+", pos)
            if lit then
                pos = pos + #lit
                if lit == "true" then return true end
                if lit == "false" then return false end
                if lit == "null" then return nil end
                return tonumber(lit)
            end
            error("bad json at " .. pos)
        end
        return parse()
    end)
    if not ok then
        print("⚠️ JSON parse failed (" .. tostring(label) .. ")")
        return nil
    end
    return res
end
_G.choosers = {}   -- created in §1 of the real init.lua
_G.service = {
    registry = {},
    provide = function(n, fn) _G.service.registry[n] = fn end,
    has     = function(n) return _G.service.registry[n] ~= nil end,
    call    = function(n, ...)
        table.insert(printed, "service.call " .. tostring(n))
        local fn = _G.service.registry[n]
        if not fn then print("🔌 No provider for '" .. tostring(n) .. "'"); return nil end
        local ok, a = pcall(fn, ...)
        return ok and a or nil
    end,
}

local TMP = (os.getenv("TMPDIR") or "/tmp") .. "/hs-feature-tests-" .. tostring(os.time())
os.execute('mkdir -p "' .. TMP .. '"')

local HYPER = {}
local core = {
    version = "6.44.0-test",
    homeDir = TMP, cloudDir = TMP, logsDir = TMP, backupDir = TMP,
    configDir = TMP, hostTag = "Test-Mac",
    warnWriteFailed = function(l) table.insert(printed, "WRITE FAILED " .. tostring(l)) end,
    adoptLegacyFile = function() end,
    csvQuote = function(s) return s end,
    splitCSVLine = function() return {} end,
    formatDuration = function(s) return tostring(s) end,
    popupKeys = { mods = { "cmd", "ctrl", "alt" } },
    popupMods = { "cmd", "ctrl", "alt" },
    showPopup = function() end,
    resolveBaseScreen = function() return SCREENS[1] end,
    panelAlpha = 0.9,
    hyperAddShortcut = function(mods, key, fn, name)
        table.insert(HYPER, { mods = mods, key = key, fn = fn, name = name })
    end,
    asanaEnabled = true, asanaToken = "SECRET-TOKEN-abc123",
    asanaWorkspaceId = "WS1", asanaProjectId = "PROJ1",
    provide = function(n, fn) _G.service.provide(n, fn) end,
    call    = function(n, ...) return _G.service.call(n, ...) end,
    diag = _G.diag, safeJson = _G.safeJson,
}

local function hyperFor(mods, key)
    local want = table.concat(mods or {}, "+")
    for _, h in ipairs(HYPER) do
        if table.concat(h.mods or {}, "+") == want and h.key == key then return h end
    end
end

local function load(name)
    local chunk, err = loadfile(MODDIR .. "/" .. name .. ".lua")
    if not chunk then
        realPrint("CANNOT LOAD " .. name .. ": " .. tostring(err))
        os.exit(1)
    end
    return chunk()
end

-- =====================================================================
realPrint("── 6.44.0 feature tests ──  modules: " .. MODDIR)
realPrint("   timezone: " .. (os.getenv("TZ") or "(system default)"))

-- =====================================================================
-- 1. CAPTURE PAD — the title rules
-- =====================================================================
local capture = load("capture_pad")
capture.setup(core)
local pad = capture.pad
pad.dir      = TMP .. "/capture-pad"
pad.imageDir = pad.dir .. "/images"
pad.file     = pad.dir .. "/queue.json"

local function title(text)
    local t, kind, trunc = pad.titleFor(text)
    return t, kind, trunc
end

check("plain instruction becomes Verb + rest",
      title("Email Dana the Q3 numbers") == "Email Dana the Q3 numbers")
check("...and is tagged as an action",
      select(2, title("Email Dana the Q3 numbers")) == "action")
check("an observation becomes Note :: rest",
      title("Dana prefers Thursdays") == "Note :: Dana prefers Thursdays")
check("...and is tagged as a note",
      select(2, title("Dana prefers Thursdays")) == "note")

check("'need to X' is rewritten so the VERB starts the title",
      title("need to renew the SSL cert") == "Renew the SSL cert")
check("'I need to X' likewise",
      title("I need to renew the SSL cert") == "Renew the SSL cert")
check("...and the rest keeps its capitals (SSL, not ssl)",
      title("I need to renew the SSL cert"):find("SSL", 1, true) ~= nil)
check("'I should X' is an action too",
      title("I should call the vendor back") == "Call the vendor back")
check("'remember to X' is an action",
      title("remember to book the room") == "Book the room")
check("'make sure to X' is an action",
      title("make sure to sign the lease") == "Sign the lease")

check("a verb followed by 'with' is read as a NOUN",
      select(2, title("Call with Dana Tuesday")) == "note")
check("...but the same verb with an object is an action",
      select(2, title("Call Dana Tuesday")) == "action")
check("'Email from legal' is a noun",
      select(2, title("Email from legal about the lease")) == "note")
check("'Review is due Friday' is a noun",
      select(2, title("Review is due Friday")) == "note")

check("! forces an action even for a non-verb",
      title("! the printer thing") == "The printer thing")
check("? forces a note even for a verb",
      title("? send the thing") == "Note :: send the thing")
check("TODO: is an action",
      title("TODO: check the backups") == "Check the backups")
check("a markdown checkbox is an action",
      title("- [ ] update the runbook") == "Update the runbook")
check("a bare dash bullet is stripped",
      title("- Dana prefers Thursdays") == "Note :: Dana prefers Thursdays")
check("'Note:' prefix is stripped, not doubled",
      title("Note: Dana prefers Thursdays") == "Note :: Dana prefers Thursdays")

local function wordCount(s)
    local n = 0; for _ in tostring(s):gmatch("%S+") do n = n + 1 end; return n
end
local long = "Email Dana the Q3 numbers and the revised forecast before the board meeting"
local lt, lk, ltr = title(long)
check("(the fixture really is longer than the cap)", wordCount(long) > 10)
check("an over-long action title stops at exactly 10 words",
      wordCount((lt:gsub("…", ""))) == 10)
check("...and says it was cut with an ellipsis", lt:sub(-3) == "…")
check("...and reports truncated = true", ltr == true)
check("...and is still an action", lk == "action")

local longNote = "Dana mentioned that the vendor contract renews automatically every "
                 .. "single year unless we cancel"
local nt = title(longNote)
check("an over-long note counts 10 words AFTER the Note :: prefix",
      wordCount((nt:gsub("^Note :: ", ""):gsub("…", ""))) == 10)
check("...and keeps the exact prefix you specified", nt:sub(1, 8) == "Note :: ")

check("only the FIRST sentence reaches the title",
      title("Fix the printer. Then go home.") == "Fix the printer")
check("only the FIRST line reaches the title",
      title("Fix the printer\nand also the scanner") == "Fix the printer")
check("an empty note is still given a title",
      title("") == "Note :: (empty note)")
check("whitespace-only is treated as empty",
      title("   \n  ") == "Note :: (empty note)")

-- description rules
check("a short note with no images needs no description",
      pad.descriptionFor({ text = "Dana prefers Thursdays", createdAt = 1 }) == "")
check("a long note puts the FULL text in the description",
      pad.descriptionFor({ text = long, createdAt = 1 }):find("board meeting", 1, true) ~= nil)
check("a multi-line note goes to the description even when short",
      pad.descriptionFor({ text = "Fix printer\nand scanner", createdAt = 1 }) ~= "")
check("images are announced in the description",
      pad.descriptionFor({ text = "hi", images = { "/a.png" }, createdAt = 1 })
          :find("1 image attached", 1, true) ~= nil)
-- 🐛 6.44.2 — a SHORT note with an image used to lose its own text: the
-- description held nothing but "1 image attached." and a timestamp, so a
-- screenshot arrived in Asana with no caption at all.
check("🐛 a short note WITH an image still carries its own text",
      pad.descriptionFor({ text = "Do total damage", images = { "/a.png" }, createdAt = 1 })
          :find("Do total damage", 1, true) ~= nil)
check("...and a short note with NO image still needs no description at all",
      pad.descriptionFor({ text = "Do total damage", images = {}, createdAt = 1 }) == "")
check("...pluralised correctly",
      pad.descriptionFor({ text = "hi", images = { "/a.png", "/b.png" }, createdAt = 1 })
          :find("2 images attached", 1, true) ~= nil)
check("a description carries provenance",
      pad.descriptionFor({ text = long, createdAt = 1 }):find("Test%-Mac") ~= nil)

-- =====================================================================
-- 2. CAPTURE PAD — the queue
-- =====================================================================
pad.queue, pad.parked = {}, {}
local okAdd = pad.addNote("Email Dana the numbers", {})
check("addNote queues a note", okAdd == true and #pad.queue == 1)
check("addNote refuses an empty note", pad.addNote("   ", {}) == false)
check("the queue is written to disk", io.open(pad.file, "r") ~= nil)

pad.queue = {}
pad.load()
check("the queue survives a reload", #pad.queue == 1
      and pad.queue[1].text == "Email Dana the numbers")

pad.maxQueue = 2
pad.addNote("second", {})
local okFull, whyFull = pad.addNote("third", {})
check("the queue is bounded", okFull == false and tostring(whyFull):find("full", 1, true))
pad.maxQueue = 200

-- 🐛 6.44.10 — A NOTE MUST LIVE IN EXACTLY ONE LIST. Reported as a PARKED
-- row showing the same text as the QUEUED row beneath it, with "parked
-- before this pad tracked reasons" as the reason — which is precisely what
-- a QUEUED note rendered as parked looks like, since queued notes carry no
-- parkedAt and no lastError and the reason line falls through to that.
printed = {}
pad.queue  = { { id = "dup", text = "Drink that tang", createdAt = 1, images = {}, tries = 0 } }
pad.parked = { { id = "dup", text = "Drink that tang", createdAt = 1, images = {}, tries = 3 } }
check("🐛 6.44.10 — a parked entry duplicating a queued note is dropped",
      pad.normalize() == true and #pad.parked == 0)
check("...and the QUEUED copy survives, because it is the one that sends",
      #pad.queue == 1 and pad.queue[1].text == "Drink that tang")
check("...and the console says so rather than repairing it silently",
      logged("stale parked"))

-- the worst version of the same fault: ONE table used as both lists, which
-- renders every queued note as parked too and which no id check would see
printed = {}
pad.queue = { { id = "z", text = "one list", createdAt = 1, images = {}, tries = 0 } }
pad.parked = pad.queue
check("...one table used as BOTH lists is caught by identity, not by id",
      pad.normalize() == true and #pad.parked == 0 and #pad.queue == 1)
check("...and that one is announced too", logged("SAME"))

-- and a genuinely parked note must be left completely alone
printed = {}
pad.queue  = { { id = "q1", text = "still going", createdAt = 1, images = {}, tries = 0 } }
pad.parked = { { id = "p1", text = "really failed", createdAt = 1, images = {}, tries = 3,
                 parkedAt = 5, lastError = "HTTP 403" } }
check("...a real parked note is untouched — this guard must not eat history",
      pad.normalize() == false and #pad.parked == 1
      and pad.parked[1].text == "really failed" and #pad.queue == 1)
check("...and stays quiet when there is nothing to fix", not logged("stale parked"))

-- and load() must apply it, or a bad queue.json survives every restart
pad.queue  = { { id = "same", text = "written twice", createdAt = 1, images = {}, tries = 0 } }
pad.parked = { { id = "same", text = "written twice", createdAt = 1, images = {}, tries = 3 } }
pad.save()
pad.queue, pad.parked = {}, {}
pad.load()
check("...and load() repairs it on the way in, so a bad file cannot persist",
      #pad.queue == 1 and #pad.parked == 0)
pad.queue, pad.parked = {}, {}

-- 🐛 6.62.0 — FROM LL's CONSOLE, ON A REAL BOOT:
--   🗒 Capture Pad: the queue and the parked list were the SAME table —
--      parked has been reset to empty.
-- The emergency guard fired, and it was right to. But it fired because
-- load() ADOPTED the decoder's tables, which silently assumes decode
-- returns a distinct table per key. load() now takes its own copy, so
-- the two lists cannot be the same object no matter what the decoder
-- hands back. The guard stays as a second line — it just should not be
-- the thing doing the work on an ordinary boot.
do
    printed = {}
    local shared = {}                     -- ONE table behind both keys
    local realJson = _G.safeJson
    _G.safeJson = function() return { queue = shared, parked = shared } end
    pad.queue, pad.parked = {}, {}
    pad.load()
    _G.safeJson = realJson

    check("🐛 a decoder returning ONE table for both keys cannot alias the lists",
          not rawequal(pad.queue, pad.parked))
    check("...and the emergency guard does not have to fire to achieve it",
          not logged("SAME"))
    pad.queue, pad.parked = {}, {}
end

-- and the copy must not quietly change what was loaded
do
    printed = {}
    local realJson = _G.safeJson
    _G.safeJson = function()
        return { queue  = { { id = "k1", text = "keep me", createdAt = 1,
                              images = {}, tries = 0 } },
                 parked = { { id = "k2", text = "parked me", createdAt = 2,
                              images = {}, tries = 3, parkedAt = 9,
                              lastError = "HTTP 500" } } }
    end
    pad.queue, pad.parked = {}, {}
    pad.load()
    _G.safeJson = realJson

    check("...a normal load still lands both lists intact",
          #pad.queue == 1 and #pad.parked == 1
          and pad.queue[1].text == "keep me"
          and pad.parked[1].text == "parked me")
    check("...and the parked note keeps the fields that make it parked",
          pad.parked[1].lastError == "HTTP 500" and pad.parked[1].parkedAt == 9)
    pad.queue, pad.parked = {}, {}
end

-- flush: success path
HTTP_POSTS = {}
pad.queue = { { id = "a", text = "Email Dana the numbers", createdAt = 1, images = {}, tries = 0 } }
pad.flush("manual")
check("flush posts to the Asana tasks endpoint",
      #HTTP_POSTS == 1 and HTTP_POSTS[1].url == "https://app.asana.com/api/1.0/tasks")
check("the task body carries the computed title",
      HTTP_POSTS[1].body:find("Email Dana the numbers", 1, true) ~= nil)
check("the task is filed into the configured project",
      HTTP_POSTS[1].body:find("PROJ1", 1, true) ~= nil)
check("the token travels in a header, not the body",
      HTTP_POSTS[1].headers["Authorization"] == "Bearer SECRET-TOKEN-abc123"
      and HTTP_POSTS[1].body:find("SECRET%-TOKEN") == nil)
HTTP_POSTS[1].cb(201, '{"data":{"gid":"999"}}')
check("a delivered note leaves the queue", #pad.queue == 0)
check("...and the user is told how many went", ({ table.unpack(ALERTS) })[#ALERTS]
      and ALERTS[#ALERTS]:find("1 sent", 1, true) ~= nil)

-- flush: failure path
HTTP_POSTS, ALERTS = {}, {}
pad.maxRetries = 2
pad.queue = { { id = "b", text = "Email Dana", createdAt = 1, images = {}, tries = 0 } }
pad.flush("manual")
HTTP_POSTS[1].cb(500, "boom")
check("a failed send KEEPS the note", #pad.queue == 1)
check("...and counts the attempt", pad.queue[1].tries == 1)
check("...and is not parked yet", #pad.parked == 0)
check("...and the alert says it was kept",
      ALERTS[#ALERTS] and ALERTS[#ALERTS]:find("kept for next time", 1, true) ~= nil)

HTTP_POSTS = {}
pad.flush("manual")
HTTP_POSTS[1].cb(500, "boom")
check("a note that hits maxRetries is PARKED, never dropped",
      #pad.queue == 0 and #pad.parked == 1 and pad.parked[1].text == "Email Dana")
check("...and says so in the Console", logged("parked after"))
pad.maxRetries = 3
pad.parked = {}

-- a task that Asana accepts but returns no gid for
HTTP_POSTS = {}
pad.queue = { { id = "c", text = "Email Dana", createdAt = 1, images = {}, tries = 0 } }
pad.flush("manual")
HTTP_POSTS[1].cb(201, '{"data":{}}')
check("a 201 with no gid is treated as a failure, not a success",
      #pad.queue == 1 and logged("returned no gid"))

-- flush guards
HTTP_POSTS, ALERTS = {}, {}
pad.queue = {}
pad.flush("manual")
check("flushing an empty queue says so and posts nothing",
      #HTTP_POSTS == 0 and ALERTS[#ALERTS]:find("nothing queued", 1, true) ~= nil)

pad.queue = { { id = "d", text = "hi there", createdAt = 1, images = {}, tries = 0 } }
core.asanaEnabled = false
HTTP_POSTS, ALERTS = {}, {}
pad.flush("manual")
check("with no Asana token nothing is sent and the queue is kept",
      #HTTP_POSTS == 0 and #pad.queue == 1
      and ALERTS[#ALERTS]:find("nothing sent", 1, true) ~= nil)
core.asanaEnabled = true

HTTP_POSTS = {}
pad.sending = true
pad.flush("manual")
check("a second flush while one is running is ignored", #HTTP_POSTS == 0)
pad.sending = false

-- attachments: the security-critical part, AND the 6.44.0 regression
-- (every attachment silently failed — see the file header for the two
-- bugs: setInput() called after start(), and a diagnostic message that
-- hid the real response body behind Lua's "" truthiness).
TASKS = {}
os.execute('mkdir -p "' .. pad.imageDir .. '"')
local imgPath = pad.imageDir .. "/test.png"
local fimg = io.open(imgPath, "w"); fimg:write("PNG"); fimg:close()
HTTP_POSTS = {}
pad.queue = { { id = "e", text = "screenshot", createdAt = 1, images = { imgPath }, tries = 0 } }
pad.flush("manual")
HTTP_POSTS[1].cb(201, '{"data":{"gid":"555"}}')
check("an image is uploaded with curl", #TASKS == 1 and TASKS[1].bin == "/usr/bin/curl")
check("...to the task's attachments endpoint",
      table.concat(TASKS[1].args, " "):find("/tasks/555/attachments", 1, true) ~= nil)
check("🔐 the token is NOT in curl's argument list",
      table.concat(TASKS[1].args, " "):find("SECRET%-TOKEN") == nil)

-- 🐛 6.44.2 — the header moved OFF stdin and into a short-lived file.
-- Ordering setInput() before start() (the 6.44.1 fix) stopped attachments
-- failing every time but not reliably: a pipe written against curl's own
-- already-running read loop can still be raced. A file is written and
-- closed before curl exists, so there is nothing left to race.
local hdrArg
for i, v in ipairs(TASKS[1].args) do
    if v == "-H" then hdrArg = TASKS[1].args[i + 1] end
end
check("the header is passed as -H @<file>", hdrArg ~= nil and hdrArg:sub(1, 1) == "@")
local hdrFile = hdrArg and hdrArg:sub(2)
check("...and that file exists on disk BEFORE curl is started",
      hdrFile ~= nil and io.open(hdrFile, "r") ~= nil)
check("🔐 ...containing exactly the auth header, nothing else", (function()
    local f = io.open(hdrFile, "r"); if not f then return false end
    local c = f:read("a"); f:close()
    return c == "Authorization: Bearer SECRET-TOKEN-abc123\n"
end)())
check("...and it is written before start(), not after", (function()
    -- the file existing at all by this point proves it, since the module
    -- writes it before hs.task.new and we are inspecting post-start
    return TASKS[1].started == true
end)())
check("stdin is no longer used for the token at all", TASKS[1].input == nil)
check("⏱ the upload is time-boxed so one hung curl cannot wedge the flush",
      table.concat(TASKS[1].args, " "):find("--max-time", 1, true) ~= nil)
check("the real HTTP status is requested via -w, not guessed from the body",
      table.concat(TASKS[1].args, " "):find("%%{http_code}", 1, false) ~= nil
      or table.concat(TASKS[1].args, " "):find("http_code", 1, true) ~= nil)
check("the note is NOT dropped before the upload finishes", #pad.queue == 1)
TASKS[1].cb(0, '{"data":{"id":"1"}}\n201', "")
check("...and leaves the queue once everything is delivered", #pad.queue == 0)
check("...clearing the sending latch", pad.sending == false)
check("🔐 the header file is DELETED as soon as curl reports back — a file "
      .. "holding a bearer token must not outlive the upload that needed it",
      io.open(hdrFile, "r") == nil)

-- 🐛 THE EXACT 6.44.0 BUG, REPRODUCED: curl exits 0 (it only fails on a
-- TRANSPORT error, never an HTTP one) while Asana's response is a 401.
-- The old body-sniffing check ("does it contain the word errors") missed
-- this whenever the failure body didn't happen to say that; the new
-- status-based check cannot miss it, because 401 is never 200 or 201.
TASKS, HTTP_POSTS, ALERTS, printed = {}, {}, {}, {}
pad.queue = { { id = "g", text = "screenshot 2", createdAt = 1, images = { imgPath }, tries = 0 } }
pad.flush("manual")
HTTP_POSTS[1].cb(201, '{"data":{"gid":"777"}}')
TASKS[1].cb(0, '{"errors":[{"message":"Not Authorized"}]}\n401', "")
check("a curl exit-0/HTTP-401 response is still treated as a FAILED attachment",
      logged("attachment failed") and logged("HTTP 401"))
check("...and the actual response body reaches the Console, not a blank line",
      logged("Not Authorized"))
check("...but the note itself still counts as sent — the TASK was created",
      #pad.queue == 0)
check("...and the flush summary says the image did not attach, not just \"1 sent\"",
      ALERTS[#ALERTS] and ALERTS[#ALERTS]:find("did not attach", 1, true) ~= nil)
check("...naming the task's gid so it can be found and fixed by hand",
      logged("gid 777"))

-- the watchdog: what happens when a callback never fires at all
HTTP_POSTS, TIMERS, ALERTS = {}, {}, {}
pad.queue = { { id = "w", text = "stuck", createdAt = 1, images = {}, tries = 0 } }
pad.flush("manual")
local watchdog
for _, t in ipairs(TIMERS) do if t.kind == "after" then watchdog = t end end
check("every flush arms a watchdog", watchdog ~= nil and pad.watchdog ~= nil)
check("...set to flushTimeout", pad.flushTimeout == 300)
watchdog.fn()
check("🚨 a wedged flush unlatches itself instead of blocking every later send",
      pad.sending == false and logged("unlatching"))
check("...and the note is still in the queue, not lost", #pad.queue == 1)
-- the real callback arriving late must not double-report
ALERTS = {}
HTTP_POSTS[1].cb(201, '{"data":{"gid":"1"}}')
check("...and a late reply does not report a second time", #ALERTS == 0)

-- a vanished image must not cost the note
TASKS = {}
HTTP_POSTS = {}
pad.sending = false
pad.queue = { { id = "f", text = "gone", createdAt = 1,
                images = { pad.imageDir .. "/missing.png" }, tries = 0 } }
pad.flush("manual")
HTTP_POSTS[1].cb(201, '{"data":{"gid":"556"}}')
check("an image that vanished is reported, not fatal",
      #TASKS == 0 and #pad.queue == 0 and logged("image vanished"))

-- clipboard images
pad.draftImages = {}
CLIPBOARD_IMAGE = nil
check("attaching with an empty clipboard is refused",
      pad.attachClipboardImage() == false)
CLIPBOARD_IMAGE = { saveToFile = function(self, path)
    local f = io.open(path, "w"); if f then f:write("PNG"); f:close(); return true end
    return false
end }
check("attaching a clipboard image works", pad.attachClipboardImage() == true)
check("...and it is pinned to the draft", #pad.draftImages == 1)
pad.maxImagesPerNote = 1
check("...and the per-note image cap is enforced",
      pad.attachClipboardImage() == false)
pad.maxImagesPerNote = 8

-- the REAL webview path — the one the user actually hits, and the one
-- neither the font bug nor the "image stays pinned" bug could be caught
-- on without exercising it. hs.webview is set here and cleared again
-- right after, so the no-webview fallback test below still runs under
-- the conditions it expects.
-- WINDOW_STYLE_REFUSES models the thing AppKit actually does and the thing
-- that made the old windowStyle({"titled", …}) call a lie: a window silently
-- keeps the mask it had when it will not honour the one you set. The stub
-- can do both, so both branches of pad.applyNonActivating get exercised.
WINDOW_STYLE_REFUSES = false
hs.webview = {
    -- the real numeric masks, so the arithmetic in applyNonActivating is
    -- tested against the values it will meet, not against invented ones
    windowMasks = { borderless = 0, titled = 1, closable = 2,
                    miniaturizable = 4, resizable = 8, utility = 16,
                    nonactivating = 128, texturedBackground = 256,
                    HUD = 8192, fullSizeContentView = 32768 },
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc
    end },
    new = function(rect, opts, uc)
        local w = { rect = rect, opts = opts, uc = uc, htmlText = nil, shown = false,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h },
                    -- hs.webview hard-codes NSWindowStyleMaskBorderless (0)
                    styleMask = 0, styleAsked = nil }
        function w:frame(f)
            if f then self.frameRect = f; return self end
            return self.frameRect
        end
        function w:html(h) self.htmlText = h; return self end
        function w:windowTitle(t) self.title = t; return self end
        function w:windowStyle(s)
            if s == nil then return self.styleMask end
            self.styleAsked = s
            if not WINDOW_STYLE_REFUSES then self.styleMask = s end
            return self
        end
        function w:allowTextEntry(b) self.textEntry = b; return self end
        function w:closeOnEscape(b) self.closeOnEsc = b; return self end
        function w:level(l) self.lvl = l; return self end
        -- ⚠️ THIS STUB METHOD IS LOAD-BEARING. capture_pad's call is
        -- pcall'd, so if the stub lacked behaviorAsLabels the call would
        -- fail silently and the assertion below would pass while the real
        -- module did nothing — a test that proves the opposite of what it
        -- claims. That is the exact bug shape 6.52.0 fixed in the module.
        function w:behaviorAsLabels(b) self.behavior = b; return self end
        function w:show() self.shown = true; return self end
        function w:bringToFront(b) self.front = b; return self end
        function w:delete() self.deleted = true; return self end
        return w
    end,
}
pad.queue, pad.draftImages, pad.draft = {}, {}, ""
pad.show()
check("pad.show() takes the real webview path when hs.webview exists",
      pad.webview ~= nil and pad.webview.htmlText ~= nil)
-- 🚨 6.52.0 — WHY THE PAD DID NOT APPEAR OVER FULL-SCREEN APPS.
-- Level and collection behaviour are different things. Level decides
-- z-order WITHIN a Space and bringToFront(true) already handled that —
-- but a full-screen app is its OWN Space, and whether a window may show
-- over one is governed entirely by fullScreenAuxiliary. Every canvas
-- popup here has set these flags since 6.20; the webview never did,
-- which is why the behaviour depended on which window you opened.
check("🚨 the pad asks to join all Spaces AND to overlay full-screen ones",
      (function()
    local b = pad.webview.behavior
    if type(b) ~= "table" then return false, "behaviorAsLabels never called" end
    local joins, fullscreen = false, false
    for _, v in ipairs(b) do
        if v == "canJoinAllSpaces"    then joins = true end
        if v == "fullScreenAuxiliary" then fullscreen = true end
    end
    if not joins then return false, "missing canJoinAllSpaces" end
    if not fullscreen then return false, "missing fullScreenAuxiliary" end
    return true
end)())
check("...and it still raises itself, since behaviour alone is not z-order",
      pad.webview.front == true)
check("...sized to the 760x700 configured above", pad.webview.rect.w == 760
      and pad.webview.rect.h == 700)
check("🐛 6.44.1 — the textarea no longer carries the invalid `font:…px inherit` "
      .. "shorthand (WebKit silently drops the whole rule on that combination)",
      pad.webview.htmlText:find("font:14px inherit", 1, true) == nil)
check("...the textarea's font-size is set as a real, valid longhand, at least 14px",
      (function()
          local sz = pad.webview.htmlText:match('textarea[^}]-font%-size:(%d+)px')
          return sz ~= nil and tonumber(sz) >= 14
      end)())
check("...and the compose box itself is taller, not just the font",
      pad.webview.htmlText:find("height:180px", 1, true) ~= nil)

-- attach an image, then take it back off before filing — the exact
-- complaint: an image that "stays attached" with no way to detach it.
CLIPBOARD_IMAGE = { saveToFile = function(self, path)
    local f = io.open(path, "w"); if f then f:write("PNG"); f:close(); return true end
    return false
end }
pad.attachClipboardImage()
check("the draft carries the pinned image", #pad.draftImages == 1)
check("...and the pad redraws with a ✕ the user can click",
      pad.webview.htmlText:find("removeImg(1)", 1, true) ~= nil)
pad.uc.callback({ body = { a = "removeImage", index = 1, text = "" } })
check("clicking the ✕ removes JUST that image from the draft",
      #pad.draftImages == 0)
check("...and the redraw no longer shows it",
      pad.webview.htmlText:find("removeImg(1)", 1, true) == nil)

-- file a note WITH an image, and confirm the draft — and its thumbnail —
-- clears from the compose box the moment the note is queued, not later.
pad.attachClipboardImage()
pad.uc.callback({ body = { a = "add", text = "Email Dana the report" } })
check("filing a note clears the draft image immediately, at file time",
      #pad.draftImages == 0)
check("...not at send time — the compose box shows no leftover thumbnail",
      pad.webview.htmlText:find("<img", 1, true) == nil)
check("...and the note itself kept its own copy of the image path",
      #pad.queue[1].images == 1)

-- 🖱 DRAGGING. hs.webview windows are borderless with no native title bar,
-- so the header is the handle and Lua drives the move by polling the real
-- mouse — a WKWebView stops seeing the pointer the moment it leaves the
-- window, which is why JS mousemove is not used.
check("the header advertises itself as the drag handle",
      pad.webview.htmlText:find("drag here", 1, true) ~= nil
      and pad.webview.htmlText:find("cursor:grab", 1, true) ~= nil)
check("...and no longer asks for a title bar hs.webview cannot give it",
      pad.webview.htmlText ~= nil
      and (math.floor((pad.webview.styleMask or 0) / 1) % 2) == 0)

-- 🐛 6.44.9 — HAMMERSPOON MUST STOP JUMPING TO THE FOREGROUND. 6.44.6
-- removed this module's launchOrFocus, which stopped it ASKING for the app
-- to activate; macOS activates an app anyway when one of its ordinary
-- windows becomes key. A non-activating panel is the one exemption.
check("🐛 6.44.9 — the pad's window is made a NON-ACTIVATING panel, so taking "
      .. "the keyboard no longer drags the whole Hammerspoon app forward",
      pad.nonActivatingApplied == true
      and (math.floor(pad.webview.styleMask / 128) % 2) == 1)
check("...and it still keeps the borderless window it was given, rather than "
      .. "replacing the mask wholesale",
      pad.webview.styleMask == 128)

-- the honest-failure branch: if AppKit refuses the mask, the pad must SAY
-- the app will come forward rather than quietly claim it fixed it. This is
-- the exact failure mode the old windowStyle({"titled", …}) call had.
WINDOW_STYLE_REFUSES = true
pad.hide(); pad.show()
check("...when macOS refuses the mask, the pad reports the failure instead of "
      .. "assuming it worked",
      pad.nonActivatingApplied == false
      and tostring(pad.nonActivatingWhy):find("dropped", 1, true) ~= nil)
check("...and says so on the console, naming the switch that certainly works",
      logged("focusOnOpen"))
WINDOW_STYLE_REFUSES = false

-- an old Hammerspoon with no nonactivating mask at all must degrade, not crash
local savedMasks = hs.webview.windowMasks
hs.webview.windowMasks = { borderless = 0, titled = 1 }
pad.hide(); pad.show()
check("...an older Hammerspoon with no nonactivating mask degrades quietly "
      .. "instead of erroring",
      pad.webview ~= nil and pad.nonActivatingApplied == false
      and tostring(pad.nonActivatingWhy):find("no nonactivating", 1, true) ~= nil)
hs.webview.windowMasks = savedMasks

-- and the switch has to be a switch
pad.nonActivating = false
pad.hide(); pad.show()
check("...setting capturePad.nonActivating = false leaves the window alone",
      pad.webview.styleAsked == nil and pad.nonActivatingApplied == false)
pad.nonActivating = true
pad.hide(); pad.show()

pad.webview:frame({ x = 100, y = 100, w = 760, h = 700 })
MOUSE, MOUSE_DOWN = { x = 150, y = 120 }, true
TIMERS = {}
pad.uc.callback({ body = { a = "dragStart", text = "" } })
check("a header mousedown starts a drag", pad.dragTimer ~= nil)
check("...recording where inside the window the grab happened",
      pad.dragOffset.x == 50 and pad.dragOffset.y == 20)
local dragTick
for _, t in ipairs(TIMERS) do if t.kind == "every" then dragTick = t end end
check("...on a HELD timer", dragTick ~= nil)

MOUSE = { x = 400, y = 300 }
dragTick.fn()
check("moving the mouse moves the pad, keeping the grab offset",
      pad.webview.frameRect.x == 350 and pad.webview.frameRect.y == 280)
check("...without resizing it",
      pad.webview.frameRect.w == 760 and pad.webview.frameRect.h == 700)

MOUSE_DOWN = false
dragTick.fn()
check("🖱 releasing the button ends the drag — even released OUTSIDE the "
      .. "window, since the button state is polled, not taken from JS",
      pad.dragTimer == nil and pad.dragOffset == nil)
MOUSE = { x = 999, y = 999 }
local before = pad.webview.frameRect.x
dragTick.fn()
check("...and the pad stops following the cursor once the drag is over",
      pad.webview.frameRect.x == before)

-- parked notes must be recoverable without hand-editing queue.json
pad.queue, pad.parked = {}, {
    { id = "p1", text = "Fight 4 chan", createdAt = 1, images = {}, tries = 3, parkedAt = 5 },
    { id = "p2", text = "Snap the jet", createdAt = 2, images = {}, tries = 3, parkedAt = 5 },
}
pad.render()
check("the pad offers a button to put parked notes back",
      pad.webview.htmlText:find("retryParked()", 1, true) ~= nil)
pad.uc.callback({ body = { a = "retryParked", text = "" } })
check("retrying moves every parked note back into the queue",
      #pad.queue == 2 and #pad.parked == 0)
check("...with its attempt count reset so it gets a fresh set of tries",
      pad.queue[1].tries == 0 and pad.queue[2].tries == 0)
check("...and nothing was lost in the move", (function()
    local seen = {}
    for _, n in ipairs(pad.queue) do seen[n.text] = true end
    return seen["Fight 4 chan"] and seen["Snap the jet"]
end)())
ALERTS = {}
check("retrying with nothing parked says so instead of pretending",
      pad.retryParked() == 0 and ALERTS[#ALERTS]:find("Nothing parked", 1, true))

-- 🐛 6.44.9 — "NOTHING HAPPENS OTHER THAN LOCAL ACTIONS." Reported with a
-- screenshot showing typed text, an attached image, and "0 queued". "File
-- it" moves the compose box into the queue; "Send now" sends the QUEUE. So
-- Send-with-a-note-in-front-of-you answered "nothing queued" — true, and
-- useless: the note on screen is self-evidently the one meant to go. Send
-- now files the open draft first.
HTTP_POSTS, ALERTS, TASKS = {}, {}, {}
pad.queue, pad.parked, pad.draftImages = {}, {}, {}
pad.draft, pad.draftCaret = "Email Dana the lease numbers", 5
pad.uc.callback({ body = { a = "flush", text = "Email Dana the lease numbers",
                           sel = 5 } })
check("🐛 6.44.9 — Send now files the note still in the compose box instead of "
      .. "answering \"nothing queued\"",
      #HTTP_POSTS == 1
      and HTTP_POSTS[1].body:find("Email Dana the lease numbers", 1, true) ~= nil)
check("...and the compose box is emptied, so the note cannot be sent twice",
      pad.draft == "" and #pad.draftImages == 0 and pad.draftCaret == 0)
HTTP_POSTS[1].cb(201, '{"data":{"gid":"901"}}')   -- clear the sending latch
check("...and the note leaves the queue on delivery, like any other",
      #pad.queue == 0 and pad.sending == false)

-- an image-only draft is still a draft: the reported screenshot had one
HTTP_POSTS, ALERTS, TASKS = {}, {}, {}
pad.queue, pad.draft, pad.draftCaret, pad.draftImages = {}, "", 0, {}
CLIPBOARD_IMAGE = { saveToFile = function(self, path)
    local f = io.open(path, "w"); if f then f:write("PNG"); f:close(); return true end
    return false
end }
pad.attachClipboardImage()
pad.uc.callback({ body = { a = "flush", text = "", sel = 0 } })
check("...an image with no text still counts as a draft worth sending",
      #HTTP_POSTS == 1 and #pad.draftImages == 0)
HTTP_POSTS[1].cb(201, '{"data":{"gid":"902"}}')
if TASKS[1] then TASKS[1].cb(0, '{"data":{"id":"1"}}\n201', "") end
check("...and that send completes, latch and all", pad.sending == false)

-- whitespace is not a note, and Send now must not invent one
HTTP_POSTS, ALERTS, TASKS = {}, {}, {}
pad.queue, pad.draft, pad.draftImages, pad.draftCaret = {}, "   \n  ", {}, 0
pad.uc.callback({ body = { a = "flush", text = "   \n  ", sel = 0 } })
check("...but whitespace alone is not a note — Send now still says nothing is "
      .. "queued rather than filing an empty task",
      #HTTP_POSTS == 0
      and ALERTS[#ALERTS]:find("nothing queued", 1, true) ~= nil)

-- and a draft that cannot be filed must abort the send, not send a half-state
HTTP_POSTS, ALERTS, TASKS = {}, {}, {}
pad.queue, pad.draft, pad.draftImages, pad.draftCaret = {}, "over the cap", {}, 0
pad.maxQueue = 0
pad.uc.callback({ body = { a = "flush", text = "over the cap", sel = 0 } })
check("...and if the draft cannot be filed, Send now reports that and stops "
      .. "rather than sending anyway",
      #HTTP_POSTS == 0 and pad.draft == "over the cap"
      and pad.sending == false)
pad.maxQueue = 200

pad.queue, pad.draft, pad.draftImages, pad.draftCaret = {}, "", {}, 0
pad.hide()
check("closing the pad also stops any drag in progress", pad.dragTimer == nil)
hs.webview = nil

-- the no-webview fallback
PROMPT_ANSWER = { "Queue it", "Email Dana about the lease" }
pad.queue = {}
pad.show()
check("with no hs.webview, ⇪N falls back to a text box and still queues",
      #pad.queue == 1 and pad.queue[1].text == "Email Dana about the lease")
PROMPT_ANSWER = { "Cancel", "nope" }
pad.queue = {}
pad.show()
check("...and a cancelled box queues nothing", #pad.queue == 0)

-- keys and services
-- 🔑 6.182.0 — ⇪N BELONGS TO THE SCORP PAD NOW. LL: "I think hyper+N is
-- enough to open the Scorp Pad." A 🗒 Capture tab is a row in the SCRATCH
-- NOTES section, opened through pad.openHere() → openKind — the same call
-- this key used to make. ⇪⇧N (send now) never moved.
check("🔑 ⇪N is NOT claimed here any more — the Scorp Pad has it",
      hyperFor({}, "n") == nil)
check("…but the route it used to take is still here and still routes",
      type(pad.openHere) == "function" and pad.viaScratch == true)
check("…and calling it opens a Capture TAB rather than this window",
      (function()
          local asked, real = nil, _G.scratchPad
          _G.scratchPad = { openKind = function(k) asked = k return true end }
          pad.openHere()
          _G.scratchPad = real
          return asked == "capture"
      end)())
check("⇪⇧N is claimed", hyperFor({ "shift" }, "n") ~= nil)
check("capturePad.add is published", _G.service.has("capturePad.add"))
check("capturePad.title is published", _G.service.has("capturePad.title"))

-- warm(): the 4 PM timer
TIMERS = {}
capture.warm(core)
local flushTimer
for _, t in ipairs(TIMERS) do if t.kind == "at" then flushTimer = t end end
check("warm() arms a daily timer", flushTimer ~= nil)
check("...at 16:00 exactly", flushTimer and flushTimer.at == "16:00")
check("...repeating every day", flushTimer and flushTimer.repeats == "1d")
check("...and the timer object is HELD (a collected timer never fires)",
      pad.timer ~= nil)

-- =====================================================================
-- 3. QUICK APPEND
-- =====================================================================
local quick = load("quick_append")
quick.setup(core)
local qa = quick.qa
qa.dir = TMP .. "/notes"

local okQ, msgQ = qa.append("first line")
check("append writes", okQ == true)
local qf = io.open(qa.pathFor(qa.targets[1]), "r")
local body1 = qf and qf:read("a") or ""
if qf then qf:close() end
check("...the text is in the file", body1:find("first line", 1, true) ~= nil)
check("...with a timestamp above it", body1:find("── ", 1, true) ~= nil)
check("...and the alert names the target and a preview — Logs is the "
      .. "default now ('if you can't tell, make it a Log entry')",
      tostring(msgQ):find("Logs", 1, true) and tostring(msgQ):find("first line", 1, true))

qa.append("second line")
local qf2 = io.open(qa.pathFor(qa.targets[1]), "r")
local body2 = qf2:read("a"); qf2:close()
check("a second append does NOT truncate the first",
      body2:find("first line", 1, true) ~= nil and body2:find("second line", 1, true) ~= nil)
check("...and the new text comes after the old",
      body2:find("second line", 1, true) > body2:find("first line", 1, true))

check("an empty append is refused", ({ qa.append("") })[1] == false)
check("a whitespace-only append is refused", ({ qa.append("  \n ") })[1] == false)

local okBad, msgBad = qa.append("x", { name = "Nope", file = "/no/such/dir/x.txt" })
check("an unwritable path fails loudly rather than silently",
      okBad == false and tostring(msgBad):find("could not open", 1, true))
check("...and reports through warnWriteFailed", logged("WRITE FAILED"))

CLIPBOARD_TEXT = ""
check("appending an empty clipboard is refused", qa.appendClipboard() == false)
CLIPBOARD_TEXT = "from the clipboard"
check("appending the clipboard works", qa.appendClipboard() == true)

check("an absolute target path is used as-is",
      qa.pathFor({ file = "/tmp/x.txt" }) == "/tmp/x.txt")
check("a ~ target path is expanded",
      qa.pathFor({ file = "~/x.txt" }) == TMP .. "/x.txt")
check("a bare filename lands in qa.dir",
      qa.pathFor({ file = "y.txt" }) == qa.dir .. "/y.txt")

check("notes.append is published", _G.service.has("notes.append"))
check("...and routes to a named target",
      _G.service.call("notes.append", "via service", "Ideas") == true
      and io.open(qa.dir .. "/ideas.txt", "r") ~= nil)
check("6.100.0 — the targets are EXACTLY Logs and Ideas, Logs first "
      .. "(the default); Scratch and Inbox are gone",
      #qa.targets == 2 and qa.targets[1].name == "Logs"
      and qa.targets[2].name == "Ideas" and qa.defaultTarget == 1)
check("notes.appendClipboard is published for ⇪pad1",
      _G.service.has("notes.appendClipboard"))
check("notes.pickTarget is published for ⇪pad3",
      _G.service.has("notes.pickTarget"))
check("⇪J is claimed", hyperFor({}, "j") ~= nil)
check("⇪⇧J is claimed", hyperFor({ "shift" }, "j") ~= nil)

-- 6.100.0 — the CSV index: LL's three columns, quoted like chrome_history
local csvF = io.open(qa.csvPath(), "r")
local csvBody = csvF and csvF:read("a") or ""
if csvF then csvF:close() end
check("every append also landed one row in notes.csv",
      csvBody:find("via service", 1, true) ~= nil
      and csvBody:find("first line", 1, true) ~= nil)
check("...with the | Date | Note Type | Note entry | header, exactly once",
      select(2, csvBody:gsub("Date,Note Type,Note entry", "")) == 1)
check("...and the Note Type column carries the target's name",
      csvBody:find(",Ideas,", 1, true) ~= nil
      and csvBody:find(",Logs,", 1, true) ~= nil)
check("...and the Date column is dated to the minute",
      csvBody:find(os.date("%Y-%m-%d"), 1, true) ~= nil)
check("a target the spec doesn't know records as Logs — 'if you can't "
      .. "tell, make it a Log entry'", qa.noteType("Mystery") == "Logs"
      and qa.noteType("Ideas") == "Ideas" and qa.noteType("Logs") == "Logs")
local okComma = qa.append("a, note with commas\nand a second line")
check("a note with commas and newlines appends fine",
      okComma == true)
local csvF2 = io.open(qa.csvPath(), "r")
local csvBody2 = csvF2 and csvF2:read("a") or ""
if csvF2 then csvF2:close() end
check("...and its CSV field is quoted whole",
      csvBody2:find('"a, note with commas\nand a second line"', 1, true) ~= nil)

-- 6.100.0 — a notes.csv left in 6.99.0's four-column format is rotated
-- to notes-v1.csv on the first append, never appended to misaligned.
check("an old four-column notes.csv is moved aside, not misaligned", (function()
    local quick2 = load("quick_append")
    quick2.setup(core)
    local qa2 = quick2.qa
    qa2.dir = TMP .. "/notes-rotate"
    os.execute('mkdir -p "' .. qa2.dir .. '"')
    local old = io.open(qa2.csvPath(), "w")
    old:write("date,time,category,note\n2026-08-17,12:00:00,Inbox,legacy row\n")
    old:close()
    local ok = qa2.append("fresh row")
    if not ok then return false, "append failed" end
    local v1 = io.open(qa2.dir .. "/notes-v1.csv", "r")
    if not v1 then return false, "notes-v1.csv missing" end
    local v1body = v1:read("a"); v1:close()
    local fresh = io.open(qa2.csvPath(), "r")
    if not fresh then return false, "new notes.csv missing" end
    local freshBody = fresh:read("a"); fresh:close()
    return v1body:find("legacy row", 1, true) ~= nil
       and freshBody:sub(1, 26) == "Date,Note Type,Note entry\n"
       and freshBody:find("fresh row", 1, true) ~= nil
end)())

qa.chooseTarget()
check("the picker lists every target plus a type-it row",
      LAST_CHOOSER and LAST_CHOOSER._choices
      and #LAST_CHOOSER._choices == #qa.targets + 1)
check("...and the type-it row is first",
      LAST_CHOOSER._choices[1].typeIt == true)
-- 👁 6.157.0 — the preview pane shows the END of the file beside the row
check("each target row carries the file's last lines for the preview pane, "
      .. "headed by the target's name",
      type(LAST_CHOOSER._choices[2].rawText) == "string"
      and tostring(LAST_CHOOSER._choices[2].head):find(qa.targets[1].name, 1, true) ~= nil,
      LAST_CHOOSER._choices[2].head)
check("qa.tailText reads only the tail, and drops the line the cut fell inside", (function()
    local p = qa.dir .. "/tail-probe.txt"
    local f = io.open(p, "w")
    for i = 1, 400 do f:write("line " .. i .. " of the probe file, padded out a little\n") end
    f:close()
    local t = qa.tailText(p, 500)
    os.remove(p)
    return t:find("line 400", 1, true) ~= nil and t:find("line 1 of", 1, true) == nil
       and t:sub(1, 5) == "line "
end)())
check("...and says so for a file that does not exist yet",
      qa.tailText(qa.dir .. "/never.txt", 500):find("first append creates it", 1, true) ~= nil)

-- =====================================================================
-- 4. SCREEN VEIL
-- =====================================================================
CANVASES, DELETED_CANVASES, ALERTS = {}, {}, {}
SCREENS = { newScreen(1, 0, 0, 1440, 900), newScreen(2, 1440, 0, 2560, 1440) }
local veilMod = load("screen_veil")
veilMod.setup(core)
local veil = veilMod.veil

veil.show()
check("the veil covers EVERY connected display", #CANVASES == 2)
check("...using fullFrame, so the menu bar is covered too",
      CANVASES[1]._frame.h == 900 and CANVASES[2]._frame.h == 1440)
check("...and is shown", CANVASES[1]._shown and CANVASES[2]._shown)
check("🖱 it is click-through — no mouse tracking at all",
      CANVASES[1]._mouseEvents[1] == false and CANVASES[1]._mouseEvents[2] == false
      and CANVASES[1]._mouseEvents[3] == false and CANVASES[1]._mouseEvents[4] == false)
check("...and never activates on a click", CANVASES[1]._clickActivating == false)
check("...and follows you between Spaces and over full-screen apps",
      (function()
          local b = table.concat(CANVASES[1]._behaviors or {}, ",")
          return b:find("canJoinAllSpaces", 1, true) and b:find("fullScreenAuxiliary", 1, true)
      end)())

veil.setLevel(5.0)
check("🚨 the strength is hard-capped and NEVER reaches opaque",
      veil.level == veil.maxLevel and veil.level < 1.0)
check("...the cap is the 90% you asked for", veil.maxLevel == 0.90)
veil.setLevel(-3)
check("...and cannot go below the floor either", veil.level == veil.minLevel)
veil.setLevel(0 / 0)
check("...a NaN cannot poison it", veil.level == veil.minLevel)

veil.setLevel(0.40)
check("the strength is remembered across reloads", SETTINGS["screenVeil.level"] == 0.40)
veil.presetIndex = 1
veil.cyclePreset()
check("cycling moves to the next preset", veil.level == veil.presets[2].level)
veil.presetIndex = #veil.presets
veil.cyclePreset()
check("...and wraps at the end", veil.level == veil.presets[1].level)

local before = #CANVASES
SCREENS = { SCREENS[1] }
veil.draw()
check("unplugging a monitor reaps its sheet",
      #DELETED_CANVASES >= 1 and before == 2)
SCREENS = { newScreen(1, 0, 0, 1440, 900), newScreen(3, 1440, 0, 1920, 1080) }
veil.draw()
check("plugging one in gets a sheet of its own", #CANVASES == 3)

veil.hide()
check("hide removes every sheet", next(veil.canvases) == nil and veil.on == false)
veil.hide()
check("...and hiding twice is harmless", veil.on == false)

local panic
for _, b in ipairs(BOUND) do
    if b.key == "G" and table.concat(b.mods, "+"):find("shift") then panic = b end
end
check("🚨 the panic key is a PLAIN chord, not a hyper shortcut", panic ~= nil)
veil.show()
panic.fn()
check("...and it tears the veil down from any state",
      veil.on == false and next(veil.canvases) == nil)

check("⇪G toggles", hyperFor({}, "g") ~= nil)
check("⇪⇧G cycles strength", hyperFor({ "shift" }, "g") ~= nil)
check("⇪⇧= and ⇪⇧- nudge",
      hyperFor({ "shift" }, "=") ~= nil and hyperFor({ "shift" }, "-") ~= nil)
check("a display-arrangement watcher is running",
      SCREEN_WATCHER ~= nil and SCREEN_WATCHER.started == true)

SETTINGS["screenVeil.level"] = 0.75
veil.on = true
veilMod.warm(core)
check("a reload restores the STRENGTH you last used", veil.level == 0.75)
check("🚨 ...but never comes back up dimmed — warm() does not switch it on",
      (function() veil.on = false; veilMod.warm(core); return veil.on == false end)())

-- ---------------------------------------------------------------------
-- 4b. THE GRAYSCALE RELAY (6.140.0) — press the key macOS listens for
-- ---------------------------------------------------------------------
-- The module was set up above with the real core, so the services are
-- already registered; the stubs below are added only now, which also
-- proves the relay looks its tools up at CALL time, not at setup.
local KEYSTROKES, EXECUTED, OPENED_URLS = {}, {}, {}
local DEFAULTS_OUT = ""
hs.eventtap.keyStroke = function(mods, key, delay)
    table.insert(KEYSTROKES, { mods = table.concat(mods, "+"),
                               key = key, delay = delay })
end
hs.execute = function(cmd)
    table.insert(EXECUTED, cmd)
    return DEFAULTS_OUT, true, "exit", 0
end
hs.urlevent = { openURL = function(u) table.insert(OPENED_URLS, u) end }

check("the three console doors exist — and the setup door is GONE "
      .. "(6.145.0, at LL's word: the tick was made by hand)",
      _G.mono ~= nil and _G.monoReport ~= nil and _G.invertColours ~= nil
      and _G.monoSetup == nil)
check("...and the ⇪; rows can reach the live ones by service name — "
      .. "and cannot reach the retired one",
      _G.service.registry["veil.mono"] ~= nil
      and _G.service.registry["veil.invert"] ~= nil
      and _G.service.registry["veil.monoSetup"] == nil)

ALERTS = {}
check("mono() presses ⌥⌘F5 — the macOS Accessibility Shortcut",
      veil.mono() == true and #KEYSTROKES == 1
      and KEYSTROKES[1].key == "f5"
      and KEYSTROKES[1].mods:find("alt") and KEYSTROKES[1].mods:find("cmd"))
check("...with an explicit 0 delay — the default is 200ms of blocked "
      .. "main thread", KEYSTROKES[1].delay == 0)
check("...and the read-back timer is HELD, not thrown away",
      veil.monoTimer ~= nil and veil.monoTimer.fn ~= nil)
check("...and NOTHING has shelled out yet — the keypress alone is the act",
      #EXECUTED == 0)

-- The read-back, three ways. Fire the held timer by hand with the
-- preference file saying three different things.
DEFAULTS_OUT = "{\n    colorFilterEnabled = 1;\n    colorFilterType = 0;\n}"
veil.monoTimer.fn()
check("read-back with the filter on says Grayscale ON",
      ALERTS[#ALERTS]:find("Grayscale ON", 1, true) ~= nil)
check("...the timer handle is released after it fires", veil.monoTimer == nil)
check("...and the whole domain went through ONE child process, not three",
      #EXECUTED == 1 and EXECUTED[1]:find("/usr/bin/defaults", 1, true) ~= nil
      and EXECUTED[1]:find(" read ", 1, true) ~= nil)

veil.mono()
DEFAULTS_OUT = "{\n    colorFilterEnabled = 1;\n    colorFilterType = 2;\n}"
veil.monoTimer.fn()
check("a filter that is on but NOT grayscale is named, not claimed",
      ALERTS[#ALERTS]:find("not grayscale", 1, true) ~= nil)

veil.mono()
DEFAULTS_OUT = ""   -- the domain has never been written
veil.monoTimer.fn()
check("an unanswerable domain names the by-hand tick, not a guess — "
      .. "and no longer points at the retired setup door",
      ALERTS[#ALERTS]:find("Color Filters", 1, true) ~= nil
      and ALERTS[#ALERTS]:find("Accessibility", 1, true) ~= nil
      and ALERTS[#ALERTS]:find("monoSetup", 1, true) == nil)

-- monoState parses the dump, and cannot be fooled by a longer key name.
DEFAULTS_OUT = "{\n    colorFilterEnabled = 0;\n    grayscaleTint = 9;\n"
            .. "    grayscale = 1;\n}"
local st = veil.monoState()
check("monoState reads the dump: off, legacy key on, no type",
      st.filterOn == 0 and st.legacyGray == 1 and st.filterType == nil)

-- The report is honest about WHAT it read.
DEFAULTS_OUT = "{\n    colorFilterEnabled = 1;\n    colorFilterType = 0;\n}"
local rep = veil.monoReport()
check("the report says it read the PREFERENCE FILE, not the screen",
      rep:find("PREFERENCE FILE, NOT THE SCREEN", 1, true) ~= nil)
check("...names the one-tick rule that makes ⌥⌘F5 a toggle",
      rep:find("one feature ticked", 1, true) ~= nil)
check("...and lands on the clipboard",
      CLIPBOARD_TEXT:find("GRAYSCALE", 1, true) ~= nil)

-- 🪦 6.145.0 — the setup door is RETIRED at LL's word ("remove it and
-- rollback changes"). The one-time tick was made by hand, and the
-- native triple-press of Touch ID covers the walk to the pane. The
-- doors check above pins the global and the service gone; these pin
-- the source, the cheat sheet, and that the relay never opens a URL.
local veilSrc = (function()
    local f = io.open(MODDIR .. "/screen_veil.lua", "r")
    if not f then return "" end
    local s = f:read("*a"); f:close(); return s
end)()
check("🪦 the retired name is out of the SOURCE, not just unhooked",
      #veilSrc > 0 and veilSrc:find("monoSetup", 1, true) == nil)
check("...and the whole run never opened a URL — the relay presses "
      .. "keys, nothing else", #OPENED_URLS == 0)
check("the cheat sheet names the native triple-press of Touch ID — "
      .. "LL's ask when the door came out", (function()
    for _, e in ipairs(veilMod.cheatsheet.entries) do
        if tostring(e[1]):find("Touch ID", 1, true)
           and tostring(e[2]):find("triple%-press") then return true end
    end
    return false
end)())

check("invert() presses ⌃⌥⌘8, also with 0 delay", (function()
    local n = #KEYSTROKES
    return veil.invert() == true and KEYSTROKES[n + 1].key == "8"
       and KEYSTROKES[n + 1].mods:find("ctrl")
       and KEYSTROKES[n + 1].delay == 0
end)())

-- 6.141.0 — LL: "why am I not using some hyperkey combo for my new
-- grayscale?" — and picked ⇪9, with ⇪⇧9 for invert. The integration
-- suite's conflict sentry refused the second half: ⇪⇧9 was the numpad
-- laptop row's top-right window key. 6.142.0 — LL answered by clearing
-- that whole layer ("These shortcuts were supposed to be cleaned,
-- cleared and the keys listed as future possible options"), so ⇪⇧9
-- now goes exactly where LL pointed in the first place.
check("⇪9 is bound and relays ⌥⌘F5", (function()
    local h = hyperFor({}, "9")
    if not h then return false, "no ⇪9 binding" end
    local n = #KEYSTROKES
    h.fn()
    return KEYSTROKES[n + 1] ~= nil and KEYSTROKES[n + 1].key == "f5"
end)())
check("🚨 ⇪⇧9 IS the veil's now — invert colours, LL's 6.141.0 pick, "
      .. "honoured once the numpad row was cleared in 6.142.0", (function()
    local h = hyperFor({ "shift" }, "9")
    return h ~= nil and h.name == "invert colours", h and h.name
end)())
check("...and pressing it relays ⌃⌥⌘8, exactly like the ⇪; row", (function()
    local h = hyperFor({ "shift" }, "9")
    if not h then return false, "no ⇪⇧9 binding" end
    local n = #KEYSTROKES
    h.fn()
    local ks = KEYSTROKES[n + 1]
    return ks ~= nil and ks.key == "8" and ks.mods:find("ctrl") ~= nil
end)())

ALERTS = {}
hs.eventtap.keyStroke = function() error("posting refused") end
check("a refused keystroke is reported, never raised",
      veil.mono() == false
      and ALERTS[1]:find("Could not send", 1, true) ~= nil)

-- 🚨 THE 6.82.0 VERDICT IS STRUCTURAL LAW: the relay READS the preference
-- and never writes it. (launchctl/killall are banned config-wide by
-- test_diagnostics 9a; this pins the write path too.)
check("🚨 the module never runs `defaults write` — it presses a key instead",
      (function()
          local f = io.open(MODDIR .. "/screen_veil.lua", "r")
          if not f then return false, "cannot read source" end
          local src = f:read("a"); f:close()
          -- comment lines are skipped: the header QUOTES 6.82.0's failed
          -- "defaults write" attempt, and prose is not a call
          for line in src:gmatch("[^\n]+") do
              if not line:match("^%s*%-%-") and line:find("write", 1, true)
                 and line:find("defaults", 1, true) then
                  return false, line
              end
          end
          return true
      end)())

-- Put the stubs back the way section 5+ expects them: absent.
hs.eventtap.keyStroke = nil
hs.execute = nil
hs.urlevent = nil

-- =====================================================================
-- 5. MINI CALENDAR
-- =====================================================================
local calMod = load("mini_calendar")
calMod.setup(core)
local cal = calMod.cal

local function ymd(t) return os.date("%Y-%m-%d", t) end
local function at(y, m, d) return os.time({ year = y, month = m, day = d, hour = 12 }) end

cal.today  = at(2026, 8, 6)
cal.cursor = at(2026, 8, 6)

cal.moveDays(1)
check("→ moves one day", ymd(cal.cursor) == "2026-08-07")
cal.moveDays(-2)
check("← moves back", ymd(cal.cursor) == "2026-08-05")
cal.moveDays(7)
check("↓ moves a week", ymd(cal.cursor) == "2026-08-12")

cal.cursor = at(2026, 1, 31)
cal.today  = at(2026, 1, 31)
cal.moveMonths(1)
check("31 January + 1 month lands on the last day of February, not 3 March",
      ymd(cal.cursor) == "2026-02-28")
cal.cursor = at(2024, 1, 31); cal.today = at(2024, 1, 31)
cal.moveMonths(1)
check("...and knows 2024 was a leap year", ymd(cal.cursor) == "2024-02-29")
cal.cursor = at(2026, 3, 31); cal.today = at(2026, 3, 31)
cal.moveMonths(1)
check("31 March + 1 month is 30 April, not 1 May", ymd(cal.cursor) == "2026-04-30")
cal.cursor = at(2026, 12, 15); cal.today = at(2026, 12, 15)
cal.moveMonths(1)
check("December + 1 rolls the year", ymd(cal.cursor) == "2027-01-15")
cal.cursor = at(2026, 1, 15); cal.today = at(2026, 1, 15)
cal.moveMonths(-1)
check("January - 1 rolls the year back", ymd(cal.cursor) == "2025-12-15")

-- ⏰ daylight saving. Under TZ=America/New_York these three cross real
-- clock changes; under UTC they simply pass.
cal.today = at(2026, 3, 7); cal.cursor = at(2026, 3, 7)
cal.moveDays(1)
check("a day step survives spring-forward", ymd(cal.cursor) == "2026-03-08")
cal.moveDays(1)
check("...and the day after it", ymd(cal.cursor) == "2026-03-09")
cal.today = at(2026, 11, 1); cal.cursor = at(2026, 10, 31)
cal.moveDays(1)
check("a day step survives fall-back", ymd(cal.cursor) == "2026-11-01")

cal.today = at(2026, 8, 6); cal.cursor = at(2026, 8, 6)
cal.rangeDays = 365
cal.moveDays(400)
check("the cursor stops at +1 year, exactly as asked",
      ymd(cal.cursor) == ymd(at(2027, 8, 6)))
check("...and the panel says it hit the wall", cal.atEdge == true)
cal.moveDays(-2000)
check("...and stops at -1 year going back",
      ymd(cal.cursor) == ymd(at(2025, 8, 6)))
cal.goToday()
check("T goes back to today", ymd(cal.cursor) == "2026-08-06")
check("...and clears the edge warning", cal.atEdge == false)

-- 6.244.0: the WIDTH is still the 1024 he asked for; the HEIGHT was a
-- literal 768 and is worked out from the content now (his "large empty
-- space below the dates"). nil is the knob saying "fit it".
check("the panel is the 1024 wide he asked for, and no longer a literal 768",
      cal.width == 1024 and cal.height == nil)
check("the date numbers are 16px, as asked", cal.dayTextSize == 16)
-- 6.244.0: the music player's #15161a rather than the old near-pure black.
-- Still unmistakably a dark card, still translucent — the check moved with
-- the colour instead of being deleted for failing.
check("it is the music player's dark card, and still translucent",
      cal.bg.red < 0.12 and cal.bg.green < 0.12 and cal.bg.blue < 0.15
      and cal.alpha < 1)
check("three months are shown", cal.months == 3)
check("⇪⇧0 opens it", hyperFor({ "shift" }, "0") ~= nil)

cal.show()
check("opening draws a canvas", cal.canvas ~= nil)
check("...anchored top-right, under the clock",
      cal.canvas._frame.x + cal.canvas._frame.w >= SCREENS[1]:frame().w - 20)
check("...that does not steal focus when clicked",
      cal.canvas._clickActivating == false)
check("...with its key modal armed", cal.modal and cal.modal.entered == true)
local hasArrows = false
for _, b in ipairs(cal.modal.bindings) do if b.key == "left" then hasArrows = true end end
check("...and the arrows bound only while it is up", hasArrows)
check("Esc is bound", (function()
    for _, b in ipairs(cal.modal.bindings) do if b.key == "escape" then return true end end
end)())
check("...and Esc has NO repeat handler (a repeat would close twice)", (function()
    for _, b in ipairs(cal.modal.bindings) do
        if b.key == "escape" then return b.repeatFn == nil end
    end
end)())
-- 📋 CLICKING A DATE COPIES IT. The format is the one asked for:
-- 08-07-26, every part zero-padded to two digits so pasted dates align.
CLIPBOARD_TEXT = ""
local aug7 = at(2026, 8, 7)
check("the date format is MM-DD-YY", cal.formatDate(aug7) == "08-07-26")
check("...zero-padded, so a single-digit month still has two digits",
      cal.formatDate(at(2026, 1, 5)) == "01-05-26")
check("...and the year rolls to two digits too",
      cal.formatDate(at(2027, 12, 31)) == "12-31-27")

ALERTS = {}
local copied = cal.copyDate(aug7)
check("copyDate returns what it put on the clipboard", copied == "08-07-26")
check("...and it really reached the clipboard", CLIPBOARD_TEXT == "08-07-26")
check("...and says so, with the weekday as a sanity check",
      ALERTS[#ALERTS]:find("08-07-26", 1, true) ~= nil
      and ALERTS[#ALERTS]:find("Fri", 1, true) ~= nil)

-- through the real mouse callback, the way an actual click arrives
-- The panel is already open from the block above; re-render it on a known
-- date rather than calling show(), which toggles and would close it.
CLIPBOARD_TEXT, ALERTS = "", {}
cal.today, cal.cursor = at(2026, 8, 6), at(2026, 8, 6)
cal.render()
local dayId = "day:2026-08-20"
check("(the fixture day is on screen and clickable)",
      cal.hitboxes[dayId] ~= nil)
cal.canvas._mouseCallback(cal.canvas, "mouseDown", dayId)
check("🖱 clicking a date selects it", ymd(cal.cursor) == "2026-08-20")
check("...AND copies it in one action", CLIPBOARD_TEXT == "08-20-26")
check("C copies the highlighted date without the mouse", (function()
    CLIPBOARD_TEXT = ""
    for _, b in ipairs(cal.modal.bindings) do
        if b.key == "c" then b.fn(); return CLIPBOARD_TEXT == "08-20-26" end
    end
end)())
check("...and holding C does NOT refill the clipboard 30 times a second",
      (function()
          for _, b in ipairs(cal.modal.bindings) do
              if b.key == "c" then return b.repeatFn == nil end
          end
      end)())
check("the ‹ › and Today buttons still only navigate, never copy", (function()
    CLIPBOARD_TEXT = ""
    cal.canvas._mouseCallback(cal.canvas, "mouseDown", "nav:today")
    return CLIPBOARD_TEXT == "" and ymd(cal.cursor) == "2026-08-06"
end)())
check("copyOnClick = false makes a click select only", (function()
    cal.copyOnClick = false
    CLIPBOARD_TEXT = ""
    cal.canvas._mouseCallback(cal.canvas, "mouseDown", "day:2026-08-20")
    local quiet = (CLIPBOARD_TEXT == "")
    cal.copyOnClick = true
    return quiet and ymd(cal.cursor) == "2026-08-20"
end)())
check("calendar.format is published for other modules",
      _G.service.call("calendar.format", aug7) == "08-07-26")

-- =====================================================================
-- 🗓 6.244.0 — THE PANEL IS AS TALL AS WHAT IS IN IT
-- =====================================================================
-- LL, with two screenshots: "I don't know why we made such a large empty
-- space below the dates" · "There's a lot of space below the calendar. Why
-- do we have that?" · "The date and time should be above the months, same
-- as large."
--
-- The height was a LITERAL 768 while the content needed about 490, and the
-- readout under the months was drawn `cal.height - L.footY - L.pad` tall —
-- so it stretched to eat every point of slack, and the footer was pinned to
-- the BOTTOM OF THE WINDOW rather than to the bottom of the calendar. Both
-- of his empty spaces were drawn on purpose, by arithmetic nobody reread.
--
-- cal.layout is PURE, so all of it is proven here with no screen.
do
    local L = cal.layout(1024, 3)

    -- 📐 THE SUM IS THE HEIGHT. This is the row the release exists for: no
    -- band may be stretched to reach an edge, so the total must equal the
    -- parts added up, with nothing left over.
    check("🗓 the panel's height IS the sum of its bands — nothing is "
          .. "stretched to fill a gap",
          L.height == L.footY + L.footH + L.pad, L.height)
    check("...and the footer sits under the MONTHS, not against the bottom "
          .. "of the window", L.footY == L.monthY + L.monthH + 12,
          L.footY .. " vs " .. (L.monthY + L.monthH))
    check("...so the space under the last row is one padding, not 274 points",
          L.height - (L.monthY + L.monthH) == 12 + L.footH + L.pad,
          L.height - (L.monthY + L.monthH))

    -- 🚨 THE ORDER LL ASKED FOR: the date and the time ABOVE the months.
    check("🗓 the readout is ABOVE the months", L.readY + L.readH <= L.monthY,
          L.readY .. "+" .. L.readH .. " vs " .. L.monthY)
    check("...and under the header strip, not over it",
          L.readY >= L.headerH, L.readY .. " vs " .. L.headerH)
    check("...and the readout's own height is FIXED, not whatever is left "
          .. "over — that box was the empty space",
          L.readH == 88 and L.readH < L.monthH, L.readH)

    -- 📏 The whole point, in one number.
    check("🗓 the panel is far shorter than the 768 it was hard-coded to",
          L.height < 560 and L.height > 380, L.height)

    -- SIX ROWS ALWAYS, deliberately: a five-row month and a six-row month
    -- must not give the panel two different heights, or it would jump size
    -- as he pages through the year with [ and ].
    check("🗓 the month block is always six rows, so paging never resizes "
          .. "the panel", L.monthH == L.titleH + L.dowH + 6 * L.cellH,
          L.monthH)
    check("...and every band is a positive number",
          L.pad > 0 and L.headerH > 0 and L.readH > 0 and L.monthH > 0
          and L.footH > 0 and L.colW > 0 and L.cellW > 0)

    -- PURE means it answers about the numbers it is GIVEN, never about the
    -- module's own state — which is what lets the gate prove a 4K panel and
    -- a clamped one without a screen.
    local wide = cal.layout(1600, 3)
    check("🗓 cal.layout is PURE — a wider panel gets wider columns and the "
          .. "same height", wide.colW > L.colW and wide.height == L.height,
          wide.colW .. " / " .. wide.height)
    local two = cal.layout(1024, 2)
    check("...and fewer months means wider columns, still the same height",
          two.colW > L.colW and two.height == L.height, two.colW)
    check("...and a nonsense width does not throw or go negative",
          cal.layout(nil, nil).height == L.height
          and cal.layout("wide", 0).cellW > 0)

    -- 🔌 NIL MEANS "WORK IT OUT", A NUMBER IS TAKEN AT ITS WORD (6.230.0's
    -- rule). His override has to keep winning, or a panel he sized by hand
    -- would silently snap back on the next release.
    local hadHeight = cal.height
    cal.height = nil
    check("🔌 with no height set, the panel asks for the content's height",
          cal.panelHeight() == L.height, cal.panelHeight())
    cal.height = 700
    check("...and a number in settings is obeyed, not overruled",
          cal.panelHeight() == 700, cal.panelHeight())
    cal.height = hadHeight

    -- 🚨 THE KNOB AND THE OUTCOME ARE DIFFERENT FIELDS. show() used to write
    -- the screen-clamped size back over cal.width/cal.height, so a panel the
    -- screen had squeezed could never work its height out again — the fix
    -- for the empty space would have been undone by the first small display.
    local src = (function()
        local f = io.open(MODDIR .. "/mini_calendar.lua", "r")
        local t = f:read("*a") ; f:close() ; return t
    end)()
    check("🚨 the clamped size is never written back over the knobs",
          src:find("cal%.width, cal%.height = f%.w, f%.h") == nil
          and src:find("cal%.drawW, cal%.drawH = f%.w, f%.h") ~= nil)
    check("...and the readout is no longer sized off the window's height",
          src:find("cal%.height %- L%.footY") == nil)

    -- 🎨 The music player's card, on his ask. The player is a WEBVIEW and is
    -- the one panel ui_style.lua does not reach, so these are written here
    -- — and the fact that this diverges from the other nine is NAMED in the
    -- module rather than left for someone to notice.
    check("🎨 the card carries the player's own colours",
          type(cal.headerBg) == "table" and type(cal.btnBg) == "table"
          and type(cal.inkDim) == "table")
    check("...and the divergence from ui_style is written down, not silent",
          src:find("NAMED, NOT FIXED", 1, true) ~= nil)

    -- =================================================================
    -- 🚨 AND NOW THE DRAWING, because the numbers above proved NOTHING
    -- about it. Two mutations — stretching the readout back to the bottom
    -- of the window, and pinning the footer to it — left every check above
    -- green, and those two ARE his complaint. A layout that is right while
    -- the render ignores it is 6.220.0's rule in a new costume: assert
    -- where the forbidden thing would actually happen.
    -- =================================================================
    local wasToday, wasCursor = cal.today, cal.cursor
    cal.today, cal.cursor = at(2026, 8, 6), at(2026, 8, 6)
    -- ⇪⇧0 TOGGLES, so a panel an earlier section left open would be
    -- CLOSED by a bare show() and this whole block would read a nil canvas.
    -- And the sections after this one expect the panel in the state they
    -- left it, so it is put back at the end rather than simply closed.
    local wasOpen = (cal.canvas ~= nil)
    if cal.canvas then cal.hide() end
    cal.show()
    local els = cal.canvas and cal.canvas._elements
    -- cal.drawW nil means show() did not record what it drew — a fault in
    -- its own right, and the layout still answers rather than throwing.
    local Ld  = cal.layout(cal.drawW or cal.width, cal.months)

    local function findText(needle)
        for _, e in ipairs(els or {}) do
            if e.type == "text" and type(e.text) == "string"
               and e.text:find(needle, 1, true) then return e end
        end
    end
    -- The readout's own panel: the one soft-white filled rectangle.
    local function readoutRect()
        for _, e in ipairs(els or {}) do
            if e.type == "rectangle" and e.action == "fill" and e.fillColor
               and e.fillColor.white == 1 and e.fillColor.alpha == 0.05 then
                return e
            end
        end
    end

    local rr = readoutRect()
    check("🚨 DRAWN: the readout box is its own height, not the window's "
          .. "leftover — this is the empty space he photographed",
          rr ~= nil and rr.frame.h == Ld.readH,
          rr and (rr.frame.h .. " tall in a " .. tostring(cal.drawH) .. " panel"))
    check("...and it is drawn ABOVE the months",
          rr ~= nil and rr.frame.y == Ld.readY and rr.frame.y < Ld.monthY,
          rr and rr.frame.y)

    local foot = findText("Esc close")
    check("🚨 DRAWN: the footer sits under the months, not against the "
          .. "bottom of the window",
          foot ~= nil and foot.frame.y == Ld.footY,
          foot and (foot.frame.y .. " vs footY " .. Ld.footY
                    .. " / panel " .. tostring(cal.drawH)))
    check("...and there is one padding under it, not a field of nothing",
          foot ~= nil and type(cal.drawH) == "number"
          and (cal.drawH - (foot.frame.y + foot.frame.h)) <= Ld.pad + 1,
          foot and type(cal.drawH) == "number"
              and (cal.drawH - (foot.frame.y + foot.frame.h))
              or ("drawH is " .. tostring(cal.drawH)))

    -- Found by SHAPE, not by the words: the date string depends on the
    -- locale and on which weekday the fixture's date happens to be, and a
    -- check that stops biting because a month rolled over is not a check.
    local dateEl, timeEl
    for _, e in ipairs(els or {}) do
        if e.type == "text" and e.textSize == 34 then
            if e.textAlignment == "right" then timeEl = e else dateEl = e end
        end
    end
    -- 🚨 NOT findText, and it is still right even though 6.249.0 deleted
    -- the range line that first made it necessary: the date string
    -- depends on the locale and on which weekday the fixture lands on.
    -- The month titles are the 18 pt centred ones.
    local monthEl
    for _, e in ipairs(els or {}) do
        if e.type == "text" and e.textSize == 18
           and e.textAlignment == "center" then monthEl = monthEl or e end
    end
    check("🗓 DRAWN: the big date is above the month titles, and is still "
          .. "34 pt — the size was never the complaint",
          dateEl ~= nil and monthEl ~= nil and dateEl.textSize == 34
          and dateEl.frame.y < monthEl.frame.y,
          dateEl and (dateEl.frame.y .. " vs "
                      .. tostring(monthEl and monthEl.frame.y)))
    check("...and the live clock sits on the same line, right-aligned",
          timeEl ~= nil and dateEl ~= nil and timeEl.frame.y == dateEl.frame.y,
          timeEl and timeEl.text)

    -- 🎨 The player's header strip, and the hairline under it.
    local strip
    for _, e in ipairs(els or {}) do
        if e.type == "rectangle" and e.action == "fill" and e.fillColor
           and e.fillColor.red and e.frame and e.frame.h == Ld.headerH then
            strip = e
        end
    end
    check("🎨 DRAWN: the music player's header strip runs across the top",
          strip ~= nil and strip.frame.y < 1, strip and strip.frame.h)

    -- ---- 🗓 6.249.0 — the header holds the nav and nothing else --------
    -- LL: "Doesn't need the 'September 2026 → November 2026' label and the
    -- ‹ Today › should go there — that month label should be gone so that
    -- Today is right above the large date text."
    local nav = cal.navButtons(Ld)
    check("navButtons answers the three, left to right",
          #nav == 3 and nav[1].id == "nav:-1" and nav[2].id == "nav:today"
          and nav[3].id == "nav:1")
    check("...laid out from the LEFT with no overlap",
          nav[1].x == Ld.btnX
          and nav[2].x == nav[1].x + nav[1].w + Ld.btnGap
          and nav[3].x == nav[2].x + nav[2].w + Ld.btnGap,
          nav[1].x .. "," .. nav[2].x .. "," .. nav[3].x)
    check("...all on one row, at the header's own button height",
          nav[1].y == Ld.btnY and nav[2].y == Ld.btnY and nav[3].y == Ld.btnY
          and nav[1].h == Ld.btnH)
    -- 🚨 MUTATION: pin btnX back to the right edge (W - pad - 216) and the
    -- cluster is no longer over the date — his whole sentence.
    check("🗓 the cluster starts at the SAME left edge as the big date",
          dateEl ~= nil and nav[1].x == dateEl.frame.x
          and Ld.btnX == Ld.textX,
          dateEl and (nav[1].x .. " vs " .. dateEl.frame.x))
    check("...and the header is only as tall as what is in it",
          Ld.headerH == Ld.btnH + 20
          and nav[1].y >= 0 and nav[1].y + nav[1].h <= Ld.headerH,
          Ld.headerH)

    -- 🚨 MUTATION: put the range line back. Found by SHAPE — "<Month>
    -- <year>  →" — because the month NAMES move with the fixture's date.
    local rangeLine
    for _, e in ipairs(els or {}) do
        if e.type == "text" and type(e.text) == "string"
           and e.text:find("%a+ %d%d%d%d%s+→") then rangeLine = e end
    end
    check("🗓 DRAWN: the month-range label is GONE — the three month "
          .. "titles under it already say it", rangeLine == nil,
          rangeLine and rangeLine.text)

    -- 🚨 DRAWN: the buttons really are where navButtons put them, and
    -- ABOVE the date. A mutation that lays the draw out by hand again
    -- passes every check above and fails this one.
    local todayBtn
    for _, e in ipairs(els or {}) do
        if e.type == "rectangle" and e.id == "nav:today" then todayBtn = e end
    end
    check("🗓 DRAWN: ‹ Today › is drawn from the pure layout, above the date",
          todayBtn ~= nil and todayBtn.frame.x == nav[2].x
          and todayBtn.frame.y == nav[2].y
          and dateEl ~= nil
          and todayBtn.frame.y + todayBtn.frame.h <= dateEl.frame.y,
          todayBtn and (todayBtn.frame.x .. "," .. todayBtn.frame.y))
    check("...and every one of them is clickable",
          (function()
              for _, b in ipairs(nav) do
                  if cal.hitboxes[b.id] == nil then return false, b.id end
              end
              return true
          end)())

    if not wasOpen then cal.hide() end
    cal.today, cal.cursor = wasToday, wasCursor
end

-- 🕐 6.147.0 — THE DATE REPORT AND THE CLOCK, both LL's ask verbatim:
-- "give all as a 'Date report:'" · "a time display: 2:00:00 PM so I
-- can see what time it is".
local noon7 = at(2026, 8, 7)
local rep = cal.buildReport(noon7, at(2026, 8, 7))
check("the report opens with the heading LL named",
      rep:find("^Date report: Friday, August 7, 2026") ~= nil, rep)
check("...and carries EVERY configured format", (function()
    for _, fmt in ipairs(cal.reportFormats) do
        if not rep:find(os.date(fmt, noon7), 1, true) then return false, fmt end
    end
    return true
end)())
check("...the week/day line", rep:find("week %d+ · day %d+ of %d+") ~= nil)
check("...and the time now, closing it", rep:find("Time now: ", 1, true) ~= nil)
check("the clock shaves the leading zero — 2:00:00 PM, not 02:00:00 PM",
      cal.timeNow(at(2026, 8, 7) + 2 * 3600):match("^2:") ~= nil
      and cal.timeNow(at(2026, 8, 7) + 2 * 3600):find("PM", 1, true) ~= nil,
      cal.timeNow(at(2026, 8, 7) + 2 * 3600))
check("R copies the report from the keyboard, and never on repeat", (function()
    CLIPBOARD_TEXT = ""
    for _, b in ipairs(cal.modal.bindings) do
        if b.key == "r" then
            b.fn()
            return CLIPBOARD_TEXT:find("Date report:", 1, true) ~= nil
                   and b.repeatFn == nil
        end
    end
    return false
end)(), CLIPBOARD_TEXT:sub(1, 40))
check("calendar.report is published for other modules", (function()
    CLIPBOARD_TEXT = ""
    local r = _G.service.call("calendar.report", noon7)
    return type(r) == "string" and r:find("08-07-26", 1, true) ~= nil
end)())
check("the panel ticks a live clock while open — held, 1s, stopped on hide",
      cal.clock ~= nil)

cal.hide()
check("closing deletes the canvas and disarms the keys",
      cal.canvas == nil and cal.modal.entered == false)

-- 🍅 6.211.0 — the pomodoro card docks beside the panel while it is up.
-- The calendar's half: it CALLS pomodoro.dock with its frame as it
-- opens, pomodoro.undock as it closes, and publishes calendar.frame.
do
    local DOCKS, UNDOCKS = {}, 0
    _G.service.provide("pomodoro.dock",   function(f) DOCKS[#DOCKS + 1] = f return true end)
    _G.service.provide("pomodoro.undock", function() UNDOCKS = UNDOCKS + 1 return true end)
    check("calendar.frame is nil while the panel is closed", _G.service.call("calendar.frame") == nil)
    cal.show()
    check("🚨 opening the calendar asks the pomodoro to dock, with the panel's own frame",
          #DOCKS == 1 and type(DOCKS[1]) == "table"
          and DOCKS[1].w == cal.drawW and DOCKS[1].h == cal.drawH
          and DOCKS[1].x == cal.canvas:frame().x, DOCKS[1] and (DOCKS[1].w .. "x" .. DOCKS[1].h))
    check("calendar.frame answers the frame while it is up", (function()
        local f = _G.service.call("calendar.frame")
        return type(f) == "table" and f.w == cal.drawW
    end)())
    cal.hide()
    check("🚨 closing it asks the pomodoro to undock — before the canvas is gone", UNDOCKS == 1 and cal.canvas == nil)
    check("...and calendar.frame is nil again", _G.service.call("calendar.frame") == nil)
    -- no pomodoro loaded: nothing is called and nothing throws
    _G.service.registry["pomodoro.dock"], _G.service.registry["pomodoro.undock"] = nil, nil
    local okShow = pcall(cal.show)
    local okHide = pcall(cal.hide)
    check("with no pomodoro loaded the calendar opens and closes exactly as before", okShow and okHide and cal.canvas == nil)
end

TIMERS = {}
calMod.warm(core)
check("a menu-bar item is added", MENUBAR ~= nil)
check("...showing the weekday and date", MENUBAR.title and #MENUBAR.title >= 4)
check("...that opens the panel when clicked", type(MENUBAR.click) == "function")
check("...and re-titles itself on a HELD timer",
      cal.tick ~= nil and cal.tick.kind == "every")

-- =====================================================================
-- 6. NUMPAD LAYER
-- =====================================================================
local numMod = load("numpad_layer")
numMod.setup(core)
local numpad = numMod.numpad

-- ✅ LIVE SINCE 6.49.0, on two layers: ⇪ + pad drives windows, ⇪⇧ + pad
-- drives tools. It shipped parked from 6.44.0 and the reversibility of
-- that is still tested below — "live" has to be a switch, not a one-way
-- door.
check("the layer ships live", numpad.enabled == true)
check("every ⇪ + pad TOOL key is claimed on the PRIMARY layer", (function()
    for k in pairs(numpad.actions) do
        if not hyperFor({}, k) then return false, k end
    end
    return true
end)())
-- 🆓 6.152.0 — THE WINDOW MAP IS CLEARED, on LL's word ("Those should
-- just say: 'Key available for use'"), the same instruction that cleared
-- the ⇪⇧ number row in 6.142.0. What is pinned here is the CLEARING —
-- a freed key's natural fate is to be quietly reclaimed.
check("🚨 6.152.0 — NO ⇪⇧ + pad key is claimed any more", (function()
    for i = 0, 9 do if hyperFor({ "shift" }, "pad" .. i) then return false, i end end
    for _, k in ipairs({ "pad+", "pad-", "pad*", "pad/", "pad.",
                         "padenter", "padclear" }) do
        if hyperFor({ "shift" }, k) then return false, k end
    end
    return true
end)())
check("🚨 …and the table is EMPTY-but-claimable, the cmdShiftActions "
      .. "posture — one line there brings a key back",
      next(numpad.shiftActions) == nil
      and numpad.actions.pad7 == nil,
      tostring(next(numpad.shiftActions)))
check("🚨 the clearing took ONLY the shifted layer — ⇪pad1 (capture row) "
      .. "is still claimed while ⇪⇧pad1 is not",
      hyperFor({}, "pad1") ~= nil and hyperFor({ "shift" }, "pad1") == nil)
-- Strengthened in 6.70.0. This used to read the TITLE alone, and adding
-- a third layer crowded the word out of it — which the check caught,
-- correctly. But a title is a header; the promise being made is that the
-- SHEET tells you the layer is free, so both halves are asserted now.
-- 🔄 6.101.0 — the module now registers TWO groups (its ⇪ pad row captures
-- text, its ⇪⇧ pad row moves windows, and those are different families on
-- the sheet), so these read across ALL of them rather than the one table
-- that used to be there. The promise is unchanged: SOMEWHERE on the sheet,
-- in a title and in an entry, the free layers say they are free.
local numGroups = numMod.cheatsheet.title and { numMod.cheatsheet } or numMod.cheatsheet
check("the module registers its groups in a shape the loader accepts",
      #numGroups >= 1 and numGroups[1].title ~= nil, #numGroups)
check("a cheat sheet TITLE still says FREE rather than listing tools "
      .. "that are no longer there", (function()
    local titles = {}
    for _, g in ipairs(numGroups) do
        titles[#titles + 1] = g.title
        if tostring(g.title):lower():find("free", 1, true) then return true end
    end
    return false, table.concat(titles, " | ")
end)())
check("...and an ENTRY says it for EACH free layer, which is where "
      .. "someone reading the sheet actually looks", (function()
    local sawHyper, sawCmd = false, false
    for _, g in ipairs(numGroups) do
        for _, e in ipairs(g.entries or {}) do
            local k, v = tostring(e[1]), tostring(e[2]):lower()
            if k:find("⇪ pad", 1, true) and v:find("free", 1, true) then sawHyper = true end
            if k:find("⌘⇧ pad", 1, true) and v:find("free", 1, true) then sawCmd = true end
        end
    end
    return sawHyper and sawCmd, tostring(sawHyper) .. "/" .. tostring(sawCmd)
end)())
-- 🚨 AND THE SPLIT ITSELF, asserted rather than assumed: the two groups
-- must land in DIFFERENT families, because filing all twenty-four rows
-- under either one is a lie about half of them — which is the whole
-- reason the loader learned to take a list.
check("🗂 the ⇪ pad capture row and the ⇪⇧ pad window map are filed in "
      .. "different families", (function()
    local fams = {}
    for _, g in ipairs(numGroups) do fams[#fams + 1] = tostring(g.family) end
    if #numGroups < 2 then return false, "only one group" end
    return fams[1] ~= fams[2] and fams[1] ~= "nil" and fams[2] ~= "nil",
           table.concat(fams, " / ")
end)())

-- ---- LAYER 3: ⌘⇧ + pad, added 6.70.0 --------------------------------
-- LL: "if i press cmd+shift+{number pad 3} it should be assignable."
-- ⇪pad has been free since 6.66.0, so the capability existed — but only
-- behind Caps Lock, which is this config's own invention. ⌘⇧ is a real
-- macOS modifier combination, so a shortcut on it also works in Raycast,
-- Keyboard Maestro and anything else that understands modifiers.
check("⌘⇧ + pad is a THIRD layer, and it ships free like the ⇪ one",
      type(numpad.cmdShiftActions) == "table"
      and next(numpad.cmdShiftActions) == nil,
      numpad.cmdShiftActions and next(numpad.cmdShiftActions))
check("...on ⌘⇧ specifically", (function()
    local m = numpad.cmdShiftMods or {}
    local seen = {}
    for _, x in ipairs(m) do seen[x] = true end
    return #m == 2 and seen.cmd and seen.shift
end)(), table.concat(numpad.cmdShiftMods or {}, "+"))
check("🚨 AND IT IS BOUND AS A GLOBAL HOTKEY, NOT THROUGH THE HYPER "
      .. "MODAL. The other two layers only exist while Caps Lock is held; "
      .. "a ⌘⇧ combination is an ordinary hotkey and binding it through "
      .. "hyperAddShortcut would mean it only fired with ⇪ held too — "
      .. "which is not what was asked for and would look like it worked",
      (function()
        local f = io.open(MODDIR .. "/numpad_layer.lua")
        local src = f:read("*a"); f:close()
        src = src:gsub("%-%-[^\n]*", "")      -- comments name both freely
        local blk = src:match("for key, what in pairs%(numpad%.cmdShiftActions.-\n        end")
        if not blk then return false, "no cmdShift binding loop" end
        return blk:find("hs.hotkey.bind", 1, true) ~= nil
               and blk:find("hyperAddShortcut", 1, true) == nil
      end)())
check("...and it skips a key this Mac has no code for, like the others — "
      .. "that guard is what stopped ⇪pad+ taking the whole layer down",
      (function()
        local f = io.open(MODDIR .. "/numpad_layer.lua")
        local src = f:read("*a"); f:close()
        src = src:gsub("%-%-[^\n]*", "")
        local blk = src:match("for key, what in pairs%(numpad%.cmdShiftActions.-\n        end")
        return blk and blk:find("hs.keycodes.map%[key%] ~= nil") ~= nil
      end)())
check("the cheat sheet tells you the ⌘⇧ layer exists — a free layer "
      .. "nobody knows about is not a feature", (function()
        for _, g in ipairs(numGroups) do
            for _, e in ipairs(g.entries or {}) do
                if tostring(e[1]):find("⌘⇧", 1, true) then return true end
            end
        end
      end)())

-- 🚨 THE TYPO TEST FOR THE SHIFTED LAYER LIVES IN test_integration.lua,
-- not here. Every shifted binding is a SERVICE NAME resolved at keypress
-- time, so "focus.tggle" binds fine, does nothing, and prints to a
-- Console nobody is reading — but proving the name is real needs the
-- OTHER modules loaded, and this suite loads one module at a time
-- against stubs. Checking it here would have meant checking it against
-- an empty registry, which is a test that always passes.
check("every TOOL binding is a string service name, so the integration "
      .. "suite can resolve it", (function()
    for key, name in pairs(numpad.actions) do
        if type(name) ~= "string" or not name:find("%.") then
            return false, tostring(key)
        end
    end
    return true
end)())

-- The ZONES survive the clearing — 6.152.0 freed the keys, not the
-- machinery: `pad7 = "topLeft"` in shiftActions revives that key in one
-- line, so the zone table has to stay whole. Everything below drives it
-- directly, without any key.
check("the topLeft zone is still defined", numpad.zones.topLeft ~= nil)
check("…and centre (computed from centreW/H at run time)",
      numpad.zones.centre == nil and numpad.centreW ~= nil)
check("…and bottomRight", numpad.zones.bottomRight ~= nil)
check("…and full, the maximise zone", numpad.zones.full ~= nil)

-- ---- and now the LIVE path -------------------------------------------
-- Everything from here runs with the layer switched on, so parking it is
-- proven to be a switch rather than a way of quietly deleting the feature.
numpad.enabled = true

-- ⇪pad7 on a 1440×900 screen with a 25pt menu bar
local placed
FOCUSED = {
    id = function() return 77 end,
    frame = function() return { x = 100, y = 100, w = 400, h = 300 } end,
    screen = function() return SCREENS[1] end,
    setFrame = function(_, f) placed = f end,
    moveToScreen = function() end,
}
numpad.run("topLeft")
check("⇪pad7 puts the window in the top-left quarter",
      placed and placed.x == 0 and placed.y == 25
      and placed.w == 720 and placed.h == (900 - 25) / 2)
numpad.run("rightHalf")
check("⇪pad6 gives the right half", placed.x == 720 and placed.w == 720
      and math.abs(placed.h - 875) < 0.001)
numpad.run("full")
check("⇪pad0 maximises without covering the menu bar",
      placed.x == 0 and placed.y == 25 and placed.h == 875)
numpad.run("centre")
check("⇪pad5 centres at 70×80%",
      math.abs(placed.w - 1440 * 0.7) < 0.001 and math.abs(placed.h - 875 * 0.8) < 0.001)

placed = nil
numpad.run("restore")
check("⇪pad. puts the window back where it was",
      placed and placed.x == 100 and placed.y == 100
      and placed.w == 400 and placed.h == 300)

numpad.run("shrink")
check("⇪pad- shrinks", placed.w < 1440)
check("...but never below the floor", (function()
    for _ = 1, 40 do numpad.run("shrink") end
    return placed.w >= 1440 * numpad.minFrac - 0.001
end)())
check("...and grow keeps it on screen", (function()
    for _ = 1, 40 do numpad.run("grow") end
    return placed.x >= 0 and placed.x + placed.w <= 1440.001
end)())

numpad.prior, numpad.priorOrder = {}, {}
numpad.maxPrior = 3
for i = 1, 10 do
    FOCUSED.id = function() return i end
    numpad.run("full")
end
check("the remembered-frames table is bounded, not a slow leak",
      #numpad.priorOrder == 3)
FOCUSED.id = function() return 77 end

-- Switching the layer on really does claim the keys — the other half of
-- the parked test above, so "parked" is proven to be reversible.
local liveMod = load("numpad_layer")
liveMod.numpad = nil
local parked = nil
do
    -- Park it the way the file switch does, by editing enabled BEFORE
    -- setup runs. This proves parking is still reachable — a layer that
    -- can only ever be on is a layer you cannot turn off.
    local m = load("numpad_layer")
    local realSetup = m.setup
    m.setup = function(c)
        realSetup(c)
        return m
    end
    m.setup(core)
    parked = m.numpad
end
liveMod.setup(core)
local live = liveMod.numpad
live.bound = {}
local boundCount = live.bindAll()
-- 6.66.0 cleared the tool layer; 6.99.0 claimed six keys back for the
-- capture row; 6.142.0 cleared the ⇪⇧ number row; 6.152.0 cleared the
-- ⇪⇧pad window map, both on LL's word. What binds now is the capture
-- row and NOTHING else — this count is how the clearings stay cleared.
check("the 6.99.0 capture row's 6 keys bind — and nothing else, now the "
      .. "6.142.0 AND 6.152.0 clearings both stand",
      boundCount == 6, boundCount)
check("...no shifted pad digit is among them", (function()
    for i = 0, 9 do if hyperFor({ "shift" }, "pad" .. i) then return false end end
    return true
end)())
check("🚨 the capture row claims EXACTLY its six keys — pad1–4, pad*, "
      .. "pad- — and nothing has crept onto the keys still promised free",
      (function()
    for _, k in ipairs({ "pad1", "pad2", "pad3", "pad4", "pad*", "pad-" }) do
        if not hyperFor({}, k) then return false, k .. " unclaimed" end
    end
    for _, k in ipairs({ "pad0", "pad5", "pad6", "pad7", "pad8", "pad9",
                         "pad+", "pad/", "pad.", "padenter", "padclear" }) do
        if hyperFor({}, k) then return false, k .. " claimed" end
    end
    return true
end)())
check("...and no shifted arithmetic key either — the whole layer is free",
      not hyperFor({ "shift" }, "pad+") and not hyperFor({ "shift" }, "pad-")
      and not hyperFor({ "shift" }, "pad*") and not hyperFor({ "shift" }, "pad/"))
-- 6.99.0 — the tool layer holds the capture row and ONLY the capture
-- row, every value a published SERVICE NAME (test_integration resolves
-- each against the live registry — a function here would dodge that
-- sentry, which is why this check forbids them).
check("🚨 the tool layer is EXACTLY the six capture entries, every one "
      .. "a service-name string", (function()
    local expect = {
        pad1     = "notes.appendClipboard",
        pad2     = "notes.openPad",
        pad3     = "notes.pickTarget",
        pad4     = "windows.splitTwo",
        ["pad*"] = "notes.typeIdeas",
        ["pad-"] = "notes.typeLog",
    }
    local n = 0
    for k, v in pairs(live.actions) do
        n = n + 1
        if expect[k] ~= v then
            return false, k .. " = " .. tostring(v)
        end
    end
    return n == 6, n .. " entries"
end)())
-- 🚨 THE ⇪pad+ STORY, pinned so it cannot repeat. That key was assigned
-- to the pomodoro in 6.65.0, documented, cheat-sheeted and TESTED — and on
-- LL's Mac hs.keycodes.map["pad+"] is nil, so bindAll correctly skipped it
-- and the key did nothing at all. Everything agreed it worked except the
-- keyboard. The timer is on a LETTER now, which cannot fail that way.
check("the pomodoro is NOT on a pad key — a key this keyboard may not "
      .. "have is a key that silently does nothing",
      live.actions["pad+"] == nil and live.shiftActions["pad+"] ~= "pomodoro.toggle")
check("...and the 6.152.0 clearing stands on the live instance too — the "
      .. "shifted table stays empty",
      next(live.shiftActions) == nil, tostring(next(live.shiftActions)))
check("binding twice does not double-claim anything", live.bindAll() == boundCount)

check("an unmapped key name is SKIPPED, not bound to nil", (function()
    local m2 = load("numpad_layer")
    m2.setup(core)
    local n2 = m2.numpad
    n2.actions = { padnonsense = "focus.toggle", pad1 = "focus.toggle" }
    -- Cleared so this checks the unshifted map alone; the shifted layer
    -- gets the same guard and its own assertion below.
    n2.shiftActions = {}
    -- ⚠️ RESET THE COUNTERS. Since 6.49.0 the layer is live, so setup()
    -- has ALREADY run bindAll and filled these — and bindAll is
    -- idempotent, so without this it returns the previous 28 and the
    -- assertion below reads a stale tally rather than this map's.
    n2.bound, n2.skipped = {}, {}
    hs.keycodes.map.padnonsense = nil     -- this macOS has no such key
    n2.enabled = true
    n2.bindAll()
    -- The real key binds, the imaginary one is skipped and NAMED rather
    -- than passed to hs.hotkey as nil, which would throw.
    return #n2.bound == 1 and n2.bound[1] == "pad1"
           and #n2.skipped == 1 and n2.skipped[1] == "padnonsense"
           and logged("no key code for")
end)())

check("the SHIFTED layer gets the same nil-key guard — a key macOS has no "
      .. "code for is skipped there too, not passed to hs.hotkey as nil",
      (function()
    local m3 = load("numpad_layer")
    m3.setup(core)
    local n3 = m3.numpad
    n3.actions      = {}
    n3.shiftActions = { padnonsense2 = "full", pad1 = "bottomLeft" }
    n3.bound, n3.skipped = {}, {}
    hs.keycodes.map.padnonsense2 = nil
    n3.enabled = true
    n3.bindAll()
    return #n3.bound == 1 and n3.bound[1] == "⇧pad1"
           and #n3.skipped == 1 and n3.skipped[1] == "⇧padnonsense2"
end)())

-- =====================================================================
-- 🆓 6.142.0 — THE LAPTOP LAYER IS GONE, AND THE KEYS STAY FREE
-- =====================================================================
-- 6.114.0 mirrored the pad zones onto ⇪⇧ + the number row. LL, with a
-- screenshot of that layer's own cheat sheet box: "These shortcuts were
-- supposed to be cleaned, cleared and the keys listed as future
-- possible options for keyboard shortcuts." What is pinned here is the
-- CLEARING, because a freed key's natural fate is to be quietly
-- reclaimed — the same reason the ⇪⇧Z giveback has a test of its own.
check("🚨 the laptop row's table is GONE — not parked, not emptied: a "
      .. "table that still exists is a table something eventually refills",
      live.rowActions == nil and live.rowMods == nil)
check("🚨 the freed number-row keys claim NOTHING — ⇪⇧1 2 3 5 7 8, "
      .. "⇪⇧comma, ⇪⇧period and ⇪⇧return are future options, not zones",
      (function()
    for _, k in ipairs({ "1", "2", "3", "5", "7", "8", ",", ".", "return" }) do
        local h = hyperFor({ "shift" }, k)
        if h and tostring(h.name):find("numpad", 1, true) then
            return false, k .. " still claimed by " .. tostring(h.name)
        end
    end
    return true
end)())
check("⇪⇧9 is the ONE digit that left the row BOUND — to the veil's "
      .. "invert, LL's 6.141.0 pick, not to a window zone", (function()
    local h = hyperFor({ "shift" }, "9")
    return h ~= nil and h.name == "invert colours", h and h.name
end)())
check("…and the zone MACHINERY the freed keys pointed at is still whole "
      .. "(6.152.0: a one-line claim revives any of them)",
      live.zones.topLeft ~= nil and live.zones.topRight ~= nil
      and live.zones.full ~= nil and type(live.run) == "function")
check("the cheat sheet's third group now IS the ledger — it names the "
      .. "freed keys and points at _G.freeKeys() instead of advertising "
      .. "bindings that no longer exist", (function()
    local g = numGroups[3]
    if not g then return false, "no third group" end
    if not tostring(g.title):lower():find("cleared", 1, true) then
        return false, "title: " .. tostring(g.title)
    end
    local sawKeys, sawTool = false, false
    for _, e in ipairs(g.entries or {}) do
        local v = tostring(e[2])
        -- 6.158.0 spent ⇪⇧2 on typing the clipboard and 6.160.0 spent
        -- ⇪⇧3 on mouse-follows-focus, so the ledger reads 5 7 8 now —
        -- and says where 1, 2 and 3 went.
        if v:find("⇪⇧5 7 8", 1, true) then sawKeys = true end
        if v:find("_G.freeKeys()", 1, true) then sawTool = true end
    end
    return sawKeys and sawTool, tostring(sawKeys) .. "/" .. tostring(sawTool)
end)())
-- 🆓 6.152.0 — the SECOND group (the old window map) is a ledger now
-- too, in LL's exact words: "Those should just say: 'Key available for
-- use'." So they do — and no row advertises a window zone any more.
check("the ⇪⇧pad group says “Key available for use”, in LL's words, and "
      .. "advertises no zone rows", (function()
    local g = numGroups[2]
    if not g then return false, "no second group" end
    local sawAvail, sawZone = false, false
    for _, e in ipairs(g.entries or {}) do
        local v = tostring(e[2])
        if v:find("Key available for use", 1, true) then sawAvail = true end
        if v:find("Top%-left quarter") or v:find("Maximise") then sawZone = true end
    end
    return sawAvail and not sawZone,
           tostring(sawAvail) .. "/" .. tostring(sawZone)
end)())
-- 🔗 THE SHARED "PUT IT BACK" MEMORY. Before 6.114.0 this layer kept its
-- own table, so ⇪⇧pad7 then ⇪↓ answered "No prior position remembered for
-- this window" about a window it had just watched move. The write-through
-- is what makes one restore key work for both keyboards.
check("🔗 placing a window writes into the SHARED prior-frame memory, so "
      .. "⇪↓ can put back something the pad or laptop layer moved",
      (function()
    local seen = nil
    local realHas, realCall = _G.service.has, _G.service.call
    _G.service.has  = function(n) return n == "windows.rememberFrame" end
    _G.service.call = function(n, w) if n == "windows.rememberFrame" then seen = w end end
    FOCUSED = FOCUSED or {}
    live.run("topLeft")
    _G.service.has, _G.service.call = realHas, realCall
    return seen ~= nil
end)())

printed = {}
numpad.run("some.published.service")
check("an action that is not a zone falls through to the service registry",
      logged("service.call some.published.service"))
check("...and a missing provider warns instead of crashing",
      logged("No provider for"))

FOCUSED = nil
ALERTS = {}
numpad.run("full")
check("with no focused window it says so instead of throwing",
      ALERTS[#ALERTS] and ALERTS[#ALERTS]:find("No focused window", 1, true))

-- =====================================================================
-- 7. CROSS-MODULE INVARIANTS
-- =====================================================================
local names = {
    "daily_backup", "app_peek", "window_switcher", "window_arranger",
    "copy_on_select", "command_history", "app_watcher", "file_tracker",
    "autocorrect", "activity_tracker", "update_tracker", "asana_comments",
    "screen_veil", "mini_calendar", "quick_append",
    "capture_pad", "numpad_layer",
}
local orders, dupes, missing = {}, {}, {}
for _, n in ipairs(names) do
    local chunk = loadfile(MODDIR .. "/" .. n .. ".lua")
    if not chunk then table.insert(missing, n)
    else
        local ok, mod = pcall(chunk)
        if not ok or type(mod) ~= "table" then table.insert(missing, n)
        else
            local o = mod.order
            if o == nil then table.insert(missing, n .. " (no order)")
            elseif orders[o] then table.insert(dupes, n .. " ties " .. orders[o] .. " at " .. o)
            else orders[o] = n end
        end
    end
end
check("every module in every profile exists and returns a table",
      #missing == 0 or table.concat(missing, ", ") == "")
check("⚠️ every cheat-sheet order number is UNIQUE (a tie reshuffles the sheet "
      .. "on every reload — Lua's table.sort is not stable)",
      #dupes == 0)
if #dupes > 0 then for _, d in ipairs(dupes) do realPrint("      " .. d) end end

-- ⚠️ COMMENTS ARE STRIPPED BEFORE THESE SCAN. A guard that reads prose
-- flags the sentence explaining the rule as a breach of it — which is
-- exactly what happened the first time this ran, on a comment that said
-- "never call hs.json.decode directly". The rule is about CODE.
local function codeOnly(src)
    local out = {}
    for line in (src .. "\n"):gmatch("([^\n]*)\n") do
        table.insert(out, (line:gsub("%-%-.*$", "")))
    end
    return table.concat(out, "\n")
end

-- 6.143.0 — one module joins this sweep BY NAME because watching windows
-- appear is the ban's textbook temptation, so the pin sits exactly where
-- it would break first. That was dialog_home until 6.261.0 deleted it;
-- mouse_follows inherits the slot — the same application-watcher plus
-- AX-observer shape, by its own header.
for _, n in ipairs({ "screen_veil", "mini_calendar", "quick_append",
                     "capture_pad", "numpad_layer", "mouse_follows" }) do
    local raw = io.open(MODDIR .. "/" .. n .. ".lua"):read("a")
    local src = codeOnly(raw)
    check(n .. ": no hs.window.filter (the 44-second beachball)",
          src:find("hs%.window%.filter") == nil)
    check(n .. ": no bare hs.json.decode (it raises on a truncated file)",
          src:find("hs%.json%.decode") == nil)
    check(n .. ": returns its module table", raw:find("\nreturn M", 1, true) ~= nil)
    check(n .. ": exposes config for machine profiles",
          src:find("M%.config") ~= nil)
end

-- Appended to test_features.lua: the 6.44.4 efficiency work.
-- =====================================================================
-- 8. SEARCH-INDEX CACHING AND IN-SESSION PRUNING (6.44.4)
-- =====================================================================
realPrint("\n-- 6.44.4 efficiency --")
do
  local S = MODDIR
  local ft = io.open(S .. "/file_tracker.lua"):read("a")
  local at = io.open(S .. "/activity_tracker.lua"):read("a")
  local ch = io.open(S .. "/command_history.lua"):read("a")

  -- 👁 6.157.0 — the preview pane, wired the same three ways everywhere
  for name, src in pairs({ file_tracker = ft, activity_tracker = at, command_history = ch }) do
    check(name .. " rows carry rawText for the preview pane",
          src:find("rawText%s*=") ~= nil)
    check(name .. " suspends the pane when its picker hides and opens it after showing",
          src:find('"preview.suspend"', 1, true) ~= nil
          and src:find('"preview.open"', 1, true) ~= nil)
  end

  check("file tracker caches its search string on the entry",
        ft:find("e%._hay") ~= nil)
  check("...and only builds it when the cache is empty",
        ft:find("if not haystack then") ~= nil)
  check("activity tracker caches its search string too",
        at:find("e%._hay") ~= nil)

  -- The cache must never reach the CSV. Both writers name their columns.
  check("🔒 the file-tracker CSV writers name columns explicitly, so _hay "
        .. "cannot leak to disk", (function()
    for line in ft:gmatch("[^\n]+") do
      if line:find("f:write") and line:find("_hay") then return false end
    end
    return true
  end)())
  check("🔒 same for the activity CSV writer", (function()
    for line in at:gmatch("[^\n]+") do
      if line:find("f:write") and line:find("_hay") then return false end
    end
    return true
  end)())

  check("the file-tracker log is pruned DURING the session, not only at boot",
        ft:find("_ftSincePrune") ~= nil and ft:find("fileTrackerPruneEvery") ~= nil)
  check("...on a counter, so recording a row stays O(1) amortised",
        ft:find("_ftSincePrune >= fileTrackerPruneEvery") ~= nil)
  check("...and both counters are LOCALS, not accidental globals",
        ft:find("local fileTrackerPruneEvery") ~= nil
        and ft:find("local _ftSincePrune") ~= nil)

  -- Behavioural proof that caching cannot change what a search returns.
  local function build(e)
    return (e.app .. " " .. (e.title or "")):lower()
  end
  local log = {}
  for i = 1, 300 do
    log[i] = { app = (i % 3 == 0) and "Safari" or "Mail",
               title = "Message " .. i, seconds = i }
  end
  local function search(entries, q, useCache)
    local hits = {}
    for _, e in ipairs(entries) do
      local hay
      if useCache then
        hay = e._hay
        if not hay then hay = build(e); e._hay = hay end
      else
        hay = build(e)
      end
      if hay:find(q, 1, true) then table.insert(hits, e.seconds) end
    end
    return table.concat(hits, ",")
  end
  local uncached = search(log, "safari", false)
  local cachedA  = search(log, "safari", true)
  local cachedB  = search(log, "safari", true)   -- now served from cache
  check("a cached search returns exactly what an uncached one does",
        uncached == cachedA and cachedA == cachedB and #uncached > 0)
  check("...and the second call really is served from the cache",
        log[1]._hay ~= nil)
end

-- Behavioural, not textual: drive the REAL pickers and prove the cache is
-- populated and reused. The first version of these tests only grepped the
-- source for "_hay", which a mutation that stopped READING the cache
-- survived untouched — a test that cannot fail is not a test.
do
  local ftMod = load("file_tracker")
  ftMod.setup(core)
  local ftChooser = _G.choosers.fileTracker
  check("the file-tracker picker exists and is query-driven",
        ftChooser ~= nil and type(ftChooser._onQuery) == "function")

  -- ⏱ 6.267.0 - THE FIXTURE GOES THROUGH THE DOOR. The 90 days are read
  -- when first needed now, so `_G.fileTrackerLog` is this module's OUTPUT
  -- and assigning it by hand installs a list nothing reads. Asking
  -- `history()` performs the (empty) read, publishes the list, and hands
  -- back the one the picker itself walks.
  _G.fileTrackerLog = nil
  local ftRows = _G.fileTracker.history()
  for i = 1, 50 do
    table.insert(ftRows, {
      fileName = "Report " .. i .. ".xlsx", newName = "", presentLoc = "/Finance",
      movedLoc = "", event = "Renamed", timestamp = "07/08/26 09:0" .. (i % 10),
      epoch = os.time(),
    })
  end
  check("(no entry carries a search cache before the first query)",
        _G.fileTrackerLog[1]._hay == nil)

  ftChooser._onQuery("report")
  local firstHits = #(ftChooser._choices or {})
  check("⚡ typing populates the per-entry search cache",
        _G.fileTrackerLog[1]._hay ~= nil)
  check("...and it is the lowercased haystack, built once",
        _G.fileTrackerLog[1]._hay:find("report 1.xlsx", 1, true) ~= nil)
  check("...the query actually matched rows", firstHits > 0)

  -- Poison the cache: if the second query reuses it, the row disappears.
  -- That is the only way to prove the cache is READ, not merely written.
  _G.fileTrackerLog[1]._hay = "zzz-cache-was-used-zzz"
  ftChooser._onQuery("report")
  check("⚡ a later query READS the cache instead of rebuilding it",
        #(ftChooser._choices or {}) == firstHits - 1)
  ftChooser._onQuery("zzz-cache-was-used-zzz")
  check("...proven: the poisoned entry is findable only via the cache",
        #(ftChooser._choices or {}) == 1)

  local actMod = load("activity_tracker")
  actMod.setup(core)
  -- ⏱ 6.267.0 - through the door, for the same reason as the file
  -- tracker's fixture above.
  _G.activityLog = nil
  local actRows = _G.activityHistory()
  for i = 1, 50 do
    table.insert(actRows, {
      date = "2026-08-07", app = (i % 2 == 0) and "Safari" or "Mail",
      title = "Message " .. i, seconds = 60,
    })
  end
  check("(the activity log has no cache before searching)",
        _G.activityLog[1]._hay == nil)
  _G.service.call("activity.renderChoices", "safari")
  check("⚡ searching activity history populates its cache too",
        _G.activityLog[2]._hay ~= nil)
  -- Poison one entry's cache with a token that appears NOWHERE in its real
  -- fields. It can only be found if the search reads the cache.
  -- Poison entry 2's cache with a token that appears NOWHERE in its real
  -- fields. It can only be found if the search reads the cache. Entry 2 is
  -- Safari / "Message 2", so a hit produces the header row plus that row.
  _G.activityLog[2]._hay = "qqq-activity-cache-qqq"
  local actChooser = _G.choosers.appTracker
  check("(the activity picker is the one being driven)", actChooser ~= nil)
  _G.service.call("activity.renderChoices", "qqq-activity-cache-qqq")
  local hit = false
  for _, c in ipairs(actChooser._choices or {}) do
      if tostring(c.text):find("Message 2", 1, true) then hit = true end
  end
  check("⚡ ...and later searches READ the cache rather than rebuilding it",
        hit, "choices=" .. #(actChooser._choices or {}))
  -- The control: with the cache honest again, the token matches nothing.
  _G.activityLog[2]._hay = nil
  _G.service.call("activity.renderChoices", "qqq-activity-cache-qqq")
  check("...and a rebuilt cache no longer contains the poison", (function()
      for _, c in ipairs(actChooser._choices or {}) do
          if tostring(c.text):find("Message 2", 1, true) then return false end
      end
      return true
  end)())
end

-- =====================================================================
-- 9. PARKED NOTES ARE VISIBLE, EXPLAINED, AND NEVER SILENTLY RESENT
-- =====================================================================
do
  hs.webview = {
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc
    end },
    new = function(rect, opts, uc)
        local w = { rect = rect, opts = opts, uc = uc, htmlText = nil,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h } }
        function w:frame(f) if f then self.frameRect = f; return self end return self.frameRect end
        function w:html(h) self.htmlText = h; return self end
        for _, m in ipairs({ "windowTitle","windowStyle","allowTextEntry","closeOnEscape",
                             "level","show","bringToFront","delete" }) do
          w[m] = function(self) return self end
        end
        return w
    end,
  }
  pad.queue, pad.parked, pad.draftImages, pad.draft = {}, {}, {}, ""
  pad.sending = false
  pad.maxRetries = 1          -- park on the first failure, to keep this short

  -- Fail a send and let it park, capturing Asana's own reason.
  HTTP_POSTS, ALERTS, printed = {}, {}, {}
  pad.queue = { { id = "p", text = "hamonaye jamboneya", createdAt = 1,
                  images = {}, tries = 0 } }
  pad.flush("manual")
  HTTP_POSTS[1].cb(403, '{"errors":[{"message":"Not Authorized to access project"}]}')
  check("a failed send parks the note", #pad.parked == 1 and #pad.queue == 0)
  check("🔎 ...recording WHY, from Asana's own error text",
        tostring(pad.parked[1].lastError):find("Not Authorized", 1, true) ~= nil)
  check("...and the HTTP status too",
        tostring(pad.parked[1].lastError):find("403", 1, true) ~= nil)
  check("...and when it happened", type(pad.parked[1].parkedAt) == "number")

  -- 🚩 THE BEHAVIOUR THAT CAUSED THE CONFUSION: a parked note is not part
  -- of any later send, so the warning persists through every flush until
  -- it is explicitly put back.
  HTTP_POSTS, ALERTS = {}, {}
  pad.queue = { { id = "ok", text = "a different note", createdAt = 2,
                  images = {}, tries = 0 } }
  pad.flush("manual")
  check("a later send posts ONLY the queued note, never the parked one",
        #HTTP_POSTS == 1
        and HTTP_POSTS[1].body:find("a different note", 1, true) ~= nil
        and HTTP_POSTS[1].body:find("hamonaye", 1, true) == nil)
  HTTP_POSTS[1].cb(201, '{"data":{"gid":"9"}}')
  check("...and the parked note is STILL parked afterwards", #pad.parked == 1)

  -- 🚩 AND THE CASE THAT ACTUALLY BITES: the queue is EMPTY, something is
  -- parked, and you press Send now. Nothing must go out — a parked note is
  -- parked precisely so it is not retried behind your back. (A mutation
  -- that made flush fall through to pad.parked survived until this test
  -- existed, because every earlier case still had a queued note to send.)
  HTTP_POSTS, ALERTS = {}, {}
  check("(the queue really is empty with one note parked)",
        #pad.queue == 0 and #pad.parked == 1)
  pad.flush("manual")
  check("🚩 Send now with only parked notes posts NOTHING", #HTTP_POSTS == 0)
  check("...and says the queue is empty rather than pretending it sent",
        ALERTS[#ALERTS] and ALERTS[#ALERTS]:find("nothing queued", 1, true) ~= nil)
  check("...and the parked note is untouched", #pad.parked == 1)

  -- The pad must now say which note, and why, rather than only a count.
  pad.show()
  local html = pad.webview.htmlText
  check("🖥 the parked note is shown as its own row, not just counted",
        html:find("hamonaye jamboneya", 1, true) ~= nil)
  check("...labelled PARKED so it cannot be mistaken for a queued note",
        html:find("PARKED", 1, true) ~= nil)
  check("...with the reason it failed on the row",
        html:find("Not Authorized", 1, true) ~= nil)
  check("...and the banner says it is from an EARLIER send, not a live error",
        html:find("from an earlier send", 1, true) ~= nil)
  check("...and states plainly that it will not be sent until you act",
        html:find("NOT included in the next send", 1, true) ~= nil)
  check("...and still offers the button that fixes it",
        html:find("retryParked()", 1, true) ~= nil)

  -- Putting it back clears the warning and makes it sendable again.
  pad.uc.callback({ body = { a = "retryParked", text = "" } })
  check("putting it back empties the parked list", #pad.parked == 0)
  check("...and the note is queued again with a fresh set of tries",
        #pad.queue == 1 and pad.queue[1].tries == 0)
  HTTP_POSTS = {}
  pad.flush("manual")
  check("...and NOW a send includes it",
        #HTTP_POSTS == 1 and HTTP_POSTS[1].body:find("hamonaye", 1, true) ~= nil)
  HTTP_POSTS[1].cb(201, '{"data":{"gid":"10"}}')
  check("...and it finally leaves the queue", #pad.queue == 0)
  check("...leaving the pad with no warning at all", (function()
      pad.render()
      return pad.webview.htmlText:find("PARKED", 1, true) == nil
  end)())

  pad.hide()
  hs.webview = nil
  pad.maxRetries = 3
end

-- =====================================================================
-- 10. OPENING THE PAD MUST NOT ACTIVATE THE WHOLE APPLICATION (6.44.6)
-- =====================================================================
do
  APP_ACTIVATIONS = {}
  hs.application = { launchOrFocus = function(n)
      table.insert(APP_ACTIVATIONS, n) end }
  hs.webview = {
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc
    end },
    new = function(rect, opts, uc)
        local w = { rect = rect, uc = uc, htmlText = nil, front = nil,
                    textEntry = nil,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h } }
        function w:frame(f) if f then self.frameRect = f; return self end return self.frameRect end
        function w:html(h) self.htmlText = h; return self end
        function w:allowTextEntry(v) self.textEntry = v; return self end
        function w:bringToFront(v) self.front = v; return self end
        for _, m in ipairs({ "windowTitle","windowStyle","closeOnEscape",
                             "level","show","delete" }) do
          w[m] = function(self) return self end
        end
        return w
    end,
  }
  pad.queue, pad.parked, pad.draftImages, pad.draft = {}, {}, {}, ""
  pad.show()
  check("🐛 6.44.6 — opening the pad does NOT activate the Hammerspoon app "
        .. "(that is what dragged the Console forward with it)",
        #APP_ACTIVATIONS == 0, table.concat(APP_ACTIVATIONS, ","))
  check("...the pad window itself is still raised", pad.webview.front == true)
  check("...and can still take the keyboard, which is what allowTextEntry does",
        pad.webview.textEntry == true)

  pad.hide()
  pad.focusOnOpen = false
  pad.show()
  check("focusOnOpen = false opens the pad without grabbing focus at all",
        pad.webview.front == nil)
  check("...and still never activates the app", #APP_ACTIVATIONS == 0)
  pad.focusOnOpen = true
  pad.hide()
  hs.webview = nil
end

-- =====================================================================
-- 11. THE DRAFT SURVIVES EVERY REDRAW (6.44.7)
-- =====================================================================
-- ⚠️ HONEST LIMIT: this bug lived in the page's JavaScript, which cannot
-- be executed from Lua. These assertions are STRUCTURAL — they check the
-- generated page, not a running browser. What they can prove is that no
-- say() call site omits the text and that say() itself always attaches
-- it; what they cannot prove is that WebKit runs it. The Lua half below
-- is exercised for real.
do
  hs.webview = {
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc
    end },
    new = function(rect, opts, uc)
        local w = { rect = rect, uc = uc, htmlText = nil,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h } }
        function w:frame(f) if f then self.frameRect = f; return self end return self.frameRect end
        function w:html(h) self.htmlText = h; return self end
        for _, m in ipairs({ "windowTitle","windowStyle","allowTextEntry","closeOnEscape",
                             "level","show","bringToFront","delete" }) do
          w[m] = function(self) return self end
        end
        return w
    end,
  }
  pad.queue, pad.parked, pad.draftImages = {}, {}, {}
  pad.draft, pad.draftCaret = "", 0
  pad.show()
  local html = pad.webview.htmlText

  -- Every say({...}) literal in the page must rely on say() for the text,
  -- and say() must set it unconditionally.
  -- Line-based extraction, not a pattern: say()'s body contains `m || {}`,
  -- and a non-greedy match to the first "}" stops right there and reads
  -- almost none of the function. (It did, on the first run of this test.)
  local sayBody, inSay = {}, false
  for line in html:gmatch("[^\n]+") do
    if line:find("function say(m){", 1, true) then inSay = true
    elseif inSay then
      if line:match("^%s*}%s*$") then inSay = false
      else table.insert(sayBody, line) end
    end
  end
  sayBody = table.concat(sayBody, "\n")
  check("say() exists and is the single place the draft is attached",
        sayBody ~= "")
  check("🐛 6.44.7 — say() sets m.text on EVERY message, unconditionally",
        sayBody:find("m.text = t.value", 1, true) ~= nil
        and sayBody:find("if", 1, true) == nil)
  check("...and carries the caret position too",
        sayBody:find("m.sel", 1, true) ~= nil)

  -- The two buttons that caused this: they must go through say().
  check("the Attach-image BUTTON goes through say()",
        html:find("onclick=\"say({a:'image'})\"", 1, true) ~= nil)
  check("the Send-now BUTTON goes through say()",
        html:find("onclick=\"say({a:'flush'})\"", 1, true) ~= nil)
  check("🔒 no say() call site passes its own text any more — one place "
        .. "sets it, so a new button cannot forget",
        html:find("text:t.value", 1, true) == nil)

  -- The Lua half, exercised for real: a message carrying text updates the
  -- draft, and the redraw writes that text back into the textarea.
  pad.uc.callback({ body = { a = "image", text = "notes I already typed", sel = 5 } })
  check("a message carrying text updates the stored draft",
        pad.draft == "notes I already typed")
  check("...and the caret with it", pad.draftCaret == 5)
  check("🐛 ...and the redraw puts that text BACK in the box, not an empty one",
        pad.webview.htmlText:find("notes I already typed", 1, true) ~= nil)
  check("...with the caret restored rather than dumped at the end",
        pad.webview.htmlText:find("var caret = 5", 1, true) ~= nil)

  -- Filing clears both, so the next note starts clean.
  pad.uc.callback({ body = { a = "add", text = "Email Dana the report", sel = 3 } })
  check("filing a note clears the draft", pad.draft == "")
  check("...and resets the caret", pad.draftCaret == 0)
  check("...and the box really is empty in the redraw",
        pad.webview.htmlText:find("Email Dana the report</textarea>", 1, true) == nil)

  pad.queue = {}
  pad.hide()
  hs.webview = nil
end

-- =====================================================================
-- 12. STALE PARKED NOTES: EXPLAINED, AND CLEARABLE (6.44.8)
-- =====================================================================
do
  hs.webview = {
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc end },
    new = function(rect, opts, uc)
        local w = { rect = rect, uc = uc, htmlText = nil,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h } }
        function w:frame(f) if f then self.frameRect = f; return self end return self.frameRect end
        function w:html(h) self.htmlText = h; return self end
        for _, m in ipairs({ "windowTitle","windowStyle","allowTextEntry","closeOnEscape",
                             "level","show","bringToFront","delete" }) do
          w[m] = function(self) return self end end
        return w end,
  }
  pad.queue, pad.draftImages, pad.draft = {}, {}, ""
  -- A note parked by an OLD version: no lastError, no parkedAt.
  pad.parked = { { id = "old", text = "Slip the skip jack", createdAt = 1,
                   images = {}, tries = 3 } }
  pad.show()
  check("🕰 a note parked before reasons were tracked says so, rather than "
        .. "leaving a blank where the reason should be",
        pad.webview.htmlText:find("parked before this pad tracked reasons", 1, true) ~= nil)

  -- A note parked with a timestamp but still no reason.
  pad.parked = { { id = "mid", text = "Slip the skip jack", createdAt = 1,
                   images = {}, tries = 3, parkedAt = os.time() } }
  pad.render()
  check("...and one with a time but no reason says THAT instead",
        pad.webview.htmlText:find("reason not recorded", 1, true) ~= nil)
  check("...while still showing when it happened",
        pad.webview.htmlText:find(os.date("%d %b"), 1, true) ~= nil)

  -- A note parked by a current version shows the real reason.
  pad.parked = { { id = "new", text = "Slip the skip jack", createdAt = 1,
                   images = {}, tries = 3, parkedAt = os.time(),
                   lastError = "HTTP 403 — Not Authorized" } }
  pad.render()
  check("a recently parked note shows Asana's actual reason",
        pad.webview.htmlText:find("Not Authorized", 1, true) ~= nil)
  check("...and does not claim the reason is missing",
        pad.webview.htmlText:find("not recorded", 1, true) == nil)

  -- Discard: the only destructive action, so it must be deliberate.
  check("the pad offers a Discard button",
        pad.webview.htmlText:find("discardParked()", 1, true) ~= nil)
  check("🛑 ...and the page CONFIRMS before discarding, because this is the "
        .. "one action that destroys a note",
        pad.webview.htmlText:find("confirm(", 1, true) ~= nil)

  -- Its images are cleaned up with it.
  os.execute('mkdir -p "' .. pad.imageDir .. '"')
  local gone = pad.imageDir .. "/to-discard.png"
  local fh = io.open(gone, "w"); fh:write("PNG"); fh:close()
  pad.parked = { { id = "d", text = "junk", createdAt = 1,
                   images = { gone }, tries = 3 } }
  ALERTS, printed = {}, {}
  local n = pad.discardParked()
  check("discarding removes every parked note", n == 1 and #pad.parked == 0)
  check("...and deletes their images rather than orphaning them",
        io.open(gone, "r") == nil)
  check("...says so in the Console, since it cannot be undone",
        logged("discarded 1 parked note"))
  check("...and confirms on screen", ALERTS[#ALERTS]:find("discarded", 1, true) ~= nil)

  ALERTS = {}
  check("discarding nothing says so instead of pretending",
        pad.discardParked() == 0
        and ALERTS[#ALERTS]:find("Nothing parked", 1, true) ~= nil)

  -- 🚩 It must NEVER touch the live queue.
  pad.queue = { { id = "live", text = "keep me", createdAt = 1, images = {}, tries = 0 } }
  pad.parked = { { id = "p", text = "drop me", createdAt = 1, images = {}, tries = 3 } }
  pad.discardParked()
  check("🚩 discarding parked notes leaves the QUEUE completely alone",
        #pad.queue == 1 and pad.queue[1].text == "keep me")

  pad.queue, pad.parked = {}, {}
  pad.hide()
  hs.webview = nil
end

-- =====================================================================
-- 13. "SEND NOW" SENDS WHAT YOU ARE LOOKING AT (6.44.9)
-- =====================================================================
do
  hs.webview = {
    usercontent = { new = function(name)
        local uc = { name = name }
        function uc:setCallback(fn) self.callback = fn; return self end
        return uc end },
    new = function(rect, opts, uc)
        local w = { rect = rect, uc = uc, htmlText = nil,
                    frameRect = { x = rect.x, y = rect.y, w = rect.w, h = rect.h } }
        function w:frame(f) if f then self.frameRect = f; return self end return self.frameRect end
        function w:html(h) self.htmlText = h; return self end
        for _, m in ipairs({ "windowTitle","windowStyle","allowTextEntry","closeOnEscape",
                             "level","show","bringToFront","delete" }) do
          w[m] = function(self) return self end end
        return w end,
  }
  pad.queue, pad.parked, pad.draftImages, pad.draft = {}, {}, {}, ""
  pad.sending, pad.maxRetries = false, 3
  pad.show()

  -- 🐛 THE EXACT REPORTED CASE: a note typed, an image pinned, nothing
  -- filed, and Send now pressed. It used to answer "nothing queued".
  CLIPBOARD_IMAGE = { saveToFile = function(self, path)
      local f = io.open(path, "w"); if f then f:write("PNG"); f:close(); return true end
      return false end }
  pad.attachClipboardImage()
  HTTP_POSTS, ALERTS = {}, {}
  pad.uc.callback({ body = { a = "flush", text = "! Slap jack", sel = 11 } })
  check("🐛 Send now with an UNFILED note actually sends it",
        #HTTP_POSTS == 1, "posts=" .. #HTTP_POSTS)
  check("...with the text you typed",
        #HTTP_POSTS > 0 and HTTP_POSTS[1].body:find("Slap jack", 1, true) ~= nil)
  check("...honouring the ! override, so it is a TASK not a Note",
        #HTTP_POSTS > 0 and HTTP_POSTS[1].body:find("Note ::", 1, true) == nil)
  check("...and it no longer claims the queue is empty", (function()
      for _, a in ipairs(ALERTS) do
          if tostring(a):find("nothing queued", 1, true) then return false end
      end
      return true
  end)())
  check("...the compose box is cleared, as if you had filed it",
        pad.draft == "" and #pad.draftImages == 0)
  -- The note carries an image, so the task callback hands off to curl and
  -- the flush is not finished until THAT returns too. Completing only the
  -- HTTP half leaves pad.sending latched and every later flush ignored —
  -- which is what happened the first time this test ran.
  TASKS = {}
  if #HTTP_POSTS > 0 then HTTP_POSTS[1].cb(201, '{"data":{"gid":"1"}}') end
  check("...the image upload is started as part of the same send",
        #TASKS == 1)
  if #TASKS > 0 then TASKS[1].cb(0, '{"data":{"id":"1"}}\n201', "") end
  check("...and the flush is finished, not left latched",
        pad.sending == false)

  -- With genuinely nothing anywhere, it must still say so.
  pad.queue, pad.draft, pad.draftImages = {}, "", {}
  HTTP_POSTS, ALERTS = {}, {}
  pad.uc.callback({ body = { a = "flush", text = "", sel = 0 } })
  check("Send now with an empty box AND empty queue still says nothing queued",
        #HTTP_POSTS == 0
        and ALERTS[#ALERTS]:find("nothing queued", 1, true) ~= nil)

  -- A draft plus an existing queue: both go.
  pad.queue = { { id = "q", text = "already filed", createdAt = 1, images = {}, tries = 0 } }
  pad.draft, pad.draftImages = "typed but not filed", {}
  HTTP_POSTS = {}
  pad.uc.callback({ body = { a = "flush", text = "typed but not filed", sel = 0 } })
  check("a draft is filed BEHIND what is already queued, preserving order",
        #HTTP_POSTS == 1 and HTTP_POSTS[1].body:find("already filed", 1, true) ~= nil)
  if #HTTP_POSTS > 0 then HTTP_POSTS[1].cb(201, '{"data":{"gid":"2"}}') end

  -- The pad now explains the two steps instead of assuming you know.
  pad.queue, pad.draft = {}, ""
  pad.render()
  check("the pad spells out what File it and Send now each do",
        pad.webview.htmlText:find("the note joins the queue below", 1, true) ~= nil
        and pad.webview.htmlText:find("the queue goes to Asana", 1, true) ~= nil)

  pad.hide()
  hs.webview = nil
  CLIPBOARD_IMAGE = nil
end

-- =====================================================================
os.execute('rm -rf "' .. TMP .. '"')
realPrint(string.format("\n%d passed, %d failed", pass, fail))
if fail > 0 then
    for _, f in ipairs(failures) do realPrint("  ✗ " .. f) end
    os.exit(1)
end
