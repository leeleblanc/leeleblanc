-- =====================================================================
-- test_scratch_pad.lua — ⇪1: tabs, saved as you type, history, 4 PM task
-- =====================================================================
--     lua5.4 test_scratch_pad.lua [/path/to/hammerspoon]
--
-- The claims under test: every keystroke lands in Lua at once and on
-- disk after the debounce (one held timer, re-armed per key); a closed
-- tab with text is the newest history row and comes back on restore; the
-- last tab closing leaves a blank one; pin keeps the pad up on Esc and
-- hides it from the escape router; the 16:00 send builds ONE task with
-- every section, start 07:30 / due 16:00 on today, assignee "me", the
-- identifying comment, and skips an empty or unchanged day; without a
-- webview the plain prompt still edits and saves; a broken store or a
-- failed write never loses the text in Lua; and the module owns no
-- eventtap, no hs.window read and no unheld timer.

local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail = 0, 0
local function check(label, cond, extra)
    if cond then pass = pass + 1
    else
        fail = fail + 1
        io.write("   ❌ " .. label
                 .. (extra and ("  [" .. tostring(extra) .. "]") or "") .. "\n")
    end
end
local function out(s) io.write(s) end

-- ---- a small real JSON (the store is nested; the module round-trips it) --
local function jenc(v)
    local tv = type(v)
    if tv == "table" then
        if #v > 0 or next(v) == nil then
            local p = {} for _, x in ipairs(v) do p[#p + 1] = jenc(x) end
            return "[" .. table.concat(p, ",") .. "]"
        end
        local p = {}
        for k, x in pairs(v) do p[#p + 1] = string.format("%q", tostring(k)) .. ":" .. jenc(x) end
        return "{" .. table.concat(p, ",") .. "}"
    elseif tv == "string" then
        return '"' .. v:gsub('[%c"\\]', function(c)
            if c == "\n" then return "\\n" elseif c == '"' then return '\\"'
            elseif c == "\\" then return "\\\\" else return string.format("\\u%04x", c:byte()) end
        end) .. '"'
    elseif tv == "number" then return tostring(v)
    elseif tv == "boolean" then return tostring(v)
    else return "null" end
end
local function jdec(s)
    local i = 1
    local function ws() i = s:find("%S", i) or #s + 1 end
    local val
    local function str()
        i = i + 1; local b = {}
        while true do
            local c = s:sub(i, i)
            if c == '"' then i = i + 1 return table.concat(b) end
            if c == "\\" then
                local n = s:sub(i + 1, i + 1)
                if n == "n" then b[#b + 1] = "\n" elseif n == "u" then
                    b[#b + 1] = string.char(tonumber(s:sub(i + 2, i + 5), 16)); i = i + 4
                else b[#b + 1] = n end
                i = i + 2
            else b[#b + 1] = c; i = i + 1 end
            if i > #s then error("bad json") end
        end
    end
    function val()
        ws(); local c = s:sub(i, i)
        if c == "{" then
            local o = {} i = i + 1 ws()
            if s:sub(i, i) == "}" then i = i + 1 return o end
            while true do
                ws(); local k = str(); ws(); i = i + 1
                o[k] = val(); ws()
                local d = s:sub(i, i); i = i + 1
                if d == "}" then return o end
                if d ~= "," then error("bad json") end
            end
        elseif c == "[" then
            local a = {} i = i + 1 ws()
            if s:sub(i, i) == "]" then i = i + 1 return a end
            while true do
                a[#a + 1] = val(); ws()
                local d = s:sub(i, i); i = i + 1
                if d == "]" then return a end
                if d ~= "," then error("bad json") end
            end
        elseif c == '"' then return str()
        elseif s:sub(i, i + 3) == "true" then i = i + 4 return true
        elseif s:sub(i, i + 4) == "false" then i = i + 5 return false
        elseif s:sub(i, i + 3) == "null" then i = i + 4 return nil
        else
            local n = s:match("^-?%d+%.?%d*[eE]?[-+]?%d*", i)
            if not n or n == "" then error("bad json") end
            i = i + #n return tonumber(n)
        end
    end
    local v = val()
    return v
end

-- ---- a controllable world ------------------------------------------------
local FILES, WRITE_FAILS, WRITE_BLOCK = {}, false, nil
local realIoOpen = io.open
io.open = function(path, mode)
    if (mode or "r"):find("w") then
        if WRITE_FAILS then return nil end
        local buf = {}
        return { write = function(_, s) buf[#buf + 1] = s return true end,
                 close = function() FILES[path] = table.concat(buf) end }
    end
    if FILES[path] == nil then return nil end
    local content, done = FILES[path], false
    return { read = function() if done then return nil end done = true return content end,
             close = function() end }
end
local realRename = os.rename
os.rename = function(a, b)
    if FILES[a] == nil then return nil, "no such file" end
    FILES[b] = FILES[a]; FILES[a] = nil
    return true
end

local ALERTS, PROVIDED, WEBVIEWS, PROMPTS, TIMERS, PRINTED = {}, {}, {}, {}, {}, {}
local PASTED, PB_FAIL, PB_REFUSE = {}, false, false
local PROMPT_ANSWER = { "Cancel", "" }
local UC_CALLBACK = nil
local realPrint = print
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    PRINTED[#PRINTED + 1] = table.concat(p, " ")
end

local function newWebviewStub(rect)
    local v = { rect = rect, _style = 0, deleted = false, shown = 0, hidden = 0, htmlSet = nil }
    function v:windowTitle(t) self.title = t return self end
    function v:allowTextEntry(x) self.textEntry = x return self end
    function v:alpha(a) self.alphaSet = a return self end
    function v:closeOnEscape(x) self.closeOnEsc = x return self end
    function v:level(l) self.lvl = l return self end
    function v:behaviorAsLabels(b) self.behave = b return self end
    function v:windowStyle(x) if x ~= nil then self._style = x end return self._style end
    function v:html(h) self.htmlSet = h return self end
    function v:show() self.shown = self.shown + 1 return self end
    function v:hide() self.hidden = self.hidden + 1 return self end
    function v:bringToFront() return self end
    function v:delete() self.deleted = true return self end
    function v:frame(f) if f then self.rect = f end return self.rect end
    return v
end

local function mkTimer(kind, delay, fn, at, rep)
    local t = { kind = kind, delay = delay, fn = fn, at = at, repeats = rep, stopped = false }
    function t:stop() self.stopped = true end
    function t:fire() if not self.stopped then self.fn() end end
    TIMERS[#TIMERS + 1] = t
    return t
end

-- 📋 6.201.0 — the pasteboard's own state, so a test can BE another app.
-- ⇪2's reset rule is decided by the change counter, so a suite that
-- cannot move that counter cannot fail a single mutation of the rule.
PB = { text = nil, count = 100 }
function PB_EXTERNAL_COPY(t)
    PB.text  = t or "someone else's copy"
    PB.count = PB.count + 1
    return PB.count
end

hs = {
    webview = {
        windowMasks = { nonactivating = 128 },
        usercontent = { new = function(name)
            local uc = { name = name }
            function uc:setCallback(fn) UC_CALLBACK = fn end
            return uc
        end },
        new = function(rect, _, _)
            local v = newWebviewStub(rect)
            WEBVIEWS[#WEBVIEWS + 1] = v
            return v
        end,
    },
    screen = { mainScreen = function()
        return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
    end },
    drawing = { windowLevels = { floating = 5 } },
    alert = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    dialog = { textPrompt = function(title, msg, dflt, ok, cancel)
        PROMPTS[#PROMPTS + 1] = { title = title, msg = msg, dflt = dflt }
        return PROMPT_ANSWER[1], PROMPT_ANSWER[2]
    end },
    timer = {
        doAfter = function(d, fn) return mkTimer("after", d, fn) end,
        doEvery = function(d, fn) return mkTimer("every", d, fn) end,
        doAt    = function(at, rep, fn) return mkTimer("at", nil, fn, at, rep) end,
    },
    json = { encode = function(t) return jenc(t) end, decode = jdec },
    fs = { mkdir = function() return true end },
    mouse = { absolutePosition = function() return { x = 300, y = 300 } end },
    eventtap = { checkMouseButtons = function() return { left = false } end },
    -- 6.182.0 — the sequential copy's other half. PB_FAIL makes the write
    -- refuse, which is the path where the grab must still be safe.
    -- 🚨 6.198.0 — PB_REFUSE is the OTHER refusal, and the one that was
    -- missing: hs.pasteboard.setContents answers FALSE without throwing.
    -- PB_FAIL alone tested only the half that pcall catches, so the module
    -- could read two values from the pcall, call every quiet refusal a
    -- success, and stay green. A stub gentler than the real thing is a
    -- hole with a tick beside it.
    -- 📋 6.201.0 — AND NOW IT HAS A REAL CHANGE COUNTER AND CONTENTS.
    -- The stub above had setContents and nothing else, so ⇪2's whole
    -- reset rule — "copying anything else starts a new sequence", decided
    -- entirely by changeCount and getContents — could not be tested at
    -- all. The counter moves on a SUCCESSFUL write ONLY, exactly as
    -- macOS's does: a refusal must not look like a copy to the rule that
    -- reads it, or a refused write would silently end the sequence.
    pasteboard = {
        setContents = function(t)
            if PB_FAIL then error("pasteboard refused") end
            if PB_REFUSE then return false end
            PASTED[#PASTED + 1] = tostring(t)
            PB.text, PB.count = tostring(t), PB.count + 1
            return true
        end,
        getContents = function() return PB.text end,
        changeCount = function() return PB.count end,
    },
}

_G.diag = { say = function() end, warn = function() end, err = function() end, mark = function() end }

local CLAIMED_ESC = {}
_G.claimEscape = function(name, _, present, close)
    CLAIMED_ESC[name] = { present = present, close = close }
end
_G.movablePanels, _G.editors = {}, {}
_G.rewrittenFiles = {}

local DEGRADES, TOLD = {}, {}
_G.notices = { tell = function(title, text)
                   TOLD[#TOLD + 1] = tostring(title) .. " :: " .. tostring(text)
                   return true
               end,
               record = function() return true end }
-- 🔬 6.299.0 — THE REAL SUBMIT ANSWERS TWICE, so this stub does too.
-- `_G.asanaSubmitTask` returns the instant it fires the POST ("accepted
-- for posting") and then calls `extra.onDone(ok, why, gid)` when Asana
-- replies. A stub that only RETURNS is gentler than the provider
-- (6.290.0) — and gentler in exactly the direction that hid the bug
-- this release fixes, because every check here would go on passing with
-- the whole second channel missing.
--   SUBMIT_RESULT  — what the call RETURNS (a validation refusal is
--                    false and answers onDone at once, as the real one
--                    does).
--   SUBMIT_ASANA   — Asana's own later answer. nil means "agrees with
--                    the return"; setting it to false with
--                    SUBMIT_RESULT true is the shape that was invisible:
--                    accepted for posting, then REFUSED.
--   SUBMIT_DEFER   — hold the answer instead of giving it, so the
--                    waiting state can be driven. SUBMIT_ANSWER() then
--                    delivers it, which is what an hs.http callback is.
local SUBMITS, SUBMIT_RESULT = {}, true
local SUBMIT_ASANA, SUBMIT_DEFER, SUBMIT_PENDING = nil, false, {}
local SUBMIT_WHY = "Asana refused it (HTTP 400) — invalid assignee"
local SUBMIT_SUBFAIL = false
_G.asanaSubmitTask = function(title, desc, assignee, attach, extra)
    SUBMITS[#SUBMITS + 1] = { title = title, desc = desc, assignee = assignee, attach = attach, extra = extra }
    local asana = SUBMIT_ASANA
    if asana == nil then asana = SUBMIT_RESULT end
    local cb = (type(extra) == "table") and extra.onDone or nil
    -- 🔬 6.301.0 — and a FOURTH value when subtasks were asked for.
    -- The real submit answers `info = { subs, subFail, subWhy }` once
    -- the second leg has landed; a stub that drops it is gentler than
    -- the provider in exactly the place the announce reads (6.290.0).
    local subs = (type(extra) == "table" and type(extra.subtasks) == "table")
                 and extra.subtasks or nil
    local info = nil
    if subs then
        local n = 0
        for _, x in ipairs(subs) do
            if tostring(x or ""):gsub("%s", "") ~= "" then n = n + 1 end
        end
        info = { subs = SUBMIT_SUBFAIL and 0 or n,
                 subFail = SUBMIT_SUBFAIL and n or 0,
                 subWhy = SUBMIT_SUBFAIL and "a subtask was refused" or nil }
    end
    local fire = function()
        if type(cb) == "function" then
            cb(asana and true or false, asana and nil or SUBMIT_WHY,
               asana and "9001" or nil, asana and info or nil)
        end
    end
    -- 🔬 A QUEUE, not a slot: several requests are in flight at once on
    -- a real Mac (6.300.0 posts one per task), and a single pending
    -- slot would silently drop all but the last — which is exactly the
    -- bug a "the mark lands on the LAST answer" check exists to catch.
    if SUBMIT_DEFER then SUBMIT_PENDING[#SUBMIT_PENDING + 1] = fire else fire() end
    return SUBMIT_RESULT
end
local function SUBMIT_ANSWER()
    local f = table.remove(SUBMIT_PENDING, 1)
    if f then f() end
    return f ~= nil
end

local HYPER, WRITE_WARNS = {}, {}
local EXPECTED, SEEN = {}, {}
_G.hyperExpectRelease = function(secs, who) EXPECTED[#EXPECTED + 1] = { secs = secs, who = who } return true end
_G.hyperReleaseSeen = function(who) SEEN[#SEEN + 1] = who return true end
local CORE = {
    logsDir = "/logs",
    asanaEnabled = true,
    provide = function(n, f) PROVIDED[n] = f end,
    hyperAddShortcut = function(mods, key, fn, src)
        HYPER[table.concat(mods or {}, "+") .. "|" .. tostring(key)] = { fn = fn, src = src }
    end,
    warnWriteFailed = function(what) WRITE_WARNS[#WRITE_WARNS + 1] = what end,
    -- 🔔 6.278.0 — THE STUB CARRIES THE DOOR. init.lua publishes
    -- core.degrade (core/notices.lua) on every real boot, so a stub
    -- without it makes every module here take its no-door fallback
    -- branch and the door itself is never exercised (6.193.0). It
    -- answers `false, why` exactly as the real one does.
    degrade = function(tool, why, opts)
        DEGRADES[#DEGRADES + 1] = { tool = tostring(tool), why = tostring(why),
                                    seconds = opts and opts.seconds }
        ALERTS[#ALERTS + 1] = "⚠️ " .. tostring(tool) .. " — " .. tostring(why)
        return false, why
    end,
}

local mod = dofile(HS .. "/modules/scratch_pad.lua")
mod.setup(CORE)
mod.warm(CORE)
local sp = _G.scratchPad
local TODAY = os.date("%Y-%m-%d")

local function lastTimer(kind)
    for i = #TIMERS, 1, -1 do if TIMERS[i].kind == kind and not TIMERS[i].stopped then return TIMERS[i] end end
end
local function msg(m) sp.handleMessage(m) end
local function store() return FILES[sp.file] and jdec(FILES[sp.file]) end

-- =======================================================================
out("1) the doors in — ⇪N, ⇪2, escape claim, editors row, services, the store\n")
-- =======================================================================
-- 🔑 6.182.0 — ⇪N, was ⇪1. LL: "I think hyper+N is enough to open the
-- Scorp Pad. Do you?" Four keys reached this one window; now one does,
-- ⇪2 is the sequential copy, and ⇪1 is FREE. Asserted as a pair — the
-- key that arrived AND the key that left — because a check that only
-- looked for ⇪N would pass with ⇪1 still bound beside it.
check("⇪N is claimed for the pad", HYPER["|n"] ~= nil and HYPER["|n"].src == "scratch pad")
check("…and ⇪1 is not bound by this module at all", HYPER["|1"] == nil)
check("⇪2 is claimed for the sequential copy",
      HYPER["|2"] ~= nil and HYPER["|2"].src == "sequential copy")
check("the escape router knows 'scratchpad'", CLAIMED_ESC.scratchpad ~= nil)
check("an editors row exists with view AND show (show never toggles)",
      #_G.editors == 1 and _G.editors[1].view and _G.editors[1].show)
check("a movable panel row exists", #_G.movablePanels == 1 and _G.movablePanels[1].name == "scratch pad")
check("scratch.show / scratch.send / scratch.report are published",
      PROVIDED["scratch.show"] and PROVIDED["scratch.send"] and PROVIDED["scratch.report"])
check("the store lives under logsDir/scratch", sp.file == "/logs/scratch/scratch.json")
check("the store is registered with the write ledger", _G.rewrittenFiles[sp.file] ~= nil)
check("a fresh install starts with exactly one blank tab", #sp.tabs == 1 and sp.tabs[1].text == "")
-- 🗓 6.300.0 — AND HE TURNED IT BACK ON. 6.254.0 switched the 16:00
-- send off on his word ("I don't need to send these at 4pm"); his
-- 6.300.0 message reverses that in the same breath as the grammar
-- ("tasks send at 4pm whether Hamsidian is open or not"). The switch
-- is unchanged and still works in both directions — the 6.254.0
-- section at the end of this file still drives the OFF side.
check("🗓 the 16:00 send IS armed by default again — his own reversal",
      sp.sendDaily == true and sp.sendTimer ~= nil, tostring(sp.sendTimer))

-- =======================================================================
out("2) typing — Lua at once, disk after the debounce, one held timer\n")
-- =======================================================================
sp.show()
local view = WEBVIEWS[#WEBVIEWS]
check("the pad opened one webview with the page in it", view and view.htmlSet and view.htmlSet:find("📝 Hamsidian", 1, true))
-- 6.171.0 — 1024×768, 35% translucent, both from sp.* so a profile can change them
check("6.171.1: the pad is 768×1024 (portrait) by default", sp.width == 768 and sp.height == 1024)
check("6.172.1: the window is SOLID (alpha 1 — never applied to the view)", sp.alpha == 1 and view and view.alphaSet == nil, view and tostring(view.alphaSet))
check("6.171.2: the page text is 16 px and no FS placeholder survives",
      sp.fontSize == 16 and view and view.htmlSet and view.htmlSet:find("font%-size:16px") ~= nil
      and view.htmlSet:find("FS%d?px") == nil, view and view.htmlSet and view.htmlSet:match("font%-size:[^;]+"))
check("6.171.2: the chrome sizes off the text (14 px buttons, 13 px labels)",
      view and view.htmlSet and view.htmlSet:find("font%-size:14px") and view.htmlSet:find("font%-size:13px"))
check("an empty tab is named by its place, not 'Untitled'", view.htmlSet:find(">Scratch 1<", 1, true) ~= nil and view.htmlSet:find("Untitled", 1, true) == nil)
check("opening told the hyper watchdog to expect the release within 1.5 s",
      EXPECTED[#EXPECTED] and EXPECTED[#EXPECTED].secs == 1.5)
msg({ a = "f18up" })
check("an F18 keyUp seen by the page releases ⇪ through _G.hyperReleaseSeen", SEEN[#SEEN] == "the scratch pad")
check("the header buttons say what they do", view.htmlSet:find("📌 Pin", 1, true) and view.htmlSet:find("→ Asana now", 1, true))
check("allowTextEntry(true) so it takes typing", view.textEntry == true)
check("closeOnEscape is OFF — the page decides what Esc means (pin)", view.closeOnEsc == false)
check("floating level + every Space", view.lvl == 5 and view.behave and view.behave[1] == "canJoinAllSpaces")
check("the non-activating mask was applied and read back", sp.nonActivatingApplied == true, sp.nonActivatingWhy)
local tab1 = sp.tabs[1].id
msg({ a = "edit", id = tab1, text = "hello", sel = 5 })
check("a keystroke is in Lua at once", sp.tabs[1].text == "hello")
check("…but not on disk yet", FILES[sp.file] == nil)
local t1 = sp.saveTimer
check("a debounce timer is armed and HELD in sp.saveTimer", t1 ~= nil and t1.kind == "after" and t1.delay == sp.saveDelay)
msg({ a = "edit", id = tab1, text = "hello w", sel = 7 })
check("a second keystroke re-arms: the first timer is stopped, a new one held", t1.stopped and sp.saveTimer ~= t1)
sp.saveTimer:fire()
local st = store()
check("after the debounce the store holds the text", st and st.tabs[1].text == "hello w", FILES[sp.file])
check("the temp file was renamed over — no .tmp left", FILES[sp.file .. ".tmp"] == nil)
check("the save count moved and dirty cleared", sp.saves == 1 and sp.dirty == false)
check("the page does NOT re-render on a keystroke (the caret would jump)", view.htmlSet:find("hello", 1, true) == nil)

-- =======================================================================
out("3) tabs — new, switch, ⌘1..9, close to history, the last one stays\n")
-- =======================================================================
msg({ a = "new", id = tab1, text = "hello w", sel = 7 })
check("⌘T adds a tab and makes it active", #sp.tabs == 2 and sp.active == sp.tabs[2].id)
local tab2 = sp.tabs[2].id
msg({ a = "edit", id = tab2, text = "second\nline two", sel = 3 })
check("the page re-rendered with both tabs", view.htmlSet:find('data-id="' .. tab2 .. '"', 1, true) ~= nil)
check("the tab title is the first line", sp.titleOf(sp.tabs[2]) == "second")
msg({ a = "switch", id = tab2, text = "second\nline two", tid = tab1 })
check("clicking a tab switches", sp.active == tab1)
msg({ a = "nth", id = tab1, text = "hello w", n = "2" })
check("⌘2 switches to the second tab", sp.active == tab2)
msg({ a = "cycle", id = tab2, text = "second\nline two", d = 1 })
check("⌃Tab cycles forward and wraps to the first tab", sp.active == tab1)
msg({ a = "cycle", id = tab1, text = "hello w", d = -1 })
check("⌃⇧Tab cycles back (wrapping) to the last tab", sp.active == tab2)
msg({ a = "close", id = tab2, text = "second\nline two", tid = tab2 })
check("⌘W on a tab with text: it is gone from the tabs…", #sp.tabs == 1 and sp.tabs[1].id == tab1)
check("…and is the newest history row with its title", sp.history[1] and sp.history[1].id == tab2 and sp.history[1].title == "second")
check("closing wrote the store at once", store().history[1].text == "second\nline two")
msg({ a = "new", id = tab1, text = "hello w" })
local tab3 = sp.tabs[2].id
msg({ a = "close", id = tab3, text = "   ", tid = tab3 })
check("an empty tab closes without a history row", #sp.history == 1 and #sp.tabs == 1)
msg({ a = "close", id = tab1, text = "hello w", tid = tab1 })
check("closing the LAST tab leaves one blank tab", #sp.tabs == 1 and sp.tabs[1].text == "" and sp.active == sp.tabs[1].id)
check("its text went to the history (now two rows, newest first)", #sp.history == 2 and sp.history[1].id == tab1)
local before = #sp.tabs
sp.maxTabs = 1
msg({ a = "new", id = sp.tabs[1].id, text = "" })
check("maxTabs holds and says so", #sp.tabs == before and ALERTS[#ALERTS]:find("tabs already", 1, true))
sp.maxTabs = 12

-- =======================================================================
out("4) history — embedded for the filter, restore brings a row back\n")
-- =======================================================================
check("the page embeds the history rows as ROWS for the JS filter",
      view.htmlSet:find("var ROWS = [{", 1, true) and view.htmlSet:find('"second"', 1, true))
check("a filter box sits under the text", view.htmlSet:find('id="q"', 1, true) ~= nil)
msg({ a = "restore", id = sp.tabs[1].id, text = "", rid = tab2 })
check("restore reopens the row as the active tab", sp.active == sp.tabs[#sp.tabs].id and sp.tabs[#sp.tabs].text == "second\nline two")
check("…and removes it from the history", #sp.history == 1 and sp.history[1].id == tab1)
check("restore of an unknown id is a no-op", sp.restore("nope") == false)

-- =======================================================================
out("5) pin and Esc\n")
-- =======================================================================
check("unpinned: the escape router sees the pad", CLAIMED_ESC.scratchpad.present() == true)
msg({ a = "pin", id = sp.active, text = "second\nline two" })
check("📌 toggles on and is remembered in the store", sp.pinned == true and store().pinned == true)
check("pinned: the escape router leaves the pad alone", CLAIMED_ESC.scratchpad.present() == false)
local hiddenBefore = view.hidden
msg({ a = "esc", id = sp.active, text = "second\nline two" })
check("pinned + Esc: the pad stays (hidden+shown, not deleted)", sp.webview ~= nil and view.deleted == false and view.hidden == hiddenBefore + 1)
msg({ a = "pin", id = sp.active, text = "second\nline two" })
msg({ a = "edit", id = sp.active, text = "second\nline two!" })
msg({ a = "esc", id = sp.active, text = "second\nline two!" })
check("unpinned + Esc: the pad closes…", sp.webview == nil and view.deleted == true)
check("…and pending keystrokes were written first", store().tabs[#sp.tabs].text == "second\nline two!" and sp.dirty == false)
sp.show()
check("⇪1 again reopens with the text where it was", WEBVIEWS[#WEBVIEWS].htmlSet:find("line two!", 1, true) ~= nil)
sp.show()
check("⇪1 while open closes (toggle)", sp.webview == nil)

-- =======================================================================
out("6) the DAY task — one task, every section, 07:30 → 16:00, me\n")
-- =======================================================================
-- 🗂 6.300.0 — THIS SECTION IS ABOUT `sp.sendDay`, which is no longer
-- the default: `sendGrammar` sends his task grammar instead, one Asana
-- task per parsed task. The day task is kept whole and reachable by a
-- settings line (6.254.0's shape — a switch, never a deletion), and
-- that is exactly why it still has to work. The checks below are
-- unchanged in what they assert; they name which send they drive.
sp.sendGrammar = false
SUBMITS = {}
local ok, why = sp.send("scheduled")
check("with text the send is accepted", ok == true and #SUBMITS == 1, why)
local s = SUBMITS[1]
check("title is the prefix + the day", s and s.title:find("^Hamsidian · ") ~= nil, s and s.title)
check("notes hold the open tab under a ## heading", s and s.desc:find("## second\nsecond\nline two!", 1, true) ~= nil, s and s.desc)
check("notes hold the row closed today too", s and s.desc:find("## hello w (closed", 1, true) ~= nil)
check("assignee is me, no attachment", s and s.assignee == "me" and s.attach == "")
check("start 07:30 and due 16:00, both on today",
      s and s.extra.startDate == TODAY and s.extra.startTime == "07:30"
      and s.extra.dueDate == TODAY and s.extra.dueTime == "16:00")
check("the identifying comment rides on extra.comment", s and s.extra.comment == sp.comment and sp.comment:find("Sent by Hammerspoon", 1, true))
check("the day's checksum is remembered in the store", store().sent[TODAY] ~= nil)
ok, why = sp.send("scheduled")
check("sending again with nothing changed is skipped", ok == false and why == "unchanged" and #SUBMITS == 1)
sp.setText(sp.active, "second\nline two!!")
ok = sp.send("button")
check("a change sends again", ok == true and #SUBMITS == 2)
check("the report names the last send", _G.scratchPadReport():find("last send:", 1, true) ~= nil)
-- the scheduled timer runs the same path, inside pcall.
-- 🗑 6.254.0 — the SCHEDULE is off by default now, so this section turns
-- it on and warms again: the machinery is unchanged and still has to
-- work, which is the whole point of a switch rather than a deletion.
SUBMITS = {}
sp.setText(sp.active, "third try")
sp.sendDaily = true
mod.warm(CORE)
check("with sendDaily on, warm arms the 16:00 timer and HOLDS it",
      sp.sendTimer ~= nil and sp.sendTimer.kind == "at"
      and sp.sendTimer.at == "16:00" and sp.sendTimer.repeats == "1d")
sp.sendTimer:fire()
check("the 16:00 timer sends", #SUBMITS == 1 and SUBMITS[1].extra.dueTime == "16:00")
-- nothing to send
local keepTabs, keepHist = sp.tabs, sp.history
sp.tabs, sp.history = { { id = "x", text = "  ", createdAt = 0, updatedAt = 0 } }, {}
sp.active = "x"
ok, why = sp.send("scheduled")
check("an empty day is skipped, not sent", ok == false and why == "nothing to send")
sp.tabs, sp.history = keepTabs, keepHist
sp.active = sp.tabs[1].id
-- Asana off
CORE.asanaEnabled = false
sp.setText(sp.active, "asana off text")
ok, why = sp.send("scheduled")
-- 🔔 6.278.0 — THIS CHECK USED TO ASSERT THE CONSOLE, which was the
-- whole defect: "said in the Console" was ALL that happened, and LL
-- asked how he is supposed to know. It asks the RULE now (6.248.0) —
-- not sent · the text kept · and HE IS TOLD, wherever the telling goes.
check("Asana off: not sent, SEEN on screen, text kept",
      ok == false and why == "asana off"
      and #ALERTS > 0 and tostring(ALERTS[#ALERTS]):find("Asana is off", 1, true) ~= nil
      and sp.tabs[1].text == "asana off text",
      tostring(ALERTS[#ALERTS]))
CORE.asanaEnabled = true
-- validation rejected
SUBMIT_RESULT = false
sp.setText(sp.active, "rejected text")
ok, why = sp.send("scheduled")
check("a rejected submit keeps the text and is not marked sent", ok == false and why == "rejected" and sp.tabs[1].text == "rejected text")
SUBMIT_RESULT = true
check("_G.scratchPadSend() is the Console door", type(_G.scratchPadSend) == "function")

-- =======================================================================
out("7) degrade — no webview, a broken store, a failed write\n")
-- =======================================================================
local savedWebview = hs.webview
hs.webview = nil
PROMPT_ANSWER = { "Save", "typed in the plain box" }
sp.show()
check("no webview: the plain prompt opens on the current tab", #PROMPTS == 1 and PROMPTS[1].dflt == "rejected text")
check("…and Save edits + writes the tab", sp.tabs[1].text == "typed in the plain box" and store().tabs[1].text == "typed in the plain box")
hs.webview = savedWebview

WRITE_FAILS = true
sp.setText(sp.active, "kept in memory")
local okS = sp.saveNow()
check("a failed write is reported once through core.warnWriteFailed", okS == false and WRITE_WARNS[#WRITE_WARNS] == "scratch pad store")
check("...and SAID on screen, once per streak", ALERTS[#ALERTS]:find("NOT SAVED", 1, true) ~= nil)
local nAl = #ALERTS
sp.saveNow()
check("...the second failure in the streak is silent", #ALERTS == nAl)
check("...and the header wears the ⚠ badge on the next render", (function() sp.show(); local h = WEBVIEWS[#WEBVIEWS].htmlSet; sp.hide(); return h:find("⚠ not saved", 1, true) ~= nil end)())
check("…and the text is still in Lua", sp.tabs[1].text == "kept in memory")
check("…and the report shows the error", _G.scratchPadReport():find("⚠️", 1, true) ~= nil)
WRITE_FAILS = false
sp.saveNow()
check("a write that succeeds again says so", ALERTS[#ALERTS]:find("Saving again", 1, true) ~= nil)

-- a fresh module over a broken store starts empty and leaves the file
FILES[sp.file] = "<<not json>>"
_G.editors, _G.movablePanels = {}, {}
local mod2 = dofile(HS .. "/modules/scratch_pad.lua")
mod2.setup(CORE)
local sp2 = _G.scratchPad
check("an unreadable store starts with one blank tab and leaves the file", #sp2.tabs == 1 and FILES[sp2.file] == "<<not json>>")
check("…and says so in the report", _G.scratchPadReport():find("unreadable", 1, true) ~= nil)

-- =======================================================================
out("7b) 6.173.0 — hosted in the Hamsidian window\n")
-- =======================================================================
do
    local HOST = { enabled = true, webview = nil, doc = nil, shows = {}, toggles = 0, hides = 0 }
    function HOST.showScratch(id) HOST.shows[#HOST.shows + 1] = id or "active"; HOST.webview = HOST.webview or {}; HOST.doc = { scratch = id or sp2.active } return true end
    function HOST.toggleScratch() HOST.toggles = HOST.toggles + 1; if HOST.webview then HOST.webview = nil; HOST.doc = nil else HOST.showScratch(nil) end return true end
    function HOST.hide() HOST.hides = HOST.hides + 1; HOST.webview = nil; HOST.doc = nil end
    _G.vault = HOST
    check("sp.host() is the vault when it is loaded and viaVault is on", sp2.host() == HOST and sp2.viaVault == true)
    sp2.viaVault = false
    check("viaVault = false → no host (the pad's own window)", sp2.host() == nil)
    sp2.viaVault = true
    HOST.enabled = false
    check("a disabled vault is no host", sp2.host() == nil)
    HOST.enabled = true
    sp2.show()
    check("⇪1 opens the vault on the tabs, no window of its own", HOST.toggles == 1 and HOST.webview ~= nil and sp2.webview == nil)
    sp2.show()
    check("⇪1 again closes it through the host", HOST.toggles == 2 and HOST.webview == nil)
    sp2.openKind("capture", { text = "from ⇪N" })
    local ct
    for _, t in ipairs(sp2.tabs) do if t.kind == "capture" then ct = t end end
    check("⇪N makes the Capture tab and shows it in the vault", ct and ct.text == "from ⇪N" and HOST.shows[#HOST.shows] == ct.id and sp2.active == ct.id)
    local ed
    for _, e in ipairs(_G.editors) do if e.name == "Hamsidian tabs" then ed = e end end
    check("the editors entry reports the host window while a tab is open there", ed and ed.view() == HOST.webview)
    HOST.doc = { rel = "Alpha.md" }
    check("…and nothing while the host shows a note", ed and ed.view() == nil)
    local plainBefore = 0
    for _, t in ipairs(sp2.tabs) do if not t.kind then plainBefore = plainBefore + 1 end end
    local keepSvc = _G.service
    local QUEUED = {}
    _G.service = { has = function(n) return n == "capturePad.add" end,
                   call = function(n, text) if n == "capturePad.add" then QUEUED[#QUEUED + 1] = text return true end end }
    sp2.onHostClose()
    _G.service = keepSvc
    local plainAfter = 0
    for _, t in ipairs(sp2.tabs) do if not t.kind then plainAfter = plainAfter + 1 end end
    check("the host closing files the Capture tab (capturePad.add) and keeps plain tabs",
          ct and sp2.findTab(ct.id) == nil and QUEUED[1] == "from ⇪N" and plainAfter == plainBefore)
    sp2.hide()
    check("sp.hide with the host open closes the host", HOST.hides == 1)
    check("the report says whose window it is", _G.scratchPadReport():find("window: Hamsidian's", 1, true) ~= nil)
    _G.vault = nil
end

-- =======================================================================
out("8) the source itself — no tap, no AX, wired everywhere\n")
-- =======================================================================
local function slurp(p) local f = assert(realIoOpen(p)); local s = f:read("a"); f:close(); return s end
local src   = slurp(HS .. "/modules/scratch_pad.lua")
local init  = slurp(HS .. "/init.lua")
local coex  = slurp(HS .. "/core/coexist.lua")
local uni   = slurp(HS .. "/modules/unified_search.lua")
local tc    = slurp(HS .. "/modules/task_creator.lua")
local rt    = slurp(HS .. "/tools/run-tests.sh")
check("🚨 the module owns NO eventtap — nothing can swallow a key system-wide", src:find("hs%.eventtap%.new") == nil)
check("🚨 the module reads NO hs.window / axuielement", src:find("hs%.window") == nil and src:find("axuielement") == nil)
check("🚨 the module has no hs.hotkey of its own (⇪1 goes through core)", src:find("hs%.hotkey") == nil)
check("every hs.timer result is assigned (held)", not src:find("\n%s*hs%.timer%.do"))
check("init.lua loads scratch_pad", init:find('"scratch_pad"', 1, true) ~= nil)
check("the escape ladder has a scratchpad rung under taskform", coex:find("scratchpad =  74", 1, true) ~= nil)
check("⇪space has a Scratch pad source", uni:find('tag = "scratch"', 1, true) ~= nil and uni:find("scratch = 200", 1, true) ~= nil)
-- 6.182.0 filed ⇪N and ⇪2 in the hint module's groups and a check here
-- read them back. 6.268.0 — THAT MODULE IS DELETED, so the rows are gone
-- with it and the assertion had nothing left to be about. The keys
-- themselves are unchanged and still proven: ⇪N by this module's own
-- cheat sheet and its binding above, ⇪2 by the sequential-copy section.
check("asanaSubmitTask honours extra.comment", tc:find("extra.comment", 1, true) ~= nil)
check("run-tests lists this suite", rt:find("test_scratch_pad", 1, true) ~= nil)

-- =======================================================================
out("9) ⇪N and ⇪2 open here — Capture / Append tabs file where they always did\n")
-- =======================================================================
_G.editors, _G.movablePanels = {}, {}
FILES = {}
local mod3 = dofile(HS .. "/modules/scratch_pad.lua")
mod3.setup(CORE)
sp = _G.scratchPad
local QUEUED, QUEUE_OK = {}, true
_G.service = {
    has  = function(n) return n == "capturePad.add" end,
    call = function(n, text)
        if n ~= "capturePad.add" then return nil end
        QUEUED[#QUEUED + 1] = text
        if not QUEUE_OK then return false, "queue full" end
        return true, { text = text }
    end,
}
local FILED, FILE_RESULT = {}, { true, "📝 1 Logs", "" }
_G.notePad = { fileAll = function(text) FILED[#FILED + 1] = text
    return FILE_RESULT[1], FILE_RESULT[2], FILE_RESULT[3] end }

check("openKind on an unknown kind is refused", sp.openKind("nope") == false)
check("⇪N with the pad closed opens it with a 🗒 Capture tab active",
      sp.openKind("capture") == true and sp.webview ~= nil and sp.activeTab().kind == "capture")
local cap = sp.activeTab()
check("the tab bar shows the badge and the header shows the kind's hint",
      WEBVIEWS[#WEBVIEWS].htmlSet:find("🗒 Capture", 1, true) and WEBVIEWS[#WEBVIEWS].htmlSet:find("queues this for the 4 PM", 1, true))
msg({ a = "edit", id = cap.id, text = "call Dana about the SAC values", sel = 5 })
sp.openKind("capture")
check("⇪N again reuses the one Capture tab (no second)",
      #sp.tabs == 2 and sp.activeTab().id == cap.id and sp.tabs[2].text == "call Dana about the SAC values")
check("⇪2 opens a ➕ Append tab seeded with the prefix",
      sp.openKind("append", { prefix = "* " }) and sp.activeTab().kind == "append" and sp.activeTab().text == "* ")
local app = sp.activeTab()
msg({ a = "edit", id = app.id, text = "* an idea\n+ a log line", sel = 3 })
check("openKind with text replaces the Append tab's text (the clipboard door)",
      sp.openKind("append", { text = "clip text" }) and app.text == "clip text" and #sp.tabs == 3)
msg({ a = "edit", id = app.id, text = "* an idea\n+ a log line", sel = 3 })

msg({ a = "close", id = cap.id, text = "call Dana about the SAC values", tid = cap.id })
check("⌘W on the Capture tab queues its text for the 4 PM send…", QUEUED[#QUEUED] == "call Dana about the SAC values")
check("…and it is gone from the tabs and in the history marked filed",
      sp.findTab(cap.id) == nil and sp.history[1].id == cap.id and sp.history[1].kind == "capture"
      and sp.history[1].filedAs:find("4 PM Asana queue", 1, true) ~= nil)
check("the history row wears the badge", WEBVIEWS[#WEBVIEWS].htmlSet:find('"🗒 call Dana', 1, true) ~= nil)

sp.openKind("capture", { text = "second capture" })
QUEUE_OK = false
local cap2 = sp.activeTab()
msg({ a = "close", id = cap2.id, text = "second capture", tid = cap2.id })
check("a failed queue KEEPS the tab and its text, and says so",
      sp.findTab(cap2.id) ~= nil and cap2.text == "second capture" and ALERTS[#ALERTS]:find("Kept in its tab", 1, true))
QUEUE_OK = true

FILE_RESULT = { false, "⚠️ Logs failed", "+ a log line" }
msg({ a = "close", id = app.id, text = "* an idea\n+ a log line", tid = app.id })
check("the Append tab routes through notePad.fileAll", FILED[#FILED] == "* an idea\n+ a log line")
check("a partial failure keeps ONLY the leftover lines in the tab", sp.findTab(app.id) ~= nil and app.text == "+ a log line")
FILE_RESULT = { true, "📝 1 Logs", "" }

-- closing the PAD files every kind tab, keeps the scratch ones
local plain = sp.tabs[1]
sp.setText(plain.id, "plain scratch text")
sp.hide()
check("closing the pad files the Append tab…", FILED[#FILED] == "+ a log line" and sp.findTab(app.id) == nil)
check("…and the Capture tab…", QUEUED[#QUEUED] == "second capture" and sp.findTab(cap2.id) == nil)
check("…and leaves the plain scratch tab alone", sp.findTab(plain.id) ~= nil and plain.text == "plain scratch text")

-- the pad's own 4 PM task never carries them
sp.openKind("capture", { text = "not for the day task" })
local _, notes = sp.dayBody(TODAY)
check("dayBody skips Capture/Append tabs and their history rows",
      notes:find("plain scratch text", 1, true) and not notes:find("not for the day task", 1, true)
      and not notes:find("call Dana", 1, true))
sp.hide()

-- the store round-trips the kind
_G.editors, _G.movablePanels = {}, {}
local mod4 = dofile(HS .. "/modules/scratch_pad.lua")
mod4.setup(CORE)
local kinds = {}
for _, h in ipairs(_G.scratchPad.history) do kinds[#kinds + 1] = tostring(h.kind) end
check("history kinds survive a reload", table.concat(kinds, ","):find("capture", 1, true) ~= nil)

local cp = slurp(HS .. "/modules/capture_pad.lua")
local npS = slurp(HS .. "/modules/note_pad.lua")
-- 6.182.0 — both pads still route into this one through openKind; what
-- changed is the DOOR, from a hyper key each to a row in the section.
-- So the routing assertions stay and a new one says the keys are gone:
-- if either module bound its old key again, two modules would fight for
-- it and the cheat sheet would show it twice.
check("capture_pad still routes to scratchPad.openKind('capture')",
      cp:find('_G.scratchPad.openKind("capture")', 1, true) and cp:find("pad.viaScratch = true", 1, true))
check("…and no longer binds ⇪N itself while viaScratch is on",
      cp:find("if not pad.viaScratch then", 1, true) ~= nil
      and cp:find('core.hyperAddShortcut({}, pad.key, function() pad.openHere() end', 1, true) ~= nil)
check("np.show routes to openKind('append') — except the 16:01 review",
      npS:find('_G.scratchPad.openKind("append"', 1, true) and npS:find("np.show({ review = true })", 1, true)
      and npS:find("np.viaScratch = true", 1, true))
check("…and note_pad's laptop key is cleared, not just unbound",
      npS:find("np.laptopKey = nil", 1, true) ~= nil)

print = realPrint
io.open, os.rename = realIoOpen, realRename
out("\n=== 6.170.0 — arrow through the history rows ===\n")
do
    local f = io.open(HS .. "/modules/scratch_pad.lua", "r"); local src = f:read("a"); f:close()
    check("the page carries the row walker over #rows .row",
          src:find("ROWSEL = '#rows .row'", 1, true) and src:find("function rowKey(e)", 1, true)
          and src:find("function moveSel(d)", 1, true))
    check("⏎ on a highlighted row restores it, the same message a click sends",
          src:find("function rowAct(r){ say({a:'restore', rid: r.getAttribute('data-id')}); }", 1, true) ~= nil)
    check("the keydown handler asks the walker first, after Esc", (function()
        local a = src:find("say({a:'esc'}); return; }", 1, true)
        local b = src:find("if (rowKey(e)) return;", 1, true)
        return a and b and b > a and b - a < 80
    end)())
    check("a new filter resets the highlight", src:find("SEL = -1; draw();", 1, true) ~= nil)
    check("the highlight has a style", src:find(".row.sel{", 1, true) ~= nil)
    check("the text box keeps plain arrows (inText checks TEXTAREA)",
          src:find("a.tagName === 'TEXTAREA'", 1, true) ~= nil)
end

out("\n=== 6.177.0 — the way out: every tab as a .md note Obsidian opens ===\n")
do
    -- the controllable world again (the sections above hand io.open back)
    local READS = {}
    io.open = function(path, mode)
        if (mode or "r"):find("w") then
            if WRITE_FAILS or (WRITE_BLOCK and path:find(WRITE_BLOCK, 1, true)) then return nil end
            local buf = {}
            return { write = function(_, s) buf[#buf + 1] = s return true end,
                     close = function() FILES[path] = table.concat(buf) end }
        end
        READS[#READS + 1] = path
        if FILES[path] == nil then return nil end
        local content, done = FILES[path], false
        return { read = function() if done then return nil end done = true return content end,
                 close = function() end }
    end
    os.rename = function(a, b)
        if FILES[a] == nil then return nil, "no such file" end
        FILES[b] = FILES[a]; FILES[a] = nil
        return true
    end
    local realExecute = os.execute
    local EXEC = {}
    os.execute = function(cmd) EXEC[#EXEC + 1] = cmd return true end

    local function reset()
        FILES = {}
        sp.tabs, sp.history, sp.exported, sp.lastExport = {}, {}, {}, nil
        sp.exportToVault, sp.exportHistory, sp.exportMax = true, true, 500
        sp.active = nil
        _G.vault = nil
        sp.cloudDir = nil
    end
    local function md(name) return FILES["/logs/vault/Scratch/" .. name] end
    local function mdNames()
        local n = {}
        for path in pairs(FILES) do
            local f = path:match("^/logs/vault/Scratch/(.+)$")
            if f then n[#n + 1] = f end
        end
        table.sort(n)
        return n
    end

    -- ---- where the notes go, on either Mac -------------------------------
    reset()
    local dir, how = sp.exportDir()
    check("with no vault module and no OneDrive the notes still have a home",
          dir == "/logs/vault/Scratch" and how == "local", dir .. " / " .. tostring(how))
    _G.vault = { dir = "/od/Vault" }
    dir, how = sp.exportDir()
    check("...the loaded vault's own folder is the truth when it is up",
          dir == "/od/Vault/Scratch" and how == "vault", dir)
    _G.vault = nil
    sp.cloudDir = "/od"
    dir, how = sp.exportDir()
    check("...and without the module it works out the SAME folder from OneDrive",
          dir == "/od/Vault/Scratch" and how == "cloud", dir)
    _G.vault = { dir = "" }
    check("an empty vault dir is not trusted — the fallback takes over",
          (select(1, sp.exportDir())) == "/od/Vault/Scratch")

    -- ---- names Finder, OneDrive and Obsidian all accept -------------------
    reset()
    check("a slash in a title never becomes a folder", sp.exportSafeName("costs 50/50 split") == "costs 50-50 split")
    check("colons, stars and quotes go too", sp.exportSafeName('a:b*c"d?e') == "a-b-c-d-e")
    check("a newline is not a file name", sp.exportSafeName("first line\nsecond") == "first line second")
    check("a leading dot never makes a hidden file", sp.exportSafeName(".hidden") == "hidden")
    check("nothing to name is still named", sp.exportSafeName("   ") == "Scratch")
    check("a long title is cut, not refused", #sp.exportSafeName(string.rep("x", 200)) == sp.exportNameChars)

    -- ---- the name a tab keeps forever ------------------------------------
    reset()
    local n1 = sp.exportNameFor("t1", "Shopping")
    check("a tab's file is named for its first line", n1 == "Shopping.md")
    check("...and asking again gives the SAME name, so a second export updates it",
          sp.exportNameFor("t1", "Renamed since") == "Shopping.md")
    check("a second tab with the same title gets its own file",
          sp.exportNameFor("t2", "Shopping") == "Shopping 2.md")
    check("the ledger lives in the store", sp.exported.t1 == "Shopping.md" and sp.exported.t2 == "Shopping 2.md")

    -- ---- the export itself ------------------------------------------------
    reset()
    sp.newTab("Milk\nBread")
    sp.newTab("")                     -- an empty tab is nothing to export
    sp.history = { { id = "h1", title = "Old thought", text = "was thinking", closedAt = os.time() } }
    local ok, summary = sp.exportAll("test")
    check("the export says it worked", ok == true, summary)
    check("one file per tab with text, and none for the empty one", #mdNames() == 2, table.concat(mdNames(), ", "))
    check("the closed-tab history comes too", md("Old thought.md") ~= nil)
    local body = md("Milk.md") or ""
    check("the note opens as Markdown with front matter Obsidian reads",
          body:find("^---\n") and body:find("\ntitle: Milk\n", 1, true) and body:find("\n---\n\n", 1, true))
    check("...it says where it came from", body:find("\nsource: Hamsidian\n", 1, true) ~= nil)
    check("...and wears a tag, so the vault's tag list finds them all",
          body:find("\ntags: scorp%-pad\n") ~= nil)
    check("the text is the text — no Markdown is invented for LL",
          body:find("\n\nMilk\nBread\n$") ~= nil, body)
    check("no .tmp is left behind", (function()
        for path in pairs(FILES) do if path:find("%.tmp$") then return false end end
        return true
    end)())
    check("the summary names the folder", summary:find("/logs/vault/Scratch", 1, true) ~= nil, summary)
    check("...and says honestly that this Mac had no OneDrive",
          summary:find("no OneDrive found", 1, true) ~= nil, summary)
    check("the report of the last run is kept", sp.lastExport and sp.lastExport.wrote == 2)
    check("the ledger was saved with the store, so the names survive a reload",
          (function() local st = store() return st and st.exported and st.exported ~= nil end)())
    check("no file in the vault was READ — a OneDrive placeholder read can block", (function()
        for _, p in ipairs(READS) do if p:find("/vault/", 1, true) then return false end end
        return true
    end)())

    -- exporting twice updates the same files instead of breeding copies
    local before = #mdNames()
    sp.exportAll("again")
    check("a second export updates the same files", #mdNames() == before, table.concat(mdNames(), ", "))

    -- ---- the switches -----------------------------------------------------
    reset()
    sp.newTab("only the open one")
    sp.history = { { id = "h1", title = "Closed", text = "closed text" } }
    sp.exportHistory = false
    sp.exportAll("no history")
    check("exportHistory = false leaves the history behind", md("Closed.md") == nil and #mdNames() == 1)

    reset()
    sp.newTab("one"); sp.newTab("two"); sp.newTab("three")
    sp.exportMax = 2
    local okM, sumM = sp.exportAll("capped")
    check("exportMax stops the export and SAYS it stopped",
          #mdNames() == 2 and sumM:find("stopped at 2", 1, true) ~= nil, sumM)

    reset()
    sp.newTab("something")
    sp.exportToVault = false
    local okOff, whyOff = sp.exportAll("off")
    check("with the export switched off nothing is written and the reason is named",
          okOff == false and #mdNames() == 0 and whyOff:find("export is off", 1, true) ~= nil, whyOff)

    -- ---- it degrades, it never breaks -------------------------------------
    reset()
    sp.newTab("keeps its text")
    WRITE_BLOCK = "/logs/vault/Scratch/"
    local okF, sumF = sp.exportAll("write fails")
    WRITE_BLOCK = nil
    check("an unwritable vault folder fails honestly", okF == false and sumF:find("could not be written", 1, true), sumF)
    check("...and the tab still has every word of its text",
          sp.tabs[1].text == "keeps its text" and #sp.tabs == 1)
    check("...and the pad's own store is untouched by the failure", sp.lastSaveErr == nil)

    reset()
    sp.newTab("first"); sp.newTab("second")
    WRITE_BLOCK = "/logs/vault/Scratch/first.md"
    local okP, sumP = sp.exportAll("one fails")
    WRITE_BLOCK = nil
    check("one file failing costs that file, not the export",
          md("second.md") ~= nil and okP == false and sumP:find("1 could not be written", 1, true), sumP)

    -- ---- the doors in -----------------------------------------------------
    reset()
    sp.newTab("through the page")
    local alertsBefore = #ALERTS
    msg({ a = "export" })
    check("⌘⇧S from the page exports and says what happened on screen",
          md("through the page.md") ~= nil and #ALERTS > alertsBefore
          and tostring(ALERTS[#ALERTS]):find("📤", 1, true), tostring(ALERTS[#ALERTS]))
    reset()
    sp.newTab("from the Console")
    -- (an earlier section loaded a SECOND copy of the module, so the global
    -- belongs to that one — here we prove the door exists and reports.)
    local realP = print; print = function() end
    local okC, sumC = _G.scorpPadExport()
    print = realP
    check("_G.scorpPadExport() is the Console door and always reports",
          type(_G.scorpPadExport) == "function" and type(sumC) == "string"
          and sumC:find("Scratch", 1, true) ~= nil, tostring(sumC))
    check("...and the pad's own export writes the note", (function()
        local okE = sp.exportAll("console")
        return okE == true and md("from the Console.md") ~= nil
    end)(), table.concat(mdNames(), ", "))

    reset()
    os.execute = realExecute
    io.open, os.rename = realIoOpen, realRename
end

do
    local f = io.open(HS .. "/modules/scratch_pad.lua", "r"); local src = f:read("a"); f:close()
    check("the page sends ⌘⇧S as the export",
          src:find("e.shiftKey && (e.key === 's' || e.key === 'S')", 1, true) ~= nil)
    local vf = io.open(HS .. "/modules/vault.lua", "r"); local vsrc = vf:read("a"); vf:close()
    check("the Vault window has the same key, and hands the work to the pad",
          vsrc:find("say({a:'export'})", 1, true) and vsrc:find('elseif a == "export" then', 1, true))
    check("...and the vault never assumes the pad is loaded",
          vsrc:find('"the Hamsidian tabs are not loaded"', 1, true) ~= nil)
    check("the report names the folder and the last run",
          src:find('"   export: ⌘⇧S → "', 1, true) ~= nil)
end


-- =======================================================================
out("\n=== 6.201.0 — ⇪2, the sequential copy: clipboard only ===\n")
-- =======================================================================
-- LL: "Can I select some text, and then immediately select some more text
-- and have it append the text I just copied a few seconds before … so I
-- can build a block of text that I can then edit quickly instead of
-- having to make multiple copy/pastes."
--
-- 🚨 AND THE BUG THAT RAN FROM 6.182.0. Each press appended the grab to a
-- 📎 Collect TAB and wrote THE WHOLE TAB to the clipboard. That tab was
-- remembered in the store and never emptied, so ⌘V pasted every grab LL
-- had ever made, beginning with the literal word "Collect" — while the
-- alert, reading a count that reset on every reload, said "1 grab". LL
-- pasted the proof. The rows below are written so that returning to that
-- shape FAILS: the pad's tabs must stay empty, and what lands on the
-- pasteboard must be the grabs of the CURRENT sequence and nothing else.
do
    sp.tabs, sp.history = {}, {}
    sp.collectReset("a test asked")
    PASTED, ALERTS = {}, {}

    local ok1, block1 = sp.collect("first piece")
    check("the first grab IS the block — no title line, no tab, no store",
          ok1 and block1 == "first piece" and #sp.tabs == 0, tostring(block1))

    local ok2, block2 = sp.collect("second piece")
    check("the second grab joins the first",
          ok2 and block2 == "first piece" .. sp.collectJoin .. "second piece",
          tostring(block2))
    check("…and the count is what the alert will say", sp.collectCount == 2, sp.collectCount)

    -- 🚨 THE ROW THAT FAILS IF THE TAB EVER COMES BACK. 6.182.0's block
    -- opened "Collect\n\n\n" because the tab was seeded with its own title,
    -- and that title went to the clipboard along with everything else.
    check("🚨 the block NEVER carries the pad's tab title, and no tab is made",
          block2:find("Collect", 1, true) == nil and #sp.tabs == 0, tostring(block2))

    check("an empty selection is refused and changes nothing",
          (function()
              local okE, why = sp.collect("   \n  ")
              return okE == false and why:find("nothing", 1, true) ~= nil
                     and sp.collectCount == 2
          end)())

    local had = sp.collectReset("a test asked")
    check("a reset SAYS how many grabs it dropped, and empties the sequence",
          had == 2 and sp.collectCount == 0 and #sp.collectSeq == 0, had)
end

-- ---- the reset rule, pure ---------------------------------------------
do
    -- 🔑 "Copying anything else starts a new sequence" — LL's choice of the
    -- three offered. Every row below fails a different mutation of it.
    sp.collectMark, sp.collectLast = 500, "our block"
    check("the counter is UNMOVED → the clipboard is still ours",
          sp.collectContinues(500, "our block") == true)
    check("the counter has MOVED → somebody else copied",
          sp.collectContinues(501, "our block") == false)
    check("…and the COUNTER outranks the contents, because macOS's counter "
          .. "sees the same text copied twice and a comparison never can",
          sp.collectContinues(501, "our block") == false
          and sp.collectContinues(500, "something else entirely") == true)

    sp.collectMark = nil
    check("🛟 no counter available → the CONTENTS are the degrade",
          sp.collectContinues(nil, "our block") == true
          and sp.collectContinues(nil, "someone else's copy") == false)

    sp.collectLast = nil
    check("🚨 NEITHER readable → not ours. The opposite default to "
          .. "pt.borrowIntact, and deliberately: there the last resort is "
          .. "that your clipboard comes back, here it is that ⌘V never "
          .. "pastes something you did not just grab",
          sp.collectContinues(nil, nil) == false)
end

do
    -- the key end to end: selection in, clipboard + alert out, pad untouched
    sp.tabs = {}
    sp.collectReset("a test asked")
    sp.collectResets = 0
    PASTED, ALERTS, PB_FAIL, PB_REFUSE = {}, {}, false, false
    PB.text, PB.count = nil, 100
    local keepSvc = _G.service
    local SEL = "a sentence from the page"
    _G.service = {
        has  = function(n) return n == "power.readSelection" end,
        call = function(_, _, done) done(SEL) return true end,
    }

    sp.collectFromSelection()
    check("⇪2 reads the selection through power_tools' ONE reader",
          PASTED[#PASTED] == SEL, tostring(PASTED[#PASTED]))
    check("…and files NOTHING in the pad — not a tab, not the store",
          #sp.tabs == 0 and sp.collectCount == 1)
    check("…and the alert names the running count and the ⌘V",
          ALERTS[#ALERTS]:find("1 grab", 1, true) and ALERTS[#ALERTS]:find("⌘V", 1, true),
          ALERTS[#ALERTS])

    -- 🚨 THE REGRESSION ROW. This is the whole complaint: two grabs, and
    -- ⌘V must paste those two and nothing else.
    SEL = "a second sentence"
    sp.collectFromSelection()
    check("🚨 a second grab pastes BOTH — and ONLY both",
          PASTED[#PASTED] == "a sentence from the page" .. sp.collectJoin
                             .. "a second sentence"
          and sp.collectCount == 2, tostring(PASTED[#PASTED]))

    -- 🔑 THE RESET ROW. Another app copies; the next grab starts clean.
    PB_EXTERNAL_COPY("a URL I copied the normal way")
    SEL = "a third sentence"
    sp.collectFromSelection()
    check("🔑 copying anything else starts a NEW sequence",
          PASTED[#PASTED] == "a third sentence" and sp.collectCount == 1,
          tostring(PASTED[#PASTED]))
    check("…and the report counts that ending, so it is never a mystery",
          sp.collectResets == 1, sp.collectResets)

    -- …and the press straight after it must CONTINUE, or the rule would
    -- reset on every press and the feature would be gone with it.
    SEL = "a fourth sentence"
    sp.collectFromSelection()
    check("…while the very next press CONTINUES the new sequence",
          PASTED[#PASTED] == "a third sentence" .. sp.collectJoin .. "a fourth sentence"
          and sp.collectCount == 2, tostring(PASTED[#PASTED]))

    -- 🛟 the clipboard half may fail; the grabs must NOT go with it
    PB_FAIL = true
    SEL = "a fifth sentence"
    sp.collectFromSelection()
    check("🛟 a pasteboard that THROWS does not lose the grabs, and says so",
          sp.collectCount == 3
          and ALERTS[#ALERTS]:find("clipboard refused", 1, true) ~= nil
          and ALERTS[#ALERTS]:find("⌘V pastes", 1, true) == nil, ALERTS[#ALERTS])
    PB_FAIL = false

    -- 🚨 6.198.0 — the refusal that does NOT throw, kept because it is the
    -- half pcall cannot see.
    PB_REFUSE = true
    SEL = "a sixth sentence"
    sp.collectFromSelection()
    check("🚨 a pasteboard answering FALSE is a refusal too, and is said",
          ALERTS[#ALERTS]:find("clipboard refused", 1, true) ~= nil
          and ALERTS[#ALERTS]:find("⌘V pastes", 1, true) == nil, ALERTS[#ALERTS])
    check("…and that grab is not lost either", sp.collectCount == 4, sp.collectCount)
    PB_REFUSE = false

    -- 🔑 AND A REFUSAL MUST NOT END THE SEQUENCE. A refused write does not
    -- move macOS's counter, so the rule has to read it as "nobody else
    -- copied" — read it as an ending and every refusal silently discards
    -- everything gathered so far.
    SEL = "a seventh sentence"
    sp.collectFromSelection()
    check("🔑 a refused write does not end the sequence — the next press "
          .. "puts all five grabs on the clipboard",
          sp.collectCount == 5
          and PASTED[#PASTED]:find("a third sentence", 1, true) ~= nil
          and PASTED[#PASTED]:find("a seventh sentence", 1, true) ~= nil,
          tostring(PASTED[#PASTED]))

    -- 🛟 no power_tools at all
    _G.service = { has = function() return false end }
    ALERTS = {}
    local okNo, whyNo = sp.collectFromSelection()
    check("🛟 without Power Tools it says so and does nothing",
          okNo == false and whyNo:find("power_tools", 1, true)
          and ALERTS[#ALERTS]:find("needs Power Tools", 1, true) ~= nil, ALERTS[#ALERTS])
    _G.service = keepSvc
end

do
    local src = slurp(HS .. "/modules/scratch_pad.lua")
    check("🚨 the sequential copy NEVER raises the window — the point is "
          .. "that you stay in the page you are reading",
          src:find("function sp.collectFromSelection", 1, true) ~= nil
          and src:match("function sp%.collectFromSelection.-\n    end"):find("sp.open()", 1, true) == nil)

    -- 🚨 6.201.0 — ASSERTED AGAINST THE SOURCE, because a functional test
    -- cannot see the difference: sp.collect returning the right block is
    -- exactly what the old tab-backed version did too, on its FIRST grab
    -- of a fresh tab. What has to be proven is that the body no longer
    -- reaches for a tab, the store or the window at all.
    local body = src:match("function sp%.collect%(text%).-\n    end")
    check("🚨 sp.collect touches NO tab, NO store and NO window — the "
          .. "whole 6.182.0 failure in one row",
          body ~= nil
          and body:find("newTab", 1, true) == nil
          and body:find("scheduleSave", 1, true) == nil
          and body:find("sp.render", 1, true) == nil
          and body:find("t.text", 1, true) == nil, tostring(body))

    -- 🔑 THE ORDER IS LOAD-BEARING. power_tools BORROWS the pasteboard to
    -- read a ⌘C selection, so by the time the text comes back the change
    -- counter has moved and says nothing about who copied last. Deciding
    -- the reset after the read would make the rule fire on every press.
    local from = src:match("function sp%.collectFromSelection%(%).-\n    end")
    check("🔑 the reset is decided BEFORE the selection is read",
          from ~= nil and from:find("collectContinues", 1, true) ~= nil
          and from:find("collectContinues", 1, true)
              < from:find('.call("power.readSelection"', 1, true), tostring(from ~= nil))

    -- The old Collect tab's id is still written and read back: it is LL's
    -- tab, full of his text, and dropping the key would quietly change his
    -- store. Nothing writes to that tab any more — the report names it.
    check("the pre-6.201.0 Collect tab's id still round-trips through the store",
          src:find("collectId = sp.collectId", 1, true) ~= nil
          and src:find('sp.collectId = type(data.collectId) == "string"', 1, true) ~= nil)

    -- 📎 A STATE WITH NO REPORT IS WHAT HID THIS. The alert said "1 grab"
    -- over a clipboard holding months of text and no line anywhere
    -- disagreed, for nineteen releases.
    check("📎 the report says what ⌘V would paste right now",
          src:find('"   📎 ⇪2: "', 1, true) ~= nil
          and src:find("sequences ended by another copy", 1, true) ~= nil
          and src:find("still in the pad, untouched", 1, true) ~= nil)

    -- 🚨 6.201.1 — THE CONSEQUENCE NOBODY HAD LOOKED FOR. sp.newTab is
    -- called with no `kind` (scratch_pad.lua:358), and sp.dayBody sweeps
    -- every tab with text and no kind into the 4 PM Asana task (:646) —
    -- so the Collect tab, and everything it accumulated, has been going
    -- to Asana daily since 6.182.0. 6.201.0 stopped FEEDING that tab but
    -- cannot stop this without closing or deleting LL's own text, which
    -- is not a release's call. So the report says it, and names the one
    -- keystroke that ends it.
    check("🚨 the report warns that the old tab still rides the 4 PM task",
          src:find("still rides the 4 PM Asana task", 1, true) ~= nil
          and src:find("⌘W on that tab in ⇪N is what ends it", 1, true) ~= nil)
    check("…and says the live sequence is this session only",
          src:find("THIS SESSION only — a reload starts a new sequence", 1, true) ~= nil)

    -- The tab really does have no kind, which is the whole reason above.
    check("…and the premise holds: a collect tab was made with NO kind",
          src:find("function sp.newTab(text, kind)", 1, true) ~= nil
          and src:find("if trim(t.text) ~= \"\" and not t.kind then", 1, true) ~= nil)

    check("…and the cheat sheet no longer promises a 📎 Collect tab",
          src:find("each grab is appended to a 📎 Collect tab", 1, true) == nil
          and src:find("Copying anything else starts a new sequence", 1, true) ~= nil)
    local vsrc = slurp(HS .. "/modules/vault.lua")
    check("the vault section is SCRATCH NOTES, with the two + rows in it",
          vsrc:find("📝 SCRATCH NOTES", 1, true) and vsrc:find('data-tab="+capture"', 1, true)
          and vsrc:find('data-tab="+append"', 1, true))
    check("…and those rows route through the same openKind the old keys used",
          vsrc:find("a:'tabkind'", 1, true) and vsrc:find('elseif a == "tabkind" then', 1, true)
          and vsrc:find("pcall(sp.openKind, kind)", 1, true))
    check("…and a × on a + row can never be read as closing a tab",
          vsrc:find("tid.charAt(0) !== '+'", 1, true) ~= nil)
end

-- =====================================================================
-- ✏️ 6.253.0 — ONE WINDOW, ONE NAME
-- =====================================================================
-- LL: "Scorp pad should be named 'Hamsidian.'" ⇪N and ⇪3 have opened the
-- same window since 6.173.0 and it carried two names. VISIBLE STRINGS
-- ONLY, exactly as 6.214.0 did for the notes: the module id, sp.*,
-- _G.scratchPad*, _G.scorpPadExport, the store path and the services are
-- all unchanged, and the COMMENTS keep the history.
do
    local fh = io.open(HS .. "/modules/scratch_pad.lua", "r")
    local src = fh and fh:read("a") or ""
    if fh then fh:close() end
    -- Comment lines dropped first: this is a check about what is SHOWN,
    -- and the file explains its own past in the lines above the code.
    local code = {}
    for line in src:gmatch("[^\n]*") do
        if not line:match("^%s*%-%-") then code[#code + 1] = line end
    end
    code = table.concat(code, "\n")
    check("no visible string in the pad says Scorp any more",
          code:find("Scorp", 1, true) == nil,
          code:match("[^\n]*Scorp[^\n]*"))
    check("...while the identifiers it is called by are untouched",
          src:find("_G.scratchPadReport", 1, true) ~= nil
          and src:find("_G.scorpPadExport", 1, true) ~= nil
          and src:find("/scratch.json", 1, true) ~= nil)
    -- 🚨 AND THE TWO SIDES MUST STILL BE TELLABLE APART. Both headers say
    -- Hamsidian; the ICON is what distinguishes them, so a rename that
    -- dropped it would leave two identical windows.
    check("the pad's header carries its own icon, not just the name",
          code:find("📝 Hamsidian", 1, true) ~= nil)
end

-- =====================================================================
-- 🗑 6.254.0 — THE THREE DOORS, CLOSED WITHOUT DELETING ANYTHING
-- =====================================================================
-- LL: "I don't need to send these at 4pm. I don't need capture or append.
-- I think those features are redundant. Am I wrong?" The answer was: the
-- DOORS are redundant, the STORES are not — so each door is a switch and
-- nothing on disk is touched.
do
    local before = pass + fail
    local okSection, secErr = pcall(function()

    -- 🚨 A FRESH LOAD, and its OWN config table. Four later sections
    -- reload this module (mod2..mod4) and `sp` above still points at the
    -- FIRST one, so warm() would be arming a table nobody here reads —
    -- which is exactly what the first version of this section measured.
    local m = dofile(HS .. "/modules/scratch_pad.lua")
    m.setup(CORE)
    local sp = m.config

    -- 🗓 6.300.0 — the 16:00 send is ON again, on his own reversal.
    -- What 6.254.0 proved is the SWITCH, and that is what this section
    -- is for: the OFF side below is unchanged and still has teeth.
    check("the daily Asana send is ON again (6.300.0, his own reversal)",
          sp.sendDaily == true)
    check("the + Capture / + Append rows are OFF by default",
          sp.showKindRows == false)

    -- 🚨 OFF MUST ARM NOTHING. A timer created and then ignored is the
    -- 4 PM task still running with nobody reading its answer.
    sp.sendDaily, sp.sendTimer = false, nil
    m.warm(CORE)
    check("🗑 warm arms NO timer while the send is off", sp.sendTimer == nil)
    sp.sendDaily = true
    m.warm(CORE)
    check("...and arms one the moment it is switched back on",
          sp.sendTimer ~= nil and sp.sendTimer.at == "16:00",
          tostring(sp.sendTimer))
    sp.sendDaily, sp.sendTimer = false, nil
    m.warm(CORE)

    -- 🔑 NOTHING WAS DELETED. The send still works when it is asked for
    -- by hand, which is what makes this a switch rather than a removal.
    SUBMITS = {}
    sp.tabs = { { id = "z1", text = "still here", createdAt = 0, updatedAt = 1 } }
    sp.active, sp.sent = "z1", {}
    local okSend = sp.send("button")
    check("🔑 _G.scratchPadSend() still sends one by hand with the schedule off",
          okSend == true and #SUBMITS == 1)

    -- The report says OFF as a STATE, not as a failure: "NOT armed" on a
    -- Mac that was asked not to arm it reads like something broken.
    local r = _G.scratchPadReport()
    check("the report calls the send OFF rather than 'NOT armed'",
          r:find("4 PM: OFF", 1, true) ~= nil
          and r:find("NOT armed", 1, true) == nil, r:match("[^\n]*4 PM[^\n]*"))
    check("...and names the settings line that puts it back",
          r:find("sendDaily = true", 1, true) ~= nil)
    check("...and says the hand-send still works",
          r:find("_G.scratchPadSend", 1, true) ~= nil)
    -- 6.201.1 — the 📎 Collect tab rode into this task every day. With the
    -- send off it cannot, and that is worth saying where the old warning
    -- was read.
    check("...and that nothing is swept into Asana at all now",
          r:find("Collect tab included", 1, true) ~= nil)
    check("the report names the hidden + rows, and that the stores are kept",
          r:find("+ rows: hidden", 1, true) ~= nil
          and r:find("still searched", 1, true) ~= nil)
    sp.showKindRows = true
    check("...and says so when they are switched back on",
          _G.scratchPadReport():find("are offered in the window", 1, true) ~= nil)
    sp.showKindRows = false

    -- 🔑 AND THE KINDS THEMSELVES ARE UNTOUCHED: openKind still works, so
    -- ⇪space's rows, the services and both pads' own routes are all live.
    check("🔑 openKind still exists and still knows both kinds",
          type(sp.openKind) == "function"
          and sp.kinds ~= nil and sp.kinds.capture ~= nil and sp.kinds.append ~= nil)

    end)
    check("§6.254.0 ran to the end — a throw here deletes the checks after it",
          okSection == true, secErr)
    local ran = (pass + fail) - before
    check("§6.254.0 ran all of its checks (" .. ran .. " of 13+)", ran >= 13, ran)
end

-- =======================================================================
out("\n6.278.0) 🔔 a send that failed is SEEN, not only logged\n")
-- =======================================================================
-- LL: "for any tool that completes an action, like the 4pm send of Asana
-- tasks from Hamsidian, how do I know if it didn't work? … I could lose
-- important information if not." A rejected send used to call warn() —
-- _G.diag.warn, the Console and nothing else. No alert, no notification,
-- nothing on screen. 6.214.0's rule, written from his own words, unpaid
-- in the one place where not knowing costs him what he captured.
do
    local before = pass + fail
    -- 🔌 ITS OWN INSTANCE, AND THE GLOBALS THAT GO WITH IT. This suite
    -- loads the module several times, so `_G.scratchPadReport` belongs to
    -- whichever copy ran setup() last — and a section that drives an
    -- EARLIER copy while reading the LATEST copy's report is measuring
    -- two different objects and calling the disagreement a bug. (It did,
    -- for as long as it took to print one address.)
    local m8 = dofile(HS .. "/modules/scratch_pad.lua")
    m8.setup(CORE)
    local sp = _G.scratchPad
    check("this section drives the same copy its report reads",
          sp ~= nil and type(_G.scratchPadReport) == "function")
    sp.tabs = { { id = "s1", text = "a task I dumped", kind = nil, at = os.time() } }
    sp.history, sp.active = {}, "s1"
    sp.sent, sp.unsent, sp.sendFails = {}, nil, 0
    -- 🗂 6.300.0 — this section is 6.278.0's and 6.299.0's, and both
    -- were written against the DAY task, which is still shipped and
    -- still has to be right. The grammar send's own announce is §6.300
    -- at the end of this file.
    sp.sendGrammar = false

    -- ---- a REJECTED send ------------------------------------------------
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    SUBMIT_RESULT = false
    local ok = sp.send("scheduled")
    check("a rejected send takes the 🔔 door — the tool and the cause, on "
          .. "screen, at the moment it happens", ok == false and #DEGRADES == 1
          and DEGRADES[1].tool:find("Hamsidian", 1, true) ~= nil,
          #DEGRADES .. " degrade(s)")
    check("...and the alert says what happened rather than that something "
          .. "happened", #ALERTS > 0
          -- 6.248.0 — the RULE, against the source of truth: whatever
          -- reason the provider handed back has to be in the alert. The
          -- literal this used to assert was the module's own sentence
          -- for "something went wrong", which is the opposite of the
          -- rule it was written for.
          and tostring(ALERTS[#ALERTS]):find(SUBMIT_WHY, 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("🕰 ...and a NOTIFICATION goes with it — the persistent half. An "
          .. "hs.alert is gone in six seconds and 16:00 lands while he is "
          .. "in a meeting; notices.tell is held through Focus and "
          .. "delivered when it ends", #TOLD == 1,
          tostring(TOLD[1]))
    check("...and the notification says his text is safe, because the "
          .. "first thing he will want to know is whether he lost it",
          #TOLD == 1 and tostring(TOLD[1]):find("safe", 1, true) ~= nil,
          tostring(TOLD[1]))

    -- 📌 the sticky flag: what is still there at 4 PM
    check("📌 the failure STICKS — both channels above can be missed (away "
          .. "from the desk, asleep, or macOS refusing to draw the alert, "
          .. "which 6.274.0 counted three times in eight hours on his Mac)",
          type(sp.unsent) == "table" and type(sp.unsent.why) == "string")
    check("...and the report carries it where he goes looking", (function()
        local r = _G.scratchPadReport()
        return r:find("NOT SENT", 1, true) ~= nil
               and r:find("still", 1, true) ~= nil
               and r:find("scratchPadSend", 1, true) ~= nil
    end)())

    -- 🚨 THE ONE THAT PROTECTS THE WRITING
    check("🚨 a failed send is NOT marked done — the day is stamped in the "
          .. "success branch only, so the next send retries it instead of "
          .. "skipping it as unchanged",
          sp.sent[TODAY] == nil, tostring(sp.sent[TODAY]))
    check("...and every word is still in the tab",
          sp.tabs[1].text == "a task I dumped")

    -- ---- it SUCCEEDS next time -----------------------------------------
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    SUBMIT_RESULT = true
    local ok2 = sp.send("scheduled")
    check("the retry goes through", ok2 == true)
    check("📌 ...and success CLEARS the sticky failure — a flag that never "
          .. "clears is a flag he learns to ignore", sp.unsent == nil)
    check("🔎 ...and success is VISIBLE too. If only failure spoke, silence "
          .. "would mean both 'it worked' and 'it never ran', which is "
          .. "6.196.1 inside the instrument he is relying on",
          #ALERTS > 0 and tostring(ALERTS[#ALERTS]):find("✅", 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("...and a success raises no degrade and no notification",
          #DEGRADES == 0 and #TOLD == 0)

    -- ---- Asana OFF is a FAILURE, not a skip -----------------------------
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    sp.sent, sp.unsent = {}, nil
    sp.setText("s1", "written expecting it to go")
    CORE.asanaEnabled = false
    sp.send("scheduled")
    check("🔎 'Asana is off on this Mac' is a FAILURE, not a skip — he "
          .. "wrote those tasks expecting them to go, and the old code "
          .. "printed this one to the Console alone",
          #DEGRADES == 1 and sp.unsent ~= nil, #DEGRADES .. " degrade(s)")
    CORE.asanaEnabled = true

    -- ---- but an empty day must NOT cry wolf -----------------------------
    -- 6.269.0: a new instrument's first duty is to be SILENT when nothing
    -- is wrong. One that warns on an ordinary quiet day is one he turns off.
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    sp.unsent = nil
    sp.tabs = {}
    sp.send("scheduled")
    check("🚨 nothing written today is a SKIP and says nothing on screen — "
          .. "an instrument that warns on a quiet day is one he switches "
          .. "off before it ever sees a real failure",
          #DEGRADES == 0 and #ALERTS == 0 and #TOLD == 0 and sp.unsent == nil,
          #DEGRADES .. "/" .. #ALERTS .. "/" .. #TOLD)
    check("...and with nothing waiting the report says so plainly",
          _G.scratchPadReport():find("nothing is waiting", 1, true) ~= nil)

    -- =================================================================
    -- 🔔 6.299.0 — IT ANNOUNCES WHEN ASANA ANSWERS, NOT WHEN IT POSTS
    -- =================================================================
    -- 🚨 THE SHAPE THAT WAS INVISIBLE: `_G.asanaSubmitTask` returns true
    -- the instant it fires the POST, so a task Asana went on to REFUSE
    -- printed "✅ Hamsidian → Asana: …" on screen. 6.278.0's whole
    -- guarantee — "a send that failed is seen" — could only ever see
    -- the failures that happen before the request leaves.
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    sp.tabs = { { id = "s1", text = "a task I dumped", kind = nil, at = os.time() } }
    sp.history, sp.active, sp.sent, sp.unsent = {}, "s1", {}, nil
    SUBMIT_RESULT, SUBMIT_ASANA = true, false     -- posted, then refused
    local okA = sp.send("scheduled")
    check("🚨 a task ACCEPTED for posting and then REFUSED by Asana is "
          .. "reported as a failure, not announced as a success",
          okA == false and #DEGRADES == 1
          and tostring(ALERTS[#ALERTS]):find(SUBMIT_WHY, 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("...and the day is NOT stamped, so it retries rather than "
          .. "reading as unchanged", sp.sent[TODAY] == nil)
    check("...and his text is untouched", sp.tabs[1].text == "a task I dumped")
    SUBMIT_ASANA = nil

    -- ⏳ POSTED IS NOT SENT (6.196.1). Between the request leaving and
    -- Asana replying there is a real third state, and calling it "sent"
    -- is exactly the lie this release removes.
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    sp.sent, sp.unsent = {}, nil
    sp.setText("s1", "waiting on the answer")
    SUBMIT_DEFER = true
    local okW = sp.send("scheduled")
    check("⏳ with Asana yet to answer, NOTHING is announced — not a "
          .. "success, not a failure", #ALERTS == 0 and #DEGRADES == 0
          and #TOLD == 0, #ALERTS .. "/" .. #DEGRADES)
    check("...the day is not stamped while the answer is out",
          sp.sent[TODAY] == nil)
    check("...and the report says posted-and-waiting rather than sent",
          _G.scratchPadReport():find("waiting on Asana", 1, true) ~= nil)
    check("...and the caller was told the request went (not that it landed)",
          okW == true)
    SUBMIT_ANSWER()
    check("🔔 when Asana finally answers, THAT is when it announces",
          #ALERTS == 1 and tostring(ALERTS[1]):find("✅", 1, true) ~= nil
          and sp.sent[TODAY] ~= nil, tostring(ALERTS[1]))
    SUBMIT_DEFER = false

    -- 🚨 AND A SUBMIT THAT RAISES ANSWERS NOBODY. finish() covers every
    -- RETURN inside asanaSubmitTask; a raise happens above it, so this
    -- is the one outcome the door cannot report — and the one that
    -- would otherwise leave the day silent.
    DEGRADES, ALERTS, TOLD = {}, {}, {}
    sp.sent, sp.unsent = {}, nil
    sp.setText("s1", "the submit will throw")
    local savedSubmit = _G.asanaSubmitTask
    _G.asanaSubmitTask = function() error("kaboom", 0) end
    local okT, whyT = sp.send("scheduled")
    _G.asanaSubmitTask = savedSubmit
    check("🚨 a submit that THROWS is reported, not swallowed",
          okT == false and whyT == "threw" and #DEGRADES == 1
          and tostring(ALERTS[#ALERTS]):find("kaboom", 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("...and the day is not stamped", sp.sent[TODAY] == nil)

    sp.unsent, sp.sendFails = nil, 0
    sp.sendGrammar = true      -- restored: later sections read this copy
    local ran = (pass + fail) - before
    check("§6.278.0 ran all of its checks (" .. ran .. " of 15+)", ran >= 15, ran)
end

-- =====================================================================
-- 🗂 6.297.0 — THE TASK GRAMMAR (PURE, so no Mac and no clock)
-- =====================================================================
-- LL's grammar: a bare line is a task · = divides · P: title · A: who ·
-- D: body · S: subtask · T: dates and times.
--
-- 🔑 THE CLOCK IS AN ARGUMENT (6.234.0). "today" and "one week from
-- today" cannot be proven by a test that waits a week, so every edge
-- below is a fixture against a fixed second.
do
    local before = pass + fail
    local S = _G.scratchPad
    S.sendGrammar = true       -- this section is about the grammar
    -- 2026-09-26 12:00:00 UTC-ish; only the DATE arithmetic matters and
    -- os.date uses the same local zone on both sides of each check.
    local NOW = os.time({ year = 2026, month = 9, day = 26, hour = 12 })
    -- 🚨 OFF THE PINNED CLOCK, NOT THE WALL ONE. This read
    -- os.date("%Y-%m-%d") with no argument — the REAL today — while
    -- every answer under test comes from the pinned NOW above. The two
    -- agreed on 26 September 2026 and on no other day, so these checks
    -- passed once, on the day they were written, and turned the whole
    -- gate red at the next midnight with nothing wrong in the config.
    -- GENERAL, and it is 6.230.0's rule in a clock: a fixture whose
    -- right and wrong answers AGREE proves nothing — and one that agrees
    -- for a day is worse, because it reports the disagreement as a bug
    -- in the code it was meant to check.
    local TODAY = os.date("%Y-%m-%d", NOW)

    -- 🧪 6.186.0, NINTH TIME: the parser walks a state machine, so a
    -- deleted guard leaves `cur` nil and the next branch indexes it —
    -- which ENDS the run with "0 failed" never printed, and a dead
    -- suite reads as a passing one in a gate that greps the tail. The
    -- helper ANSWERS FALSELY instead, so a mutation fails a check.
    local function P(txt)
        local ok, a, b = pcall(S.parseTasks, txt, NOW)
        if ok then return a, b end
        return {}, { "THREW: " .. tostring(a) }
    end

    out("\n-- 6.297.0 the task grammar --\n")

    -- ---- a bare line is a task ------------------------------------------
    local t, probs = P("Create the Asana task maker in Hamsidian")
    check("🗂 a bare line is ONE task, titled exactly as typed — his "
          .. "sentence, and the commonest case",
          #t == 1 and t[1].title == "Create the Asana task maker in Hamsidian"
          and #probs == 0, #t .. " tasks")
    check("...and it gets the default assignee without him typing one",
          t[1].assignee == "me", t[1].assignee)

    t = P("First thing\nSecond thing\nThird thing")
    check("🗂 three bare lines are THREE tasks, in order — folding them "
          .. "into one is exactly what he is asking to change",
          #t == 3 and t[1].title == "First thing" and t[3].title == "Third thing", #t)

    t = P("Alpha\n\n\nBeta")
    check("...and blank lines between them cost nothing", #t == 2, #t)

    -- 🚨 A BARE LINE AFTER A P: BLOCK IS ITS OWN TASK, NOT A CONTINUATION.
    -- The other reading is defensible and it is the one that loses work:
    -- a line he meant as a task would vanish into a description.
    t = P("P: Big one\nD: why\nAnother task")
    check("🚨 a bare line after a P: block is its OWN task — the other "
          .. "reading silently swallows a task into a description",
          #t == 2 and t[1].title == "Big one" and t[2].title == "Another task"
          and t[1].desc == "why", #t .. ": " .. tostring(t[2] and t[2].title))

    -- ---- the divider -----------------------------------------------------
    t = P("P: One\nD: a\n=\nP: Two\nD: b")
    check("🗂 = divides two blocks, and each keeps its own description",
          #t == 2 and t[1].desc == "a" and t[2].desc == "b",
          #t .. " " .. tostring(t[1] and t[1].desc))
    t = P("P: One\nD: a\n===\nP: Two")
    check("...and more than one = is still a divider", #t == 2, #t)
    t = P("P: One\nD: a = b\nP: Two")
    check("🚨 ...but an = INSIDE a line is text, not a divider — a "
          .. "description with an equals sign in it must survive",
          #t == 2 and t[1].desc == "a = b", tostring(t[1] and t[1].desc))

    -- ---- the complex shape, exactly as he wrote it ------------------------
    t, probs = P(table.concat({
        "P: Generate a new init.lua feature",
        "A: me",
        "D: We need to structure a new Hammerspoon feature.",
        "S: Structure tool request",
        "S: Submit tool request",
        "T: today +1w 7:00 AM 4:00 PM",
    }, "\n"))
    check("🗂 HIS OWN EXAMPLE parses to one task with its parts in the "
          .. "right places", #t == 1
          and t[1].title == "Generate a new init.lua feature"
          and t[1].assignee == "me"
          and t[1].desc == "We need to structure a new Hammerspoon feature."
          and #t[1].subs == 2 and t[1].subs[2] == "Submit tool request",
          #t .. " / " .. tostring(t[1] and #t[1].subs))
    check("📅 ...and the T: line reads start today, due a week out, "
          .. "7 AM to 4 PM", t[1].when.startDate == TODAY
          and t[1].when.dueDate == os.date("%Y-%m-%d", NOW + 7 * 86400)
          and t[1].when.startTime == "07:00" and t[1].when.dueTime == "16:00",
          hs.inspect and "" or tostring(t[1].when.startTime))
    check("...with nothing it could not read", #probs == 0,
          table.concat(probs, " | "))

    -- ---- several D: lines join, several S: accumulate ---------------------
    t = P("P: X\nD: one\nD: two")
    check("🗂 two D: lines join into one description with a line break",
          t[1].desc == "one\ntwo", (t[1].desc or ""):gsub("\n", "\\n"))

    -- ---- his outline bullets ----------------------------------------------
    t = P("P: X\n   - S: a\n   * S: b\n   • S: c")
    check("🗂 the outline bullets he writes in are stripped — his own "
          .. "message used -, * and •", #t[1].subs == 3, #t[1].subs)

    -- ---- what it CANNOT read is NAMED --------------------------------------
    t, probs = P("P: X\nT: sometime next quarter")
    check("🚨 a T: line it cannot read NAMES the words rather than "
          .. "silently setting no date — a date that never happens is "
          .. "found out from Asana a week later",
          #probs >= 1 and table.concat(probs, " "):find("quarter", 1, true) ~= nil
          and t[1].when.startDate == nil, table.concat(probs, " | "))
    -- 🧪 pcall'd: with the guard deleted `cur` is nil and the next
    -- branch indexes it, so the run would END here with "0 failed"
    -- never printed and a dead suite reads as a passing one in a gate
    -- that greps the tail. 6.186.0, ninth time — the test answers
    -- falsely rather than dying.
    t, probs = P("D: orphan description")
    check("🚨 a D:/S:/A:/T: with no task above it is NAMED and dropped, "
          .. "never silently attached to the next thing",
          #t == 0 and #probs == 1
          and probs[1]:find("before any task", 1, true) ~= nil, table.concat(probs, " | "))
    t, probs = P("P: X\nA: lee\nA: sam")
    check("...and a second A: for one task says the last one wins "
          .. "rather than changing it in silence",
          t[1].assignee == "sam" and #probs == 1, tostring(t[1].assignee))
    t, probs = P("P:\nD: body")
    check("...and a P: with no title is refused, not turned into an "
          .. "untitled Asana task", #t == 0 and #probs >= 1, #t)

    -- ---- dates, PURE, every branch -----------------------------------------
    check("📅 today / tomorrow / yesterday",
          S.taskDate("today", NOW) == TODAY
          and S.taskDate("tomorrow", NOW) == os.date("%Y-%m-%d", NOW + 86400)
          and S.taskDate("Yesterday", NOW) == os.date("%Y-%m-%d", NOW - 86400))
    check("📅 +Nd / +Nw / +Nm",
          S.taskDate("+3d", NOW) == os.date("%Y-%m-%d", NOW + 3 * 86400)
          and S.taskDate("+2w", NOW) == os.date("%Y-%m-%d", NOW + 14 * 86400)
          and S.taskDate("+1m", NOW) == os.date("%Y-%m-%d", NOW + 30 * 86400))
    check("📅 ISO, and it is zero-padded so Asana takes it",
          S.taskDate("2026-9-5", NOW) == "2026-09-05"
          and S.taskDate("2026-09-05", NOW) == "2026-09-05")
    check("📅 his own US shape, with / or -, two digits or four — a "
          .. "two-digit year is 20xx",
          S.taskDate("09/13/26", NOW) == "2026-09-13"
          and S.taskDate("9-13-2026", NOW) == "2026-09-13")
    check("🚨 ...and a word that is NOT a date answers nil rather than "
          .. "guessing one", S.taskDate("soon", NOW) == nil
          and S.taskDate("", NOW) == nil and S.taskDate(nil, NOW) == nil)

    -- ---- times --------------------------------------------------------------
    check("🕐 7:00 AM · 4:00 PM · 07:00 · 16:00 · 4pm all reach 24-hour",
          S.taskTime("7:00 AM") == "07:00" and S.taskTime("4:00 PM") == "16:00"
          and S.taskTime("07:00") == "07:00" and S.taskTime("16:00") == "16:00"
          and S.taskTime("4pm") == "16:00", tostring(S.taskTime("4pm")))
    check("🕐 midnight and noon are the two that get written wrong",
          S.taskTime("12:00 AM") == "00:00" and S.taskTime("12:00 PM") == "12:00",
          tostring(S.taskTime("12:00 AM")))
    check("🚨 ...and an impossible time answers nil rather than a "
          .. "plausible wrong one", S.taskTime("25:00") == nil
          and S.taskTime("7:99") == nil and S.taskTime("lunch") == nil)

    -- 🔤 6.236.0 IN THE FILLER SET. "a" is inside "and", so a substring
    -- test over one joined string would wave through every stray letter
    -- and the preview would stop naming what it could not read.
    local _, bad = S.taskWhen("from today to +1w", NOW)
    check("🔤 the joining words are a SET, so from/to cost nothing",
          #bad == 0, table.concat(bad, " "))
    local _, bad2 = S.taskWhen("a q today", NOW)
    check("🔤 ...and a stray letter is still NAMED — a substring test "
          .. "over 'at to and from' would have swallowed both",
          #bad2 == 2, table.concat(bad2, " "))

    -- ---- the preview itself ------------------------------------------------
    S.tabs = { { id = 1, title = "Today", text =
        "Fix the printer\n=\nP: Ship the release\nD: with words\nS: run the gate\nT: today" } }
    local prev = S.taskPreview(NOW)
    check("🔎 the preview names both tasks it found", 
          prev:find("Fix the printer", 1, true) ~= nil
          and prev:find("Ship the release", 1, true) ~= nil, prev)
    -- 🗂 6.300.0 — THESE TWO SUPERSEDE 6.297.0'S. That release's rule
    -- was "a preview must not read as a send"; it sends now, so the
    -- rule becomes "the preview describes the send that is ARMED", and
    -- the check drives BOTH switch positions rather than asserting one
    -- sentence (6.248.0).
    check("🗂 with the grammar armed, the preview says one task per task "
          .. "and names the two marks",
          prev:find("ONE ASANA TASK PER TASK", 1, true) ~= nil
          and prev:find(S.sentMark, 1, true) ~= nil
          and prev:find(S.failMark, 1, true) ~= nil, prev)
    S.sendGrammar = false
    local prevDay = S.taskPreview(NOW)
    check("🗂 ...and with it off it describes the DAY task instead — the "
          .. "switch is real in the preview too",
          prevDay:find("ONE task for the whole day", 1, true) ~= nil
          and prevDay:find("ONE ASANA TASK PER TASK", 1, true) == nil, prevDay)
    S.sendGrammar = true
    -- 📅 `T: today` is a start date with no end, which Asana refuses
    -- outright — so the preview shows what Asana will RECEIVE and says
    -- what it did to the line.
    check("📅 a lone date is previewed as the DUE date, and it says so",
          prev:find("one date given", 1, true) ~= nil
          and prev:find("due " .. os.date("%Y-%m-%d", NOW), 1, true) ~= nil,
          prev)
    check("🗂 6.301.0 — ...and says the subtasks GO, with the one caveat "
          .. "that can lose a line: a refused subtask does not fail its "
          .. "task, because retrying would duplicate the parent",
          prev:find("subtask(s) sent under this task", 1, true) ~= nil
          and prev:find("would duplicate", 1, true) ~= nil, prev)
    check("🔎 ...and teaches the grammar at the point of use",
          prev:find("P: title", 1, true) ~= nil
          and prev:find("= divides", 1, true) ~= nil)
    S.tabs = { { id = 1, title = "Empty", text = "   " } }
    check("🔎 an empty pad says 'nothing to send', which is not the same "
          .. "sentence as a pad it failed to read (6.196.1)",
          S.taskPreview(NOW):find("nothing to send", 1, true) ~= nil)

    local ran = (pass + fail) - before
    check("§6.297.0 ran all of its checks (" .. ran .. " of 28+)", ran >= 28, ran)
end

-- =====================================================================
out("\n🗂 6.300.0 — THE GRAMMAR SENDS, AND THE TAB WEARS THE ANSWER\n")
-- =====================================================================
-- LL: "Can we rewrite the task titles to either of the names in the
-- screenshot … So they stay until I delete them?" — his own answer to
-- the question 6.297.0 asked about where cleared text should go. He
-- does not want it cleared: the tab keeps every word and wears the
-- outcome as its title.
do
    local before = pass + fail
    -- The controllable world again: several sections above hand io.open
    -- back to the real one, and /logs is not a real folder.
    io.open = function(path, mode)
        if (mode or "r"):find("w") then
            if WRITE_FAILS then return nil end
            local buf = {}
            return { write = function(_, s) buf[#buf + 1] = s return true end,
                     close = function() FILES[path] = table.concat(buf) end }
        end
        if FILES[path] == nil then return nil end
        local content, done = FILES[path], false
        return { read = function() if done then return nil end done = true return content end,
                 close = function() end }
    end
    os.rename = function(a, b)
        if FILES[a] == nil then return nil, "no such file" end
        FILES[b] = FILES[a] ; FILES[a] = nil ; return true
    end
    local m9 = dofile(HS .. "/modules/scratch_pad.lua")
    m9.setup(CORE)
    local sp = _G.scratchPad
    sp.sendGrammar, sp.sendDaily = true, true
    local TODAY9 = os.date("%Y-%m-%d")
    local function reset(text)
        sp.tabs = { { id = "t1", text = text, kind = nil, at = os.time() } }
        sp.history, sp.active, sp.sent, sp.unsent = {}, "t1", {}, nil
        SUBMITS, DEGRADES, ALERTS, TOLD = {}, {}, {}, {}
        SUBMIT_RESULT, SUBMIT_ASANA, SUBMIT_DEFER = true, nil, false
        SUBMIT_PENDING, SUBMIT_SUBFAIL = {}, false
        -- §7 leaves the fake disk refusing writes; this section is not
        -- about that, and a "NOT SAVED" alert would be counted as the
        -- send's own.
        WRITE_FAILS, sp.saveErrSaid = false, nil
    end

    -- ---- one Asana task per parsed task ---------------------------------
    reset("Fix the printer\nCall the vendor\n=\nP: Ship the release\n"
          .. "A: sarah\nD: with words\nT: today +1w 7:00 AM 4:00 PM")
    local ok = sp.send("scheduled")
    check("🗂 every parsed task becomes its OWN Asana task",
          ok == true and #SUBMITS == 3, #SUBMITS .. " submit(s)")
    check("...with the task's own title", SUBMITS[1].title == "Fix the printer"
          and SUBMITS[2].title == "Call the vendor"
          and SUBMITS[3].title == "Ship the release",
          SUBMITS[3] and SUBMITS[3].title)
    check("...its assignee, defaulting to \"me\" where he named nobody",
          SUBMITS[1].assignee == "me" and SUBMITS[3].assignee == "sarah")
    check("...its description", SUBMITS[3].desc == "with words")
    check("📅 ...and its dates, both ends with both times",
          SUBMITS[3].extra.startDate == TODAY9
          and SUBMITS[3].extra.startTime == "07:00"
          and SUBMITS[3].extra.dueTime == "16:00"
          and SUBMITS[3].extra.dueDate ~= TODAY9,
          tostring(SUBMITS[3].extra.dueDate))

    -- ---- 🏷 THE MARK ----------------------------------------------------
    check("🏷 the tab is retitled with HIS success label",
          sp.tabs[1].mark == sp.sentMark
          and sp.titleOf(sp.tabs[1]) == sp.sentMark, sp.titleOf(sp.tabs[1]))
    check("...and every word is still in it — nothing is cleared, which "
          .. "is the whole shape of his answer",
          sp.tabs[1].text:find("Fix the printer", 1, true) ~= nil)
    check("...and the announce names the run once, not once per task",
          #ALERTS == 1 and tostring(ALERTS[1]):find("3 task", 1, true) ~= nil,
          tostring(ALERTS[1]))
    check("...and it survives the store", (function()
        local raw = FILES[sp.file] and jdec(FILES[sp.file])
        return raw and raw.tabs and raw.tabs[1] and raw.tabs[1].mark == sp.sentMark
    end)(), tostring(FILES[sp.file]))

    -- 🔑 THE RENAME IS THE MEMORY (6.281.0): a ✅ tab is never sent twice,
    -- or the 4 PM run would post yesterday's tasks again every day.
    SUBMITS, ALERTS = {}, {}
    local ok2 = sp.send("scheduled")
    check("🔑 a ✅ tab is SKIPPED by the next send — the rename is the "
          .. "memory, so nothing is posted twice",
          ok2 == false and #SUBMITS == 0, #SUBMITS)
    check("...and a run with nothing new says nothing on screen",
          #ALERTS == 0 and #DEGRADES == 0)

    -- 🏷 TYPING CLEARS THE MARK: new text is new work.
    sp.setText("t1", "A brand new thing")
    check("🏷 editing a ✅ tab clears its mark", sp.tabs[1].mark == nil)
    SUBMITS = {}
    sp.send("scheduled")
    check("...and it sends again", #SUBMITS == 1
          and SUBMITS[1].title == "A brand new thing")

    -- ---- ❌ AND THE FAILURE MARK ----------------------------------------
    reset("Something that will be refused")
    SUBMIT_ASANA = false                     -- posted, then Asana says no
    local okF = sp.send("scheduled")
    check("❌ a refused task marks the tab with HIS failure label",
          okF == true and sp.tabs[1].mark == sp.failMark, sp.tabs[1].mark)
    check("...and his text is untouched",
          sp.tabs[1].text == "Something that will be refused")
    check("...and it takes the 🔔 door with Asana's own reason",
          #DEGRADES == 1
          and tostring(ALERTS[#ALERTS]):find(SUBMIT_WHY, 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    -- 🔑 A ❌ TAB IS RETRIED. That is the only reason to mark a failure.
    SUBMITS, SUBMIT_ASANA = {}, nil
    sp.send("scheduled")
    check("🔑 a ❌ tab is RETRIED on the next send, and goes green",
          #SUBMITS == 1 and sp.tabs[1].mark == sp.sentMark, sp.tabs[1].mark)

    -- 🚨 ONE FAILURE IN A TAB MARKS THE WHOLE TAB FAILED. A ✅ over a tab
    -- that lost a task is the reassuring answer and the wrong one.
    reset("First one\nSecond one")
    local n = 0
    local savedSubmit = _G.asanaSubmitTask
    _G.asanaSubmitTask = function(t, d, a, x, e)
        n = n + 1
        SUBMITS[#SUBMITS + 1] = { title = t, extra = e }
        if e and e.onDone then e.onDone(n ~= 2, n == 2 and "refused" or nil, "1") end
        return true
    end
    sp.send("scheduled")
    _G.asanaSubmitTask = savedSubmit
    check("🚨 one refused task in a tab marks the whole tab ❌ — a ✅ over "
          .. "a lost task is the reassuring answer and the wrong one",
          #SUBMITS == 2 and sp.tabs[1].mark == sp.failMark, sp.tabs[1].mark)

    -- 🔢 TWO TABS, ONE ANNOUNCE. With a single tab the run-level
    -- counter is indistinguishable from the tab-level one — the
    -- mutation that announces per tab survived until this fixture
    -- existed (6.230.0: pick the input where the two implementations
    -- must differ).
    reset("Tab one task")
    sp.tabs[2] = { id = "t2", text = "Tab two task", kind = nil, at = os.time() }
    sp.send("scheduled")
    check("🔢 two tabs are announced ONCE for the run, not once each",
          #SUBMITS == 2 and #ALERTS == 1
          and tostring(ALERTS[1]):find("2 task", 1, true) ~= nil,
          #ALERTS .. " alert(s): " .. tostring(ALERTS[1]))
    check("...and both tabs are marked",
          sp.tabs[1].mark == sp.sentMark and sp.tabs[2].mark == sp.sentMark)
    -- ...and a failure in ONE tab marks only that tab, while the run
    -- still speaks once.
    reset("Good tab")
    sp.tabs[2] = { id = "t2", text = "Bad tab", kind = nil, at = os.time() }
    local savedSub2 = _G.asanaSubmitTask
    _G.asanaSubmitTask = function(t, d, a, x, e)
        SUBMITS[#SUBMITS + 1] = { title = t }
        if e and e.onDone then
            e.onDone(t ~= "Bad tab", t == "Bad tab" and "refused" or nil, "1")
        end
        return true
    end
    sp.send("scheduled")
    _G.asanaSubmitTask = savedSub2
    check("🔢 ...and one bad tab marks only itself",
          sp.tabs[1].mark == sp.sentMark and sp.tabs[2].mark == sp.failMark
          and #ALERTS == 1, tostring(sp.tabs[1].mark) .. "/" .. tostring(sp.tabs[2].mark))

    -- ⏳ THE MARK LANDS WHEN THE LAST ANSWER DOES, not the first.
    reset("Alpha\nBravo")
    SUBMIT_DEFER = true
    sp.send("scheduled")
    check("⏳ with the answers still out, the tab wears no mark and "
          .. "nothing is announced",
          sp.tabs[1].mark == nil and #ALERTS == 0, tostring(sp.tabs[1].mark))
    SUBMIT_ANSWER()
    check("...still nothing after only ONE of the two answers",
          sp.tabs[1].mark == nil, tostring(sp.tabs[1].mark))
    SUBMIT_ANSWER()
    check("...and the mark lands when the LAST one does",
          sp.tabs[1].mark == sp.sentMark and #ALERTS == 1)
    SUBMIT_DEFER = false

    -- ---- Asana off is a failure, and it says so on every tab -----------
    reset("Written expecting it to go")
    CORE.asanaEnabled = false
    sp.send("scheduled")
    check("Asana off marks the tab ❌ and takes the 🔔 door",
          sp.tabs[1].mark == sp.failMark and #DEGRADES == 1)
    CORE.asanaEnabled = true

    -- 🚨 A SUBMIT THAT RAISES must not hold the run open for ever.
    reset("This one throws")
    _G.asanaSubmitTask = function() error("kaboom", 0) end
    sp.send("scheduled")
    _G.asanaSubmitTask = savedSubmit
    check("🚨 a submit that THROWS still marks the tab and ends the run — "
          .. "one un-answered tab would hold it open for ever, with no ✅, "
          .. "no ❌ and no announce",
          sp.tabs[1].mark == sp.failMark and #DEGRADES == 1,
          tostring(sp.tabs[1].mark))

    -- 📏 CLOSED ROWS ARE NAMED, NOT SILENTLY DROPPED (6.201.1). The day
    -- task swept them; a closed row has no title to rewrite.
    reset("An open one")
    sp.history = { { id = "h1", text = "closed earlier today", kind = nil,
                     closedAt = os.time() } }
    sp.send("scheduled")
    check("📏 a row closed today is NOT sent — and it is counted, not "
          .. "quietly dropped", #SUBMITS == 1
          and sp.lastTaskSend.closedToday == 1, tostring(sp.lastTaskSend.closedToday))
    check("...and the report says so where he would read it",
          _G.scratchPadReport():find("closed", 1, true) ~= nil)

    -- 🔌 THE SWITCH IS REAL IN BOTH DIRECTIONS (6.228.0): the day task is
    -- kept whole, not deleted, and one settings line brings it back.
    reset("Line one\nLine two")
    sp.sendGrammar = false
    sp.send("scheduled")
    check("🔌 sendGrammar = false sends the DAY task instead — ONE submit "
          .. "for every tab, exactly as before", #SUBMITS == 1
          and SUBMITS[1].title:find(sp.titlePrefix, 1, true) == 1,
          #SUBMITS .. " / " .. tostring(SUBMITS[1] and SUBMITS[1].title))
    check("...and the day task does not mark the tab — the marks belong "
          .. "to the send that can answer for each one",
          sp.tabs[1].mark == nil, tostring(sp.tabs[1].mark))
    sp.sendGrammar = true

    -- ---- 🗂 6.301.0 — the S: lines reach Asana ------------------------
    reset("P: Ship the release\nS: run the gate\nS: write the notes")
    sp.send("scheduled")
    check("🗂 the S: lines ride into the submit as subtasks",
          #SUBMITS == 1 and type(SUBMITS[1].extra.subtasks) == "table"
          and #SUBMITS[1].extra.subtasks == 2,
          tostring(SUBMITS[1] and SUBMITS[1].extra.subtasks))
    check("...and the announce says how many went",
          tostring(ALERTS[#ALERTS]):find("2 subtasks", 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("...and the tab is ✅", sp.tabs[1].mark == sp.sentMark)

    -- 🚨 A REFUSED SUBTASK DOES NOT FAIL THE TASK. The parent is in
    -- Asana; marking the tab ❌ would retry and duplicate it.
    reset("P: Ship it\nS: one that fails")
    SUBMIT_SUBFAIL = true
    sp.send("scheduled")
    check("🚨 a refused SUBTASK leaves the tab ✅ — the task went, and a "
          .. "retry would put a second copy of it on his board",
          sp.tabs[1].mark == sp.sentMark, tostring(sp.tabs[1].mark))
    check("...but the announce SAYS one was refused, or a lost line is "
          .. "invisible", tostring(ALERTS[#ALERTS]):find("refused", 1, true) ~= nil,
          tostring(ALERTS[#ALERTS]))
    check("...and the report carries it with the reason it is not retried",
          _G.scratchPadReport():find("would duplicate their task", 1, true) ~= nil)
    SUBMIT_SUBFAIL = false

    -- ---- 📅 whenForAsana, PURE -----------------------------------------
    local w, notes = sp.whenForAsana({ startDate = "2026-09-26" })
    check("📅 a lone date is the DUE date — the only shape Asana takes, "
          .. "and what a single date means everywhere else",
          w.dueDate == "2026-09-26" and w.startDate == nil and #notes == 1,
          tostring(w.startDate) .. "/" .. tostring(w.dueDate))
    w = sp.whenForAsana({ startDate = "2026-09-26", startTime = "07:00" })
    check("...and its time goes with it", w.dueTime == "07:00" and w.startTime == nil)
    w, notes = sp.whenForAsana({ startDate = "a", dueDate = "b", startTime = "07:00" })
    check("📅 two dates with only ONE time go all-day — Asana cannot mix "
          .. "a timed end with an all-day start",
          w.startDate == "a" and w.dueDate == "b"
          and w.startTime == nil and w.dueTime == nil and #notes == 1)
    w = sp.whenForAsana({ startDate = "a", dueDate = "b",
                          startTime = "07:00", dueTime = "16:00" })
    check("📅 ...and his own two-date, two-time line is passed through "
          .. "untouched", w.startDate == "a" and w.dueDate == "b"
          and w.startTime == "07:00" and w.dueTime == "16:00")
    w, notes = sp.whenForAsana({ dueTime = "16:00" })
    check("📅 a time with no date at all is dropped and NAMED",
          w.dueTime == nil and #notes == 1, #notes)
    check("📅 ...and nothing at all answers nothing, quietly",
          (function() local a, b = sp.whenForAsana(nil)
             return a.dueDate == nil and #b == 0 end)())

    local ran = (pass + fail) - before
    check("§6.300.0 ran all of its checks (" .. ran .. " of 30+)", ran >= 30, ran)
end

-- ==========================================================================
-- §6.305.0 — A RETRY MUST NOT RE-SEND WHAT ALREADY LANDED
-- ==========================================================================
-- LL's first unattended 16:00 run read 122 tasks out of his tabs, 121
-- reached Asana and one was refused. The tab was marked ❌, and a ❌ tab
-- is re-parsed WHOLE — so the next run would have posted those 121 a
-- second time, and the run after that a third. The same hole was open
-- with no failure at all: typing in a ✅ tab clears its mark.
do
    local before = pass + fail
    io.open = function(path, mode)
        if (mode or "r"):find("w") then
            if WRITE_FAILS then return nil end
            local buf = {}
            return { write = function(_, s) buf[#buf + 1] = s return true end,
                     close = function() FILES[path] = table.concat(buf) end }
        end
        if FILES[path] == nil then return nil end
        local content, done = FILES[path], false
        return { read = function() if done then return nil end done = true return content end,
                 close = function() end }
    end
    os.rename = function(a, b)
        if FILES[a] == nil then return nil, "no such file" end
        FILES[b] = FILES[a] ; FILES[a] = nil ; return true
    end
    local m10 = dofile(HS .. "/modules/scratch_pad.lua")
    m10.setup(CORE)
    local sp = _G.scratchPad
    sp.sendGrammar, sp.sendDaily = true, true
    local function reset(text)
        sp.tabs = { { id = "t1", text = text, kind = nil, at = os.time() } }
        sp.history, sp.active, sp.sent, sp.unsent = {}, "t1", {}, nil
        SUBMITS, DEGRADES, ALERTS, TOLD = {}, {}, {}, {}
        SUBMIT_RESULT, SUBMIT_ASANA, SUBMIT_DEFER = true, nil, false
        SUBMIT_PENDING, SUBMIT_SUBFAIL = {}, false
        WRITE_FAILS, sp.saveErrSaid = false, nil
    end
    local function titles()
        local t = {}
        for _, x in ipairs(SUBMITS) do t[#t + 1] = x.title end
        return table.concat(t, "|")
    end
    -- A report PRINTS and returns nothing (6.179.1 — one string, one
    -- print), and earlier sections hand `print` back to the real one,
    -- so this section captures it for itself.
    local function reportText()
        local cap, saved = {}, print
        print = function(...)
            local q = {}
            for i = 1, select("#", ...) do q[#q + 1] = tostring((select(i, ...))) end
            cap[#cap + 1] = table.concat(q, " ")
        end
        pcall(_G.scratchPadReport)
        print = saved
        return table.concat(cap, "\n")
    end

    -- ---- 🔑 sp.digest — PURE ---------------------------------------------
    check("🔑 the digest is deterministic",
          sp.digest("abc") == sp.digest("abc"))
    check("...and different text answers differently",
          sp.digest("abc") ~= sp.digest("abd"))
    -- 🚨 THE KEY BECOMES A JSON OBJECT KEY, so it must never carry his
    -- own characters: a truncated slice of a title can cut a UTF-8 glyph
    -- in half and make the WHOLE store unencodable (6.204.0).
    check("🚨 the key is pure ASCII hex — his text never rides in it",
          sp.digest("Café — naïve 🎵"):match("^[0-9a-f]+$") ~= nil,
          sp.digest("Café — naïve 🎵"))
    check("...and a nil does not throw", sp.digest(nil) ~= nil)
    -- 🧪 THE FIRST VERSION OF THIS CHECK PASSED ITS OWN MUTATION: it
    -- compared digest("a") with digest("a "), and a plain FNV-1a with
    -- NO length term already answers differently for those, so it
    -- proved nothing about the term it was written for (6.230.0 — pick
    -- the input where the two implementations must differ; here there
    -- is none, so assert the FORMAT the contract promises instead).
    check("...and the length is part of the key, so two strings of "
          .. "different length can never collide",
          sp.digest(("x"):rep(255)):match("^%x%x%x%x%x%x%x%xff$") ~= nil,
          sp.digest(("x"):rep(255)))
    check("...and a shorter one carries its own length",
          sp.digest("ab"):match("^%x%x%x%x%x%x%x%x2$") ~= nil, sp.digest("ab"))

    -- ---- 🔑 sp.taskKey — PURE, and keyed by WHAT IT SAYS -----------------
    local function T(over)
        local t = { title = "Ship it", desc = "with words", assignee = "me",
                    when = { startDate = "2026-01-01", dueDate = "2026-01-08" },
                    subs = { "one", "two" } }
        for k, v in pairs(over or {}) do t[k] = v end
        return t
    end
    check("🔑 the same task answers the same key", sp.taskKey(T()) == sp.taskKey(T()))
    -- Each of these is a field a mutation can drop out of the canonical
    -- form; drop one and an EDIT to it stops counting as new work, so
    -- the edited task is silently never sent again.
    check("...a different TITLE is a different task",
          sp.taskKey(T()) ~= sp.taskKey(T({ title = "Ship it now" })))
    check("...a different DESCRIPTION is a different task",
          sp.taskKey(T()) ~= sp.taskKey(T({ desc = "with other words" })))
    check("...a different ASSIGNEE is a different task",
          sp.taskKey(T()) ~= sp.taskKey(T({ assignee = "sarah" })))
    check("...a different DATE is a different task",
          sp.taskKey(T()) ~= sp.taskKey(T({
              when = { startDate = "2026-02-02", dueDate = "2026-01-08" } })))
    check("...a different SUBTASK is a different task",
          sp.taskKey(T()) ~= sp.taskKey(T({ subs = { "one", "three" } })))
    -- 🧪 AND THE ORDER-INDEPENDENCE CHECK COULD NOT BITE AT TWO KEYS.
    -- Two tables holding the same two string keys iterate the same way
    -- inside one process, so deleting `table.sort` changed nothing and
    -- the mutation survived. The sort is load-bearing across a RELOAD,
    -- not within a run — Lua seeds its string hashes per state — so
    -- the contract is asserted directly, over enough keys that the
    -- hash order is reliably not alphabetical (6.230.0).
    check("🔑 the dates are canonicalised in SORTED order", (function()
        local w = {}
        for _, k in ipairs({ "h", "g", "f", "e", "d", "c", "b", "a" }) do
            w[k] = k:upper()
        end
        return sp.canonWhen(w) ==
            "a=A\1b=B\1c=C\1d=D\1e=E\1f=F\1g=G\1h=H"
    end)(), sp.canonWhen({ b = "B", a = "A" }))
    -- 🧪 pcall'd, because the mutation that takes the type guard off
    -- makes pairs("nonsense") RAISE — and a raise inside a check kills
    -- the run with "0 failed" never printed, which in a gate that reads
    -- the tail looks like a pass (6.186.0, eighth time).
    check("...and no dates at all answers an empty string, not a throw",
          (function()
              local okA, a = pcall(sp.canonWhen, nil)
              local okB, b = pcall(sp.canonWhen, "nonsense")
              return okA and a == "" and okB and b == ""
          end)())
    check("...so the same task keys the same whatever order Lua walks "
          .. "its date fields in", (function()
        local a = { title = "x", when = { dueDate = "b", startDate = "a" } }
        local b = { title = "x", when = { startDate = "a", dueDate = "b" } }
        return sp.taskKey(a) == sp.taskKey(b)
    end)())
    check("...and a bare table does not throw", sp.taskKey({}) ~= nil)

    -- ---- 🔢 sp.tasksToSend — PURE, a MULTISET difference ------------------
    local t1, t2, t3 = T({ title = "A" }), T({ title = "B" }), T({ title = "C" })
    local send, done = sp.tasksToSend({ t1, t2, t3 }, nil)
    check("🔢 with nothing landed, everything is sent",
          #send == 3 and #done == 0)
    send, done = sp.tasksToSend({ t1, t2, t3 }, { [sp.taskKey(t2)] = { n = 1 } })
    check("🔢 a landed task is SKIPPED and the rest still go",
          #send == 2 and #done == 1 and send[1].title == "A"
          and send[2].title == "C" and done[1].title == "B",
          #send .. "/" .. #done)
    -- 🚨 THE FIXTURE THAT SEPARATES A COUNT FROM A SET (6.230.0): two
    -- identical lines are two tasks. A set would skip both for ever
    -- after one landed, losing the second silently.
    send, done = sp.tasksToSend({ t1, t1 }, { [sp.taskKey(t1)] = { n = 1 } })
    check("🚨 two identical tasks, ONE landed — exactly one is skipped "
          .. "and one still goes", #send == 1 and #done == 1, #send .. "/" .. #done)
    send = sp.tasksToSend({ t1, t1 }, { [sp.taskKey(t1)] = { n = 2 } })
    check("...and both landed skips both", #send == 0)
    send = sp.tasksToSend({ t1 }, { [sp.taskKey(t1)] = { n = 0 } })
    check("...a count of 0 is not a landing", #send == 1)
    send = sp.tasksToSend({ t1 }, { [sp.taskKey(t1)] = { n = -3 } })
    check("...and neither is a negative one", #send == 1)
    send = sp.tasksToSend({ t1 }, { ["a key for a line he deleted"] = { n = 9 } })
    check("...a remembered key for a task no longer in the tab changes "
          .. "nothing", #send == 1)
    check("...and no input at all answers empty, not a throw",
          #(sp.tasksToSend(nil, nil)) == 0)

    -- ---- 🚨 HIS CASE, END TO END -----------------------------------------
    -- Three tasks, the middle one refused. The tab is ❌ and is retried.
    reset("Alpha\nBravo\nCharlie")
    local savedSubmit = _G.asanaSubmitTask
    _G.asanaSubmitTask = function(t, d, a, x, e)
        SUBMITS[#SUBMITS + 1] = { title = t }
        if e and e.onDone then
            e.onDone(t ~= "Bravo", t == "Bravo" and "refused" or nil,
                     t ~= "Bravo" and "9001" or nil)
        end
        return true
    end
    sp.send("scheduled")
    check("🚨 three tasks go, one is refused, the tab is ❌",
          #SUBMITS == 3 and sp.tabs[1].mark == sp.failMark, titles())
    -- THE WHOLE RELEASE IS THIS CHECK. Before it, the retry sent all
    -- three again and his Asana board grew by 121 a day.
    SUBMITS = {}
    sp.send("scheduled")
    check("🚨 the retry sends ONLY the task that did not land — the two "
          .. "already in Asana are not posted a second time",
          #SUBMITS == 1 and SUBMITS[1].title == "Bravo", titles())
    _G.asanaSubmitTask = savedSubmit
    -- ...and once the last one lands the tab goes green.
    SUBMITS = {}
    sp.send("scheduled")
    check("...and when the last one finally lands the tab goes ✅",
          #SUBMITS == 1 and SUBMITS[1].title == "Bravo"
          and sp.tabs[1].mark == sp.sentMark, sp.tabs[1].mark)

    -- ---- 🚨 THE ✅ SIDE, WHICH NEEDS NO FAILURE AT ALL --------------------
    reset("One\nTwo")
    sp.send("scheduled")
    check("🏷 a clean send marks ✅", #SUBMITS == 2 and sp.tabs[1].mark == sp.sentMark)
    SUBMITS = {}
    sp.setText("t1", "One\nTwo\nThree")
    check("🏷 typing clears the mark, as it must — new text is new work",
          sp.tabs[1].mark == nil)
    sp.send("scheduled")
    check("🚨 ...and the next send posts ONLY the new line. Before this "
          .. "release, editing one character in a sent tab re-posted "
          .. "every task in it",
          #SUBMITS == 1 and SUBMITS[1].title == "Three", titles())

    -- ---- 🔁 A TAB WITH NOTHING LEFT TO SEND IS DONE, NOT FAILED ----------
    -- His tab today is ❌ over one bad line. If he deletes that line,
    -- the tab must stop being retried rather than sitting ❌ for ever.
    reset("Alpha\nBravo")
    sp.send("scheduled")
    sp.tabs[1].mark = sp.failMark          -- as a partial failure left it
    SUBMITS, ALERTS = {}, {}
    local okN = sp.send("scheduled")
    check("🔁 a ❌ tab whose tasks have ALL landed is marked ✅ and sends "
          .. "nothing — it stops being retried for ever",
          okN == false and #SUBMITS == 0 and sp.tabs[1].mark == sp.sentMark,
          tostring(sp.tabs[1].mark) .. " / " .. #SUBMITS)
    check("...and the announce says so rather than \"nothing written\"",
          #ALERTS == 0 and (sp.lastSend and sp.lastSend.outcome or ""):find("nothing", 1, true) ~= nil,
          tostring(sp.lastSend and sp.lastSend.outcome))

    -- ---- 🔔 RECORDED ON THE ANSWER, NEVER ON THE ASK ---------------------
    -- `asanaSubmitTask` returns the moment the POST is fired (6.299.0).
    -- Recording there would mark a REFUSED task as landed, and it would
    -- then never be retried — the opposite failure, and a silent one.
    reset("Refused one")
    SUBMIT_ASANA = false
    sp.send("scheduled")
    check("🔔 a refused task is NOT remembered as landed",
          sp.tabs[1].landed == nil or next(sp.tabs[1].landed) == nil,
          tostring(sp.tabs[1].landed and next(sp.tabs[1].landed)))
    SUBMITS, SUBMIT_ASANA = {}, nil
    sp.send("scheduled")
    check("...so it IS retried, and lands", #SUBMITS == 1
          and sp.tabs[1].mark == sp.sentMark, #SUBMITS)

    -- ---- 💾 IT SURVIVES THE STORE ----------------------------------------
    -- A record that lives only in memory is no record at all: the 16:00
    -- run that duplicates is the one after a reload.
    reset("Persisted task")
    sp.send("scheduled")
    check("💾 the landed record is written to the store", (function()
        local raw = FILES[sp.file] and jdec(FILES[sp.file])
        local t = raw and raw.tabs and raw.tabs[1]
        return t and type(t.landed) == "table" and next(t.landed) ~= nil
    end)(), tostring(FILES[sp.file]):sub(1, 200))
    check("...and it is read back", (function()
        sp.tabs = {}
        sp.load()
        return sp.tabs[1] and type(sp.tabs[1].landed) == "table"
               and next(sp.tabs[1].landed) ~= nil
    end)())
    SUBMITS = {}
    sp.tabs[1].mark = nil                  -- as typing would leave it
    sp.send("scheduled")
    check("🚨 ...so a send AFTER A RELOAD posts nothing that already "
          .. "landed", #SUBMITS == 0, titles())

    -- ---- 📣 THE SKIP IS SAID AND COUNTED ---------------------------------
    reset("Kept\nNew one")
    sp.send("scheduled")
    SUBMITS, ALERTS = {}, {}
    sp.setText("t1", "Kept\nNew one\nThird")

    -- ---- 👁 THE PREVIEW ASKS THE SAME SELECTOR ---------------------------
    -- One function, two callers (6.231.0): a preview that promised a
    -- task the send will correctly skip is a preview that lies. Asked
    -- BEFORE the send below, so the two tasks it names are the two the
    -- send is about to skip.
    local pv = sp.taskPreview()
    check("👁 the preview marks a task already in Asana",
          pv:find("already in Asana", 1, true) ~= nil, pv:sub(1, 400))
    check("...and says how many of the tab's tasks are already there",
          pv:find("2 already in Asana", 1, true) ~= nil, pv:sub(1, 400))
    check("...and it does NOT print the dates of a task it will not send "
          .. "— \"would send\" and \"already sent\" must not read alike",
          select(2, pv:gsub("📅", "")) == 0, pv:sub(1, 400))

    sp.send("scheduled")
    check("📣 the announce names how many were already in Asana",
          #ALERTS == 1 and tostring(ALERTS[1]):find("already in Asana", 1, true) ~= nil,
          tostring(ALERTS[1]))
    check("...and the run records the skip count",
          (sp.lastTaskSend and sp.lastTaskSend.landed) == 2,
          tostring(sp.lastTaskSend and sp.lastTaskSend.landed))
    local rep = reportText()
    check("📣 the report carries the ledger",
          rep:find("landed", 1, true) ~= nil
          and rep:find("already in Asana", 1, true) ~= nil, rep:sub(1, 300))

    -- ---- 📏 THE BOUND IS A STATE, NOT A FOOTNOTE (6.197.2) ---------------
    reset("Aaa\nBbb\nCcc\nDdd")
    local savedMax = sp.landedMax
    sp.landedMax, sp.landedEvicted = 2, 0
    sp.send("scheduled")
    check("📏 past the cap the oldest remembered task is forgotten",
          (sp.landedEvicted or 0) > 0, tostring(sp.landedEvicted))
    local rep2 = reportText()
    check("...and the report WARNS, because a forgotten key is a task "
          .. "that can be sent twice",
          rep2:find("were forgotten this session", 1, true) ~= nil,
          rep2:sub(1, 300))
    sp.landedMax, sp.landedEvicted = savedMax, 0

    local ran = (pass + fail) - before
    check("§6.305.0 ran all of its checks (" .. ran .. " of 32+)", ran >= 32, ran)
end

out(string.format("\n%d passed, %d failed\n", pass, fail))
os.exit(fail == 0 and 0 or 1)
