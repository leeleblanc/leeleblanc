-- =====================================================================
-- test_music_player.lua — 6.231.0: ⇪⇧pad. a card you drop music on
-- =====================================================================
--     lua5.4 test_music_player.lua [/path/to/hammerspoon]
--
-- Executes modules/music_player.lua against a stubbed Mac. Everything
-- that DECIDES anything here is pure — what plays, what comes next, what
-- a drop yielded, how long a track has run — so the whole of it is proven
-- with no sound card, no files and no window.
--
-- 🧪 AND THE STUBS ARE AS UNFORGIVING AS macOS, which is this project's
-- most expensive lesson (6.193.0, and four costumes since): hs.sound's
-- end-of-track callback can be made NOT to fire, a file can be made to
-- vanish between the drop and the play, getByFile can refuse, and
-- setContents-style "returns false rather than throwing" refusals are
-- answered rather than raised. A stub gentler than the real provider is
-- a hole with a tick beside it.
local HS = (arg and arg[1]) or os.getenv("HAMMERSPOON_DIR")
           or ((os.getenv("HOME") or ".") .. "/.hammerspoon")

local pass, fail, failures = 0, 0, {}
-- The screens this stub Mac has. §15 changes it.
SCREENS = { { x = 0, y = 0, w = 1440, h = 900 } }

local function check(label, cond, extra)
    if cond then pass = pass + 1
    else fail = fail + 1
         failures[#failures + 1] = label
            .. (extra ~= nil and ("\n        got: " .. tostring(extra)) or "") end
end
local function out(s) io.write(s) end

-- ---- the stub Mac ------------------------------------------------------
local FILES     = {}     -- path → true when the file "is there"
local OPENABLE  = {}     -- path → false when macOS refuses to decode it
local DURATION  = {}     -- path → seconds
local SOUNDS    = {}     -- every hs.sound handed out
local TIMERS    = {}
-- ⌨️ 6.251.0 — which window macOS currently considers key.
local FOCUSED_WIN, WIN_SEQ = nil, 0
local NO_HSWINDOW, REFUSE_FOCUS = false, false
local ALERTS, PRINTED, DEGRADED = {}, {}, {}
local JS        = {}     -- every script pushed into the page
NO_SEEK         = false  -- a Mac that refuses to move the playing position
local WEBVIEWS  = {}
local NO_WEBVIEW, NO_SOUND = false, false
local WRITES    = {}     -- path → the bytes written
local READABLE  = {}     -- path → the bytes a read returns

local realPrint = print
print = function(...)
    local p = {}
    for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
    PRINTED[#PRINTED + 1] = table.concat(p, " ")
end

-- io.open is stubbed so the store can be proven without touching disk.
local realOpen = io.open
io.open = function(path, mode)
    if (mode or "r"):find("w") then
        return {
            write = function(_, s) WRITES[path] = (WRITES[path] or "") .. s end,
            close = function() READABLE[path] = WRITES[path] end,
        }
    end
    local body = READABLE[path]
    if not body then return nil end
    local done = false
    return {
        read  = function() if done then return nil end done = true return body end,
        close = function() end,
    }
end

-- ⏯ 6.289.0 — the media-key tap. hs.eventtap.event.types.systemDefined is
-- the only event class this player ever watches, and the stub records
-- what was created and started so a check can prove the tap is REAL
-- rather than intended.
TAPS = {}
NO_EVENTTAP = false
TAP_REFUSES = false
TAP_START_REFUSES = false
hs = {
    eventtap = {
        -- 6.291.0 — the SECOND route. F8 is an NSSystemDefined media key
        -- with "Use F1, F2… as standard function keys" OFF and a plain
        -- keyDown with it ON, so the stub has to be able to deliver
        -- both or the release is untestable (6.193.0, the whole point
        -- of 6.290.0's audit).
        event = {
            types = { systemDefined = 14, keyDown = 10 },
            properties = { keyboardEventAutorepeat = "autorepeat" },
        },
        new = function(types, fn)
            if TAP_REFUSES then error("macOS refused the tap", 0) end
            local t = { types = types, fn = fn, running = false }
            -- 6.265.0 — "created, wired, REFUSED TO START" is a different
            -- shape from "new threw", and on a beta OS it is the one this
            -- config keeps meeting. Modelled apart.
            function t:start()
                if TAP_START_REFUSES then error("macOS refused to start it", 0) end
                self.running = true; return self
            end
            function t:stop()  self.running = false; return self end
            TAPS[#TAPS + 1] = t
            return t
        end,
    },
    window = {
        focusedWindow = function()
            if FOCUSED_WIN == nil then return nil end
            local id = FOCUSED_WIN
            local w = {}
            function w:id() return id end
            return w
        end,
    },
    timer = {
        doAfter = function(secs, fn)
            local t = { secs = secs, fn = fn, every = false, stopped = false }
            function t:stop() self.stopped = true end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
        doEvery = function(secs, fn)
            local t = { secs = secs, fn = fn, every = true, stopped = false }
            function t:stop() self.stopped = true end
            TIMERS[#TIMERS + 1] = t
            return t
        end,
    },
    fs = {
        attributes = function(p, what)
            if not FILES[p] then return nil end
            if what == "mode" then return "file" end
            return { mode = "file" }
        end,
        mkdir = function() return true end,
    },
    alert  = { show = function(m) ALERTS[#ALERTS + 1] = tostring(m) end },
    screen = {
        mainScreen = function()
            return { frame = function() return { x = 0, y = 0, w = 1440, h = 900 } end }
        end,
        -- Two screens on purpose: the second is where a remembered spot
        -- that belongs to an unplugged monitor is proven to be refused.
        allScreens = function()
            local out = {}
            for _, f in ipairs(SCREENS) do
                out[#out + 1] = { frame = function() return f end }
            end
            return out
        end,
    },
    drawing = { windowLevels = { floating = 5 } },
    json = {
        encode = function(t)
            -- Deliberately a real round-trip, not a pretty printer: the
            -- store must survive encode → decode with its shape intact.
            local function enc(v)
                if type(v) == "table" then
                    local isArr = (#v > 0)
                    local parts = {}
                    if isArr then
                        for _, x in ipairs(v) do parts[#parts + 1] = enc(x) end
                        return "[" .. table.concat(parts, ",") .. "]"
                    end
                    local keys = {}
                    for k in pairs(v) do keys[#keys + 1] = k end
                    table.sort(keys)
                    for _, k in ipairs(keys) do
                        parts[#parts + 1] = string.format("%q", k) .. ":" .. enc(v[k])
                    end
                    return "{" .. table.concat(parts, ",") .. "}"
                end
                if type(v) == "string" then return string.format("%q", v) end
                if type(v) == "boolean" then return tostring(v) end
                return tostring(v)
            end
            return enc(t)
        end,
        decode = function(s) return _G.FAKE_DECODE end,
    },
}

-- 🚚 hs.canvas — the ONE thing on this Mac that can accept a dragged
-- file (checked in libcanvas.m, not remembered). The stub can be made to
-- be an older Hammerspoon that has no draggingCallback at all, or one
-- whose canvas refuses to show, because both are real Macs.
CANVASES, NO_CANVAS, NO_DRAGCB = {}, false, false
    NO_SEEK = false
hs.canvas = {
    windowLevels = { dragging = 500, screenSaver = 1000, floating = 3 },
    new = function(rect)
        if NO_CANVAS then return nil end
        local c = { rect = rect, elements = {} }
        function c:level(l) if l == nil then return self.lvl end self.lvl = l return self end
        function c:mouseCallback(f) self.mouseCb = f return self end
        function c:show() self.shown = true return self end
        function c:hide() self.shown = false return self end
        function c:delete() self.deleted = true return self end
        function c:frame(f) if f == nil then return self.rect end self.rect = f return self end
        if not NO_DRAGCB then
            function c:draggingCallback(f) self.dragCb = f return self end
        end
        setmetatable(c, { __newindex = function(t, k, v) rawset(t, k, v) end })
        CANVASES[#CANVASES + 1] = c
        return c
    end,
}
-- The drag pasteboard. macOS answers on whichever reader it feels like,
-- so each can be silenced independently and the ORDER is what is proven.
-- 🧪 AND EVERY READER CAN BE MADE TO THROW, because macOS's do: the bug
-- this suite could not see was a throw inside a dragging callback, where
-- nothing catches it and nothing is printed.
PB = { url = nil, str = nil, contents = nil, uti = nil, types = nil,
       plist = nil, throw = {} }
hs.pasteboard = {
    readURL = function(name, all)
        -- level 0: no "file:line:" prefix, so the message is EXACTLY what
        -- the test asked for. macOS's own errors carry the chunk path in
        -- front, which is the shape that made this bug look like a file.
        if PB.throw.url then
            if PB.throwMsg then error(PB.throwMsg, 0) end
            error("readURL blew up")
        end
        if PB.url == nil then return nil end
        return all and PB.url or PB.url[1]
    end,
    readDataForUTI = function(name, uti)
        if PB.throw.uti then error("readDataForUTI blew up") end
        return PB.uti
    end,
    readString = function(name, all)
        if PB.throw.str then error("readString blew up") end
        if PB.str == nil then return nil end
        return all and PB.str or PB.str[1]
    end,
    getContents = function(name)
        if PB.throw.contents then error("getContents blew up") end
        return PB.contents
    end,
    pasteboardTypes = function(name) return PB.types end,
    -- 📁 NSFilenamesPboardType — a plist ARRAY OF POSIX PATHS, which is
    -- the flavour that never needed resolving at all.
    readPListForUTI = function(name, uti)
        if PB.throw.plist then error("readPListForUTI blew up") end
        if uti ~= "NSFilenamesPboardType" then return nil end
        return PB.plist
    end,
}

-- 🔗 hs.fs, for the bookmark round-trip that turns a file reference back
-- into a file. BOOKMARKS is the stub Mac's own record of where each
-- reference really points; a reference not in it resolves to nothing, the
-- way a file that has gone would.
BOOKMARKS = {}
NO_BOOKMARK = false
BOOKMARK_THROW = false
hs.fs.pathToBookmark = function(path)
    if NO_BOOKMARK then error("no bookmark here", 0) end
    if BOOKMARKS[path] == nil then return nil end
    return "bookmark:" .. path
end
-- 🧪 It answers `nil, why` on a failure, exactly as the real one does — a
-- stub that simply returns nothing cannot see a caller reading two values
-- where there are three (6.193.0, 6.179.0).
hs.fs.pathFromBookmark = function(data)
    -- 🧪 A REAL FAILURE'S MESSAGE BEGINS WITH A PATH (6.236.1), and level 0
    -- so the fake has the shape the real one has.
    if BOOKMARK_THROW then
        error("/m/its-own-traceback.mp3:99: resolving blew up", 0)
    end
    if type(data) ~= "string" then return nil, "not bookmark data" end
    local path = data:match("^bookmark:(.*)$")
    local real = path and BOOKMARKS[path]
    if not real then return nil, "could not resolve" end
    return real
end

-- 🔊 hs.sound, and it can be made to behave badly on purpose.
hs.sound = {
    getByFile = function(path)
        if NO_SOUND then error("no sound on this Mac") end
        if OPENABLE[path] == false then return nil end
        local s = {
            path = path, playing = false, plays = 0, stops = 0,
            cb = nil, t = 0,
        }
        function s:play() self.playing = true ; self.plays = self.plays + 1 ; return true end
        function s:pause() self.playing = false ; return true end
        function s:resume() self.playing = true ; return true end
        function s:stop() self.playing = false ; self.stops = self.stops + 1 ; return true end
        function s:isPlaying() return self.playing end
        -- 🧪 A GETTER AND A SETTER, because the real one is both
        -- ([NSSound setCurrentTime:] — libsound.m). A getter-only stub is
        -- how 6.227.0's restore "succeeded" while moving nothing, twice.
        function s:currentTime(n)
            if n == nil then return self.t end
            if NO_SEEK then error("this sound will not seek", 0) end
            self.t = n
            self.seeks = (self.seeks or 0) + 1
            return self
        end
        function s:duration() return DURATION[path] or 180 end
        function s:setCallback(fn) self.cb = fn ; return self end
        SOUNDS[#SOUNDS + 1] = s
        return s
    end,
}

hs.webview = {
    usercontent = {
        new = function(name)
            local uc = { name = name, cb = nil }
            function uc:setCallback(fn) self.cb = fn ; return self end
            return uc
        end,
    },
    new = function(rect, _, uc)
        if NO_WEBVIEW then return nil end
        local v = { rect = rect, uc = uc, shown = false, deleted = false, html = "" }
        function v:windowTitle() return self end
        function v:allowTextEntry() return self end
        function v:level() return self end
        function v:behaviorAsLabels() return self end
        function v:alpha() return self end
        function v:html(h) self.htmlText = h ; return self end
        function v:show() self.shown = true ; return self end
        function v:bringToFront() return self end
        function v:delete() self.deleted = true ; return self end
        -- 🧪 A REAL GETTER *AND* SETTER, because hs.webview's frame() is
        -- both: a getter-only stub lets every move succeed while moving
        -- nothing, and no mutation of the drag could ever be caught
        -- (6.227.0's selectedRow, in a new costume).
        function v:frame(r)
            if r == nil then return self.rect end
            self.rect = { x = r.x, y = r.y, w = r.w, h = r.h }
            return self
        end
        function v:evaluateJavaScript(s) JS[#JS + 1] = s ; return self end
        -- ⌨️ 6.251.0 — hs.webview:hswindow() and the window it answers
        -- with. A REAL FOCUS: win:focus() makes it the focused window, so
        -- "the card took the keys" can actually be reached. A stub whose
        -- focus() did nothing would let the chase run its four tries and
        -- give up on a healthy Mac — and a getter-only one would let the
        -- opposite pass. NO_HSWINDOW plays a build that does not expose
        -- the window at all; REFUSE_FOCUS plays a window macOS will not
        -- make key.
        v.winId = (WIN_SEQ or 0) + 1
        WIN_SEQ = v.winId
        function v:hswindow()
            if NO_HSWINDOW then return nil end
            local id = self.winId
            local w = { }
            function w:id() return id end
            function w:focus()
                if not REFUSE_FOCUS then FOCUSED_WIN = id end
                return self
            end
            return w
        end
        WEBVIEWS[#WEBVIEWS + 1] = v
        return v
    end,
}

_G.diag = { say = function() end, warn = function() end, err = function() end }

local BOUND, PROVIDED, ESC_CLAIMS = {}, {}, {}
local CORE = {
    homeDir = "/Users/lee",
    hyperAddShortcut = function(mods, key, fn, src)
        BOUND[((mods and mods[1]) or "") .. "+" .. key] = { fn = fn, src = src }
    end,
    provide = function(n, f) PROVIDED[n] = f end,
    degrade = function(tool, why)
        DEGRADED[#DEGRADED + 1] = tostring(tool) .. ": " .. tostring(why)
        return false, why
    end,
}
_G.claimEscape = function(name, _, active, handle)
    ESC_CLAIMS[name] = { active = active, handle = handle }
    return true
end
_G.hyperExpectRelease = function() end
_G.hyperReleaseSeen   = function(who) _G.RELEASED = who end

local chunk = assert(loadfile(HS .. "/modules/music_player.lua"))
local M = chunk()
M.setup(CORE)
local mp = _G.musicPlayer

-- 🏷 6.296.0 — the panel id is READ from the registry rather than typed
-- here: 6.248.0's rule, and the reason the rename did not quietly
-- retire eleven checks about the drag grip.
local PANEL_ID = (function()
    for _, e in ipairs(_G.movablePanels or {}) do
        if type(e.frame) == "function" and e.frame() ~= nil then return e.name end
    end
    for _, e in ipairs(_G.movablePanels or {}) do return e.name end
    return "?"
end)()

local function reset()
    FILES, OPENABLE, DURATION = {}, {}, {}
    SOUNDS, TIMERS, ALERTS, PRINTED, DEGRADED, JS, WEBVIEWS = {}, {}, {}, {}, {}, {}, {}
    WRITES, READABLE = {}, {}
    NO_WEBVIEW, NO_SOUND = false, false
    _G.FAKE_DECODE, _G.RELEASED = nil, nil
    if mp.webview then pcall(mp.hide) end
    mp.queue, mp.history, mp.refused = {}, {}, {}
    mp.index, mp.sel, mp.mode = 0, 1, "off"
    mp.playing, mp.sound, mp.elapsed, mp.duration = false, nil, 0, 0
    mp.advances = { callback = 0, belt = 0, manual = 0 }
    mp.loaded, mp.enabled = true, true
    mp.tickTimer, mp.saveTimer = nil, nil
    mp.pos, mp.posWhy = nil, "not opened yet"
    -- ⌨️ 6.251.0
    mp.takeKeyboard, mp.focusTimer = true, nil
    mp.focus = { tries = 0, why = "not asked" }
    FOCUSED_WIN, NO_HSWINDOW, REFUSE_FOCUS = nil, false, false
    SCREENS = { { x = 0, y = 0, w = 1440, h = 900 } }
    CANVASES, NO_CANVAS, NO_DRAGCB = {}, false, false
    NO_SEEK = false
    PB = { url = nil, str = nil, contents = nil, uti = nil, types = nil,
           plist = nil, throw = {}, throwMsg = nil }
    BOOKMARKS, NO_BOOKMARK, BOOKMARK_THROW = {}, false, false
    mp.catcher, mp.dropReader = nil, nil
    mp.dropWhy, mp.dragSeen = "not opened yet", "no drag yet this session"
    mp.dropRefs = "nothing read yet"
end

-- 🧪 The catcher, and the drag that reaches it. Both answer falsely
-- rather than indexing a nil (6.186.0), so a mutation FAILS a check.
local function catcher()
    return CANVASES[#CANVASES] or { lvl = nil, rect = nil, mouseCb = nil }
end
local function drag(msg, pb)
    local c = CANVASES[#CANVASES]
    if not (c and c.dragCb) then return false end
    return c.dragCb(c, msg, { pasteboard = pb or "drag-pb", sequence = 1 })
end

local function drop(uri, names)
    local view = WEBVIEWS[#WEBVIEWS]
    local uc = view and view.uc
    if not (uc and uc.cb) then return false end
    uc.cb({ body = { a = "drop", uri = uri, names = names } })
    return true
end
local function post(body)
    local view = WEBVIEWS[#WEBVIEWS]
    local uc = view and view.uc
    if not (uc and uc.cb) then return false end
    uc.cb({ body = body })
    return true
end
-- 🚨 6.186.0 / 6.225.0's rule, applied to this suite's own helpers: a
-- mutation must make a check FAIL, never make the run DIE. Every one of
-- these answers falsely rather than indexing a nil sound.
local function lastSound() return SOUNDS[#SOUNDS] end
local function fireEnd()
    local s = lastSound()
    if not (s and s.cb) then return false end
    s.cb(s, true)
    return true
end
local function muteCallback()
    local s = lastSound()
    if not s then return false end
    s.cb = nil
    return true
end
local function setSound(field, value)
    local s = lastSound()
    if not s then return false end
    s[field] = value
    return true
end

local function tickOnce()
    for _, t in ipairs(TIMERS) do
        if t.every and not t.stopped then t.fn() return true end
    end
    return false
end
local function has(list, needle)
    for _, s in ipairs(list) do
        if tostring(s):find(needle, 1, true) then return true end
    end
    return false
end
local function report()
    PRINTED = {}
    _G.musicReport()
    return table.concat(PRINTED, "\n")
end

out("\n=== 🎵 6.231.0 — what plays, and what comes next (PURE) ===\n")

-- ---- §1 the file rule --------------------------------------------------
check("🎧 mp3 and m4a play — the two formats he named",
      (mp.playableFor("/m/a.mp3")) and (mp.playableFor("/m/b.m4a")))
check("...and wav / aiff, which NSSound also decodes",
      (mp.playableFor("/m/a.wav")) and (mp.playableFor("/m/b.aiff")))
check("🚨 .flac is REFUSED, and the reason names the format and the way out",
      (function()
           local ok, why = mp.playableFor("/m/a.flac")
           return ok == false and why:find("flac", 1, true)
                  and why:find("m4a", 1, true) ~= nil
       end)(), select(2, mp.playableFor("/m/a.flac")))
check("...and so is .ogg — both named, neither silently skipped",
      select(1, mp.playableFor("/m/a.ogg")) == false)
check("a .pdf dropped by accident is refused BY NAME, never 'nothing happened'",
      (function()
           local ok, why = mp.playableFor("/m/a.pdf")
           return ok == false and why:find("pdf", 1, true) ~= nil
       end)())
check("a file with no extension is refused and says so",
      select(2, mp.playableFor("/m/noext")) == "no file extension")
check("EXTENSION MATCHING IS CASE-BLIND — Finder hands over .MP3 too",
      mp.playableFor("/m/A.MP3") == true)
check("a nil path does not throw", select(1, mp.playableFor(nil)) == false)

check("📛 the title is the file name with the extension off",
      mp.titleOf("/Users/lee/Music/Bad Blood.mp3") == "Bad Blood",
      mp.titleOf("/Users/lee/Music/Bad Blood.mp3"))
check("...and a dot inside the NAME survives it",
      mp.titleOf("/m/Mr. Blue Sky.m4a") == "Mr. Blue Sky",
      mp.titleOf("/m/Mr. Blue Sky.m4a"))

-- ---- §2 the clock ------------------------------------------------------
check("🕐 the clock reads m:ss", mp.clock(0) == "0:00" and mp.clock(65) == "1:05",
      mp.clock(65))
check("...and h:mm:ss ONLY once there are hours — no '0:' on every track",
      mp.clock(3725) == "1:02:05" and mp.clock(599) == "9:59",
      mp.clock(3725) .. " / " .. mp.clock(599))
check("...and a negative or absent time is 0:00, never a minus sign",
      mp.clock(-5) == "0:00" and mp.clock(nil) == "0:00")

-- ---- §3 the repeat rule, and the half that is the whole point ----------
check("🔁 repeat OFF walks to the end and then stops",
      mp.nextIndex(1, 3, "off") == 2 and mp.nextIndex(3, 3, "off") == nil)
check("🔁 repeat ALL wraps round", mp.nextIndex(3, 3, "all") == 1)
check("🔂 repeat ONE plays the same track again when it ENDS",
      mp.nextIndex(2, 3, "one") == 2)
-- 🚨 THE ROW THIS FUNCTION EXISTS FOR. A mode is about what the player
-- does on its own; it never refuses an instruction.
check("🚨 ...but ⏭ under repeat ONE moves ON — a person asking for the "
      .. "next track is asking for the next track",
      mp.nextIndex(2, 3, "one", true) == 3, mp.nextIndex(2, 3, "one", true))
check("...and ⏭ on the LAST track under repeat one wraps, it does not stop",
      mp.nextIndex(3, 3, "one", true) == 1)
check("an empty queue has no next, in any mode",
      mp.nextIndex(1, 0, "all") == nil and mp.nextIndex(1, 0, "one") == nil)
check("an index off the end of the queue lands on the first track",
      mp.nextIndex(99, 3, "off") == 1)
check("⏮ wraps to the last track from the first",
      mp.prevIndex(1, 4) == 4 and mp.prevIndex(3, 4) == 2)

-- ---- §4 the drop, which is where the paths come from -------------------
check("🚚 a Finder drag's uri-list becomes paths",
      (function()
           local p = mp.pathsFromURIList("file:///m/a.mp3\r\nfile:///m/b.m4a\r\n")
           return #p == 2 and p[1] == "/m/a.mp3" and p[2] == "/m/b.m4a"
       end)())
check("🚨 ...and the percent-escapes are undone, or a track with a space "
      .. "or an apostrophe in its name can never be opened",
      mp.pathsFromURIList("file:///m/Ain%27t%20It%20Fun.mp3")[1]
      == "/m/Ain't It Fun.mp3",
      mp.pathsFromURIList("file:///m/Ain%27t%20It%20Fun.mp3")[1])
check("the format's own # comment lines are not files",
      #mp.pathsFromURIList("# a comment\nfile:///m/a.mp3") == 1)
check("blank lines are not files either",
      #mp.pathsFromURIList("\n\nfile:///m/a.mp3\n\n") == 1)
check("a bare absolute path (a plain-text drag) is taken too",
      mp.pathsFromURIList("/m/a.mp3")[1] == "/m/a.mp3")
check("something that is neither is ignored rather than guessed at",
      #mp.pathsFromURIList("https://example.com/a.mp3") == 0)
check("a nil drop does not throw", #mp.pathsFromURIList(nil) == 0)

-- ---- §5 building the queue --------------------------------------------
check("➕ adding keeps the order he dropped them in",
      (function()
           local q = mp.addPaths({}, { "/m/a.mp3", "/m/b.mp3", "/m/c.mp3" })
           return #q == 3 and q[1].title == "a" and q[3].title == "c"
       end)())
check("🚨 the same file dropped twice is ONE row — dropping a folder "
      .. "again must not double the list",
      (function()
           local q = mp.addPaths({}, { "/m/a.mp3" })
           local q2, added, refused = mp.addPaths(q, { "/m/a.mp3" })
           return #q2 == 1 and #added == 0 and #refused == 1
                  and refused[1].why:find("already", 1, true) ~= nil
       end)())
check("🚨 ONE UNPLAYABLE FILE LOSES ITS OWN ROW, NEVER THE BATCH — the "
      .. "mp3s in a mixed drop still queue",
      (function()
           local q, added, refused =
               mp.addPaths({}, { "/m/a.mp3", "/m/b.flac", "/m/c.mp3" })
           return #q == 2 and #added == 2 and #refused == 1
       end)())
check("...and the refusal carries the file AND the reason, for the card",
      (function()
           local _, _, r = mp.addPaths({}, { "/m/b.flac" })
           return r[1].path == "/m/b.flac" and r[1].why:find("flac", 1, true) ~= nil
       end)())
check("the queue has a ceiling, and the overflow says which",
      (function()
           mp.maxQueue = 2
           local q, _, r = mp.addPaths({}, { "/m/a.mp3", "/m/b.mp3", "/m/c.mp3" })
           mp.maxQueue = 200
           return #q == 2 and #r == 1 and r[1].why:find("full", 1, true) ~= nil
       end)())

out("\n=== 🔊 the player itself, through the window ===\n")

-- ---- §6 opening -------------------------------------------------------
reset()
check("⇪⇧pad. is the key, and it is bound", BOUND["shift+pad."] ~= nil)
BOUND["shift+pad."].fn()
check("...and it opens the card", mp.webview ~= nil and #WEBVIEWS == 1)
check("...in the TOP-RIGHT corner, like the calendar he compared it to",
      (function()
           local r = WEBVIEWS[1].rect
           return r.x > 1000 and r.y < 40
       end)(), WEBVIEWS[1] and (WEBVIEWS[1].rect.x .. "," .. WEBVIEWS[1].rect.y))
check("...and the elapsed clock is ticking on a HELD timer (6.196.1 — a "
      .. "timer nothing references is collected and simply never fires)",
      mp.tickTimer ~= nil and mp.tickTimer.every == true)
check("...and it claimed Esc, so the cheat sheet still closes LAST",
      ESC_CLAIMS["musicplayer"] ~= nil and ESC_CLAIMS["musicplayer"].active())
BOUND["shift+pad."].fn()
check("the same key closes it again", mp.webview == nil)
check("...and the tick stops with the window — nothing keeps beating at a "
      .. "card that is not there", mp.tickTimer == nil)

-- ---- §7 the drop, end to end ------------------------------------------
reset()
FILES["/m/one.mp3"], FILES["/m/two.mp3"], FILES["/m/three.mp3"] = true, true, true
mp.show()
drop("file:///m/one.mp3\nfile:///m/two.mp3\nfile:///m/three.mp3")
check("🎵 three files dropped, three tracks queued", #mp.queue == 3, #mp.queue)
check("🚨 ...and THE FIRST ONE PLAYS, which is exactly what he asked for",
      mp.playing == true and mp.index == 1 and #SOUNDS == 1,
      tostring(mp.index) .. " sounds=" .. #SOUNDS)
check("...the rest are the playlist under it, untouched",
      mp.queue[2].title == "two" and mp.queue[3].title == "three")
check("...and the page was redrawn with them", has(JS, "draw("))

check("⌘3 plays the third track",
      (function() post({ a = "pick", i = 3 }) return mp.index == 3 end)(), mp.index)
check("...and the one that was playing was STOPPED, not left running under it",
      SOUNDS[1] ~= nil and SOUNDS[1].stops >= 1)
check("↓ moves the highlight without playing anything",
      (function()
           local before = #SOUNDS
           mp.sel = 1
           post({ a = "sel", d = 1 })
           return mp.sel == 2 and #SOUNDS == before
       end)(), mp.sel)
check("⏎ plays the highlighted row",
      (function() post({ a = "pick", i = mp.sel }) return mp.index == 2 end)())
check("space pauses, and space again resumes",
      (function()
           post({ a = "play" })
           local paused = (mp.playing == false)
           post({ a = "play" })
           return paused and mp.playing == true
       end)())
check("⌫ takes the highlighted track out",
      (function()
           local n = #mp.queue
           mp.sel = 3
           post({ a = "remove", i = 3 })
           return #mp.queue == n - 1
       end)(), #mp.queue)

-- ---- §8 the two ways a track ends -------------------------------------
reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
check("track 1 is playing", mp.index == 1)
check("a sound was actually handed out to end", fireEnd())
check("🔔 hs.sound's callback ends the track and the next one starts",
      mp.index == 2, mp.index)
check("...and it is COUNTED as a callback advance",
      mp.advances.callback == 1 and mp.advances.belt == 0)

-- 🚨 THE BELT, AND WHY IT EXISTS. A callback this module cannot prove
-- fires is a playlist that stops after one song with no error anywhere.
-- Here the callback is simply deleted, exactly as a Hammerspoon that does
-- not deliver it would behave.
reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
DURATION["/m/a.mp3"] = 10
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
check("a sound was handed out before the belt is tested", muteCallback())
setSound("playing", false)             -- macOS never tells us, but it HAS stopped
setSound("t", 10)
tickOnce()
check("🔔 THE BELT: with no callback at all, the tick notices the track "
      .. "stopped and moves on — the playlist does not die after one song",
      mp.index == 2, mp.index)
check("...and it is counted SEPARATELY, so the report can say which half "
      .. "this Mac is actually using",
      mp.advances.belt == 1 and mp.advances.callback == 0,
      mp.advances.belt .. "/" .. mp.advances.callback)

-- 🚨 AND THE BELT MUST NOT FIRE EARLY. A paused track has stopped too.
reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
DURATION["/m/a.mp3"] = 200
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
setSound("playing", false)
setSound("t", 4)                        -- four seconds into a 200 s track
tickOnce()
check("🚨 ...and a track stopped FOUR SECONDS into two hundred is not a "
      .. "track that ended — the belt does not skip on a pause",
      mp.index == 1 and mp.advances.belt == 0, mp.index)

-- ---- §9 repeat, through the window ------------------------------------
reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
post({ a = "repeat" }) ; post({ a = "repeat" })
check("🔂 two clicks of the repeat button reach 'one' (off → all → one)",
      mp.mode == "one", mp.mode)
mp.playAt(1, "test")
check("a sound is playing before the repeat rule is asked", fireEnd())
check("🔂 a track that ENDS under repeat one plays again",
      mp.index == 1, mp.index)
post({ a = "next" })
check("🚨 ...and ⏭ under repeat one moves ON — the window proves the same "
      .. "rule the pure function does",
      mp.index == 2, mp.index)
check("...and the asked-for advance is counted apart from the automatic ones",
      mp.advances.manual >= 1)

-- ---- §10 the degrades, every one of them ------------------------------
reset()
mp.show()
drop("", { "Song.mp3", "Other.mp3" })
check("🚚 A DROP macOS GAVE NO PATH FOR IS NOT SILENT — the names are "
      .. "named and the reason is said, because a card that ignored the "
      .. "drop reads as broken",
      #mp.refused == 1 and mp.refused[1] ~= nil
      and mp.refused[1].why:find("Song.mp3", 1, true) ~= nil
      and mp.refused[1].why:find("path", 1, true) ~= nil,
      mp.refused[1] and mp.refused[1].why)
check("...and it reaches the page, not just the log", has(JS, "draw("))

reset()
FILES["/m/a.mp3"] = true
mp.show()
drop("file:///m/a.mp3")
FILES["/m/a.mp3"] = nil                 -- deleted between the drop and the play
local okGone = mp.playAt(1, "test")
check("🗑 a file that has GONE is a stat, never a read — no cloud download "
      .. "on the main thread to find out",
      okGone == false and mp.queue[1] ~= nil and mp.queue[1].bad ~= nil,
      mp.queue[1] and mp.queue[1].bad)
check("...and the row says so where he is looking",
      mp.queue[1] ~= nil
      and tostring(mp.queue[1].bad):find("not there", 1, true) ~= nil)

reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
OPENABLE["/m/a.mp3"] = false            -- macOS refuses this one file
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
check("🚨 a file macOS refuses to DECODE marks its own row and leaves the "
      .. "rest of the queue alone — one failed item, never the batch",
      #mp.queue == 2 and mp.queue[1] ~= nil and mp.queue[1].bad ~= nil
      and mp.queue[2] ~= nil and mp.queue[2].bad == nil, #mp.queue)

-- 🔔 TWO DIFFERENT NO-WINDOW FACTS, AND THEY MUST NOT READ ALIKE: a
-- Hammerspoon built without hs.webview at all, and a Mac that has the API
-- and still refuses to make the window. Both take the door; each says its
-- own thing, so the Console line names which one happened.
reset()
local SAVED_WEBVIEW = hs.webview
hs.webview = nil
local okApi, whyApi = mp.show()
check("🔔 no hs.webview AT ALL → the card refuses, says so, and TAKES THE "
      .. "DOOR rather than failing in silence",
      okApi == false and #DEGRADED == 1
      and DEGRADED[1]:find("hs.webview", 1, true) ~= nil,
      DEGRADED[1] or whyApi)
hs.webview = SAVED_WEBVIEW

reset()
NO_WEBVIEW = true
local okShow, whyShow = mp.show()
check("🔔 ...and a Mac that HAS the API but will not open the window says "
      .. "a DIFFERENT thing — two facts, two sentences",
      okShow == false and #DEGRADED == 1
      and DEGRADED[1]:find("could not open the player window", 1, true) ~= nil
      and DEGRADED[1]:find("hs.webview", 1, true) == nil,
      DEGRADED[1] or whyShow)
check("...and it does not leave the page bridge held behind it",
      mp.uc == nil and mp.webview == nil)
NO_WEBVIEW = false

reset()
FILES["/m/a.mp3"] = true
mp.show()
drop("file:///m/a.mp3")
NO_SOUND = true
mp.index = 0
local okNo = mp.playAt(1, "test")
check("🔔 an hs.sound that throws is caught, named and degraded — never a "
      .. "traceback into the config",
      okNo == false, okNo)
NO_SOUND = false

reset()
mp.enabled = false
local okOff = mp.show()
check("🔌 the off switch is real, and it is read at the PRESS — not "
      .. "latched at setup where a settings override could never reach it",
      okOff == false and mp.webview == nil)
mp.enabled = true

-- ---- §11 the store -----------------------------------------------------
reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.mp3")
for _, t in ipairs(TIMERS) do if not t.every then t.fn() end end
check("💾 the queue is written",
      WRITES[mp.storeFile] ~= nil
      and WRITES[mp.storeFile]:find("a.mp3", 1, true) ~= nil,
      WRITES[mp.storeFile])
check("🚨 ...LOCALLY. Not into OneDrive — a cloud write costs a main-thread "
      .. "wake-up (6.229.0) and a half-played queue is not cross-Mac data",
      mp.storeFile:find("Application Support", 1, true) ~= nil
      and mp.storeFile:find("OneDrive", 1, true) == nil,
      mp.storeFile)

-- 🗂 6.198.1's rule, in the loader: "it is a table" is not "it is MY
-- table". A store written by an older build, truncated by a crash, or
-- hand-edited must not reach a single reader — and the REPORT reads the
-- same structure the feature does, so a bad store would otherwise take
-- out the diagnostic that names it.
reset()
READABLE[mp.storeFile] = "{}"
_G.FAKE_DECODE = { queue = { { path = "/m/good.mp3" }, "not a table",
                             { nope = true }, { path = 42 } },
                   -- 🧪 `at` is RECENT on purpose: 6.234.0 prunes by age at
                   -- the loader, so a 1970 timestamp here would make this
                   -- check pass for the wrong reason (6.219.0's rule — a
                   -- test built on one behaviour is retired by a change to
                   -- it, so re-arm it in the same release).
                   history = { { path = "/m/h.mp3", at = os.time() }, 7 },
                   mode = "all" }
mp.loaded = false
mp.loadStore()
check("🗂 the loader keeps the rows that are the right SHAPE",
      #mp.queue == 1 and mp.queue[1] ~= nil
      and mp.queue[1].path == "/m/good.mp3", #mp.queue)
check("...and drops the ones that are not, without throwing", #mp.history == 1)
check("...and a remembered repeat mode comes back", mp.mode == "all")
check("...and the report still works over the cleaned store — the "
      .. "diagnostic must survive the thing it diagnoses",
      report():find(mp.brand:upper(), 1, true) ~= nil)

reset()
READABLE[mp.storeFile] = "{{{ not json"
_G.FAKE_DECODE = nil
mp.loaded = false
mp.loadStore()
check("🚨 a store that cannot be decoded starts EMPTY and says so — it "
      .. "never throws on the way to a keypress",
      #mp.queue == 0 and tostring(mp.lastWhy):find("could not be read", 1, true) ~= nil,
      mp.lastWhy)

-- =====================================================================
-- 🏷 6.296.0 — JUG PLAYER
-- =====================================================================
-- LL: "From here forward, call the music player, Jug Player and put the
-- name to the left of now playing." Visible strings only, which is
-- 6.214.0's and 6.253.0's precedent.
reset()
check("🏷 ONE FIELD carries the name, so the card, the alert, the door "
      .. "and the reports cannot drift apart",
      type(mp.brand) == "string" and mp.brand ~= "", tostring(mp.brand))

-- 🔑 6.239.0 — MOVE THE CONFIG AND REQUIRE EVERYTHING TO FOLLOW.
-- Asserting the shipped word passes when the word is typed in twice,
-- which is the whole failure mode a rename creates.
do
    local saved = mp.brand
    mp.brand = "Zzyzx Box"
    local html = mp.buildHtml()
    check("🏷 the CARD is written from the field, not from a literal — "
          .. "the name is drawn and the old one is nowhere in the page",
          html:find("Zzyzx Box", 1, true) ~= nil
          and html:find("Music player", 1, true) == nil
          and html:find("Jug Player", 1, true) == nil, "moved brand")
    local r = report()
    check("🏷 ...and so is the report's heading",
          r:find("ZZYZX BOX", 1, true) ~= nil, r:sub(1, 50))
    mp.brand = saved
end

-- 📐 HIS WORDS WERE POSITIONAL: "put the name to the left of now
-- playing". Asserting only that the name is SOMEWHERE in the page
-- passes with it dropped into the footer, so the check reads the
-- ORDER inside the header and that they share one line.
do
    local html = mp.buildHtml()
    local hd   = html:match('<header id="hd">(.-)</header>') or ""
    local ib   = hd:find('id="brand"', 1, true)
    local inow = hd:find('id="now"', 1, true)
    check("📐 the name is in the HEADER and to the LEFT of the "
          .. "now-playing text — his words, as an ordering",
          ib ~= nil and inow ~= nil and ib < inow,
          tostring(ib) .. " / " .. tostring(inow))
    check("📐 ...and they sit on ONE line: the row is a flex box, so the "
          .. "name is beside the track rather than above it",
          html:find("#top { display:flex", 1, true) ~= nil
          and hd:find('<div id="top">', 1, true) ~= nil)
    check("🪟 ...and the drag grip is untouched — the mousedown is still "
          .. "on #hd, which both children bubble to (6.232.0)",
          html:find("hd.addEventListener('mousedown'", 1, true) ~= nil)
end

-- 🔤 6.231.1 IN A NEW PLACE: the name goes into markup, so a name with
-- an & or a < in it would break the header exactly as a track name did.
check("🔤 the name is escaped before it reaches the page",
      mp.brandText('Jug & <b>Box</b>')
        == "Jug &amp; &lt;b&gt;Box&lt;/b&gt;", mp.brandText('Jug & <b>Box</b>'))
check("🔤 ...and an empty or missing name falls back rather than drawing "
      .. "a nameless card",
      mp.brandText("") == "Jug Player" and mp.brandText(nil) == "Jug Player"
      and mp.brandText("   ") == "Jug Player")

-- 🔒 THE SENTRY IS ABOUT THE CLASS, not the eight strings I found: a
-- ninth written next month brings the old name back and nothing
-- functional would notice. COMMENTS ARE STRIPPED (6.262.0) — the
-- history lives in them and they quote the very words this forbids.
do
    local f = realOpen(HS .. "/modules/music_player.lua")
    local src = f and f:read("a") or ""
    if f then f:close() end
    local bare = src:gsub("%-%-%[%[.-%]%]", " "):gsub("%-%-[^\n]*", " ")
    local hits = {}
    for line in bare:gmatch("[^\n]+") do
        if line:lower():find("music player", 1, true) then
            hits[#hits + 1] = line:gsub("^%s+", ""):sub(1, 70)
        end
    end
    check("🔒 no VISIBLE 'Music player' is left in the module — the ids "
          .. "(the module key, movablePanels, the escape router) keep "
          .. "their names on purpose and are not this string",
          #hits == 0, table.concat(hits, " | "))
    check("...and the sentry had a file to read (6.187.0)", #src > 1000, #src)

    -- 🏷 THE ID PAIR. window_move's report prints the panel name, so it
    -- is visible after all and it moved — but the registry entry and
    -- the beginPanelDrag() argument must be the SAME string or the
    -- title-strip grip silently stops working (6.232.0).
    local reg  = bare:match('name%s*=%s*"([^"]*)",%s*\n%s*frame')
    local drag = bare:match('beginPanelDrag%("([^"]*)"%)')
    check("🏷 the movablePanels id and the beginPanelDrag argument are "
          .. "the same string — renaming one half is how a panel stops "
          .. "being draggable with nothing to see",
          reg ~= nil and reg == drag, tostring(reg) .. " vs " .. tostring(drag))

    -- 🔕 AND THE QUIET LIST NAMES THIS TOOL BY THE NAME IT ACTUALLY
    -- USES. 6.295.0 made this player Console-only by listing its tool
    -- name in core/notices.lua, and 6.296.0 changed that name — two
    -- files, one string, and if they drift the player starts alerting
    -- again with nothing to see. 6.268.0's rule: when a rename crosses
    -- a file boundary, a sentry joins the two sides.
    local nf = realOpen(HS .. "/core/notices.lua")
    local nsrc = nf and nf:read("a") or ""
    if nf then nf:close() end
    local list = nsrc:match("notices%.quietTools%s*=%s*{(.-)}")
    check("🔕 core/notices.lua's quiet list names this player by the "
          .. "name this module passes to the door — the two files must "
          .. "not drift, or the card starts alerting again silently",
          list ~= nil and list:find('"' .. mp.brand .. '"', 1, true) ~= nil,
          tostring(list) .. "  vs  " .. tostring(mp.brand))
    check("...and the sentry really read notices.lua (6.187.0)",
          #nsrc > 1000, #nsrc)
end

-- ---- §12 the report ----------------------------------------------------
reset()
local r0 = report()
check("📋 the report opens with the tool and its key",
      r0:find("🎵 " .. mp.brand:upper() .. " — ⇪⇧pad.", 1, true) ~= nil,
      r0:sub(1, 60))
check("...and an empty queue reads as EMPTY, not as a silent zero",
      r0:find("empty", 1, true) ~= nil)
check("...and it names the local store and why it is local",
      r0:find("LOCAL, never OneDrive", 1, true) ~= nil)
check("...and it says there is no volume control, on purpose",
      r0:find("volume", 1, true) ~= nil)
check("🚨 ...and it prints as ONE string (6.179.1 — a report printed row "
      .. "by row loses rows to the console gate)", #PRINTED == 1, #PRINTED)

FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
mp.show()
drop("file:///m/a.mp3\nfile:///m/b.flac")
local r1 = report()
check("📋 the queue is listed with the playing track marked",
      r1:find("← playing", 1, true) ~= nil, r1)
check("🚨 ...and the REFUSED file is named with its reason — a drop that "
      .. "half worked must say which half",
      r1:find("flac", 1, true) ~= nil)
check("...and the two advance counters are printed side by side, so "
      .. "nobody deletes the belt for looking redundant",
      r1:find("by callback", 1, true) and r1:find("by the belt", 1, true))

-- ---- §13 the handshake and the housekeeping ---------------------------
reset()
mp.show()
post({ a = "f18" })
check("⇪ THE HANDSHAKE: the page forwards F18's keyup so the hold can end "
      .. "while the card is up (6.165.1)", _G.RELEASED == "musicPlayer",
      tostring(_G.RELEASED))
check("...and Esc from the page closes the card",
      (function() post({ a = "esc" }) return mp.webview == nil end)())

reset()
FILES["/m/a.mp3"] = true
mp.show()
drop("file:///m/a.mp3")
mp.hide()
check("🎶 closing the card does NOT stop the music — putting a window away "
      .. "is not an instruction to stop playing",
      mp.playing == true and mp.sound ~= nil)

reset()
check("🔌 the services are published for other modules",
      PROVIDED["music.show"] and PROVIDED["music.toggle"] and PROVIDED["music.hide"])

-- ---- §14 a name the card cannot draw ----------------------------------
-- 🔔 6.231.1. `rowsJson` used to answer "{}" when hs.json refused the
-- queue. That drew an EMPTY CARD over a queue that was still playing and
-- told nobody — 6.196.1's rule ("not yet" and "never" must not read
-- alike), in the one function every redraw goes through.
reset()
FILES["/m/a.mp3"] = true
mp.show()
drop("file:///m/a.mp3")
local goodEncode = hs.json.encode
hs.json.encode = function() error("not text") end
local payload = mp.rowsJson()
hs.json.encode = goodEncode
check("🔔 a queue that cannot be encoded takes the degrade door",
      #DEGRADED > 0 and DEGRADED[#DEGRADED]:find("could not be turned into text",
                                                 1, true) ~= nil,
      table.concat(DEGRADED, " | "))
check("🚨 ...and the answer is NOT a bare {} — an empty card over a "
      .. "playing queue is a lie the page cannot tell from an empty queue",
      payload ~= "{}" and payload:find("refused", 1, true) ~= nil, payload)
check("...and what it does answer still carries the fields the page reads",
      payload:find('"rows"', 1, true) and payload:find('"hist"', 1, true)
      and payload:find('"mode"', 1, true), payload)
check("...and the queue itself is untouched — the drawing failed, "
      .. "not the music", #mp.queue == 1 and mp.playing == true)

-- ---- §15 the window moves ----------------------------------------------
-- 🪟 6.232.0. The card was the one panel this config draws that never
-- registered itself in _G.movablePanels, so neither grip reached it: not
-- window_move's ⌘-drag, and not the bare drag on a title strip.

-- PURE first, with no Mac: where does it open?
local SF = { x = 0, y = 0, w = 1440, h = 900 }
local ONE = { SF }
local TWO = { SF, { x = 1440, y = 0, w = 1920, h = 1080 } }

local corner = mp.frameFor(SF)
local r, why = mp.placeFor(nil, SF, ONE)
check("🪟 a card that has never been moved opens in the corner",
      r.x == corner.x and r.y == corner.y and why == "corner", why)

r, why = mp.placeFor({ x = 200, y = 300 }, SF, ONE)
check("...and one he moved opens where he left it",
      r.x == 200 and r.y == 300 and why == "moved", why)
check("...at the same size as ever", r.w == corner.w and r.h == corner.h)

r, why = mp.placeFor({ x = 2000, y = 200 }, SF, ONE)
check("🚨 a spot on a monitor that is NOT attached now is refused for the "
      .. "corner — never clamped onto the edge of a screen it was never on",
      r.x == corner.x and r.y == corner.y
      and why:find("no screen now", 1, true) ~= nil, why)

r, why = mp.placeFor({ x = 2000, y = 200 }, SF, TWO)
check("...and the same spot is kept once that monitor is back",
      r.x == 2000 and r.y == 200 and why == "moved", why)

r, why = mp.placeFor({ x = 1430, y = 880 }, SF, ONE)
check("a card remembered three-quarters off the bottom right is nudged "
      .. "back on, because a grip you cannot reach is the bug this fixes",
      r.x == SF.w - corner.w and r.y == SF.h - corner.h
      and why:find("nudged", 1, true) ~= nil, why)
check("...and the nudge SAYS so rather than reading as an exact restore",
      why ~= "moved")

r = mp.placeFor({ x = "over there" }, SF, ONE)
check("a store holding nonsense for a position opens in the corner",
      r.x == corner.x and r.y == corner.y)

-- the registration, and the two grips
reset()
local entry
for _, e in ipairs(_G.movablePanels or {}) do
    if e.name == PANEL_ID then entry = e end
end
check("🪟 the card is listed in _G.movablePanels, which is the ONLY way "
      .. "window_move can reach it", entry ~= nil)
-- 🧪 6.186.0, and this suite has now paid it twice: the mutation that
-- deletes the registration must FAIL these checks, not kill the run on
-- `entry.frame`. The stand-in answers falsely instead.
local grip = entry or { frame = function() return nil end,
                        move  = function() end }
check("...with a frame and a move, the two things window_move calls",
      entry and type(entry.frame) == "function"
            and type(entry.move) == "function")
check("🚨 ...and NOT as plain — a bare click on this card picks a track, "
      .. "so only the title strip may take one",
      entry and not entry.plain)

mp.show()
local view = WEBVIEWS[#WEBVIEWS]
check("the frame it reports is the window's own",
      grip.frame() ~= nil and grip.frame().w == view.rect.w)

grip.move(120, 240)
check("🪟 moving it moves the WINDOW",
      view.rect.x == 120 and view.rect.y == 240,
      view.rect.x .. "," .. view.rect.y)
check("...and keeps its size", view.rect.w == corner.w and view.rect.h == corner.h)
check("...and remembers the spot", mp.pos and mp.pos.x == 120 and mp.pos.y == 240)

-- it comes back where he put it
mp.hide()
mp.show()
local v2 = WEBVIEWS[#WEBVIEWS]
check("🚨 ...so ⇪⇧pad. opens it where he left it, not back in the corner",
      v2.rect.x == 120 and v2.rect.y == 240,
      v2.rect.x .. "," .. v2.rect.y)

-- and the spot survives a reload, through the store — both ways
for _, t in ipairs(TIMERS) do if not t.every then t.fn() end end
check("💾 the spot is written to the store",
      (WRITES[mp.storeFile] or ""):find("120", 1, true) ~= nil,
      WRITES[mp.storeFile])

reset()
READABLE[mp.storeFile] = "{}"
_G.FAKE_DECODE = { queue = {}, history = {}, mode = "off",
                   pos = { x = 300, y = 400 } }
mp.loaded = false
mp.loadStore()
check("...and read back on the next boot",
      mp.pos and mp.pos.x == 300 and mp.pos.y == 400,
      mp.pos and (mp.pos.x .. "," .. mp.pos.y) or "nil")

reset()
READABLE[mp.storeFile] = "{}"
_G.FAKE_DECODE = { queue = {}, history = {}, pos = "somewhere" }
mp.loaded = false
mp.loadStore()
check("🗂 ...and a store whose position is not a position is DROPPED at "
      .. "the loader, never handed to the window",
      mp.pos == nil, tostring(mp.pos))
_G.FAKE_DECODE = nil

-- the header's bare drag
reset()
mp.show()
_G.PICKED_UP = nil
_G.beginPanelDrag = function(n) _G.PICKED_UP = n ; return true end
post({ a = "dragStart" })
check("🪟 a press on the title strip asks window_move to pick the card up",
      _G.PICKED_UP == PANEL_ID, tostring(_G.PICKED_UP))

-- 🔔 and with window_move absent it says so instead of doing nothing
reset()
mp.show()
_G.beginPanelDrag = nil
local okDrag = pcall(post, { a = "dragStart" })
check("🚨 with window_move not loaded the press does not throw",
      okDrag == true)
check("...and the reason is recorded rather than swallowed",
      tostring(mp.lastWhy):find("window_move", 1, true) ~= nil,
      tostring(mp.lastWhy))
_G.beginPanelDrag = function(n) _G.PICKED_UP = n ; return true end

-- the page carries the grip
reset()
mp.show()
local page = WEBVIEWS[#WEBVIEWS].htmlText or ""
check("🚨 ...and it is the HEADER that listens, not the whole card — a "
      .. "press on a row must still pick a track",
      page:find("hd.addEventListener('mousedown'", 1, true) ~= nil)

-- the report
reset()
mp.show()
grip.move(75, 85)
local rw = report()
check("📋 the report says where the card is and why it is there",
      rw:find("window", 1, true) and rw:find("75,85", 1, true), rw)
check("...and names both grips, because neither is discoverable",
      rw:find("⌘-drag", 1, true) ~= nil)

-- ---- §16 a dragged file lands on the card ------------------------------
-- 🚚 6.233.0, and it is the release that made the feature exist. hs.webview
-- has NO drag-and-drop (checked in libwebview.m: the string "dragg" appears
-- zero times), so the drop LL was told to test could never have worked — the
-- drag fell through to whatever was behind the card, which is his report.
-- hs.canvas is the one that can, under two conditions its own docs state.

reset()
FILES["/m/a.mp3"], FILES["/m/b.mp3"] = true, true
mp.show()
local cat = catcher()
check("🚚 opening the card puts a drop catcher up — without it nothing "
      .. "can accept a dragged file at all", CANVASES[1] ~= nil)
check("...at the card's own frame, or the drop lands somewhere else",
      cat.rect and cat.rect.w == mp.frameFor(SF).w, cat.rect and cat.rect.w)
check("🚨 ...at the DRAGGING window level, which hs.canvas REQUIRES — "
      .. "anything higher and macOS never offers it the drag",
      cat.lvl == hs.canvas.windowLevels.dragging, tostring(cat.lvl))
check("🚨 ...and with a mouseCallback, the second documented condition — "
      .. "a canvas that takes no mouse events takes no drags either",
      type(cat.mouseCb) == "function")

-- the drag itself
JS = {}
drag("enter")
check("a drag coming over the card shows the drop veil",
      table.concat(JS, " "):find("dropShow(true)", 1, true) ~= nil,
      table.concat(JS, " "))
JS = {}
drag("exit")
check("...and taking it away again hides it",
      table.concat(JS, " "):find("dropShow(false)", 1, true) ~= nil)

JS = {}
PB.url = { "file:///m/a.mp3", "file:///m/b.mp3" }
drag("receive")
check("🚚 DROPPING TWO FILES PUTS THEM IN THE QUEUE — the whole feature",
      #mp.queue == 2 and mp.queue[1].path == "/m/a.mp3",
      #mp.queue)
check("...and the first one starts playing, as he described it",
      mp.playing == true and mp.index == 1)
check("...and the veil is taken down", 
      table.concat(JS, " "):find("dropShow(false)", 1, true) ~= nil)
check("...and the report names which reader macOS answered on",
      mp.dropReader == "readURL", tostring(mp.dropReader))

-- the readers, in order, because macOS answers on whichever it likes
reset() ; mp.show()
PB.url = nil
PB.str = { "file:///m/c.mp3" }
FILES["/m/c.mp3"] = true
drag("receive")
check("a Mac that answers on readString instead is still read",
      #mp.queue == 1 and mp.dropReader == "readString", tostring(mp.dropReader))

reset() ; mp.show()
PB.url, PB.str = nil, nil
PB.contents = "file:///m/d.mp3"
FILES["/m/d.mp3"] = true
drag("receive")
check("...and one that only answers on getContents too",
      #mp.queue == 1 and mp.dropReader == "getContents", tostring(mp.dropReader))

reset() ; mp.show()
PB.url = { "file:///m/first.mp3" }
PB.str = { "file:///m/second.mp3" }
FILES["/m/first.mp3"], FILES["/m/second.mp3"] = true, true
drag("receive")
check("🚨 the FIRST reader that answers decides — the order is the rule, "
      .. "not a preference", mp.queue[1] and mp.queue[1].path == "/m/first.mp3",
      mp.queue[1] and mp.queue[1].path)

-- a drop that carries nothing is NAMED
reset() ; mp.show()
PB.url, PB.str, PB.contents = nil, nil, nil
drag("receive")
check("🔔 a drop macOS hands over with no path in it is NAMED, never "
      .. "swallowed", #mp.refused == 1 and mp.refused[1].why ~= "",
      mp.refused[1] and mp.refused[1].why)
check("...and the queue is untouched", #mp.queue == 0)

-- the catcher follows the card, and goes with it
reset() ; mp.show()
local entry2
for _, e in ipairs(_G.movablePanels or {}) do
    if e.name == PANEL_ID then entry2 = e end
end
;(entry2 or { move = function() end }).move(400, 500)
check("🪟 moving the card moves the catcher with it — a catcher left "
      .. "behind is a dead zone over the old spot",
      catcher().rect and catcher().rect.x == 400,
      catcher().rect and catcher().rect.x)
local was = catcher()
mp.hide()
check("...and closing the card takes the catcher down",
      was.deleted == true and mp.catcher == nil)

-- 🔔 the degrades, both of them, and they must not read alike
reset()
local realCanvas = hs.canvas
hs.canvas = nil
local okNoCv = mp.show()
check("🔔 a Hammerspoon with NO hs.canvas at all still OPENS the card",
      okNoCv == true and mp.webview ~= nil)
check("...and says so, rather than the card looking broken",
      tostring(mp.dropWhy):find("no hs.canvas", 1, true) ~= nil,
      tostring(mp.dropWhy))
check("...through the 🔔 door, so he sees it at the moment it happens",
      #DEGRADED > 0, table.concat(DEGRADED, " | "))
check("...and the report names that state, never 'ready'",
      report():find("⚠️", 1, true) ~= nil and mp.catcher == nil)
hs.canvas = realCanvas

reset()
NO_CANVAS = true
mp.show()
check("🔔 ...and a Mac whose hs.canvas REFUSES to make the window is a "
      .. "DIFFERENT state, which must not read the same (6.196.1)",
      tostring(mp.dropWhy):find("could not be created", 1, true) ~= nil
      and tostring(mp.dropWhy):find("no hs.canvas", 1, true) == nil,
      tostring(mp.dropWhy))
check("🔔 ...and THAT one takes the door too — every way the drop can "
      .. "fail is a break he is shown, not one he finds later",
      #DEGRADED > 0, table.concat(DEGRADED, " | "))

reset()
NO_DRAGCB = true
mp.show()
check("🔔 a Hammerspoon whose canvas cannot take drags is its OWN state",
      mp.catcher == nil and tostring(mp.dropWhy):find("cannot accept drags",
                                                      1, true) ~= nil,
      tostring(mp.dropWhy))
check("...and the canvas it made is cleaned up, not left on screen",
      catcher().deleted == true)

-- the page's own door still reaches the same function
reset() ; mp.show()
FILES["/m/z.mp3"] = true
drop("file:///m/z.mp3")
check("🚚 the page's own drop handler goes through the SAME door, so the "
      .. "two can never drift", #mp.queue == 1)

-- the report
reset() ; mp.show()
PB.url = { "file:///m/a.mp3" }
drag("receive")
local rd = report()
check("📋 the report says the catcher is up and what it last saw",
      rd:find("catcher up", 1, true) and rd:find("dropped", 1, true), rd)

-- ---- §17 thirty days, one row per file ---------------------------------
-- 🕘 6.234.0. PURE, so the clock is an argument and nothing here waits.
local NOW = 1000000000
local DAY = 86400
-- 🧪 6.186.0, third time in this suite: a mutation that empties the list
-- must FAIL these checks, not die on h[1].path.
local function row(list, i)
    return (type(list) == "table" and type(list[i]) == "table") and list[i]
           or { path = "<none>", at = -1 }
end

local h = mp.noteHistory({}, { path = "/m/a.mp3", title = "a" }, NOW, 30, 400)
check("🕘 a track played goes into the history", #h == 1 and h[1].path == "/m/a.mp3")
check("...stamped with when it played", row(h, 1).at == NOW)

h = mp.noteHistory(h, { path = "/m/b.mp3", title = "b" }, NOW + 10, 30, 400)
check("...and the newest is FIRST, which is the order the card draws",
      row(h, 1).path == "/m/b.mp3" and row(h, 2).path == "/m/a.mp3", #h)

-- 🚨 THE ROW HE ASKED FOR
h = mp.noteHistory(h, { path = "/m/a.mp3", title = "a" }, NOW + 20, 30, 400)
check("🚨 THE SAME FILE IS LISTED ONCE — playing it again MOVES it up "
      .. "rather than adding a second row (his ask, word for word)",
      #h == 2, #h)
check("...at the top, with the new time",
      row(h, 1).path == "/m/a.mp3" and row(h, 1).at == NOW + 20)
check("...and the other track is still there, not lost to the de-duplicate",
      row(h, 2).path == "/m/b.mp3")

-- the window
local old30 = {
    { path = "/m/yesterday.mp3", title = "y", at = NOW - DAY },
    { path = "/m/lastweek.mp3",  title = "w", at = NOW - (7 * DAY) },
    { path = "/m/day29.mp3",     title = "n", at = NOW - (29 * DAY) },
    { path = "/m/day31.mp3",     title = "o", at = NOW - (31 * DAY) },
    { path = "/m/lastyear.mp3",  title = "l", at = NOW - (400 * DAY) },
}
h = mp.noteHistory(old30, nil, NOW, 30, 400)
check("🕘 thirty days is the rule: everything inside the window stays",
      #h == 3, #h)
check("...and day 29 is INSIDE it", row(h, 3).path == "/m/day29.mp3",
      row(h, 3).path)
check("🚨 ...and day 31 is not — the edge is a real edge, not a rounding",
      (function()
          for _, t in ipairs(h) do if t.path == "/m/day31.mp3" then return false end end
          return true
      end)())
check("...nor is last year", #h == 3)

h = mp.noteHistory(old30, nil, NOW, 365, 400)
check("...and the window is a NUMBER, not a hard-coded thirty — at 365 "
      .. "days the day-31 row comes back, and last year's still does not",
      #h == 4 and row(h, 4).path == "/m/day31.mp3",
      #h .. " " .. row(h, 4).path)

-- the bound is still a bound
local many = {}
for i = 1, 50 do many[i] = { path = "/m/t" .. i .. ".mp3", at = NOW - i } end
h = mp.noteHistory(many, nil, NOW, 30, 10)
check("🔒 the cap is still a bound — days decide, but a runaway list is "
      .. "still a runaway list", #h == 10, #h)
check("...and it keeps the NEWEST ten, never the oldest",
      row(h, 1).path == "/m/t1.mp3")

-- it never throws on a store somebody else wrote
check("🗂 a history list full of nonsense is dropped, not fatal",
      #mp.noteHistory({ "x", 7, { nope = true }, { path = "" } }, nil,
                      NOW, 30, 400) == 0)
check("...and a nil list is an empty history",
      #mp.noteHistory(nil, nil, NOW, 30, 400) == 0)

-- 🕘 AND THE LOADER PRUNES, which is its own branch: a Mac left off for
-- six weeks must not come back with six weeks of rows and lose them one
-- play at a time.
reset()
READABLE[mp.storeFile] = "{}"
_G.FAKE_DECODE = { queue = {}, mode = "off", history = {
    { path = "/m/fresh.mp3", at = os.time() - DAY },
    { path = "/m/stale.mp3", at = os.time() - (60 * DAY) },
} }
mp.loaded = false
mp.loadStore()
check("🕘 a store holding a row older than the window is pruned AT THE "
      .. "LOADER, not on the next play",
      #mp.history == 1 and row(mp.history, 1).path == "/m/fresh.mp3",
      #mp.history .. " " .. row(mp.history, 1).path)
_G.FAKE_DECODE = nil

-- through the real player
reset()
FILES["/m/one.mp3"], FILES["/m/two.mp3"] = true, true
mp.show()
drop("file:///m/one.mp3\nfile:///m/two.mp3")
mp.playAt(2, "test") ; mp.playAt(1, "test") ; mp.playAt(2, "test")
check("🕘 four plays over two files leave TWO history rows",
      #mp.history == 2, #mp.history)
check("...the most recent play at the top",
      row(mp.history, 1).path == "/m/two.mp3", row(mp.history, 1).path)

local rh = report()
check("📋 the report says the window, not just a count",
      rh:find("30 day", 1, true) and rh:find("one row per file", 1, true), rh)

-- ---- §18 the drop that lit up and did nothing --------------------------
-- 🚚 6.235.0. LL on 6.234.0: "Turns highlighted blue so it seems to see the
-- file but drop doesn't work." The blue proves the catcher IS being offered
-- the drag — registration, level and mouseCallback are all right — so the
-- failure is in the half AFTER it, and a throw in there is invisible: the
-- callback dies, the veil is already down, and nothing is printed anywhere.

-- 🧷 PURE: joining whatever a reader answered with
check("🧷 a reader that answers with one string is taken as it is",
      mp.joinLines("file:///m/a.mp3") == "file:///m/a.mp3")
check("...a list of strings becomes lines",
      mp.joinLines({ "a", "b" }) == "a\nb")
check("🚨 ...AND A LIST HOLDING A TABLE DOES NOT THROW — this is the bug: "
      .. "table.concat blows up on anything that is not a string, inside a "
      .. "callback with nothing to catch it",
      (function()
          local ok, v = pcall(mp.joinLines, { { url = "file:///m/a.mp3" } })
          return ok and v == "file:///m/a.mp3"
      end)())
check("...and a table it cannot read a url out of is skipped, not fatal",
      (function()
          local ok, v = pcall(mp.joinLines, { { nope = true }, "file:///m/b.mp3" })
          return ok and v == "file:///m/b.mp3"
      end)())
check("...nothing usable answers nil rather than an empty string",
      mp.joinLines({}) == nil and mp.joinLines({ true }) == nil)
check("...and a number is a line, not a crash", mp.joinLines({ 7 }) == "7")
check("...a non-table, non-string is nil", mp.joinLines(nil) == nil)

-- 🚨 THE SHAPE THAT BIT: a reader answering with OBJECTS, not strings.
-- A bare table.concat over this throws, and the throw is inside a
-- dragging callback where nothing catches it.
reset() ; mp.show()
FILES["/m/obj.mp3"] = true
PB.url = { { url = "file:///m/obj.mp3" } }
drag("receive")
check("🚚 a pasteboard reader that answers with objects still lands the "
      .. "file — this is the drop that lit up blue and did nothing",
      #mp.queue == 1 and mp.queue[1].path == "/m/obj.mp3",
      #mp.queue .. " " .. tostring(mp.queue[1] and mp.queue[1].path))

-- a reader that throws must not end the drop
reset() ; mp.show()
FILES["/m/ok.mp3"] = true
PB.throw.url = true
PB.str = { "file:///m/ok.mp3" }
drag("receive")
check("🔒 a reader that THROWS is stepped over, and the next one answers",
      #mp.queue == 1 and mp.dropReader == "readString", tostring(mp.dropReader))

-- 🚨 AND A READER'S ERROR MESSAGE IS NOT A FILE. `select(2, pcall(f))` is
-- the result when f returns and the ERROR when it raises; a Lua error
-- begins with the chunk name, so from an absolute path it starts with a
-- slash and `pathsFromURIList` takes it as a plain-text drag. The reader
-- that FAILED would hand back its own traceback as a track to play — which
-- is 6.179.0's read-THREE-values rule, broken in new code, and caught only
-- because the gate runs this suite from an absolute path.
reset() ; mp.show()
PB.throw.url = true
-- A real Lua error reads "/Users/…/music_player.lua:612: …" — it BEGINS
-- with the chunk path. This says so outright rather than depending on how
-- the suite happened to be invoked.
PB.throwMsg = "/m/its-own-traceback.mp3:612: readURL blew up"
FILES["/m/its-own-traceback.mp3"] = true
drag("receive")
check("🚨 a reader that raises hands back NOTHING — never its own error "
      .. "message, which on a real Mac begins with a path and is taken "
      .. "for one", #mp.queue == 0 and mp.dropReader ~= "readURL",
      tostring(mp.dropReader) .. " / " .. #mp.queue)
PB.throwMsg = nil

-- the file-url reader, which is the type a Finder drag really carries
reset() ; mp.show()
FILES["/m/u.mp3"] = true
PB.uti = "file:///m/u.mp3"
drag("receive")
check("🚚 public.file-url is asked for BY NAME — it is the type a Finder "
      .. "drag actually carries", #mp.queue == 1 and mp.dropReader == "file-url",
      tostring(mp.dropReader))

-- every reader throwing is a NAMED state, never a silent nothing
reset() ; mp.show()
PB.throw = { url = true, uti = true, str = true, contents = true }
local okDrag = pcall(drag, "receive")
check("🔔 every reader throwing does not throw out of the callback",
      okDrag == true)
check("...and the card says a drop arrived and could not be read",
      #mp.refused == 1, #mp.refused)
-- 🧪 pcall around the harness's own call cannot prove the WRAP — it
-- catches the throw either way, and every READER is already guarded on
-- its own. What the outer guard exists for is everything AFTER them, so
-- that is what is made to throw (6.212.0: assert what only the branch
-- can do).
reset() ; mp.show()
local realTake = mp.takeDrop
mp.takeDrop = function() error("filing blew up") end
PB.url = { "file:///m/a.mp3" }
local okOuter = pcall(drag, "receive")
mp.takeDrop = realTake
check("🔒 a throw AFTER the readers does not escape the callback either",
      okOuter == true)
check("...and the guard records it, where a bare callback would record "
      .. "nothing at all", tostring(mp.dragSeen):find("threw", 1, true) ~= nil,
      tostring(mp.dragSeen))
check("...through the 🔔 door, so it is not a silence he has to notice",
      #DEGRADED > 0, table.concat(DEGRADED, " | "))

-- 🔎 and when nothing is readable, the report says what the drag CARRIED
reset() ; mp.show()
PB.types = { "public.tiff", "com.apple.pasteboard.promised-file-url" }
drag("receive")
check("🔎 a drop nothing could read NAMES THE TYPES it was carrying — "
      .. "without that the next report can only repeat 'it did not work'",
      tostring(mp.dropReader):find("public.tiff", 1, true) ~= nil,
      tostring(mp.dropReader))
local r18 = report()
check("...and the report carries it to him",
      r18:find("public.tiff", 1, true) ~= nil, r18)

-- ---- §19 a Finder drag hands back a reference, not a path -------------
-- 🆔 6.237.0, and LL's card is the whole artefact: "⚠️ .15194583 is not an
-- audio file this can play" over an empty queue. By 6.235.0 the read was
-- working — what it read was file:///.file/id=6571367.15194583, a FILE
-- REFERENCE URL, which names a file by volume and inode and carries no
-- name and no extension. This module took the inode for a file type.

check("🆔 a reference path is recognised",
      mp.isRefPath("/.file/id=6571367.15194583") == true)
check("...and an ordinary path is not",
      mp.isRefPath("/Users/lee/Music/a.mp3") == false)
check("...and neither is a nil or a name that merely mentions it",
      mp.isRefPath(nil) == false and mp.isRefPath("/m/.file-notes.mp3") == false)

-- 🔤 THE MESSAGE HE ACTUALLY SAW. A true sentence about a string that was
-- never a name is the one answer he cannot act on.
local refWhy = select(2, mp.playableFor("/.file/id=6571367.15194583"))
check("🔔 a reference names ITSELF in the refusal — not the inode as a "
      .. "file type, which is what the card said",
      refWhy:find("file reference", 1, true) ~= nil
      and refWhy:find("15194583", 1, true) == nil, refWhy)

-- 🧷 PURE, given the resolver
local asked = {}
local function fakeResolve(p)
    asked[#asked + 1] = p
    return ({ ["/.file/id=1.2"] = "/m/Real Name.mp3" })[p]
end
local rp, fixed, stuck = mp.resolveRefs({ "/.file/id=1.2", "/m/plain.mp3" },
                                        fakeResolve)
check("🔗 a reference is turned back into the file it points at",
      rp[1] == "/m/Real Name.mp3" and fixed == 1 and stuck == 0,
      table.concat(rp, " | "))
check("...an ordinary path is passed through untouched",
      rp[2] == "/m/plain.mp3")
check("...and is never handed to the resolver at all — a plain path has "
      .. "nothing to resolve and a bookmark costs a file read",
      #asked == 1 and asked[1] == "/.file/id=1.2", #asked)

-- 🚨 THE ANSWER realpath GIVES, AND WHY IT IS REFUSED. Libc's realpath
-- (stdlib/FreeBSD/realpath.c, checked in the source) replaces each
-- component with the real NAME from getattrlist, so it answers
-- "/.file/Max McNown - A Lot More Free.mp3" — the right name in a folder
-- that holds nothing. It even ends in .mp3, so a queue would fill with
-- rows that look perfect and cannot open.
local rp2, f2, s2 = mp.resolveRefs({ "/.file/id=1.2" }, function()
    return "/.file/Max McNown - A Lot More Free.mp3"
end)
check("🚨 an answer that is ITSELF a reference is refused, however much "
      .. "it looks like a file — this is realpath's answer",
      rp2[1] == "/.file/id=1.2" and f2 == 0 and s2 == 1, rp2[1])
local rp3, f3, s3 = mp.resolveRefs({ "/.file/id=1.2" }, function()
    return "Max.mp3"
end)
check("...and so is a relative one", rp3[1] == "/.file/id=1.2" and s3 == 1)
-- 🧪 pcall'd HERE so a missing guard fails a check instead of ending the
-- run with "0 failed" never printed (6.186.0).
local ok4, rp4, f4, s4 = pcall(mp.resolveRefs, { "/.file/id=1.2" }, function()
    error("resolving blew up")
end)
check("🔒 a resolver that THROWS keeps the path and does not escape — "
      .. "this runs inside a dragging callback",
      ok4 and rp4[1] == "/.file/id=1.2" and s4 == 1 and f4 == 0,
      tostring(ok4) .. " " .. tostring(rp4))

-- 🚚 LIVE, THROUGH THE DRAG
reset() ; mp.show()
FILES["/m/Max McNown - A Lot More Free.mp3"] = true
BOOKMARKS["/.file/id=6571367.15194583"] = "/m/Max McNown - A Lot More Free.mp3"
PB.url = { "file:///.file/id=6571367.15194583" }
drag("receive")
check("🚚 A DRAG THAT CARRIES ONLY A FILE REFERENCE NOW LANDS THE TRACK — "
      .. "LL's own drop, end to end",
      #mp.queue == 1 and mp.queue[1].path == "/m/Max McNown - A Lot More Free.mp3",
      #mp.queue .. " " .. tostring(mp.queue[1] and mp.queue[1].path))
check("...and it is named by its file, not by an inode",
      mp.queue[1] and mp.queue[1].title == "Max McNown - A Lot More Free",
      tostring(mp.queue[1] and mp.queue[1].title))

-- and the Mac that cannot resolve it says so in words he can act on
reset() ; mp.show()
NO_BOOKMARK = true
PB.url = { "file:///.file/id=6571367.15194583" }
drag("receive")
check("🔔 a reference this Mac cannot resolve is REFUSED BY NAME",
      #mp.refused == 1 and tostring(mp.refused[1].why):find("file reference",
      1, true) ~= nil, tostring(mp.refused[1] and mp.refused[1].why))
check("...and never as '.15194583 is not an audio file', which was true "
      .. "and useless", tostring(mp.refused[1].why):find("15194583", 1,
      true) == nil, tostring(mp.refused[1].why))
NO_BOOKMARK = false

-- 📁 the plain-path flavour is asked FIRST, so where macOS still offers it
-- nothing needs resolving at all
reset() ; mp.show()
FILES["/m/plain.mp3"] = true
PB.plist = { "/m/plain.mp3" }
PB.url = { "file:///.file/id=6571367.15194583" }
drag("receive")
check("📁 NSFilenamesPboardType is read first — real paths, no reference "
      .. "to resolve", #mp.queue == 1 and mp.queue[1].path == "/m/plain.mp3"
      and mp.dropReader == "filenames", tostring(mp.dropReader))

-- 🔑 and a plain path is NOT percent-decoded
reset() ; mp.show()
FILES["/m/50%25 off.mp3"] = true
PB.plist = { "/m/50%25 off.mp3" }
drag("receive")
check("🔑 a POSIX path keeps its %25 — the escapes belong to a URL, and "
      .. "decoding one here makes a path that is not there",
      #mp.queue == 1 and mp.queue[1].path == "/m/50%25 off.mp3",
      tostring(mp.queue[1] and mp.queue[1].path))

-- ...while a file:// URL still is
reset() ; mp.show()
FILES["/m/Ain't It.mp3"] = true
PB.url = { "file:///m/Ain%27t%20It.mp3" }
drag("receive")
check("🔑 ...and a file:// URL still has its escapes undone",
      #mp.queue == 1 and mp.queue[1].path == "/m/Ain't It.mp3",
      tostring(mp.queue[1] and mp.queue[1].path))

-- the report carries the state, both ways
reset() ; mp.show()
FILES["/m/r.mp3"] = true
BOOKMARKS["/.file/id=9.9"] = "/m/r.mp3"
PB.url = { "file:///.file/id=9.9" }
drag("receive")
local r19 = report()
check("🔎 the report says how many references were turned back into files",
      r19:find("1 file reference(s) turned back into files, 0", 1, true) ~= nil,
      r19:match("[^\n]*reference[^\n]*") or "no line")

-- 🔌 a Hammerspoon with no bookmark functions degrades, never throws
-- 🚨 A BOOKMARK THAT RAISES MUST NOT BECOME A TRACK. `select(2, pcall(f))`
-- is the error message when f raises, and a real Lua error begins with a
-- path — so a resolver written the short way hands its own traceback back
-- as an absolute path and the card plays it. 6.236.1's rule, in the new
-- code, closed at the point where the new code could break it.
reset() ; mp.show()
BOOKMARKS["/.file/id=7.7"] = "/m/r.mp3"
FILES["/m/r.mp3"], FILES["/m/its-own-traceback.mp3"] = true, true
BOOKMARK_THROW = true
PB.url = { "file:///.file/id=7.7" }
local okThrow = pcall(drag, "receive")
check("🚨 a bookmark read that RAISES resolves nothing — never its own "
      .. "error message, which begins with a path and would be taken for "
      .. "one", okThrow and #mp.queue == 0,
      tostring(okThrow) .. " " .. #mp.queue)
BOOKMARK_THROW = false

-- 🔌 a Hammerspoon with no hs.fs at all degrades, never throws
local realFs = hs.fs
hs.fs = nil
local okNoFs, gotNoFs = pcall(mp.refResolver, "/.file/id=1.2")
hs.fs = realFs
check("🔌 a Hammerspoon without hs.fs answers nothing and does NOT throw "
      .. "— this runs inside a dragging callback",
      okNoFs == true and gotNoFs == nil,
      tostring(okNoFs) .. " " .. tostring(gotNoFs))
local realToBookmark = hs.fs.pathToBookmark
hs.fs.pathToBookmark = nil
local r19b = report()
check("...and one without the bookmark functions is NAMED in the report, "
      .. "so a drop that fails there is answerable",
      r19b:find("pathToBookmark", 1, true) ~= nil)
hs.fs.pathToBookmark = realToBookmark

-- ---- §20 the card reopened empty over music that was playing ----------
-- 🪟 6.238.0. LL: "I was playing a song in the first screenshot but I closed
-- the window and it didn't show but then opened again it did." `view:html()`
-- returns before WebKit has parsed the document, so the draw pushed on the
-- next line finds no `draw` function and is dropped in SILENCE; the page then
-- runs its own draw(S) over the empty default. The clock kept landing —
-- the tick pushes one every half second — which is why his card showed a
-- full progress bar over "QUEUE EMPTY".

reset() ; mp.queue = { { path = "/m/a.mp3", title = "A" } }
mp.index, mp.playing = 1, true
JS = {}
mp.show()
check("🪟 a card just opened has NOT heard from its page yet",
      mp.pageReady == false)
check("...and the draw it pushed anyway is counted as EARLY — a push into "
      .. "a page that does not exist is dropped in silence, and must not "
      .. "read like one that landed",
      mp.draws.early >= 1 and mp.draws.landed == 0,
      mp.draws.early .. " early / " .. mp.draws.landed .. " landed")
local r20 = report()
check("...and the report says so rather than calling the card healthy",
      r20:find("NOT said it is ready", 1, true) ~= nil,
      r20:match("[^\n]*ready[^\n]*") or "no line")

-- the page speaks, and the card is drawn with what is actually playing
JS = {}
-- through the real bridge, the way the page sends it (6.203.0)
local okReady = post({ a = "ready" })
check("🪟 THE PAGE ASKS AND LUA ANSWERS — the queue is drawn again once "
      .. "the page exists", okReady and (function()
          for _, j in ipairs(JS) do
              if j:find("draw(", 1, true) and j:find('"A"', 1, true) then
                  return true
              end
          end
          return false
      end)(), table.concat(JS, " | "))
check("...and that draw is counted as LANDED",
      mp.pageReady == true and mp.draws.landed >= 1,
      tostring(mp.pageReady) .. " " .. mp.draws.landed)
local r20b = report()
check("...and the report changes with it",
      r20b:find("since the page said", 1, true) ~= nil)

-- 🧪 The page must say it LAST. Said before draw() is defined it proves
-- nothing, which is the whole bug one level up.
local html20 = mp.buildHtml()
check("🪟 the page posts 'ready' as the last thing its script does",
      (function()
          local rd = html20:find("say({a:'ready'})", 1, true)
          local dr = html20:find("\ndraw(S);", 1, true)
          return rd ~= nil and dr ~= nil and rd > dr
      end)(), tostring(html20:find("say({a:'ready'})", 1, true)))

-- 🔒 a reopened card starts the count again, or yesterday's numbers answer
-- today's question
mp.hide() ; JS = {} ; mp.show()
check("🔒 reopening the card resets the handshake and the counts",
      mp.pageReady == false and mp.draws.landed == 0,
      tostring(mp.pageReady) .. " " .. mp.draws.landed)

-- ---- §21 ← → seek ------------------------------------------------------
-- ⏪ 6.239.0, LL: "I need an arrow keys left/right as seek". v1 shipped
-- without it on his own answers; this is him asking for it.

check("⏪ forward moves by the step", mp.seekTo(10, 5, 200) == 15)
check("...and back", mp.seekTo(10, -5, 200) == 5)
check("🔒 never below zero — and it SAYS which", (function()
        local at, why = mp.seekTo(2, -5, 200)
        return at == 0 and why:find("start", 1, true) ~= nil
      end)())
check("...and pressing ← again at the start says so rather than nothing",
      select(2, mp.seekTo(0, -5, 200)):find("already", 1, true) ~= nil,
      select(2, mp.seekTo(0, -5, 200)))
check("🔒 never past the end", (function()
        local at, why = mp.seekTo(198, 30, 200)
        return at == 200 and why:find("end", 1, true) ~= nil
      end)())
-- 🔔 duration 0 is "macOS did not answer", NOT a zero-length track. The
-- difference decides whether → jumps into silence with no way back.
check("🔔 a track whose length is unknown does not seek FORWARD, and the "
      .. "answer names why", (function()
        local at, why = mp.seekTo(10, 5, 0)
        return at == 10 and why:find("not known", 1, true) ~= nil
      end)(), select(2, mp.seekTo(10, 5, 0)))
check("...but ← still works there — going back is always safe",
      mp.seekTo(10, -5, 0) == 5)

-- live, through the page's own key
reset() ; mp.show()
FILES["/m/a.mp3"] = true
mp.queue = { { path = "/m/a.mp3", title = "A" } }
mp.playAt(1, "test")
lastSound().duration = 200
mp.duration = 200
lastSound().t = 30
post({ a = "seek", d = 5 })
check("⏪ → SEEKS THE PLAYING TRACK — through the page's own message",
      lastSound().t == 35 and mp.elapsed == 35,
      tostring(lastSound().t) .. " / " .. tostring(mp.elapsed))
check("...and the sound was really told to move, not just the clock",
      (lastSound().seeks or 0) >= 1, tostring(lastSound().seeks))
-- 🚨 THE BELT CLOCK IS RE-ANCHORED. mp.startedAt is what the tick falls
-- back on when the sound will not answer; left alone it drags the time
-- straight back to where it was on the next tick.
check("🚨 the fallback clock moves with the seek — or the next tick undoes "
      .. "it", math.abs((os.time() - mp.startedAt) - 35) <= 1,
      tostring(os.time() - mp.startedAt))
post({ a = "seek", d = -5 })
check("⏪ ← seeks back", lastSound().t == 30, tostring(lastSound().t))
check("...and the report counts them",
      report():find("2 this session", 1, true) ~= nil,
      report():match("[^\n]*seek[^\n]*") or "no line")

-- nothing playing is a SENTENCE, never a silence
reset() ; mp.show()
local okSeek = mp.seekBy(5)
check("🔔 seeking with nothing playing says so and changes nothing",
      okSeek == false and tostring(mp.lastWhy):find("nothing is playing",
      1, true) ~= nil, tostring(mp.lastWhy))

-- a Mac that refuses to move the position takes the 🔔 door
reset() ; mp.show()
FILES["/m/b.mp3"] = true
mp.queue = { { path = "/m/b.mp3", title = "B" } }
mp.playAt(1, "test")
mp.duration = 200
DEGRADED = {}
NO_SEEK = true
local okRefuse = pcall(mp.seekBy, 5)
NO_SEEK = false
check("🔔 a sound that refuses to seek does not throw, and is NAMED",
      okRefuse == true and #DEGRADED > 0, table.concat(DEGRADED, " | "))

-- the page sends it, and ⇧ is the big step
local html21 = mp.buildHtml()
check("⏪ the page binds ← and → and nothing else moved",
      html21:find("a:'seek'", 1, true) ~= nil
      and html21:find("ArrowLeft", 1, true) ~= nil)
check("...⇧ asks for the bigger step",
      html21:find("shiftKey ? BIGSTEP : STEP", 1, true) ~= nil)
-- 🧪 The numbers must FOLLOW the config. Asserting the shipped defaults
-- passes just as happily when they are typed into the page as literals —
-- so the config is moved and the page has to move with it.
mp.seekStep, mp.seekBigStep = 9, 45
local html21b = mp.buildHtml()
mp.seekStep, mp.seekBigStep = 5, 30
check("...and the steps are the CONFIG's numbers, not literals in the page",
      html21b:find("var STEP = 9, BIGSTEP = 45;", 1, true) ~= nil,
      html21b:match("var STEP[^\n]*") or "no line")
check("...the footer teaches the key, because a shortcut nobody is told "
      .. "about is not a feature", html21:find("seek", 1, true) ~= nil)

-- 🚨 The section asserts its own check count (6.186.0): a throw would
-- delete every check after it while the run still said "0 failed".
check("🚨 the suite asserted every check it was written to make",
      (pass + fail) >= 225, pass + fail)

os.execute("true")

-- =====================================================================
out("\n=== ⌨️ THE CARD TAKES THE KEYBOARD (6.251.0) ===\n")
-- =====================================================================
-- LL: "I have to click on it to make it the focus to use the space bar to
-- play/pause… even if I hide it and bring it back, it's not the active
-- window." bringToFront RAISES a window; it does not make it KEY, and
-- only a key window is handed the keyboard (6.225.0, on the OCR box).
do
    local before = pass + fail
    local okSection, secErr = pcall(function()

    local function fireFocusTimers()
        for _, t in ipairs(TIMERS) do
            if t.every and not t.stopped and t.secs == mp.focusEvery then t.fn() end
        end
    end

    -- ---- the healthy Mac -----------------------------------------------
    reset()
    FOCUSED_WIN, NO_HSWINDOW, REFUSE_FOCUS = nil, false, false
    mp.show()
    check("⌨️ opening the card takes the keyboard — no click needed",
          mp.cardIsKey() == true, mp.focus.why)
    check("...and it says so, naming the try it landed on",
          tostring(mp.focus.why):find("took the keys", 1, true) ~= nil,
          mp.focus.why)
    -- 🚨 THE TIMER MUST BE GONE, not merely "nil or stopped": a chase
    -- that got the keys and kept ticking is a held timer nobody can see.
    -- The first version of this check read "nil OR stopped" and passed
    -- under the mutation, because the healthy path never armed one it had
    -- to stop. It asserts the object is gone now.
    check("...and the chase is torn down the moment it has them",
          mp.focusTimer == nil, tostring(mp.focusTimer))
    check("...and no focus timer is left ticking anywhere",
          (function()
              for _, t in ipairs(TIMERS) do
                  if t.every and t.secs == mp.focusEvery and not t.stopped then
                      return false
                  end
              end
              return true
          end)())

    -- ---- a window macOS will not make key --------------------------------
    reset()
    FOCUSED_WIN, REFUSE_FOCUS = nil, true
    mp.show()
    for _ = 1, 8 do fireFocusTimers() end
    REFUSE_FOCUS = false
    check("a window macOS refuses to focus is BOUNDED, not chased for ever",
          mp.focus.tries <= mp.focusTries, mp.focus.tries)
    check("...and it says to click the card once rather than failing silently",
          tostring(mp.focus.why):find("click the card once", 1, true) ~= nil,
          mp.focus.why)
    check("...and the timer is stopped when it gives up",
          mp.focusTimer == nil or mp.focusTimer.stopped == true)

    -- 🚨 AND A CHASE STILL RUNNING WHEN THE CARD CLOSES. This is the case
    -- the first "closing stops the chase" check could not reach: on a
    -- healthy Mac the chase is over before hide() is ever called, so the
    -- mutation that deletes stopFocusChase() from hide() passed. A window
    -- that will not take focus keeps it running.
    reset()
    FOCUSED_WIN, REFUSE_FOCUS = nil, true
    mp.show()
    local chasing = nil
    for _, t in ipairs(TIMERS) do
        if t.every and t.secs == mp.focusEvery and not t.stopped then chasing = t end
    end
    check("a card that has not got the keys yet is still chasing them",
          chasing ~= nil)
    mp.hide()
    REFUSE_FOCUS = false
    check("🚨 closing the card stops a chase that was STILL RUNNING",
          chasing == nil or chasing.stopped == true,
          chasing and tostring(chasing.stopped))

    -- ---- a build with no hswindow ----------------------------------------
    reset()
    FOCUSED_WIN, NO_HSWINDOW = nil, true
    local okShow = pcall(function() return mp.show() end)
    NO_HSWINDOW = false
    check("a build that cannot name the window does not throw, and the card "
          .. "still opens", okShow and mp.webview ~= nil)
    -- 🚨 RETRYING CANNOT MAKE KEY A WINDOW THAT CANNOT BE NAMED.
    check("...it asks ONCE and stops, rather than four identical failures",
          mp.focus.tries <= 1
          and tostring(mp.focus.why):find("cannot focus", 1, true) ~= nil,
          mp.focus.tries .. " — " .. tostring(mp.focus.why))

    -- ---- the off switch ---------------------------------------------------
    reset()
    FOCUSED_WIN = nil
    mp.takeKeyboard = false
    mp.show()
    check("takeKeyboard = false leaves the keyboard where it was",
          mp.cardIsKey() == false
          and tostring(mp.focus.why):find("takeKeyboard", 1, true) ~= nil,
          mp.focus.why)
    check("...and no focus timer is left running",
          mp.focusTimer == nil or mp.focusTimer.stopped == true)
    check("...and the report says so rather than looking like a failure",
          _G.musicReport():find("off (takeKeyboard)", 1, true) ~= nil)
    mp.takeKeyboard = true

    -- ---- closing the card ------------------------------------------------
    reset()
    FOCUSED_WIN = nil
    mp.show()
    mp.hide()
    check("closing the card stops the chase — a timer outliving its window "
          .. "is 6.196.1's shape",
          mp.focusTimer == nil or mp.focusTimer.stopped == true)

    -- ---- the report's three states ---------------------------------------
    reset()
    FOCUSED_WIN = nil
    check("the report says 'not asked' before the card has ever opened",
          _G.musicReport():find("not asked", 1, true) ~= nil)
    mp.show()
    local r = _G.musicReport()
    check("...and names the state once it has",
          r:find("keyboard", 1, true) ~= nil
          and r:find("the card has the keys", 1, true) ~= nil)
    -- 🚨 THE COST IS NAMED, because it is the answer to a DIFFERENT report
    -- of his ("the Hammerspoon console jumps to the front").
    check("...and says what taking the keys costs",
          r:find("ACTIVATES Hammerspoon", 1, true) ~= nil)

    end)
    check("§6.251.0 ran to the end — a throw here deletes the checks after it",
          okSection == true, secErr)
    local ran = (pass + fail) - before
    check("§6.251.0 ran all of its checks (" .. ran .. " of 14+)", ran >= 14, ran)
end

realPrint(table.concat(PRINTED, "\n"))
out("\n")
-- =====================================================================
-- §6.272.0 — 🗑 FORGETTING A TRACK FROM THE HISTORY
-- =====================================================================
-- LL: "did you make it so I could delete entries from my music history
-- list? … I don't wanna have to ask a second time or third time or
-- fourth time wondering if it's there." He could not: ⌫ took a track out
-- of the QUEUE and a history row only ever PLAYED. `mp.forgetHistory` is
-- PURE, so every edge is proven here with no Mac and no store.
do
    local H = {
        { path = "/m/a.mp3", title = "a", at = 100 },
        { path = "/m/b.mp3", title = "b", at = 90 },
        { path = "/m/c.mp3", title = "c", at = 80 },
    }
    local out1, gone1 = mp.forgetHistory(H, "/m/b.mp3")
    check("🗑 forgetting a track removes exactly that row",
          gone1 == 1 and #out1 == 2
          and out1[1].path == "/m/a.mp3" and out1[2].path == "/m/c.mp3",
          tostring(gone1) .. " gone, " .. #out1 .. " left")
    check("🗑 ...and the ORIGINAL list is untouched — it answers a new one, "
          .. "so a refused save cannot half-apply a removal",
          #H == 3 and H[2].path == "/m/b.mp3", #H)

    -- 🔑 BY PATH, NEVER BY INDEX (6.186.0). The page draws 40 rows of a
    -- store holding up to 400 and a redraw renumbers every one of them,
    -- so an index would delete a DIFFERENT track than the one clicked.
    local shifted = { { path = "/m/z.mp3", title = "z", at = 101 } }
    for _, r in ipairs(H) do shifted[#shifted + 1] = r end
    local out2, gone2 = mp.forgetHistory(shifted, "/m/b.mp3")
    check("🗑 a row that has MOVED is still the row that goes — the path "
          .. "names the track, the number names a position",
          gone2 == 1 and #out2 == 3
          and out2[1].path == "/m/z.mp3" and out2[2].path == "/m/a.mp3"
          and out2[3].path == "/m/c.mp3")

    local out3, gone3 = mp.forgetHistory(H, "/m/nope.mp3")
    check("🗑 a path that is not there removes nothing and says so",
          gone3 == 0 and #out3 == 3)
    local out4, gone4 = mp.forgetHistory(H, "")
    check("🗑 an EMPTY path is refused rather than matching a row with no "
          .. "path — a blank message must never empty the list",
          gone4 == 0 and #out4 == 3)
    local out5, gone5 = mp.forgetHistory(H, nil)
    check("🗑 nil is refused too, and does not throw", gone5 == 0 and #out5 == 3)
    local out6, gone6 = mp.forgetHistory(nil, "/m/a.mp3")
    check("🗑 no list at all answers an empty one rather than indexing a nil",
          type(out6) == "table" and #out6 == 0 and gone6 == 0)

    -- 6.199.0's forget rule: leaving a duplicate behind after a command
    -- that said it removed the track is worse than not removing it.
    local dupes = {
        { path = "/m/d.mp3", title = "d", at = 70 },
        { path = "/m/e.mp3", title = "e", at = 60 },
        { path = "/m/d.mp3", title = "d", at = 50 },
    }
    local out7, gone7 = mp.forgetHistory(dupes, "/m/d.mp3")
    check("🗑 EVERY matching row goes, not just the first — a store written "
          .. "by an older build can hold two rows for one file",
          gone7 == 2 and #out7 == 1 and out7[1].path == "/m/e.mp3")

    -- a row that is not a table must not take the whole removal down
    local messy = { { path = "/m/a.mp3" }, "junk", { path = "/m/b.mp3" } }
    local out8, gone8 = mp.forgetHistory(messy, "/m/a.mp3")
    check("🗑 a malformed row is carried through rather than throwing",
          gone8 == 1 and #out8 == 2)
end

-- =====================================================================
out("\n⏯ 6.289.0 — THE KEYBOARD'S OWN PLAY/PAUSE KEY DRIVES THIS PLAYER\n")
-- =====================================================================
-- LL: "Pressing play/pause doesn't work. But volume keys do." Those two
-- sentences are about the same row of keys — the volume keys are macOS's
-- and work everywhere, and F8 was going wherever macOS thought the music
-- was, which is not this card.
do
    local n = pass + fail
    reset()

    -- ---- the verdict is PURE -------------------------------------------
    -- ⏯ 6.309.0 — the signature gained ON SCREEN, and it sits in front
    -- of the queue because it is the gate LL actually asked for. These
    -- rows MOVED rather than being deleted (6.248.0): what they prove is
    -- unchanged — the volume keys are never ours, an unknown key is
    -- never ours, the switch is real — and only the call shape moved.
    local V = mp.mediaVerdict
    check("mp.mediaVerdict is pure and reachable", type(V) == "function")
    check("⏯ open with a queue is TAKEN", V("PLAY", true, true, true) == "take")
    check("⏭ open with a queue is TAKEN", V("FAST", true, true, true) == "take")
    check("⏮ open with a queue is TAKEN", V("REWIND", true, true, true) == "take")

    -- 🚨 6.309.0 — LL's OWN RULE, AND THE CHECK THAT BITES. Closing the
    -- card deliberately does not stop the sound, so on 6.289.0 a CLOSED
    -- card went on holding ⏯ for as long as a queue survived it. He
    -- reported it twice; the second time: "You're introducing a fix that
    -- is not real." The queue is not the gate — the card being on screen
    -- is, and the queue only stops an open card eating a key it cannot
    -- act on. Both must hold, which is the narrow direction.
    check("🚨 ⏯ with the card CLOSED is passed through, queue or not",
          V("PLAY", false, true, true) == "pass", V("PLAY", false, true, true))
    check("…and it says the card is closed, not something about a queue",
          (select(2, V("PLAY", false, true, true)) or ""):find("closed", 1, true) ~= nil,
          select(2, V("PLAY", false, true, true)))
    check("⏭ and ⏮ are closed-card-passed too — one rule, every key",
          V("FAST", false, true, true) == "pass"
          and V("REWIND", false, true, true) == "pass")
    check("🚨 ⏯ OPEN with NOTHING QUEUED is passed through — an open card"
          .. " must not eat a key it cannot act on",
          V("PLAY", true, false, true) == "pass", V("PLAY", true, false, true))
    check("…and says why", select(2, V("PLAY", true, false, true)):find("macOS", 1, true) ~= nil)
    check("the volume keys are never ours", V("SOUND_UP", true, true, true) == "pass")
    check("brightness, eject, anything else — never ours",
          V("BRIGHTNESS_UP", true, true, true) == "pass"
          and V("EJECT", true, true, true) == "pass")
    check("switched off, nothing is taken even open with a queue",
          V("PLAY", true, true, false) == "pass")
    check("a nil key is not a media key", V(nil, true, true, true) == "pass")
    check("every answer carries a reason",
          select(2, V("PLAY", true, true, true)) ~= nil
          and select(2, V("SOUND_UP", true, true, true)) ~= nil)

    -- 🔑 ONE DOOR, TWO ROUTES (6.231.0). 6.291.0 exists because the two
    -- routes for one physical key nearly disagreed; this asserts they
    -- ask the SAME function, so a rule changed in one cannot miss the
    -- other. The mutation that gives fnKeyVerdict its own copy of the
    -- rule passes every row above and fails this one.
    do
        local MT = mp.mayTake
        check("mp.mayTake is the one gate and is pure", type(MT) == "function")
        for _, st in ipairs({ { false, false }, { false, true },
                              { true, false }, { true, true } }) do
            local a, wa = MT(st[1], st[2], true)
            local b, wb = V("PLAY", st[1], st[2], true)
            local c, wc = mp.fnKeyVerdict(100, { [100] = "PLAY" }, {},
                                          st[1], st[2], true)
            check("⏯ on screen=" .. tostring(st[1]) .. " queue=" .. tostring(st[2])
                  .. ": both routes give the same verdict AND the same reason",
                  a == b and b == c and wa == wb and wb == wc,
                  tostring(a) .. "/" .. tostring(b) .. "/" .. tostring(c))
        end
    end

    -- 👁 mp.onScreen reads the WEBVIEW, not a flag beside it: mp.show
    -- creates it and mp.hide deletes it, so there is nothing to fall out
    -- of step with. A second boolean is how a card reports itself open
    -- after macOS refused to draw it.
    do
        local was = mp.webview
        mp.webview = nil
        check("mp.onScreen() is false with no card", mp.onScreen() == false)
        mp.webview = { fake = true }
        check("mp.onScreen() is true once the card exists", mp.onScreen() == true)
        mp.webview = was
    end

    -- ---- the tap really runs -------------------------------------------
    TAPS = {}
    mp.stopMediaTap()
    mp.mediaKeys = true
    local ok = mp.startMediaTap()
    -- 🚨 6.291.0 — TWO TAPS NOW, and these two checks MOVED rather than
    -- being deleted: they were written when there was one route, and
    -- asserting the literal 1 would have gone red with nothing to say
    -- about the change it exists to prove (6.248.0). What they assert is
    -- the RULE — every route this module claims is created AND started.
    check("both routes are created AND started, not merely created",
          ok == true and #TAPS == 2
          and TAPS[1].running == true and TAPS[2].running == true, #TAPS)
    check("…the media route watches systemDefined and nothing else",
          TAPS[1].types[1] == 14 and #TAPS[1].types == 1)
    check("…the function-key route watches keyDown and nothing else",
          TAPS[2].types[1] == 10 and #TAPS[2].types == 1, TAPS[2].types[1])
    check("…and BOTH are HELD, in their own slots — one global holding"
          .. " two taps drops the first (6.196.1)",
          mp.mediaTap ~= nil and mp.fnTap ~= nil and mp.mediaTap ~= mp.fnTap)
    local again = mp.startMediaTap()
    check("starting twice does not stack another pair",
          again == false and #TAPS == 2)

    -- ---- driving it -----------------------------------------------------
    local function press(keyName, opts)
        opts = opts or {}
        local ev = { systemKey = function() return {
            key = keyName, down = (opts.down ~= false),
            ["repeat"] = opts.rep or false } end }
        return mp.onMediaKey(ev)
    end

    mp.queue = {}
    mp.resetMedia()
    check("🚨 with an EMPTY queue ⏯ is not eaten", press("PLAY") == false)
    check("…and it is counted as passed, so the report can say so",
          mp.media.passed == 1 and mp.media.taken == 0)

    FILES["/m/a.mp3"], DURATION["/m/a.mp3"] = true, 100
    FILES["/m/b.mp3"], DURATION["/m/b.mp3"] = true, 100
    mp.takeDrop({ "/m/a.mp3", "/m/b.mp3" })
    mp.resetMedia()
    local wasPlaying = mp.playing
    check("(fixture) something is playing", wasPlaying == true and #mp.queue == 2)

    -- 🚨 6.309.0 — DRIVEN THROUGH THE TAP, not just the pure function.
    -- 6.264.0's rule: proving a decision function is not proving that
    -- anything CALLS it with the values that matter. With a full queue
    -- and NO CARD the key must reach macOS — which is LL's report, and
    -- on 6.289.0 this press returned true.
    mp.webview = nil
    check("🚨 LL's bug: a full queue with the card CLOSED does NOT eat ⏯",
          press("PLAY") == false)
    check("…and it did not touch the player either",
          mp.playing == wasPlaying)
    check("…and the reason names the card, so the report can say so",
          tostring(mp.media.last):find("closed", 1, true) ~= nil, mp.media.last)
    mp.resetMedia()

    mp.webview = { frame = function() return { x = 0, y = 0, w = 420, h = 320 } end }
    check("⏯ is EATEN when the card is open with a queue — macOS must not act too",
          press("PLAY") == true)
    check("…and it really paused the player", mp.playing == false)
    check("⏯ again resumes", press("PLAY") == true and mp.playing == true)
    check("…and both were counted as taken", mp.media.taken == 2, mp.media.taken)

    local at = mp.index
    check("⏭ steps forward", press("FAST") == true and mp.index ~= at)
    check("⏮ steps back", press("REWIND") == true and mp.index == at)

    -- 🚨 A KEY-UP AND AN AUTOREPEAT ARE NOT A PRESS. Acting on the release
    -- would toggle twice per press, which reads as "the key does nothing".
    local before = mp.media.taken
    check("🚨 a key UP is ignored", press("PLAY", { down = false }) == false
          and mp.media.taken == before)
    check("🚨 an autorepeat is ignored", press("PLAY", { rep = true }) == false
          and mp.media.taken == before)
    check("an event that is not a system key at all is ignored, never thrown",
          mp.onMediaKey({ systemKey = function() return nil end }) == false)
    check("an event whose systemKey THROWS is ignored, never thrown",
          mp.onMediaKey({ systemKey = function() error("no") end }) == false)

    -- 🚨 EVERY TAP IN THIS CONFIG STANDS DOWN WHEN PAUSED (6.152.0).
    _G.hsPaused = true
    local b2 = mp.media.taken
    check("🚨 ⇪⇧Esc pause stands the tap down", press("PLAY") == false
          and mp.media.taken == b2)
    _G.hsPaused = false

    -- ---- one door for a step (6.231.0) ----------------------------------
    check("mp.step is the ONE way a track is stepped, and the page's ⏭ takes it",
          type(mp.step) == "function")
    do
        local fh = assert(realOpen(HS .. "/modules/music_player.lua"))
        local src = fh:read("a"); fh:close()
        local code = {}
        for line in (src .. "\n"):gmatch("([^\n]*)\n") do
            code[#code + 1] = (line:gsub("%-%-.*$", ""))
        end
        code = table.concat(code, "\n")
        check("🚨 SOURCE: the page's next/prev go through mp.step, so the "
              .. "buttons and the keys cannot drift apart",
              code:find('if a == "next"   then mp.step%(1%)') ~= nil
              and code:find('if a == "prev"   then mp.step%(%-1%)') ~= nil)
        check("🚨 SOURCE: the tap stands down while paused, like every tap here",
              code:find("function mp%.onMediaKey.-_G%.hsPaused") ~= nil)
    end

    -- ---- the degrades ---------------------------------------------------
    mp.stopMediaTap()
    check("stopping really stops it", mp.mediaTap == nil)
    TAP_REFUSES = true
    local ok2, why2 = mp.startMediaTap()
    check("🛟 a Mac that REFUSES the tap says so and does not throw",
          ok2 == false and tostring(why2):find("refused", 1, true) ~= nil, why2)
    check("…and leaves no half-made tap behind", mp.mediaTap == nil)
    TAP_REFUSES = false
    -- 🚨 AND THE OTHER SHAPE: created and wired, and then :start() refuses.
    -- Here mp.mediaTap HAS been assigned, so the nil-out is what stops a
    -- dead tap being held as if it were live — a later start would see it
    -- and answer "not wanted" for the rest of the session (6.265.0).
    mp.stopMediaTap()
    TAP_START_REFUSES = true
    local ok2b, why2b = mp.startMediaTap()
    check("🛟 a tap that is created and then REFUSES TO START also says so",
          ok2b == false and tostring(why2b):find("refused", 1, true) ~= nil, why2b)
    check("🚨 …and is not held as if it were live, or every later start "
          .. "would answer 'not wanted' for the rest of the session",
          mp.mediaTap == nil)
    TAP_START_REFUSES = false
    local realTap = hs.eventtap
    hs.eventtap = nil
    local ok3, why3 = mp.startMediaTap()
    check("🛟 a Hammerspoon with no event taps says so", ok3 == false
          and tostring(why3):find("event taps", 1, true) ~= nil, why3)
    hs.eventtap = realTap
    mp.mediaKeys = false
    local ok4, why4 = mp.startMediaTap()
    check("switched off, nothing is created at all",
          ok4 == false and why4 == "not wanted" and mp.mediaTap == nil)
    mp.mediaKeys = true
    mp.startMediaTap()

    -- ---- the report ------------------------------------------------------
    PRINTED = {}
    _G.musicReport()
    local rep = table.concat(PRINTED, "\n")
    check("🔎 the report says the keys are being watched, and counts taken "
          .. "apart from passed — 'the play key does nothing' reads the same "
          .. "in three states and they need different answers",
          rep:find("⏯ keys", 1, true) and rep:find("taken", 1, true)
          and rep:find("passed through to macOS", 1, true), rep)
    -- ⏯ 6.309.0 — THE LINE SAYS WHAT THE KEY WOULD DO RIGHT NOW, and it
    -- is mp.mayTake's OWN words rather than a sentence retyped beside
    -- the rule (6.276.0). The check moves the STATE and requires the
    -- line to follow — asserting the shipped wording passes with the
    -- line hard-coded (6.239.0).
    do
        local wasW, wasQ = mp.webview, mp.queue
        mp.webview, mp.queue = nil, { "x" }
        PRINTED = {}; _G.musicReport()
        local closed = table.concat(PRINTED, "\n")
        mp.webview = { frame = function() return { x = 0, y = 0, w = 420, h = 320 } end }
        PRINTED = {}; _G.musicReport()
        local open = table.concat(PRINTED, "\n")
        mp.webview, mp.queue = wasW, wasQ
        check("6.309.0: the report names the live verdict, and it CHANGES "
              .. "with the card — closed says so",
              closed:find("right now", 1, true)
              and closed:find("the card is closed", 1, true) ~= nil, closed)
        check("…and open with a queue says it is holding the key",
              open:find("right now", 1, true)
              and open:find("holding a queue", 1, true) ~= nil, open)
    end
    mp.stopMediaTap()
    PRINTED = {}
    _G.musicReport()
    check("…and a WANTED tap that is not running reads as a ⚠️, not as off",
          table.concat(PRINTED, "\n"):find("WANTED but not running", 1, true) ~= nil,
          table.concat(PRINTED, "\n"))
    mp.mediaKeys = false
    PRINTED = {}
    _G.musicReport()
    check("…and OFF-by-settings reads differently again, with the line back",
          table.concat(PRINTED, "\n"):find("mediaKeys = false", 1, true) ~= nil)
    mp.mediaKeys = true
    mp.startMediaTap()

    -- 6.186.0 — a section that can throw asserts its own check count, or
    -- a raise deletes every check after it while the run still says
    -- "0 failed". 43 → 58 in 6.309.0: the closed-card rows, the
    -- one-door-two-routes join, mp.onScreen and the live report line.
    check("the 6.289.0 / 6.309.0 block ran every one of its checks",
          (pass + fail) - n == 58, (pass + fail) - n)
end

-- =====================================================================
out("\n⌨️ 6.291.0 — F8 ARRIVES BY TWO ROUTES AND ONLY ONE WAS WATCHED\n")
-- =====================================================================
-- LL, asked which key he meant: "It's the F8 Key." On an Apple keyboard
-- F7 · F8 · F9 ARE ⏮ · ⏯ · ⏭, and WHICH event macOS sends for that one
-- physical key depends on a System Setting: an NSSystemDefined media key
-- with "Use F1, F2… as standard function keys" OFF, and a plain keyDown
-- carrying keycode 100 with it ON. 6.289.0 watched only the first, and
-- its report could not tell the second apart from "he never pressed it".
do
    local n = pass + fail
    reset()

    -- ---- the verdict is PURE, and the codes are an ARGUMENT ------------
    -- 6.239.0's rule: the gate moves the map under the rule, so a check
    -- cannot pass by asserting the same literal the code was typed with.
    local FV = mp.fnKeyVerdict
    local CODES = { [98] = "REWIND", [100] = "PLAY", [101] = "FAST" }
    check("mp.fnKeyVerdict is pure and reachable", type(FV) == "function")
    check("F8 with a queue is TAKEN", FV(100, CODES, {}, true, true, true) == "take")
    check("…and it answers WHICH action, so one function serves both routes",
          select(3, FV(100, CODES, {}, true, true, true)) == "PLAY")
    check("F7 is ⏮ and F9 is ⏭",
          select(3, FV(98, CODES, {}, true, true, true)) == "REWIND"
          and select(3, FV(101, CODES, {}, true, true, true)) == "FAST")
    -- 🚨 THE RULE THAT PROTECTS EVERY OTHER APP, twice over.
    check("🚨 F8 with NOTHING QUEUED is passed through",
          FV(100, CODES, {}, true, false, true) == "pass")
    check("🚨 ⌘F8 is NEVER ours — that chord belongs to the app",
          FV(100, CODES, { cmd = true }, true, true, true) == "pass")
    check("🚨 ⌥F8, ⌃F8 and ⇧F8 likewise",
          FV(100, CODES, { alt = true }, true,   true, true) == "pass"
          and FV(100, CODES, { ctrl = true }, true,  true, true) == "pass"
          and FV(100, CODES, { shift = true }, true, true, true) == "pass")
    -- 🔎 fn is IGNORED on purpose: macOS sets the function-key mask on
    -- F1–F12 under BOTH settings, so testing it would kill the feature
    -- under one of them and which is which is not knowable from here.
    check("fn alone does NOT disqualify a press — that decision is stated",
          FV(100, CODES, { fn = true }, true, true, true) == "take")
    check("F5 is not a key this player answers",
          FV(96, CODES, {}, true, true, true) == "pass")
    check("switched off, nothing is taken", FV(100, CODES, {}, true, true, false) == "pass")
    check("a nil keycode is not a key", FV(nil, CODES, {}, true, true, true) == "pass")
    check("every answer carries a reason",
          select(2, FV(100, CODES, {}, true, true, true)) ~= nil
          and select(2, FV(100, CODES, {}, true, false, true)) ~= nil)

    -- ---- driving the REAL tap, not the pure function -------------------
    -- 6.264.0's rule: proving a pure decision function is not proving
    -- that anything CALLS it with the values that matter.
    TAPS = {}
    mp.stopMediaTap()
    mp.fnCodesCache = nil
    mp.mediaKeys = true
    mp.startMediaTap()
    local fnFire = TAPS[2] and TAPS[2].fn
    check("the function-key route has a callback wired", type(fnFire) == "function")

    -- 6.309.0 — the card is on screen for this block; the closed case has
    -- its own rows below, driven through this same helper.
    mp.webview = { frame = function() return { x = 0, y = 0, w = 420, h = 320 } end }
    local function fkey(code, opts)
        opts = opts or {}
        return fnFire({
            getKeyCode = function() return code end,
            getFlags   = function() return opts.flags or {} end,
            getProperty = function() return opts.rep and 1 or 0 end,
        })
    end

    FILES["/m/a.mp3"], DURATION["/m/a.mp3"] = true, 100
    FILES["/m/b.mp3"], DURATION["/m/b.mp3"] = true, 100
    mp.takeDrop({ "/m/a.mp3", "/m/b.mp3" })
    mp.resetMedia()
    check("(fixture) something is playing", mp.playing == true and #mp.queue == 2)

    check("⌨️ a bare F8 is EATEN when there is a queue", fkey(100) == true)
    check("…and it really paused the player", mp.playing == false)
    check("…and it was counted on the FUNCTION-KEY route, not the media one",
          mp.media.viaFnKey == 1 and mp.media.viaMedia == 0, mp.media.viaFnKey)
    check("⌨️ F9 steps forward", (function()
              local at = mp.index ; return fkey(101) == true and mp.index ~= at end)())
    check("⌨️ F7 steps back", (function()
              local at = mp.index ; return fkey(98) == true and mp.index ~= at end)())

    -- 🚨 THE ONE THAT PROTECTS HIS OTHER APPS — the check that bites.
    mp.resetMedia()
    check("🚨 ⌘F8 is passed straight through", fkey(100, { flags = { cmd = true } }) == false)
    check("🚨 and it is counted as PASSED, not silently dropped",
          mp.media.passed == 1 and mp.media.taken == 0)
    local held = mp.queue
    mp.queue = {}
    mp.resetMedia()
    check("🚨 with an empty queue F8 goes to macOS", fkey(100) == false)
    mp.queue = held

    -- 🔎 SEEN IS COUNTED EVEN WHEN PASSED — this is the whole diagnosis,
    -- and the number 6.289.0's report could not produce.
    check("⌨️ every F7/F8/F9 arrival is counted, acted on or not",
          mp.media.fnSeen == 1, mp.media.fnSeen)
    mp.resetMedia()
    check("…and a key that is NOT the media row is not counted at all",
          fkey(96) == false and mp.media.fnSeen == 0)

    -- an autorepeat is not a press (holding ⏯ must not toggle forty times)
    mp.resetMedia()
    check("⌨️ an autorepeat is not a press",
          fkey(100, { rep = true }) == false and mp.media.fnSeen == 0)

    -- the pause switch, which every tap in this config answers (6.152.0)
    mp.resetMedia()
    _G.hsPaused = true
    check("⌨️ paused, the function-key route stands down", fkey(100) == false)
    _G.hsPaused = false

    -- 🚪 the shape door: a caller that rebuilds mp.media must not be able
    -- to kill ⏯ silently, because a throw in a tap callback is a silence.
    mp.media = { taken = 0, passed = 0, last = nil }   -- the old shape
    mp.resetMedia()
    check("🚪 mp.resetMedia is the one door and it builds every field",
          mp.media.viaMedia == 0 and mp.media.viaFnKey == 0
          and mp.media.fnSeen == 0 and mp.media.taken == 0)
    -- 🚨 AND THIS CHECK WAS MEASURING THE WRONG GUARD. It asked only
    -- whether the call threw — which the outer pcall added above makes
    -- true whether or not the `or 0` defences exist, so the mutation
    -- stripping them SURVIVED. What the defences actually buy is that
    -- the key still WORKS over a half-built table instead of silently
    -- doing nothing, so that is what is asserted.
    mp.queue = held
    if not mp.playing then mp.togglePlay() end
    mp.media = { taken = 0, passed = 0 }               -- a hand-built table
    local wasPlaying = mp.playing
    check("🚪 …and over a hand-built table the key still ACTS, rather than"
          .. " dying quietly inside the callback",
          fkey(100) == true and mp.playing ~= wasPlaying)

    -- the report NAMES the route, or none of this is askable
    mp.resetMedia()
    mp.queue = held
    fkey(100)
    local rep = _G.musicReport()
    check("🔎 the report counts the routes apart",
          rep:find("by route", 1, true) ~= nil
          and rep:find("as a plain F7/F8/F9", 1, true) ~= nil, rep)
    check("🔎 …and SAYS the setting when the plain route is the live one",
          rep:find("standard", 1, true) ~= nil)

    -- 🚨 THE TWO GUARDS hs-lint CAUGHT, each with its own check. Both
    -- are rules this project already owned and the first draft of this
    -- release paid neither — and a keyDown tap is the one place they
    -- matter most, because it sees every keystroke on the Mac.
    mp.resetMedia()
    _G.typingInjection = function() return true end
    check("🔁 a SYNTHETIC key is not a press (6.218.0) — our own retypes"
          .. " must not drive the player",
          fkey(100) == false and mp.media.fnSeen == 0)
    _G.typingInjection = nil
    check("…and a real key still is, with the guard back down",
          fkey(100) == true)

    -- 6.235.0: a throw in a tap callback is a silence, so the body is
    -- pcall'd and the throw is COUNTED.
    -- 🚨 AND THE FIRST VERSION OF THIS CHECK PROVED NOTHING: it made
    -- getKeyCode raise, which is INSIDE the body's own inner pcall
    -- around the three reads — so the body never threw and the outer
    -- guard was never exercised. 6.235.0's own words: the check that
    -- earns its place makes something throw that is NOT already guarded
    -- on its own. mp.fnKeyVerdict is that line.
    mp.resetMedia()
    local realVerdict = mp.fnKeyVerdict
    mp.fnKeyVerdict = function() error("the verdict blew up", 0) end
    local threw = fkey(100)
    mp.fnKeyVerdict = realVerdict
    check("🔒 a throw inside the handler does not escape the callback",
          threw == false)
    check("…and it is COUNTED, never swallowed",
          mp.media.threw == 1 and mp.media.lastThrow ~= nil, mp.media.threw)
    check("…and the report's ⚠️ outranks the counts above it",
          _G.musicReport():find("THREW inside the handler", 1, true) ~= nil)
    mp.resetMedia()

    check("the 6.291.0 block ran every one of its checks",
          (pass + fail) - n == 35, (pass + fail) - n)
end

if fail > 0 then
    out("FAILURES:\n")
    for _, f in ipairs(failures) do out("   ❌ " .. f .. "\n") end
end
out(("\n%d passed, %d failed\n\n"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
